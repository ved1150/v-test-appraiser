import { fabric } from "fabric";
import { cloneDeep } from "lodash";
import { FindNewCoordinates } from "../View3DFloorPlan/UtilityThreejs";
export function convertJSON(
  roomArrayRef,
  minX,
  minY,
  ratio,
  zoomFactor = 200,
  floorIndexForJson,
  floorNameForJson,
  wallThickness
) {
  let JSONOBJ = {
    EAGLEVIEW_EXPORT: {
      LOCATION: {
        "@address": "",
        "@city": "",
        "@lat": "",
        "@long": "",
        "@postal": "",
        "@state": "",
      },
      METADATA: {
        "@appversion": "",
        "@buildversion": "",
        "@createdby": "",
        "@createddate": "",
        "@device": "",
        "@devicetype": "",
        "@jobOrderId": "",
        "@lastmodifieddatemobile": "",
        "@latitude": "",
        "@longitude": "",
        "@osversion": "",
        "@timezone": "",
        "@updatedby": "",
        "@updatedon": "",
      },
      REPORT: {
        "@claimId": "",
        "@reportId": "",
      },
      STRUCTURES: {
        "@exteriorWallThickness": wallThickness,
        "@interiorWallThickness": wallThickness / 2,
        "@northorientation": "",
        zoomFactor: zoomFactor.toString(),
        ROOF: {
          FACES: {
            FACE: [],
          },
          LINES: {
            LINE: [],
          },
          POINTS: {
            POINT: [],
          },
          "@id": "roof1",
        },
      },
      VERSION: {
        "@coplanarity": "",
        "@dormers": "",
        "@precision": "",
        "@precisionUnits": "",
        "@sourceVersion": "",
        "@targetVersion": "",
        "@triangulation": "",
      },
    },
  };

  let roofPoints = [],
    linesArray = [];
  let faceArray = [];

  let PIXEL_TO_FOOT_CONSTANT = 0.035;
  let zoomlevel = zoomFactor;
  let metertofeet = 3.28084;
  let pixeltometer = 1 / zoomlevel;
  let pixeltofeet = pixeltometer * metertofeet;
  PIXEL_TO_FOOT_CONSTANT = pixeltofeet;
  roomArrayRef.forEach((fdata) => {
    let cid = getMaxId(roofPoints, "C") + 1;
    let lid = getMaxId(linesArray, "L") + 1;
    let wallid = getMaxId(faceArray, "WALL") + 1;
    let roomid = getMaxId(faceArray, "ROOM") + 1;
    let c1id = cid++;
    let lineData = [],
      doorData = [],
      windowData = [],
      textDataArray = [],
      partitionDataArray = [],
      partitionDoorDataArray = [],
      partitionWindowDataArray = [],
      childStairCaseDataArray = [];
    fdata.data.forEach((element, index) => {
      lineData.push(element.points[0]);
      doorData.push({ id: index, data: element.doorData });
      windowData.push({ id: index, data: element.windowData });
      textDataArray = [...textDataArray, ...element.textData];
      partitionDataArray.push({ id: index, data: element.partitionData });
      partitionDoorDataArray.push({
        id: index,
        data: element.partitionDoorData,
      });
      partitionWindowDataArray.push({
        id: index,
        data: element.partitionWindowData,
      });
      childStairCaseDataArray = [
        ...childStairCaseDataArray,
        ...element.childStairCaseData,
      ];
    });
    let lineArrayFab = lineData;
    let COARRAY = [],
      LINEARRAY = [],
      cdata = [],
      cordinateArray = [];
    lineArrayFab.forEach((e, i) => {
      let d;
      if (i < lineArrayFab.length - 1) {
        d = Math.sqrt(
          Math.pow(lineArrayFab[i + 1].dx - lineArrayFab[i].dx, 2) +
            Math.pow(lineArrayFab[i + 1].dy - lineArrayFab[i].dy, 2) +
            Math.pow(lineArrayFab[i + 1].dz - lineArrayFab[i].dz, 2)
        ).toFixed(2);
        cdata.push({ x: lineArrayFab[i].x, y: lineArrayFab[i].y, d: d });
      } else {
        d = Math.sqrt(
          Math.abs(
            Math.pow(lineArrayFab[0].dx - lineArrayFab[i].dx, 2) +
              Math.pow(lineArrayFab[0].dy - lineArrayFab[i].dy, 2) +
              Math.pow(lineArrayFab[0].dz - lineArrayFab[i].dz, 2)
          )
        ).toFixed(2);
        cdata.push({ x: lineArrayFab[i].x, y: lineArrayFab[i].y, d: d });
      }
    });
    cdata.forEach((e, i) => {
      let cdata1 = {
        "@id": "C" + c1id,
        "@data": "0,0",
        "@dataXY": e.x + "," + e.y,
        "@editedXY": e.x + "," + e.y,
        "@autoSnappedXY": e.x + "," + e.y,
        "@isFrom3D": true,
      };
      c1id = cid++;
      COARRAY.push(cdata1);
    });

    COARRAY.forEach((element, i) => {
      if (i > 0) {
        let ldata = {
          "@id": "L" + lid++,
          "@path": COARRAY[i - 1]["@id"] + "," + COARRAY[i]["@id"],
          "@type": "TOPWALL",
        };
        LINEARRAY.push(ldata);
        let x1 =
          (parseFloat(COARRAY[i - 1]["@dataXY"].split(",")[0]) - minX) * ratio;
        let y1 =
          (parseFloat(COARRAY[i - 1]["@dataXY"].split(",")[1]) - minY) * ratio;
        let x2 =
          (parseFloat(COARRAY[i]["@dataXY"].split(",")[0]) - minX) * ratio;
        let y2 =
          (parseFloat(COARRAY[i]["@dataXY"].split(",")[1]) - minY) * ratio;
        cordinateArray.push(x1);
        cordinateArray.push(y1);
        cordinateArray.push(x2);
        cordinateArray.push(y2);
      }
      if (i == COARRAY.length - 1) {
        let ldata = {
          "@id": "L" + lid++,
          "@path": COARRAY[i]["@id"] + "," + COARRAY[0]["@id"],
          "@type": "TOPWALL",
        };
        LINEARRAY.push(ldata);

        let x1 =
          (parseFloat(COARRAY[i]["@dataXY"].split(",")[0]) - minX) * ratio;
        let y1 =
          (parseFloat(COARRAY[i]["@dataXY"].split(",")[1]) - minY) * ratio;
        let x2 =
          (parseFloat(COARRAY[0]["@dataXY"].split(",")[0]) - minX) * ratio;
        let y2 =
          (parseFloat(COARRAY[0]["@dataXY"].split(",")[1]) - minY) * ratio;
        cordinateArray.push(x1);
        cordinateArray.push(y1);
        cordinateArray.push(x2);
        cordinateArray.push(y2);
      }
    });

    roofPoints = roofPoints.concat(COARRAY);
    linesArray = linesArray.concat(LINEARRAY);
    let wallidarry = [];
    LINEARRAY.forEach((element, i) => {
      let x1 = (lineArrayFab[i].x - minX) * ratio;
      let y1 = (lineArrayFab[i].y - minY) * ratio;
      let x2 = 0;
      let y2 = 0;
      let d;
      if (i < lineArrayFab.length - 1) {
        x2 = (lineArrayFab[i + 1].x - minX) * ratio;
        y2 = (lineArrayFab[i + 1].y - minY) * ratio;
        d = cdata[i].d;
      } else {
        d = cdata[i].d;
        x2 = (lineArrayFab[0].x - minX) * ratio;
        y2 = (lineArrayFab[0].y - minY) * ratio;
      }
      const line = new fabric.Line([x1, y1, x2, y2], {});
      let width1 =
        Math.sqrt(line.width * line.width + line.height * line.height) *
        PIXEL_TO_FOOT_CONSTANT;

      width1 /= ratio;

      let tempFoot = parseInt(width1);
      let tempPoints = width1 - tempFoot;
      let inch = (tempPoints * 100 * 12) / 100;
      inch = parseInt(inch);
      let unroundedSize = tempFoot + "." + inch;
      let doorD = doorData.filter((elm) => elm.id == i);
      let windowD = windowData.filter((elm) => elm.id == i);
      let doorwinData = addDoorWindow(
        doorD,
        windowD,
        roofPoints,
        linesArray,
        faceArray
      );
      roofPoints = doorwinData.roofPoints;
      linesArray = doorwinData.linesArray;
      faceArray = doorwinData.faceArray;

      let facedata = {
        "@floorindex": "",
        "@floor": "",
        "@areaname": "",
        "@measuretype": "",
        "@additionalType": "",
        "@type": "WALL",
        "@area": "",
        "@editedArea": "",
        "@designator": "",
        POLYGON: {
          "@orientation": "",
          "@pitch": "",
          "@unroundedsize": unroundedSize.toString(),
          "@path": element["@id"],
          "@editedUnroundedsize": unroundedSize.toString(),
          "@size": Math.ceil(parseFloat(unroundedSize)).toString(),
          "@editedSize": Math.ceil(parseFloat(unroundedSize)).toString(),
          "@id": "",
        },
        "@children": doorwinData.doorWindowids,
        "@id": "WALL" + wallid,
        "@mode": "WALL",
        "@isFrom3D": true,
      };

      wallidarry.push("WALL" + wallid);
      faceArray.push(facedata);
      wallid++;
    });
    let areaSum = 0;
    for (
      var i = 0, cordinateArrayIndex = cordinateArray.length - 2;
      i < cordinateArrayIndex;
      i += 2
    ) {
      areaSum +=
        cordinateArray[i] * cordinateArray[i + 3] -
        cordinateArray[i + 2] * cordinateArray[i + 1];
    }

    let calculatedArea =
      (Math.abs(areaSum / 2) *
        PIXEL_TO_FOOT_CONSTANT *
        PIXEL_TO_FOOT_CONSTANT) /
      (ratio * ratio);

    let textData = addLabel(textDataArray, roofPoints, linesArray, faceArray);
    roofPoints = textData.roofPoints;
    linesArray = textData.linesArray;
    faceArray = textData.faceArray;

    let stairCaseData = addStairCase(
      childStairCaseDataArray,
      roofPoints,
      linesArray,
      faceArray,
      ratio,
      minX,
      minY
    );
    roofPoints = stairCaseData.roofPoints;
    linesArray = stairCaseData.linesArray;
    faceArray = stairCaseData.faceArray;

    let filteredPartitionDataArray = partitionDataArray.filter(
      (elm) => elm?.data?.length !== 0
    );
    let partitionData = addPartitionWall(
      filteredPartitionDataArray,
      roofPoints,
      linesArray,
      faceArray
    );
    roofPoints = partitionData.roofPoints;
    linesArray = partitionData.linesArray;
    faceArray = partitionData.faceArray;

    let filteredPartitionDoorDataArray = partitionDoorDataArray.filter(
      (elm) => elm?.data?.length !== 0
    );
    let partitionDoorData = addPartitionDoor(
      filteredPartitionDoorDataArray,
      roofPoints,
      linesArray,
      faceArray
    );
    roofPoints = partitionDoorData.roofPoints;
    linesArray = partitionDoorData.linesArray;
    faceArray = partitionDoorData.faceArray;

    let filteredPartitionWindowDataArray = partitionWindowDataArray.filter(
      (elm) => elm?.data?.length !== 0
    );
    let partitionWindowData = addPartitionWindow(
      filteredPartitionWindowDataArray,
      roofPoints,
      linesArray,
      faceArray
    );
    roofPoints = partitionWindowData.roofPoints;
    linesArray = partitionWindowData.linesArray;
    faceArray = partitionWindowData.faceArray;

    faceArray.push({
      "@area": calculatedArea.toString(),
      "@areaname": fdata.roomname,
      "@childrenLabel": textData.labelids,
      "@childrenLine": partitionData.lineids,
      "@partitionDoor": partitionDoorData.lineids,
      "@partitionWindow": partitionWindowData.lineids,
      "@children": wallidarry.join(","),
      "@childrenStairCase": stairCaseData.staircaseids,
      "@designator": "DES1",
      "@editedArea": calculatedArea.toString(),
      "@floor": floorNameForJson,
      "@floorindex": floorIndexForJson,
      "@height": "",
      "@id": "ROOM" + roomid,
      "@measuretype": fdata.areatype,
      "@additionalType": fdata.additionaltype,
      "@mode": "",
      POLYGON: {
        "@editedSize": "",
        "@editedUnroundedsize": "",
        "@id": "ROOM" + roomid,
        "@orientation": "",
        "@path": "",
        "@pitch": "",
        "@size": "",
        "@unroundedsize": "",
      },
      "@text": "",
      "@type": "ROOM",
      "@isFrom3D": true,
    });
    roomid++;
  });
  JSONOBJ.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = faceArray;
  JSONOBJ.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE = linesArray;
  JSONOBJ.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
  return acceptAutoDegreeAll(
    acceptAutoDegreeAll(JSONOBJ, minX, minY, ratio),
    minX,
    minY,
    ratio
  );
}

function addDoorWindow(door, window, roofPoints, linesArray, faceArray) {
  let cid = getMaxId(roofPoints, "C") + 1;
  let lid = getMaxId(linesArray, "L") + 1;
  let DataArray = [],
    doorWindowids = [];

  door[0].data.forEach((element) => {
    DataArray.push({ element, type: "door" });
  });
  window[0].data.forEach((element) => {
    DataArray.push({ element, type: "window" });
  });
  for (let i = 0; i < DataArray.length; i += 2) {
    let doorId = getMaxId(faceArray, "DOOR") + 1;
    let windowId = getMaxId(faceArray, "WINDOW") + 1;
    let lineStart = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY": DataArray[i].element.x + "," + DataArray[i].element.y,
      "@editedXY": DataArray[i].element.x + "," + DataArray[i].element.y,
      "@autoSnappedXY": DataArray[i].element.x + "," + DataArray[i].element.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineStart);
    let lineEnd = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY": DataArray[i + 1].element.x + "," + DataArray[i + 1].element.y,
      "@editedXY":
        DataArray[i + 1].element.x + "," + DataArray[i + 1].element.y,
      "@autoSnappedXY":
        DataArray[i + 1].element.x + "," + DataArray[i + 1].element.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineEnd);
    let ldata = {
      "@id": "L" + lid++,
      "@path": lineStart["@id"] + "," + lineEnd["@id"],
      "@type": "TOPWALL",
    };
    linesArray.push(ldata);
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@additionalType": "",
      "@type": "WALLPENETRATION",
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": ldata["@id"],
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@id":
        DataArray[i].type == "door" ? "DOOR" + doorId : "WINDOW" + windowId,
      "@mode": DataArray[i].type == "door" ? "DOOR" : "WINDOW",
      "@isFrom3D": true,
    };
    if (DataArray[i].type == "door") {
      facedata["@doorDirection"] = DataArray[i].element.doorDirection;
    }
    faceArray.push(facedata);
    doorWindowids.push(
      DataArray[i].type == "door" ? "DOOR" + doorId : "WINDOW" + windowId
    );
  }
  return {
    roofPoints,
    linesArray,
    faceArray,
    doorWindowids: doorWindowids.join(","),
  };
}
function addLabel(textArray, roofPoints, linesArray, faceArray) {
  let cid = getMaxId(roofPoints, "C") + 1;
  let lid = getMaxId(linesArray, "L") + 1;
  let labelid = getMaxId(faceArray, "LABEL") + 1;
  let labelids = [];
  for (let i = 0; i < textArray.length; i++) {
    let lineStart = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY": textArray[i].points.x + "," + textArray[i].points.y,
      "@editedXY": textArray[i].points.x + "," + textArray[i].points.y,
      "@autoSnappedXY": textArray[i].points.x + "," + textArray[i].points.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineStart);
    let ldata = {
      "@id": "L" + lid++,
      "@path": lineStart["@id"],
      "@type": "LABEL",
    };
    linesArray.push(ldata);
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@type": "LABEL",
      "@text": textArray[i].text,
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": ldata["@id"],
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@id": "LABEL" + labelid,
      "@mode": "LABEL",
      "@isFrom3D": true,
    };
    faceArray.push(facedata);
    labelids.push("LABEL" + labelid);
    labelid++;
  }
  return {
    roofPoints,
    linesArray,
    faceArray,
    labelids: labelids.join(","),
  };
}

function addStairCase(
  childStairCaseDataArray,
  roofPoints,
  linesArray,
  faceArray,
  ratio,
  minX,
  minY
) {
  let cid = getMaxId(roofPoints, "C") + 1;
  let lid = getMaxId(linesArray, "L") + 1;
  let staircaseid = getMaxId(faceArray, "STAIR_CASE") + 1;
  let staircaseids = [];
  for (let i = 0; i < childStairCaseDataArray.length; i++) {
    let lineStart = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY":
        childStairCaseDataArray[i].x + "," + childStairCaseDataArray[i].y,
      "@editedXY":
        childStairCaseDataArray[i].x + "," + childStairCaseDataArray[i].y,
      "@autoSnappedXY":
        childStairCaseDataArray[i].x + "," + childStairCaseDataArray[i].y,
      "@scaleX": (parseFloat(childStairCaseDataArray[i].scaleX) || 1) / ratio,
      "@scaleY": (parseFloat(childStairCaseDataArray[i].scaleY) || 1) / ratio,
      "@isFrom3D": true,
    };
    roofPoints.push(lineStart);
    let ldata = {
      "@id": "L" + lid++,
      "@path": lineStart["@id"],
      "@type": "STAIR_CASE",
    };
    linesArray.push(ldata);
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@type": "STAIR_CASE",
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": ldata["@id"],
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@id": "STAIR_CASE" + staircaseid,
      "@mode": "STAIR_CASE",
      "@isFrom3D": true,
    };
    faceArray.push(facedata);
    staircaseids.push("STAIR_CASE" + staircaseid);
    staircaseid++;
  }
  return {
    roofPoints,
    linesArray,
    faceArray,
    staircaseids: staircaseids.join(","),
  };
}

function addPartitionWall(partitionArray, roofPoints, linesArray, faceArray) {
  let cid = getMaxId(roofPoints, "C") + 1;
  let lid = getMaxId(linesArray, "L") + 1;
  let lineid = getMaxId(faceArray, "LINE") + 1;
  let lineids = [];
  let DataArray = [];
  partitionArray?.[0]?.data.forEach((element) => {
    DataArray.push({ element, type: "partitionWall" });
  });
  for (let i = 0; i < DataArray.length; i += 2) {
    // prepare points data
    let lineStart = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY":
        DataArray[i].element.points.x + "," + DataArray[i].element.points.y,
      "@editedXY":
        DataArray[i].element.points.x + "," + DataArray[i].element.points.y,
      "@autoSnappedXY":
        DataArray[i].element.points.x + "," + DataArray[i].element.points.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineStart);
    let lineEnd = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY":
        DataArray[i + 1].element.points.x +
        "," +
        DataArray[i + 1].element.points.y,
      "@editedXY":
        DataArray[i + 1].element.points.x +
        "," +
        DataArray[i + 1].element.points.y,
      "@autoSnappedXY":
        DataArray[i + 1].element.points.x +
        "," +
        DataArray[i + 1].element.points.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineEnd);
    let ldata = {
      "@id": "L" + lid++,
      "@path": lineStart["@id"] + "," + lineEnd["@id"],
      "@type": "LINE",
    };
    linesArray.push(ldata);
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@type": ldata["@type"],
      "@text": "",
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": ldata["@id"],
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@windowId": DataArray[i].element.childWindowId,
      "@id": ldata["@type"] + lineid,
      "@mode": ldata["@type"],
      "@isFrom3D": true,
    };
    faceArray.push(facedata);
    lineids.push(ldata["@type"] + lineid);
    lineid++;
  }
  return {
    roofPoints,
    linesArray,
    faceArray,
    lineids: lineids.join(","),
  };
}

function addPartitionDoor(
  partitionDoorArray,
  roofPoints,
  linesArray,
  faceArray
) {
  let cid = getMaxId(roofPoints, "C") + 1;
  let lid = getMaxId(linesArray, "L") + 1;
  let lineid = getMaxId(faceArray, "PARTITION_DOOR") + 1;
  let lineids = [];
  let DataArray = [];
  partitionDoorArray?.[0]?.data.forEach((element) => {
    DataArray.push({ element, type: "partitionDoor" });
  });
  for (let i = 0; i < DataArray.length; i += 2) {
    // prepare points data
    let lineStart = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY": DataArray[i].element.x + "," + DataArray[i].element.y,
      "@editedXY": DataArray[i].element.x + "," + DataArray[i].element.y,
      "@autoSnappedXY": DataArray[i].element.x + "," + DataArray[i].element.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineStart);
    let lineEnd = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY": DataArray[i + 1].element.x + "," + DataArray[i + 1].element.y,
      "@editedXY":
        DataArray[i + 1].element.x + "," + DataArray[i + 1].element.y,
      "@autoSnappedXY":
        DataArray[i + 1].element.x + "," + DataArray[i + 1].element.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineEnd);
    let parentPartitionPoint = getParentPartitionPoint(
      roofPoints,
      linesArray,
      faceArray,
      `${DataArray[i].element.x},${DataArray[i].element.y}`,
      `${DataArray[i + 1].element.x},${DataArray[i + 1].element.y}`,
      cid
    );
    let ldata = {
      "@id": "L" + lid++,
      "@path": lineStart["@id"] + "," + lineEnd["@id"],
      "@type": "PARTITION_DOOR",
    };
    linesArray.push(ldata);
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@type": ldata["@type"],
      "@text": "",
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": ldata["@id"],
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@id": ldata["@type"] + lineid,
      "@mode": ldata["@type"],
      "@parentPartition": parentPartitionPoint,
      "@isFrom3D": true,
    };
    if (DataArray[i].type == "door" || DataArray[i].type == "partitionDoor") {
      facedata["@doorDirection"] = DataArray[i].element.doorDirection;
    }
    faceArray.push(facedata);
    lineids.push(ldata["@type"] + lineid);
    lineid++;
  }
  return {
    roofPoints,
    linesArray,
    faceArray,
    lineids: lineids.join(","),
  };
}

function addPartitionWindow(
  partitionWindowArray,
  roofPoints,
  linesArray,
  faceArray
) {
  let cid = getMaxId(roofPoints, "C") + 1;
  let lid = getMaxId(linesArray, "L") + 1;
  let lineid = getMaxId(faceArray, "PARTITION_WINDOW") + 1;
  let lineids = [];
  let DataArray = [];
  partitionWindowArray?.[0]?.data.forEach((element) => {
    DataArray.push({ element, type: "partitionWindow" });
  });
  for (let i = 0; i < DataArray.length; i += 2) {
    // prepare points data
    let lineStart = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY":
        DataArray[i].element.points.x + "," + DataArray[i].element.points.y,
      "@editedXY":
        DataArray[i].element.points.x + "," + DataArray[i].element.points.y,
      "@autoSnappedXY":
        DataArray[i].element.points.x + "," + DataArray[i].element.points.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineStart);
    let lineEnd = {
      "@id": "C" + cid++,
      "@data": "0,0",
      "@dataXY":
        DataArray[i + 1].element.points.x +
        "," +
        DataArray[i + 1].element.points.y,
      "@editedXY":
        DataArray[i + 1].element.points.x +
        "," +
        DataArray[i + 1].element.points.y,
      "@autoSnappedXY":
        DataArray[i + 1].element.points.x +
        "," +
        DataArray[i + 1].element.points.y,
      "@isFrom3D": true,
    };
    roofPoints.push(lineEnd);
    let ldata = {
      "@id": "L" + lid++,
      "@path": lineStart["@id"] + "," + lineEnd["@id"],
      "@type": "PARTITION_WINDOW",
    };
    linesArray.push(ldata);
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@type": ldata["@type"],
      "@text": "",
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": ldata["@id"],
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@id": ldata["@type"] + lineid,
      "@mode": ldata["@type"],
      "@parentPartition": getWindowParentPartitionPoint(
        faceArray,
        DataArray[i].element.partitionId
      ),
      "@isFrom3D": true,
    };
    faceArray.push(facedata);
    lineids.push(ldata["@type"] + lineid);
    lineid++;
  }
  return {
    roofPoints,
    linesArray,
    faceArray,
    lineids: lineids.join(","),
  };
}

function getMaxId(array, prefix) {
  let MatchArray = array
    .filter((el) => el["@id"].startsWith(prefix))
    .map((el) => {
      return parseInt(el["@id"].replace(prefix, ""));
    });
  return MatchArray.length > 0 ? Math.max(...MatchArray) : 0;
}

export function getParentPartitionPoint(
  roofPoints,
  linesArray,
  faceArray,
  startPoint,
  endPoint,
  currentCoord
) {
  let matchArray = [];
  faceArray?.forEach((faceArrayEl) => {
    if (faceArrayEl["@type"] === "LINE") {
      linesArray?.forEach((lineArrayEl) => {
        if (lineArrayEl["@id"] === faceArrayEl.POLYGON["@path"]) {
          roofPoints?.forEach((roofPointsEl) => {
            if (
              (lineArrayEl["@path"].split(",")[0] === roofPointsEl["@id"] ||
                lineArrayEl["@path"].split(",")[1] === roofPointsEl["@id"]) &&
              (roofPointsEl["@editedXY"] === startPoint ||
                roofPointsEl["@editedXY"] === endPoint)
            ) {
              if (lineArrayEl["@path"].split(",")[0] === roofPointsEl["@id"]) {
                matchArray.push({
                  partitionCoord: roofPointsEl["@id"],
                  partitionDoorCoord:
                    roofPointsEl["@editedXY"] === startPoint
                      ? currentCoord - 2
                      : currentCoord - 1,
                  line: faceArrayEl["@id"],
                });
              } else if (
                lineArrayEl["@path"].split(",")[1] === roofPointsEl["@id"]
              ) {
                matchArray.push({
                  partitionCoord: roofPointsEl["@id"],
                  partitionDoorCoord:
                    roofPointsEl["@editedXY"] === startPoint
                      ? currentCoord - 2
                      : currentCoord - 1,
                  line: faceArrayEl["@id"],
                });
              }
            }
          });
        }
      });
    }
  });
  return matchArray;
}

function acceptAutoDegreeAll(originalFloorPlan, minX, minY, ratio) {
  let copyOriginal = cloneDeep(originalFloorPlan);
  let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
  let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
  let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
  let designatorWiseObjectArray = {};
  for (
    let faceArrayIndex = 0;
    faceArrayIndex < facesArray.length;
    faceArrayIndex++
  ) {
    let roomFaceObject = facesArray[faceArrayIndex];

    if (
      designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
      roomFaceObject["@type"] == "ROOM"
    ) {
      //Get walls of room

      let roomChildrenArray = [];
      designatorWiseObjectArray[roomFaceObject["@id"]] = [];

      designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

      let children = roomFaceObject["@children"];
      roomChildrenArray = children.split(",");

      let childrenLine = roomFaceObject["@childrenLine"];
      for (let i = 0; i < childrenLine.split(",").length; i++)
        roomChildrenArray.push(childrenLine.split(",")[i]);

      let partitionDoor = roomFaceObject["@partitionDoor"];
      for (let i = 0; i < partitionDoor.split(",").length; i++)
        roomChildrenArray.push(partitionDoor.split(",")[i]);

      let partitionWindow = roomFaceObject["@partitionWindow"];
      for (let i = 0; i < partitionWindow.split(",").length; i++)
        roomChildrenArray.push(partitionWindow.split(",")[i]);
      //Not iterate room child...

      for (
        let roomChildrenIndex = 0;
        roomChildrenIndex < roomChildrenArray.length;
        roomChildrenIndex++
      ) {
        let roomId = roomChildrenArray[roomChildrenIndex];
        //Loop to iterate face object again. Later we'll manage processed ids

        for (
          let wallFaceObjectIndex = 0;
          wallFaceObjectIndex < facesArray.length;
          wallFaceObjectIndex++
        ) {
          let faceObject = facesArray[wallFaceObjectIndex];

          if (
            faceObject["POLYGON"]["@path"].trim().length > 0 &&
            roomId == faceObject["@id"]
          ) {
            let lineId = faceObject["POLYGON"]["@path"];

            //Find Line
            for (
              let lineArrayIndex = 0;
              lineArrayIndex < rooflines.length;
              lineArrayIndex++
            ) {
              let lineObject = rooflines[lineArrayIndex];
              if (lineObject["@id"] == lineId) {
                var linePointObjectArray = [];
                let linePoints = lineObject["@path"].split(",");
                for (
                  let linePointsIndex = 0;
                  linePointsIndex < linePoints.length;
                  linePointsIndex++
                ) {
                  for (
                    let roofPointsArrayIndex = 0;
                    roofPointsArrayIndex < roofPoints.length;
                    roofPointsArrayIndex++
                  ) {
                    let roofPointObject = roofPoints[roofPointsArrayIndex];
                    if (roofPointObject["@id"] == linePoints[linePointsIndex]) {
                      linePointObjectArray.push(roofPointObject);

                      break;
                    }
                  }
                }

                lineObject["linePointObjectArray"] = linePointObjectArray;
                rooflines[lineArrayIndex] = lineObject;

                faceObject["LINE"] = lineObject;
                facesArray[wallFaceObjectIndex] = faceObject;
              }
            }

            designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
          }
        }
      }
    } else {
      //TBD. NOT IN USE.
    }
  }
  let roomArray = Object.keys(designatorWiseObjectArray);
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < roomArray.length;
    roomArrayIndex++
  ) {
    let roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];
    let windowsArray = roomObjectArray.filter(
      (el) => el["@type"] == "PARTITION_WINDOW"
    );
    for (let i = 0; i < windowsArray.length; i++) {
      let parentPartition = windowsArray[i]["@parentPartition"];
      let line = roomObjectArray.filter((el) => el["@id"] == parentPartition);
      let pointobjeArray = line[0].LINE.linePointObjectArray;
      let linePointXYstart = pointobjeArray[0]["@editedXY"].split(",");
      let linePointXYend = pointobjeArray[1]["@editedXY"].split(",");

      windowsArray[i].LINE[
        "@beforeautosnappedstartXY"
      ] = `${linePointXYstart[0]},${linePointXYstart[1]}`;
      windowsArray[i].LINE[
        "@beforeautosnappedendXY"
      ] = `${linePointXYend[0]},${linePointXYend[1]}`;
    }
    for (
      let roomObjectArrayIndex = 0;
      roomObjectArrayIndex < roomObjectArray.length;
      roomObjectArrayIndex++
    ) {
      const roomObjectArrayClone = JSON.parse(JSON.stringify(roomObjectArray));
      const roofPointsClone = JSON.parse(JSON.stringify(roofPoints));
      let isfallinline = true;
      let wallObject = roomObjectArray[roomObjectArrayIndex];
      if (wallObject["@type"] != "ROOM" && wallObject["@type"] != "LABEL") {
        let linePointObjectArray = wallObject.LINE.linePointObjectArray;
        let point0x =
          (parseFloat(linePointObjectArray[0]["@autoSnappedXY"].split(",")[0]) -
            minX) *
          ratio;
        let point0y =
          (parseFloat(linePointObjectArray[0]["@autoSnappedXY"].split(",")[1]) -
            minY) *
          ratio;
        let point1x =
          (parseFloat(linePointObjectArray[1]["@autoSnappedXY"].split(",")[0]) -
            minX) *
          ratio;
        let point1y =
          (parseFloat(linePointObjectArray[1]["@autoSnappedXY"].split(",")[1]) -
            minY) *
          ratio;
        let angleDegl =
          (Math.atan2(point0y - point1y, point0x - point1x) * 180) / Math.PI;
        let connecteddata = [];
        if (angleDegl % 45 != 0) {
          let rad = 0;
          angleDegl = getAcurateAngle(angleDegl);
          rad = fabric.util.degreesToRadians(angleDegl);
          const diff = Math.sqrt(
            Math.pow(point1x - point0x, 2) + Math.pow(point1y - point0y, 2)
          );
          const updatedX = point0x - diff * Math.cos(rad);
          const updatedY = point0y - diff * Math.sin(rad);
          let x = updatedX / ratio + minX;
          let y = updatedY / ratio + minY;
          if (wallObject["@type"] == "LINE") {
            linePointObjectArray[1]["@autoSnappedXY"] = x + "," + y;
            linePointObjectArray[1]["@editedXY"] = x + "," + y;
          } else if (wallObject["@type"] == "PARTITION_WINDOW") {
            //window start and end points
            let windowstartXY = linePointObjectArray[0]["@editedXY"].split(",");
            let windowendXY = linePointObjectArray[1]["@editedXY"].split(",");

            let currentPointStartXYArray =
              wallObject.LINE["@beforeautosnappedstartXY"].split(",");
            let currentPointEndXYArray =
              wallObject.LINE["@beforeautosnappedendXY"].split(",");

            let parentLineID = wallObject["@parentPartition"];
            let newLineAutoSnapPoints = designatorWiseObjectArray[
              roomArray[roomArrayIndex]
            ].filter((el) => el["@id"] == parentLineID)[0].LINE
              .linePointObjectArray;

            let newlineEndPointXY =
              newLineAutoSnapPoints[1]["@autoSnappedXY"].split(",");
            let NewLineEndXY = [newlineEndPointXY[0], newlineEndPointXY[1]];
            let newWindowStartXY = FindNewCoordinates(
              [
                parseFloat(currentPointStartXYArray[0]),
                parseFloat(currentPointStartXYArray[1]),
              ],
              {
                x: parseFloat(NewLineEndXY[0]),
                y: parseFloat(NewLineEndXY[1]),
              },
              [
                parseFloat(currentPointEndXYArray[0]),
                parseFloat(currentPointEndXYArray[1]),
              ],
              [parseFloat(windowstartXY[0]), parseFloat(windowstartXY[1])]
            );
            let newWindowEndXY = FindNewCoordinates(
              [
                parseFloat(currentPointStartXYArray[0]),
                parseFloat(currentPointStartXYArray[1]),
              ],
              {
                x: parseFloat(NewLineEndXY[0]),
                y: parseFloat(NewLineEndXY[1]),
              },
              [
                parseFloat(currentPointEndXYArray[0]),
                parseFloat(currentPointEndXYArray[1]),
              ],
              [parseFloat(windowendXY[0]), parseFloat(windowendXY[1])]
            );

            linePointObjectArray[0][
              "@autoSnappedXY"
            ] = `${newWindowStartXY.x},${newWindowStartXY.y}`;
            linePointObjectArray[0][
              "@editedXY"
            ] = `${newWindowStartXY.x},${newWindowStartXY.y}`;
            linePointObjectArray[1][
              "@autoSnappedXY"
            ] = `${newWindowEndXY.x},${newWindowEndXY.y}`;
            linePointObjectArray[1][
              "@editedXY"
            ] = `${newWindowEndXY.x},${newWindowEndXY.y}`;
          } else if (wallObject["@type"] == "PARTITION_DOOR") {
            let parentPartition = wallObject["@parentPartition"];
            //connected line coordinates
            let connectDoorLine1Coordinate =
              parentPartition[0]["partitionCoord"];
            let connectDoorLine2Coordinate =
              parentPartition[1]["partitionCoord"];
            let line1ID = parentPartition[0]["line"];
            let line2ID = parentPartition[1]["line"];
            let line1PointObjectArray = designatorWiseObjectArray[
              roomArray[roomArrayIndex]
            ].filter((el) => el["@id"] == line1ID)[0].LINE.linePointObjectArray;
            let connectDoorCoordinateLine1 = line1PointObjectArray.filter(
              (el) => el["@id"] == connectDoorLine1Coordinate
            );
            let xcordinateautosnaped =
              connectDoorCoordinateLine1[0]["@autoSnappedXY"].split(",")[0];
            let ycordinateautosnaped =
              connectDoorCoordinateLine1[0]["@autoSnappedXY"].split(",")[1];
            let xcordinateeditedxy =
              connectDoorCoordinateLine1[0]["@editedXY"].split(",")[0];
            let ycordinateeditedxy =
              connectDoorCoordinateLine1[0]["@editedXY"].split(",")[1];

            linePointObjectArray[0][
              "@autoSnappedXY"
            ] = `${xcordinateautosnaped},${ycordinateautosnaped}`;
            linePointObjectArray[0][
              "@editedXY"
            ] = `${xcordinateeditedxy},${ycordinateeditedxy}`;

            let line2PointObjectArray = designatorWiseObjectArray[
              roomArray[roomArrayIndex]
            ].filter((el) => el["@id"] == line2ID)[0].LINE.linePointObjectArray;

            let connectDoorCoordinateLine2 = line2PointObjectArray.filter(
              (el) => el["@id"] == connectDoorLine2Coordinate
            );
            let xcordinateautosnaped1 =
              connectDoorCoordinateLine2[0]["@autoSnappedXY"].split(",")[0];
            let ycordinateautosnaped1 =
              connectDoorCoordinateLine2[0]["@autoSnappedXY"].split(",")[1];
            let xcordinateeditedxy1 =
              connectDoorCoordinateLine2[0]["@editedXY"].split(",")[0];
            let ycordinateeditedxy1 =
              connectDoorCoordinateLine2[0]["@editedXY"].split(",")[1];

            linePointObjectArray[1][
              "@autoSnappedXY"
            ] = `${xcordinateautosnaped1},${ycordinateautosnaped1}`;
            linePointObjectArray[1][
              "@editedXY"
            ] = `${xcordinateeditedxy1},${ycordinateeditedxy1}`;
          } else linePointObjectArray[1]["@autoSnappedXY"] = x + "," + y;
          wallObject.LINE.linePointObjectArray = linePointObjectArray;
          const parantwall = facesArray.filter(
            (el) => el["@id"] == wallObject["@id"]
          );
          const childIdsline = facesArray.filter((el) =>
            parantwall[0]["@children"].split(",").includes(el["@id"])
          );
          for (
            let roomObjectArrayIndexcon = 0;
            roomObjectArrayIndexcon < roomObjectArray.length;
            roomObjectArrayIndexcon++
          ) {
            let wallObjectconnected = roomObjectArray[roomObjectArrayIndexcon];
            if (wallObjectconnected["@type"] != "ROOM") {
              let linePointObjectArrayconnected =
                wallObjectconnected.LINE.linePointObjectArray;
              for (
                let linePointObjectArrayInedex = 0;
                linePointObjectArrayInedex <
                linePointObjectArrayconnected.length;
                linePointObjectArrayInedex++
              ) {
                if (wallObjectconnected["@id"] != wallObject["@id"]) {
                  if (
                    wallObject.LINE["@path"].split(",")[1] ==
                    linePointObjectArrayconnected[linePointObjectArrayInedex][
                      "@id"
                    ]
                  ) {
                    linePointObjectArrayconnected[linePointObjectArrayInedex][
                      "@autoSnappedXY"
                    ] = x + "," + y;
                    wallObjectconnected.LINE.linePointObjectArray =
                      linePointObjectArrayconnected;
                    connecteddata.push({
                      wallID: wallObjectconnected["@id"],
                      data: linePointObjectArrayconnected,
                      basex: updatedX,
                      basey: updatedY,
                    });
                    connecteddata.forEach((element) => {
                      let basex, basey, nbasex, nbasey;
                      const parantwall = facesArray.filter(
                        (el) => el["@id"] == element.wallID
                      );
                      const childIdsline = facesArray.filter((el) =>
                        parantwall[0]["@children"]
                          .split(",")
                          .includes(el["@id"])
                      );
                      const x1 =
                        (parseFloat(
                          element.data[0]["@autoSnappedXY"].split(",")[0]
                        ) -
                          minX) *
                        ratio;
                      const y1 =
                        (parseFloat(
                          element.data[0]["@autoSnappedXY"].split(",")[1]
                        ) -
                          minY) *
                        ratio;
                      const x2 =
                        (parseFloat(
                          element.data[1]["@autoSnappedXY"].split(",")[0]
                        ) -
                          minX) *
                        ratio;
                      const y2 =
                        (parseFloat(
                          element.data[1]["@autoSnappedXY"].split(",")[1]
                        ) -
                          minY) *
                        ratio;
                      let angleDegl = 0,
                        rad = 0;
                      if (
                        x1.toFixed(2) == element.basex.toFixed(2) &&
                        y1.toFixed(2) == element.basey.toFixed(2)
                      ) {
                        basex = x2;
                        basey = y2;
                        nbasex = x1;
                        nbasey = y1;
                        angleDegl =
                          (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
                        rad = fabric.util.degreesToRadians(angleDegl);
                      } else {
                        basex = x1;
                        basey = y1;
                        nbasex = x2;
                        nbasey = y2;
                        angleDegl =
                          (Math.atan2(y1 - y2, x1 - x2) * 180) / Math.PI;
                        rad = fabric.util.degreesToRadians(angleDegl);
                      }
                      childIdsline.forEach((childObj) => {
                        for (
                          let lineindex = 0;
                          lineindex < rooflines.length;
                          lineindex++
                        ) {
                          if (
                            rooflines[lineindex]["@id"] ==
                            childObj.POLYGON["@path"]
                          ) {
                            for (
                              let roofPointsindex = 0;
                              roofPointsindex < roofPoints.length;
                              roofPointsindex++
                            ) {
                              if (
                                rooflines[lineindex]["@path"]
                                  .split(",")
                                  .includes(roofPoints[roofPointsindex]["@id"])
                              ) {
                                const childRoofPoints =
                                  roofPoints[roofPointsindex][
                                    "@autoSnappedXY"
                                  ].split(",");
                                let x =
                                  (parseFloat(childRoofPoints[0]) - minX) *
                                  ratio;
                                let y =
                                  parseFloat(childRoofPoints[1] - minY) * ratio;
                                const diff = Math.sqrt(
                                  Math.pow(x - basex, 2) +
                                    Math.pow(y - basey, 2)
                                );
                                const ndiff = Math.sqrt(
                                  Math.pow(x - nbasex, 2) +
                                    Math.pow(y - nbasey, 2)
                                );
                                const diffmain = Math.sqrt(
                                  Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)
                                );
                                if (diff > diffmain || ndiff > diffmain) {
                                  isfallinline = false;
                                }
                                const updatedX =
                                  (basex - diff * Math.cos(rad)) / ratio + minX;
                                const updatedY =
                                  (basey - diff * Math.sin(rad)) / ratio + minY;
                                roofPoints[roofPointsindex]["@autoSnappedXY"] =
                                  updatedX + "," + updatedY;
                              }
                            }
                          }
                        }
                      });
                    });

                    if (isfallinline) {
                      roomObjectArray[roomObjectArrayIndexcon] =
                        cloneDeep(wallObjectconnected);
                    } else {
                      roomObjectArray[roomObjectArrayIndexcon] = cloneDeep(
                        roomObjectArrayClone[roomObjectArrayIndexcon]
                      );
                      roofPoints = roofPointsClone;
                    }
                  }
                }
              }
            }
            //roomObjectArray[roomObjectArrayIndex] = wallObjectconnected;
          }
          if (isfallinline) {
            childIdsline.forEach((childObj) => {
              for (
                let lineindex = 0;
                lineindex < rooflines.length;
                lineindex++
              ) {
                if (rooflines[lineindex]["@id"] == childObj.POLYGON["@path"]) {
                  for (
                    let roofPointsindex = 0;
                    roofPointsindex < roofPoints.length;
                    roofPointsindex++
                  ) {
                    if (
                      rooflines[lineindex]["@path"]
                        .split(",")
                        .includes(roofPoints[roofPointsindex]["@id"])
                    ) {
                      const childRoofPoints =
                        roofPoints[roofPointsindex]["@autoSnappedXY"].split(
                          ","
                        );
                      let x = (parseFloat(childRoofPoints[0]) - minX) * ratio;
                      let y = parseFloat(childRoofPoints[1] - minY) * ratio;
                      const diff = Math.sqrt(
                        Math.pow(x - point0x, 2) + Math.pow(y - point0y, 2)
                      );
                      const updatedX =
                        (point0x - diff * Math.cos(rad)) / ratio + minX;
                      const updatedY =
                        (point0y - diff * Math.sin(rad)) / ratio + minY;
                      roofPoints[roofPointsindex]["@autoSnappedXY"] =
                        updatedX + "," + updatedY;
                    }
                  }
                }
              }
            });
          }
          if (isfallinline) {
            roomObjectArray[roomObjectArrayIndex] = cloneDeep(wallObject);
          } else {
            roomObjectArray[roomObjectArrayIndex] = cloneDeep(
              roomObjectArrayClone[roomObjectArrayIndex]
            );
          }
        }
      }
    }
    designatorWiseObjectArray[roomArray[roomArrayIndex]] = roomObjectArray;
  }
  copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
  return copyOriginal;
}

function getAcurateAngle(angle) {
  if (angle >= -23 && angle <= 22.99) {
    return 0;
  } else if (angle >= 23 && angle <= 67.99) {
    return 45;
  } else if (angle >= 68 && angle <= 112.99) {
    return 90;
  } else if (angle >= 113 && angle <= 157.99) {
    return 135;
  } else if (angle >= 158) {
    return 180;
  } else if (angle <= -158) {
    return 180;
  } else if (angle >= -157.99 && angle <= -113) {
    return -135;
  } else if (angle >= -112.99 && angle <= -68) {
    return -90;
  } else if (angle <= -22.99 && angle >= -67.99) {
    return -45;
  }
}

export function getWindowParentPartitionPoint(faceArray, partitionId) {
  let matchArray = "";
  faceArray
    ?.filter((el) => el["@type"] === "LINE")
    ?.map((faceArrayEl) => {
      if (matchArray === "" && faceArrayEl["@windowId"] === partitionId) {
        matchArray = faceArrayEl["@id"];
      }
      return matchArray;
    });
  return matchArray;
}
