import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import Button from "../../../../common/Button";

const NoDataEagleView = (props) => {
  const { t } = useTranslation();
  const [message, setMessage] = useState();
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    setIsLoading(true);
    props
      .createOrder(props.jobOrderId)
      .then((res) => {
        if (
          res?.data?.data?.status ==
            "JOB_ORDER_EAGLEVIEW_PROCESS_ALREADY_REQUESTED" ||
          res?.data?.data?.status == "JOB_ORDER_EAGLEVIEW_PROCESS_SUCCESS"
        ) {
          setMessage(t("WEB_LABELS.Eagle_View_Report_Is_Requested"));
        }
        setIsLoading(false);
      })
      .catch(() => {
        setIsLoading(false);
        setMessage("Job Order processing failed with Eagleview");
      });
  }, [props.jobOrderId]);
  return (
    <div className="no-data-found">
      <div className="box">
        {isLoading ? (
          <div className="loader-spin"></div>
        ) : (
          <div>
            <i className="icon-Measurement-Details"></i>
            <p>{message}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NoDataEagleView;
