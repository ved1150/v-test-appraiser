import { useState } from "react";

const Structure = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Structure{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {Object.keys(props.estatedData.data.structure).map((key) => (
          <li key={key}>
            <div style={{ textTransform: "capitalize" }}>
              {key.split("_").join(" ")}
            </div>
            {!Array.isArray(props.estatedData.data.structure[key]) && (
              <div>{props.estatedData.data.structure[key] ?? "N/A"}</div>
            )}
            {Array.isArray(props.estatedData.data.structure[key]) && (
              <div>
                {props.estatedData.data.structure[key] &&
                props.estatedData.data.structure[key].length !== 0
                  ? key === "other_improvements" ||
                    key === "other_features" ||
                    key === "other_areas"
                    ? props.estatedData.data.structure[key]
                        .map((e) => `${e.type}: ${e.sq_ft}`)
                        .join(", ")
                    : props.estatedData.data.structure[key].join(", ")
                  : "N/A"}
              </div>
            )}
          </li>
        ))}
      </ul>
    </>
  );
};

export default Structure;
