import * as actionTypes from "../actions/actionTypes";

const transactionHistoryState = {
  fetchTransactionHistoryStart: false,
  fetchTransactionHistorySuccess: [],
  fetchTransactionHistoryError: null,
  fetchTransactionStatusStart: false,
  fetchTransactionStatusSuccess: [],
  fetchTransactionStatusError: null,
  exportTransactionHistoryStart: false,
  exportTransactionHistorySuccess: false,
  exportTransactionHistoryError: null,
};

export const defaultState = {
  ...transactionHistoryState,
};

const transactionHistoryReducer = (state = defaultState, action = {}) => {
  switch (action.type) {
    // ----------------------------------
    // Start of Fetch Transaction History
    // ----------------------------------
    case actionTypes.FETCH_TRANSACTION_HISTORY_START:
      return {
        ...state,
        fetchTransactionHistoryStart: true,
        fetchTransactionHistorySuccess: [],
        fetchTransactionHistoryError: null,
      };
    case actionTypes.FETCH_TRANSACTION_HISTORY_SUCCESS:
      return {
        ...state,
        fetchTransactionHistoryStart: false,
        fetchTransactionHistorySuccess: action.payload,
        fetchTransactionHistoryError: null,
      };
    case actionTypes.FETCH_TRANSACTION_HISTORY_ERROR:
      return {
        ...state,
        fetchTransactionHistoryStart: false,
        fetchTransactionHistorySuccess: [],
        fetchTransactionHistoryError: action.payload,
      };
    // --------------------------------
    // End of Fetch Transaction History
    // --------------------------------

    // ---------------------------------
    // Start of Fetch Transaction Status
    // ---------------------------------
    case actionTypes.FETCH_TRANSACTION_STATUS_START:
      return {
        ...state,
        fetchTransactionStatusStart: true,
        fetchTransactionStatusSuccess: [],
        fetchTransactionStatusError: null,
      };
    case actionTypes.FETCH_TRANSACTION_STATUS_SUCCESS:
      return {
        ...state,
        fetchTransactionStatusStart: false,
        fetchTransactionStatusSuccess: action.payload,
        fetchTransactionStatusError: null,
      };
    case actionTypes.FETCH_TRANSACTION_STATUS_ERROR:
      return {
        ...state,
        fetchTransactionStatusStart: false,
        fetchTransactionStatusSuccess: [],
        fetchTransactionStatusError: action.payload,
      };
    // -------------------------------
    // End of Fetch Transaction Status
    // -------------------------------

    // -----------------------------------
    // Start of Export Transaction History
    // -----------------------------------
    case actionTypes.EXPORT_TRANSACTION_HISTORY_START:
      return {
        ...state,
        exportTransactionHistoryStart: true,
        exportTransactionHistorySuccess: false,
        exportTransactionHistoryError: null,
      };
    case actionTypes.EXPORT_TRANSACTION_HISTORY_SUCCESS:
      return {
        ...state,
        exportTransactionHistoryStart: false,
        exportTransactionHistorySuccess: true,
        exportTransactionHistoryError: null,
      };
    case actionTypes.EXPORT_TRANSACTION_HISTORY_ERROR:
      return {
        ...state,
        exportTransactionHistoryStart: false,
        exportTransactionHistorySuccess: false,
        exportTransactionHistoryError: action.payload,
      };
    // ---------------------------------
    // End of Export Transaction History
    // ---------------------------------

    default:
      return state;
  }
};

export default transactionHistoryReducer;
