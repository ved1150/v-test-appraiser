import React, { Component } from "react";
import NoDataEstatedView from "./NoDataEstatedView";
import "./index.scss";
import _ from "lodash";
import { Wrapper } from "@googlemaps/react-wrapper";
import CustomGoogleMapsComponent from "./EstatedGoogleMapsComponent";
import Address from "./EstatedDetails/Address";
import Assesments from "./EstatedDetails/Assesments";
import Deeds from "./EstatedDetails/Deeds";
import MarketAssesments from "./EstatedDetails/MarketAssesments";
import Owner from "./EstatedDetails/Owner";
import Metadata from "./EstatedDetails/Metadata";
import Parcel from "./EstatedDetails/Parcel";
import Structure from "./EstatedDetails/Structure";
import Taxes from "./EstatedDetails/Taxes";
import Valuation from "./EstatedDetails/Valuation";
export default class EstatedMeasurementTab extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    const estatedData = this.props.mesurementData.estatedJsonData;
    const { t } = this.props;
    return (
      <div className="imageView">
        {this.props.measurementError ||
        _.isEmpty(estatedData) ||
        _.isEmpty(estatedData.data) ||
        this.props.isSwitchAndLoadingTab ? (
          <div className="no-data-found">
            <div className="box">
              {this.props.isSwitchAndLoadingTab ? (
                <div className="loader-spin"></div>
              ) : (
                <NoDataEstatedView
                  jobOrderId={this.props.jobOrderId}
                  text={"WEB_LABELS.There_is_no_Public_Records_Data_available"}
                  fetchEstatedData={this.props.fetchEstatedData}
                  estatedStatus={this.props.estatedStatus}
                ></NoDataEstatedView>
              )}
            </div>
          </div>
        ) : (
          <div className="estate-row-container">
            <div className="inner-estate-row">
              {estatedData.data.address &&
              estatedData.data.address.latitude &&
              estatedData.data.address.longitude &&
              estatedData.data.boundary &&
              estatedData.data.boundary.geojson ? (
                <Wrapper apiKey={process.env.REACT_APP_GOOGLE_MAP_API_KEY}>
                  <CustomGoogleMapsComponent {...estatedData} />
                </Wrapper>
              ) : (
                <div className="estate-map">
                  {t("WEB_LABELS.No_Map_View_Available")}
                </div>
              )}
              <div className="estated-measurement-details scroll-bar-style">
                <div class="details">
                  {!_.isEmpty(estatedData.data.address) && (
                    <Address estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.assessments) && (
                    <Assesments estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.deeds) && (
                    <Deeds estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.market_assessments) && (
                    <MarketAssesments estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.metadata) && (
                    <Metadata estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.owner) && (
                    <Owner estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.parcel) && (
                    <Parcel estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.structure) && (
                    <Structure estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.taxes) && (
                    <Taxes estatedData={estatedData} />
                  )}
                  {!_.isEmpty(estatedData.data.valuation) && (
                    <Valuation estatedData={estatedData} />
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}
