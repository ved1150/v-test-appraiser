import * as actionTypes from "../actions/actionTypes";

const defaultState = {
  uiloading: false,
  isNavOpen: true,
  centerLoaderLoading: false,
  showHeader: true,
};

export default (state = defaultState, action = {}) => {
  switch (action.type) {
    case actionTypes.UI_LOADER_START:
      return {
        ...state,
        uiloading: true,
      };
    case actionTypes.UI_LOADER_STOP:
      return {
        ...state,
        uiloading: false,
      };
    case actionTypes.UI_NAV_TOGGLE:
      return {
        ...state,
        isNavOpen: !state.isNavOpen,
      };
    case actionTypes.CENTER_LOADER_START:
      return {
        ...state,
        centerLoaderLoading: true,
      };
    case actionTypes.CENTER_LOADER_STOP:
      return {
        ...state,
        centerLoaderLoading: false,
      };
    case actionTypes.UI_HEADER_TOGGLE:
      return {
        ...state,
        showHeader: !state.showHeader,
      };
    default:
      return state;
  }
};
