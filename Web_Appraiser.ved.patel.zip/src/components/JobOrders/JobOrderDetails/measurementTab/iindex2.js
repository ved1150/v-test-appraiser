import React, { Component } from "react";

import { fabric } from "fabric";
import "fabric-history";
import * as THREE from "three";
import _ from "lodash";

const STATE_IDLE = "idle";
const STATE_PANNING = "panning";

let designatorWiseObjectArray = {};

var roomWiseLineAndTextObjects = {};
var roomLinesGroup = [];
var roomTextGroup = [];

let ratioX = 1;
let ratioY = 1;

let originalFloorPlan = null;
let updatedFloorPlan = null;

export default class MeasurementTab extends Component {
  canvas = null;
  maxX = 0;
  maxY = 0;
  minX = null;
  minY = null;
  canvasWidth = window.innerHeight - 400;
  canvasHeight = window.innerWidth - 400;

  constructor(props) {
    super();

    this.state = {};
    this.onObjectChange = this.onObjectChange.bind(this);
    this.editArea = this.editArea.bind(this);
  }
  async componentDidMount() {
    let canvas;

    this.canvasHeight = document.querySelector(
      "div.open.tab-content"
    ).clientHeight;

    this.canvasWidth = document.querySelector(
      "div.open.tab-content"
    ).clientWidth;

    canvas = new fabric.Canvas("measurementcanvas", {
      height: this.canvasHeight,
      width: this.canvasWidth,
      selection: false,
    });

    fabric.Canvas.prototype.toggleDragMode = function (dragMode) {
      // Remember the previous X and Y coordinates for delta calculations
      let lastClientX;
      let lastClientY;
      // Keep track of the state
      let state = STATE_IDLE;
      // We're entering dragmode
      if (dragMode) {
        // Discard any active object
        this.discardActiveObject();
        // Set the cursor to 'move'
        this.defaultCursor = "move";
        // Loop over all objects and disable events / selectable. We remember its value in a temp variable stored on each object
        this.forEachObject(function (object) {
          object.prevEvented = object.evented;
          object.prevSelectable = object.selectable;
          object.evented = false;
          object.selectable = false;
        });
        // Remove selection ability on the canvas
        this.selection = false;
        // When MouseUp fires, we set the state to idle
        this.on("mouse:up", function (e) {
          state = STATE_IDLE;
        });
        // When MouseDown fires, we set the state to panning
        this.on("mouse:down", (e) => {
          state = STATE_PANNING;
          lastClientX = e.e.clientX;
          lastClientY = e.e.clientY;
        });
        // When the mouse moves, and we're panning (mouse down), we continue
        this.on("mouse:move", (e) => {
          if (state === STATE_PANNING && e && e.e) {
            // let delta = new fabric.Point(e.e.movementX, e.e.movementY); // No Safari support for movementX and movementY
            // For cross-browser compatibility, I had to manually keep track of the delta

            // Calculate deltas
            let deltaX = 0;
            let deltaY = 0;
            if (lastClientX) {
              deltaX = e.e.clientX - lastClientX;
            }
            if (lastClientY) {
              deltaY = e.e.clientY - lastClientY;
            }
            // Update the last X and Y values
            lastClientX = e.e.clientX;
            lastClientY = e.e.clientY;

            let delta = new fabric.Point(deltaX, deltaY);
            this.relativePan(delta);
            //   this.trigger('moved');
          }
        });
      } else {
        // When we exit dragmode, we restore the previous values on all objects
        this.forEachObject(function (object) {
          object.evented =
            object.prevEvented !== undefined
              ? object.prevEvented
              : object.evented;
          object.selectable =
            object.prevSelectable !== undefined
              ? object.prevSelectable
              : object.selectable;
        });
        // Reset the cursor
        this.defaultCursor = "default";
        // Remove the event listeners
        this.off("mouse:up");
        this.off("mouse:down");
        this.off("mouse:move");
        // Restore selection ability on the canvas
        this.selection = true;
      }
    };

    fabric.Canvas.prototype.getItemByAttr = function (attr, name) {
      var object = null,
        objects = this.getObjects();
      for (var i = 0, len = this.size(); i < len; i++) {
        if (objects[i][attr] && objects[i][attr] === name) {
          object = objects[i];
          break;
        }
      }
      return object;
    };

    this.canvas = canvas;

    var xhr = new XMLHttpRequest();
    // xhr.open("GET", "/updated_json_polygon_room-1.json", true);

    xhr.open("GET", "/mobile_json_three_obj.json", true);

    // xhr.open("GET", "/updated_json_one_room.json", true);
    // xhr.open("GET", "/updated_json_polygon_room.json", true);
    xhr.responseType = "json";
    xhr.send(null);
    xhr.onload = function (response) {
      console.log(response.target.response);

      console.log("response.target.response - ", response.target.response);

      this.showTheListFromJsonRoomWise(response.target.response);
    }.bind(this);

    // console.log("this.props.mesurementData.jsonData - ", this.props.mesurementData.jsonData);
    // console.log("this.props.mesurementData.jsonData - ",JSON.stringify(this.props.mesurementData.jsonData) );
    if (_.isObject(this.props.mesurementData.jsonData)) {
      const newJson = _.cloneDeep(this.props.mesurementData.jsonData);
      // this.showTheListFromJson(newJson);
    }
  }

  async showTheListFromJsonRoomWise(json) {
    var pointarr = [];
    var pointarrThreeD = [];
    var paths = [];

    var jsonObject = json;

    updatedFloorPlan = _.cloneDeep(jsonObject);
    // var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    // var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    // var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    // var linesArray = lines[0].LINE;

    // var faceArray = roofObject[0]["FACES"]["FACE"];

    /** devide all arrays individually */
    const roofPointsArray = _.get(
      jsonObject,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "POINTS", "POINT"],
      []
    );
    const linesArray = _.get(
      jsonObject,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "LINES", "LINE"],
      []
    );
    const faceArray = _.get(
      jsonObject,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "FACES", "FACE"],
      []
    );

    designatorWiseObjectArray = {};

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = faceArray[faceArrayIndex];

      if (
        designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
        roomFaceObject["@type"] == "ROOM"
      ) {
        //Get walls of room

        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        const roomChildrenArray = _.split(
          _.get(roomFaceObject, ["@children"], ""),
          ","
        );

        //Now iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomchildId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          //find roomChild From FaceArray
          const faceArrayIndex = _.findIndex(faceArray, (faceObject) => {
            return (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomchildId == faceObject["@id"]
            );
          });
          const faceObject = faceArray[faceArrayIndex];

          // if faceObject found.
          if (faceObject) {
            const lineId = faceObject["POLYGON"]["@path"];
            const lineArrayIndex = _.findIndex(linesArray, (lineobject) => {
              return lineobject["@id"] == lineId;
            });

            const lineObject = linesArray[lineArrayIndex];
            if (lineObject) {
              const linePoints = _.split(_.get(lineObject, ["@path"], ""), ",");
              const linePointObjectArray = _.filter(
                roofPointsArray,
                (point) => {
                  return linePoints && linePoints.includes(point["@id"]);
                }
              );
              lineObject["linePointObjectArray"] = linePointObjectArray;
              linesArray[lineArrayIndex] = lineObject;
              faceObject["LINE"] = lineObject;
              faceArray[faceArrayIndex] = faceObject;
            }

            designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
          }
        }
      } else {
        //TBD. NOT IN USE.
      }
    }

    console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    this.canvas.viewportTransform[4] = 0;
    this.canvas.viewportTransform[5] = 0;

    this.canvas.isDrawingMode = false;
    this.canvas.freeDrawingBrush.width = 5;
    this.canvas.freeDrawingBrush.color = "red";

    var pointer = {
      x: 0,
      y: 0,
    };

    let options = { pointer, e: {} }; // required for Fabric 4.3.1

    this.canvas.freeDrawingBrush.onMouseDown(pointer, options);

    console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    let roomArray = Object.keys(designatorWiseObjectArray);
    console.log("roomArray 1 - ", roomArray);

    //find min and max X Y.
    _.map(roofPointsArray, (p) => {
      const dataXY = _.split(_.get(p, ["@dataXY"], ""), ",");
      if (dataXY.length > 1) {
        if (parseFloat(dataXY[0]) > this.maxX) {
          this.maxX = parseFloat(dataXY[0]);
        }
        if (parseFloat(dataXY[1]) > this.maxY) {
          this.maxY = parseFloat(dataXY[1]);
        }
        if (this.minX == null) {
          this.minX = this.maxX;
        }
        if (this.minY == null) {
          this.minY = this.maxY;
        }

        if (parseFloat(dataXY[0]) < this.minX) {
          this.minX = parseFloat(dataXY[0]);
        }

        if (parseFloat(dataXY[1]) < this.minY) {
          this.minY = parseFloat(dataXY[1]);
        }
      }
    });

    this.canvasHeight = this.maxY - this.minY;
    this.canvasWidth = this.maxX - this.minX;

    this.canvas.setHeight(this.canvasHeight + 50);
    this.canvas.setWidth(this.canvasWidth + 50);

    ratioX = 1;
    ratioY = 1;

    let multiplierX = 1;
    if (this.maxX - this.minX > this.canvasWidth) {
      ratioX = (this.canvasWidth / (this.maxX - this.minX)) * multiplierX;
    } else {
      ratioX = ((this.maxX - this.minX) / this.canvasWidth) * multiplierX;
    }

    if (this.maxY - this.minY > this.canvasHeight) {
      ratioY =
        (this.canvasHeight / (this.maxY - this, this.minY)) * multiplierX;
    } else {
      ratioY = ((this.maxY - this.minY) / this.canvasHeight) * multiplierX;
    }

    console.log("ratioX - ", ratioX);
    console.log("ratioY - ", ratioY);

    console.log("this.minX - ", this.minX);
    console.log("this.minY - ", this.minY);

    // Draw Room by Room

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomArea = "";
      let roomID = "";
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];

      roomLinesGroup = [];
      roomTextGroup = [];

      let connectorCircleGroup = [];

      let wallNo = 0;
      //Draw Lines of Room
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        console.log("wallObject - ", wallObject);
        let wallID = wallObject["@id"];
        if (wallObject.LINE == null) {
          roomArea = wallObject["@area"];
          roomID = wallObject["@id"];
          // create new object of Room for Line and Text
          roomWiseLineAndTextObjects[roomID] = {};
          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

          //don't need to execute anything when it is Room Type
          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          //TBD
        } else {
          continue;
        }

        let linePointObjectArray = wallObject.LINE.linePointObjectArray;
        let poligonObject = wallObject.POLYGON;
        let points = [];
        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          let v1 = _.split(
            _.get(
              linePointObjectArray[linePointObjectArrayInedex],
              ["@dataXY"],
              ""
            ),
            ","
          );
          if (v1.length < 2) {
            break;
          }
          let id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          let fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }

        //Add line
        if (points.length < 2) {
          break;
        }

        let line = null;

        let color = wallNo % 2 == 0 ? "#fe741f" : "black";

        line = new fabric.Line(
          [
            (points[0].x - this.minX) * ratioX,
            (points[0].y - this.minY) * ratioY,
            (points[1].x - this.minX) * ratioX,
            (points[1].y - this.minY) * ratioY,
          ],
          {
            stroke: color,
            strokeWidth: 2,
            selectable: false,
            evented: false,
            id: wallID,
            roomID: roomID,
            type: "WALL-LINE",
            linePointObjectArray: linePointObjectArray,
            unroundedsize: wallObject["POLYGON"]["@unroundedsize"],
          }
        );

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
        roomLinesGroup.push(line);

        this.canvas.add(line);

        if (isWallPenetration == false) {
          wallNo++;
        } else {
        }
      }

      //Draw the Center Area Lable and connetors
      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        let roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        let color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";

        // Connectors

        if (roomLinesGroupArrayIndex == 0) {
          let circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color
          );

          this.canvas.add(circle);
        } else {
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            let circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            this.canvas.add(circle);
          } else {
            let circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            connectorCircleGroup.push(circle);
            this.canvas.add(circle);
          }
        }

        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }
      let totalPoints = roomLinesGroup.length;
      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        let textObject = this.canvas.getItemByAttr("id", roomID);
        const centerX = areaLabelLeft - text.getBoundingRect().width / 2;
        const centerY = areaLabelTop - text.getBoundingRect().height / 2;
        textObject.set("left", centerX);
        textObject.set("top", centerY);
        roomWiseLineAndTextObjects[roomID]["centerPoint"] = {
          x: centerX,
          y: centerY,
        };
      } else {
        //Add label

        let text = new fabric.Text(roomArea, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: areaLabelLeft,
          top: areaLabelTop,
          angle: 0,
          fill: "Red",
          id: roomID,
          objectCaching: false,
        });
        const centerX = areaLabelLeft - text.getBoundingRect().width / 2;
        const centerY = areaLabelTop - text.getBoundingRect().height / 2;
        text.set("left", centerX);
        text.set("top", centerY);
        roomWiseLineAndTextObjects[roomID]["centerPoint"] = {
          x: centerX,
          y: centerY,
        };

        this.canvas.add(text);
      }

      //Draw the lines Labels

      for (
        let roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        const line = roomLinesGroup[roomLinesGroupArrayIndex];
        const unroundedsize = line.get("unroundedsize");
        const ceneterPoint = roomWiseLineAndTextObjects[roomID]["centerPoint"];
        let coordinateForLable = this.coordinateForlable(
          line.x1,
          line.x2,
          line.y1,
          line.y2,
          ceneterPoint.x,
          ceneterPoint.y
        );

        const wallID = line.get("id");
        let unRoundedSize = parseFloat(unroundedsize);
        let unRoundedSizeFeet =
          parseFloat(unRoundedSize * 3.28084).toFixed(2) +
          " ft wall - " +
          wallID;

        let label = new fabric.Text(unRoundedSizeFeet, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: coordinateForLable.x,
          top: coordinateForLable.y,
          angle: coordinateForLable.orientation,
          fill: "red",
          id: wallID,
          roomID: roomID,
          objectCaching: false,
          type: "LABEL",
        });

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(label);
        roomTextGroup.push(label);
        this.canvas.add(label);
      }
    }

    //Now start drawing

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      var roomArea = "";
      var roomID = "";
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];

      console.log("roomObjectArray - ", roomObjectArray);

      //if(roomLinesGroup[""])

      roomLinesGroup = [];
      roomTextGroup = [];

      var connectorCircleGroup = [];

      var wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        console.log("wallObject - ", wallObject);
        let wallID = wallObject["@id"];
        if (wallObject.LINE == null) {
          roomArea = wallObject["@area"];
          roomID = wallObject["@id"];
          roomWiseLineAndTextObjects[roomID] = {};
          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;
          roomWiseLineAndTextObjects[roomID]["centerPoint"] = {};
          roomWiseLineAndTextObjects[roomID]["Name"] = wallObject["@areaname"];

          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          //TBD
        } else {
          continue;
        }

        let linePointObjectArray = wallObject.LINE.linePointObjectArray;
        let poligonObject = wallObject.POLYGON;

        let points = [];

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          let value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];

          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }

        console.log("points - ", points);
        //Add line
        if (points.length < 2) {
          break;
        }

        var line = null;

        var color = wallNo % 2 == 0 ? "#fe741f" : "black";
        console.log("wallNo - ", wallNo);
        console.log("color - ", color);

        console.log("points - ", points);

        line = new fabric.Line(
          [
            (points[0].x - this.minX) * ratioX,
            (points[0].y - this.minY) * ratioY,
            (points[1].x - this.minX) * ratioX,
            (points[1].y - this.minY) * ratioY,
          ],
          {
            stroke: color,
            strokeWidth: 2,
            selectable: false,
            evented: false,
            id: wallID,
            roomID: roomID,
            type: "WALL-LINE",
            linePointObjectArray: linePointObjectArray,
            unroundedsize: wallObject["POLYGON"]["@unroundedsize"],
          }
        );

        console.log("line - ", line);

        let textLeftPosition = line.get("x1");
        let textTopPosition = line.get("y1");
        let moveLeft = false;
        let moveTop = false;

        if (line.get("x1") == line.get("x2")) {
          textTopPosition = (line.get("y1") + line.get("y2")) / 2;

          moveTop = true;
          if (isWallPenetration) {
            textLeftPosition = line.get("x2") - 15;
          } else {
            if (wallNo == 2) {
              textLeftPosition = line.get("x2") - 5;
            } else {
              textLeftPosition = line.get("x2") + 15;
            }
          }
        } else if (line.get("y1") == line.get("y2")) {
          textLeftPosition = (line.get("x1") + line.get("x2")) / 2;

          moveLeft = true;

          if (isWallPenetration) {
            textTopPosition = line.get("y2") - 15;
          } else {
            if (wallNo == 3) {
              textTopPosition = line.get("y2") - 15;
            } else {
              textTopPosition = line.get("y2") + 5;
            }
          }
        }

        var unRoundedSize = parseFloat(poligonObject["@unroundedsize"]);
        var unRoundedSizeFeet =
          parseFloat(unRoundedSize * 3.28084).toFixed(2) +
          " ft wall - " +
          wallID;

        var text = new fabric.Text(unRoundedSizeFeet, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: textLeftPosition,
          top: textTopPosition,
          angle: wallNo == 2 || wallNo == 4 ? 90 : 0,
          fill: color,
          id: wallID,
          roomID: roomID,
          objectCaching: false,
          type: "LABEL",
        });

        if (moveLeft) {
          text.set(
            "left",
            text.getBoundingRect().left - text.getBoundingRect().width / 2
          );
        } else if (moveTop) {
          text.set(
            "top",
            text.getBoundingRect().top - text.getBoundingRect().height / 2
          );
        }

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);

        roomTextGroup.push(text);
        roomLinesGroup.push(line);

        // this.canvas.add(text);
        // this.canvas.add(line);

        if (isWallPenetration == false) {
          wallNo++;
        } else {
        }
      }

      // this.canvas.renderAll();
      console.log("roomLinesGroup.length - ", roomLinesGroup.length);

      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";

        // Connectors

        if (roomLinesGroupArrayIndex == 0) {
          console.log("else 0");
          var circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color
          );

          // this.canvas.add(circle);
        } else {
          console.log("else");
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            console.log("else 1");

            var circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            // this.canvas.add(circle);
          } else {
            console.log("else 2 - ", roomLinesGroupArrayIndex);
            console.log("else 2 - ", roomLinesGroup[roomLinesGroupArrayIndex]);

            var circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            connectorCircleGroup.push(circle);
            // this.canvas.add(circle);
          }

          // this.canvas.add(circle);
        }

        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }

      let totalPoints = roomLinesGroup.length;
      console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
      console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        var textObject = this.canvas.getItemByAttr("id", roomID);
        console.log("got textObject - ", textObject);

        textObject.set(
          "left",
          areaLabelLeft - textObject.getBoundingRect().width / 2
        );

        textObject.set(
          "top",
          areaLabelTop - textObject.getBoundingRect().height / 2
        );

        // this.canvas.renderAll();
      } else {
        //Add label
        console.log("not found add");

        var text = new fabric.Text(roomArea, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: areaLabelLeft,
          top: areaLabelTop,
          angle: 0,
          fill: "Red",
          id: roomID,
          objectCaching: false,
        });

        // this.canvas.add(text);
      }

      this.canvas.renderAll();

      /*
      var roomDrawingObjectArray = roomLinesGroup.concat(roomTextGroup);
      roomDrawingObjectArray = roomDrawingObjectArray.concat(connectorCircleGroup);

      var group = new fabric.Group(roomDrawingObjectArray, {

        // left: 150,
        // top: 100,
        // angle: -10

        lockScalingX: true,
        lockScalingY: true,

        objectCaching: false,
        selectable:true,

      });


      group.setControlsVisibility({

        mt: false,
        mb: false,
        ml: false,
        mr: false,


      });



      var left = group.get('left') + (group.get('width') / 2);
      var top = group.get('top') + (group.get('height') / 2)




      var centreLabelTemp = new fabric.Text(roomArea, {
        fontFamily: "Delicious_500",
        fontSize: 10,
        left: left,
        top: top,
        fill: "blue"
      });




      left = centreLabelTemp.getBoundingRect().left - (centreLabelTemp.getBoundingRect().width);








      var centreLabel = new fabric.Text(roomArea, {
        fontFamily: "Delicious_500",
        fontSize: 10,
        left: left,
        top: top,
        fill: "black"
      });

      group.addWithUpdate(centreLabel);



      this.canvas.add(group);
      */
    }

    let canvasHeight = document.querySelector(
      "div.open.tab-content"
    ).clientHeight;

    let canvasWidth = document.querySelector(
      "div.open.tab-content"
    ).clientWidth;

    this.canvas.setHeight(canvasHeight);
    this.canvas.setWidth(canvasWidth);

    this.canvas.renderAll();

    // Ends drawing

    var printedAreaName = [];

    this.canvas.on(
      "object:moving",
      function (e) {
        var p = e.target;

        let roomID = p.line1.roomID;

        p.line1 && p.line1.set({ x2: p.left, y2: p.top });
        p.line2 && p.line2.set({ x1: p.left, y1: p.top });

        // var width1 = (p.line1.width/89 * 3.2804);
        // console.log("line 1 - "+ p.line1.id +" area -",width1);

        // var width2 = (p.line2.width/89 * 3.2804);
        // console.log("line 2 - "+ p.line2.id +" area 2 -",width2);

        console.log("line 1 - ", p.line1);
        console.log("line 2 - ", p.line2);

        var width1 =
          Math.sqrt(
            p.line1.width * p.line1.width + p.line1.height * p.line1.height
          ) / 10;

        //Now based on id of wall find label and update position

        for (
          let roomTextGroupIndex = 0;
          roomTextGroupIndex < roomTextGroup.length;
          roomTextGroupIndex++
        ) {
          let label = roomTextGroup[roomTextGroupIndex];

          if (label.id == p.line1.id) {
            // console.log("label  -", label);

            var left = (p.line1.x1 + p.line1.x2) / 2;
            var top = (p.line1.y1 + p.line1.y2) / 2;
            var textObject = this.canvas.getItemByAttr("id", roomID);
            var coordinateForLable = this.coordinateForlable(
              p.line1.x1,
              p.line1.x2,
              p.line1.y1,
              p.line1.y2,
              textObject.left,
              textObject.top
            );

            label.set("left", coordinateForLable.x);

            label.set("top", coordinateForLable.y);
            label.set("angle", coordinateForLable.orientation);

            p.line1.unroundedsize = width1;

            let wallLabel = parseFloat(width1).toFixed(2) + " ft - " + label.id;

            label.set("text", wallLabel);

            break;
          }
        }

        var width2 =
          Math.sqrt(
            p.line2.width * p.line2.width + p.line2.height * p.line2.height
          ) / 10;

        for (
          let roomTextGroupIndex = 0;
          roomTextGroupIndex < roomTextGroup.length;
          roomTextGroupIndex++
        ) {
          let label = roomTextGroup[roomTextGroupIndex];

          if (label.id == p.line2.id) {
            // console.log("label  -", label);

            var left = (p.line2.x1 + p.line2.x2) / 2;
            var top = (p.line2.y1 + p.line2.y2) / 2;
            var textObject = this.canvas.getItemByAttr("id", roomID);
            var coordinateForLable = this.coordinateForlable(
              p.line2.x1,
              p.line2.x2,
              p.line2.y1,
              p.line2.y2,
              textObject.left,
              textObject.top
            );

            // console.log("label2 left -", left);
            // console.log("label2 top -", top);

            label.set("left", coordinateForLable.x);

            label.set("top", coordinateForLable.y);
            label.set("angle", coordinateForLable.orientation);

            p.line2.unroundedsize = width2;

            let wallLabel = parseFloat(width2).toFixed(2) + " ft - " + label.id;
            console.log("wallLabel updated - ", wallLabel);
            label.set("text", wallLabel);

            break;
          }
        }

        //Now based on Rooms, calculate the center point of label

        // designatorWiseObjectArray

        let roomArray = Object.keys(designatorWiseObjectArray);
        // console.log("roomArray 1 - ", roomArray);
        console.log(
          "roomWiseLineAndTextObjects - ",
          roomWiseLineAndTextObjects
        );

        roomLinesGroup = roomWiseLineAndTextObjects[roomID]["roomLinesGroup"];
        roomTextGroup = roomWiseLineAndTextObjects[roomID]["roomTextGroup"];
        let roomArea = roomWiseLineAndTextObjects[roomID]["roomArea"];

        let roomCenterPointX = 0;
        let roomCenterPointY = 0;

        for (
          let roomLinesGroupIndex = 0;
          roomLinesGroupIndex < roomLinesGroup.length;
          roomLinesGroupIndex++
        ) {
          roomCenterPointX +=
            (roomLinesGroup[roomLinesGroupIndex].x1 +
              roomLinesGroup[roomLinesGroupIndex].x2) /
            2;
          roomCenterPointY +=
            (roomLinesGroup[roomLinesGroupIndex].y1 +
              roomLinesGroup[roomLinesGroupIndex].y2) /
            2;
        }

        let totalPoints = roomLinesGroup.length;
        console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
        console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

        let areaLabelLeft = roomCenterPointX / totalPoints;
        let areaLabelTop = roomCenterPointY / totalPoints;

        if (this.canvas.getItemByAttr("id", roomID) != null) {
          //this.canvas.getItemByAttr('id', "room1").remove();
          var textObject = this.canvas.getItemByAttr("id", roomID);
          console.log("got textObject - ", textObject);

          textObject.set(
            "left",
            areaLabelLeft - textObject.getBoundingRect().width / 2
          );

          textObject.set(
            "top",
            areaLabelTop - textObject.getBoundingRect().height / 2
          );

          // this.canvas.renderAll();
        } else {
          //Add label
          console.log("not found add");

          var text = new fabric.Text(roomArea, {
            fontFamily: "Delicious_500",
            fontSize: 10,
            left: areaLabelLeft,
            top: areaLabelTop,
            angle: 0,
            fill: "Red",
            id: roomID,
            objectCaching: false,
          });

          this.canvas.add(text);
        }

        /*
        for (let roomArrayIndex = 0; roomArrayIndex < roomArray.length; roomArrayIndex++) {

          let roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];

        
  

          for (let roomObjectArrayIndex = 0; roomObjectArrayIndex < roomObjectArray.length; roomObjectArrayIndex++) {


            let wallObject = roomObjectArray[roomObjectArrayIndex];


            if (wallObject.LINE == null) {
              continue;
            }
            //For multiple rooms get line group by rooms.
            //console.log("wallObject - ",wallObject);
            console.log("roomLinesGroup - ", roomLinesGroup);

            let roomCenterPointX = 0;
            let roomCenterPointY = 0;

            for (let roomLinesGroupIndex = 0; roomLinesGroupIndex < roomLinesGroup.length; roomLinesGroupIndex++) {
              
              roomCenterPointX += (roomLinesGroup[roomLinesGroupIndex].x1 + roomLinesGroup[roomLinesGroupIndex].x2)/2;
              roomCenterPointY += (roomLinesGroup[roomLinesGroupIndex].y1 + roomLinesGroup[roomLinesGroupIndex].y2)/2;
              


            }

            let totalPoints = (roomLinesGroup.length);
            console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
            console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

            let areaLabelLeft = roomCenterPointX / totalPoints;
            let areaLabelTop = roomCenterPointY / totalPoints;

            if (this.canvas.getItemByAttr('id', "room1") != null) {
              //this.canvas.getItemByAttr('id', "room1").remove();
              var textObject = this.canvas.getItemByAttr('id', "room1");
              console.log("got textObject - ",textObject);
              
              textObject.set(
                "left",
                areaLabelLeft - textObject.getBoundingRect().width / 2
              );
  
              textObject.set(
                "top",
                areaLabelTop - textObject.getBoundingRect().height / 2
              );

             // this.canvas.renderAll();

              
            }else{

              //Add label
              console.log("not found add");

              var text = new fabric.Text("Center", {
                fontFamily: "Delicious_500",
                fontSize: 10,
                left: areaLabelLeft,
                top: areaLabelTop,
                angle: 0,
                fill: "Red",
                id: "room1",
              });
  
              this.canvas.add(text);
              

            }

           


           

            




          }

        }
        */

        this.canvas.renderAll();
      }.bind(this)
    );

    this.canvas.on(
      "mouse:wheel",
      function (opt) {
        var delta = opt.e.deltaY;
        var zoom = this.canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        this.canvas.setZoom(zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }.bind(this)
    );

    /* 
   this.canvas.on({

     'object:scaling': this.onObjectChange,
     'object:rotating': this.onObjectChange,
   });
   */

    // this.canvas.toggleDragMode(true);
  }

  async showTheListFromJson(json) {
    var pointarr = [];
    var pointarrThreeD = [];
    var paths = [];

    var jsonObject = json;

    var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    var roofPointsArray = roofPoints[0]["POINT"];

    var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    var linesArray = lines[0].LINE;

    var faceArray = roofObject[0]["FACES"]["FACE"];

    designatorWiseObjectArray = {};

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let faceObject = faceArray[faceArrayIndex];

      if (designatorWiseObjectArray[faceObject["@designator"]] == null) {
        designatorWiseObjectArray[faceObject["@designator"]] = [];
      } else {
        //TBD
      }

      if (faceObject["POLYGON"]["@path"].trim().length > 0) {
        var lineId = faceObject["POLYGON"]["@path"];

        //Find Line
        for (
          let lineArrayIndex = 0;
          lineArrayIndex < linesArray.length;
          lineArrayIndex++
        ) {
          let lineObject = linesArray[lineArrayIndex];
          if (lineObject["@id"] == lineId) {
            var linePointObjectArray = [];
            var linePoints = lineObject["@path"].split(",");
            for (
              var linePointsIndex = 0;
              linePointsIndex < linePoints.length;
              linePointsIndex++
            ) {
              for (
                let roofPointsArrayIndex = 0;
                roofPointsArrayIndex < roofPointsArray.length;
                roofPointsArrayIndex++
              ) {
                let roofPointObject = roofPointsArray[roofPointsArrayIndex];
                if (roofPointObject["@id"] == linePoints[linePointsIndex]) {
                  linePointObjectArray.push(roofPointObject);

                  break;
                }
              }
            }

            lineObject["linePointObjectArray"] = linePointObjectArray;
            linesArray[lineArrayIndex] = lineObject;

            faceObject["LINE"] = lineObject;
            faceArray[faceArrayIndex] = faceObject;
          }
        }
      }

      designatorWiseObjectArray[faceObject["@designator"]].push(faceObject);
    }

    // console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    this.canvas.viewportTransform[4] = 0;
    this.canvas.viewportTransform[5] = 0;

    this.canvas.isDrawingMode = false;
    this.canvas.freeDrawingBrush.width = 5;
    this.canvas.freeDrawingBrush.color = "red";

    var pointer = {
      x: 0,
      y: 0,
    };

    let options = { pointer, e: {} }; // required for Fabric 4.3.1

    this.canvas.freeDrawingBrush.onMouseDown(pointer, options);

    console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    let roomArray = Object.keys(designatorWiseObjectArray);
    // console.log("roomArray 1 - ", roomArray);

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      // console.log("roomObject - ", roomObjectArray);

      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];

        if (wallObject.LINE == null) {
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];
          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

          if (parseFloat(v1[0]) > this.maxX) {
            this.maxX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) > this.maxY) {
            this.maxY = parseFloat(v1[1]);
          }

          if (this.minX == null) {
            this.minX = this.maxX;
          }
          if (this.minY == null) {
            this.minY = this.maxY;
          }

          if (parseFloat(v1[0]) < this.minX) {
            this.minX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) < this.minY) {
            this.minY = parseFloat(v1[1]);
          }
        }
      }
    }

    this.canvasHeight = this.maxY - this.minY;
    this.canvasWidth = this.maxX - this.minX;

    this.canvas.setHeight(this.canvasHeight + 50);
    this.canvas.setWidth(this.canvasWidth + 50);

    let ratioX = 1;
    let ratioY = 1;

    let multiplierX = 1;
    if (this.maxX - this.minX > this.canvasWidth) {
      ratioX = (this.canvasWidth / (this.maxX - this.minX)) * multiplierX;
    } else {
      ratioX = ((this.maxX - this.minX) / this.canvasWidth) * multiplierX;
    }

    if (this.maxY - this.minY > this.canvasHeight) {
      ratioY =
        (this.canvasHeight / (this.maxY - this, this.minY)) * multiplierX;
    } else {
      ratioY = ((this.maxY - this.minY) / this.canvasHeight) * multiplierX;
    }

    // ratioX = 10;
    // ratioY = 10;

    //Now start drawing

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      var roomArea = "";
      var roomID = "";
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];

      console.log("roomObjectArray - ", roomObjectArray);

      //if(roomLinesGroup[""])

      roomLinesGroup = [];
      roomTextGroup = [];

      var connectorCircleGroup = [];

      var wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        console.log("wallObject - ", wallObject);
        let wallID = wallObject["@id"];

        if (wallObject.LINE == null) {
          roomArea = wallObject["@area"];
          roomID = wallObject["@id"];

          roomWiseLineAndTextObjects[roomID] = {};
          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          //TBD
        } else {
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;
        var poligonObject = wallObject.POLYGON;

        let points = [];

        console.log("linePointObjectArray - ", linePointObjectArray);

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];

          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }

        console.log("points - ", points);
        //Add line
        if (points.length < 2) {
          break;
        }

        var line = null;

        var color = wallNo % 2 == 0 ? "#fe741f" : "black";
        console.log("wallNo - ", wallNo);
        console.log("color - ", color);

        console.log("points - ", points);

        line = new fabric.Line(
          [
            (points[0].x - this.minX) * ratioX,
            (points[0].y - this.minY) * ratioY,
            (points[1].x - this.minX) * ratioX,
            (points[1].y - this.minY) * ratioY,
          ],
          {
            stroke: color,
            strokeWidth: 2,
            selectable: false,
            evented: false,
            id: wallID,
            roomID: roomID,
          }
        );

        console.log("line - ", line);

        let textLeftPosition = line.get("x1");
        let textTopPosition = line.get("y1");
        let moveLeft = false;
        let moveTop = false;

        if (line.get("x1") == line.get("x2")) {
          textTopPosition = (line.get("y1") + line.get("y2")) / 2;

          moveTop = true;
          if (isWallPenetration) {
            textLeftPosition = line.get("x2") - 15;
          } else {
            if (wallNo == 2) {
              textLeftPosition = line.get("x2") - 5;
            } else {
              textLeftPosition = line.get("x2") + 15;
            }
          }
        } else if (line.get("y1") == line.get("y2")) {
          textLeftPosition = (line.get("x1") + line.get("x2")) / 2;

          moveLeft = true;

          if (isWallPenetration) {
            textTopPosition = line.get("y2") - 15;
          } else {
            if (wallNo == 3) {
              textTopPosition = line.get("y2") - 15;
            } else {
              textTopPosition = line.get("y2") + 5;
            }
          }
        }

        var unRoundedSize = parseFloat(poligonObject["@unroundedsize"]);
        var unRoundedSizeFeet =
          parseFloat(unRoundedSize * 3.28084).toFixed(2) +
          " ft wall - " +
          wallID;

        var text = new fabric.Text(unRoundedSizeFeet, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: textLeftPosition,
          top: textTopPosition,
          angle: wallNo == 2 || wallNo == 4 ? 90 : 0,
          fill: color,
          id: wallID,
          roomID: roomID,
          objectCaching: false,
        });

        if (moveLeft) {
          text.set(
            "left",
            text.getBoundingRect().left - text.getBoundingRect().width / 2
          );
        } else if (moveTop) {
          text.set(
            "top",
            text.getBoundingRect().top - text.getBoundingRect().height / 2
          );
        }

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);

        roomTextGroup.push(text);
        roomLinesGroup.push(line);

        this.canvas.add(text);
        this.canvas.add(line);

        if (isWallPenetration == false) {
          wallNo++;
        } else {
        }
      }

      // this.canvas.renderAll();
      console.log("roomLinesGroup.length - ", roomLinesGroup.length);

      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";

        // Connectors

        if (roomLinesGroupArrayIndex == 0) {
          console.log("else 0");
          var circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color
          );

          this.canvas.add(circle);
        } else {
          console.log("else");
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            console.log("else 1");

            var circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            this.canvas.add(circle);
          } else {
            console.log("else 2 - ", roomLinesGroupArrayIndex);
            console.log("else 2 - ", roomLinesGroup[roomLinesGroupArrayIndex]);

            var circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            connectorCircleGroup.push(circle);
            this.canvas.add(circle);
          }

          // this.canvas.add(circle);
        }

        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }

      let totalPoints = roomLinesGroup.length;
      console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
      console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        var textObject = this.canvas.getItemByAttr("id", roomID);
        console.log("got textObject - ", textObject);

        textObject.set(
          "left",
          areaLabelLeft - textObject.getBoundingRect().width / 2
        );

        textObject.set(
          "top",
          areaLabelTop - textObject.getBoundingRect().height / 2
        );

        // this.canvas.renderAll();
      } else {
        //Add label
        console.log("not found add");

        var text = new fabric.Text(roomArea, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: areaLabelLeft,
          top: areaLabelTop,
          angle: 0,
          fill: "Red",
          id: roomID,
          objectCaching: false,
        });

        this.canvas.add(text);
      }

      this.canvas.renderAll();

      /*
      var roomDrawingObjectArray = roomLinesGroup.concat(roomTextGroup);
      roomDrawingObjectArray = roomDrawingObjectArray.concat(connectorCircleGroup);

      var group = new fabric.Group(roomDrawingObjectArray, {

        // left: 150,
        // top: 100,
        // angle: -10

        lockScalingX: true,
        lockScalingY: true,

        objectCaching: false,
        selectable:true,

      });


      group.setControlsVisibility({

        mt: false,
        mb: false,
        ml: false,
        mr: false,


      });



      var left = group.get('left') + (group.get('width') / 2);
      var top = group.get('top') + (group.get('height') / 2)




      var centreLabelTemp = new fabric.Text(roomArea, {
        fontFamily: "Delicious_500",
        fontSize: 10,
        left: left,
        top: top,
        fill: "blue"
      });




      left = centreLabelTemp.getBoundingRect().left - (centreLabelTemp.getBoundingRect().width);








      var centreLabel = new fabric.Text(roomArea, {
        fontFamily: "Delicious_500",
        fontSize: 10,
        left: left,
        top: top,
        fill: "black"
      });

      group.addWithUpdate(centreLabel);



      this.canvas.add(group);
      */
    }

    let canvasHeight = document.querySelector(
      "div.open.tab-content"
    ).clientHeight;

    let canvasWidth = document.querySelector(
      "div.open.tab-content"
    ).clientWidth;

    this.canvas.setHeight(canvasHeight);
    this.canvas.setWidth(canvasWidth);

    this.canvas.renderAll();

    // Ends drawing

    var printedAreaName = [];

    this.canvas.on(
      "object:moving",
      function (e) {
        var p = e.target;

        let roomID = p.line1.roomID;

        p.line1 && p.line1.set({ x2: p.left, y2: p.top });
        p.line2 && p.line2.set({ x1: p.left, y1: p.top });

        // var width1 = (p.line1.width/89 * 3.2804);
        // console.log("line 1 - "+ p.line1.id +" area -",width1);

        // var width2 = (p.line2.width/89 * 3.2804);
        // console.log("line 2 - "+ p.line2.id +" area 2 -",width2);

        // console.log("line 1 - ", p.line1);
        // console.log("line 2 - ", p.line2);

        var width1 =
          Math.sqrt(
            p.line1.width * p.line1.width + p.line1.height * p.line1.height
          ) / 10;

        //Now based on id of wall find label and update position

        for (
          let roomTextGroupIndex = 0;
          roomTextGroupIndex < roomTextGroup.length;
          roomTextGroupIndex++
        ) {
          let label = roomTextGroup[roomTextGroupIndex];

          if (label.id == p.line1.id) {
            // console.log("label  -", label);

            var left = (p.line1.x1 + p.line1.x2) / 2;
            var top = (p.line1.y1 + p.line1.y2) / 2;
            var textObject = this.canvas.getItemByAttr("id", roomID);
            var coordinateForLable = this.coordinateForlable(
              p.line1.x1,
              p.line1.x2,
              p.line1.y1,
              p.line1.y2,
              textObject.left,
              textObject.top
            );

            // console.log("label left -", left);
            // console.log("label top -", top);

            label.set("left", coordinateForLable.x);

            label.set("top", coordinateForLable.y);
            label.set("angle", coordinateForLable.orientation);

            let wallLabel = parseFloat(width1).toFixed(2) + " ft - " + label.id;
            //label.set('Text',wallLabel);
            label.set("text", wallLabel);

            break;
          }
        }

        var width2 =
          Math.sqrt(
            p.line2.width * p.line2.width + p.line2.height * p.line2.height
          ) / 10;

        for (
          let roomTextGroupIndex = 0;
          roomTextGroupIndex < roomTextGroup.length;
          roomTextGroupIndex++
        ) {
          let label = roomTextGroup[roomTextGroupIndex];

          if (label.id == p.line2.id) {
            // console.log("label  -", label);

            var left = (p.line2.x1 + p.line2.x2) / 2;
            var top = (p.line2.y1 + p.line2.y2) / 2;
            var textObject = this.canvas.getItemByAttr("id", roomID);
            var coordinateForLable = this.coordinateForlable(
              p.line2.x1,
              p.line2.x2,
              p.line2.y1,
              p.line2.y2,
              textObject.left,
              textObject.top
            );
            console.log("label2 left -", left);
            console.log("label2 top -", top);

            label.set("left", coordinateForLable.x);

            label.set("top", coordinateForLable.y);
            label.set("angle", coordinateForLable.orientation);

            let wallLabel = parseFloat(width2).toFixed(2) + " ft - " + label.id;
            console.log("wallLabel updated - ", wallLabel);
            label.set("text", wallLabel);

            break;
          }
        }

        //Now based on Rooms, calculate the center point of label

        // designatorWiseObjectArray

        let roomArray = Object.keys(designatorWiseObjectArray);
        // console.log("roomArray 1 - ", roomArray);
        console.log(
          "roomWiseLineAndTextObjects - ",
          roomWiseLineAndTextObjects
        );

        roomLinesGroup = roomWiseLineAndTextObjects[roomID]["roomLinesGroup"];
        roomTextGroup = roomWiseLineAndTextObjects[roomID]["roomTextGroup"];
        let roomArea = roomWiseLineAndTextObjects[roomID]["roomArea"];

        let roomCenterPointX = 0;
        let roomCenterPointY = 0;

        for (
          let roomLinesGroupIndex = 0;
          roomLinesGroupIndex < roomLinesGroup.length;
          roomLinesGroupIndex++
        ) {
          roomCenterPointX +=
            (roomLinesGroup[roomLinesGroupIndex].x1 +
              roomLinesGroup[roomLinesGroupIndex].x2) /
            2;
          roomCenterPointY +=
            (roomLinesGroup[roomLinesGroupIndex].y1 +
              roomLinesGroup[roomLinesGroupIndex].y2) /
            2;
        }

        let totalPoints = roomLinesGroup.length;
        console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
        console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

        let areaLabelLeft = roomCenterPointX / totalPoints;
        let areaLabelTop = roomCenterPointY / totalPoints;

        if (this.canvas.getItemByAttr("id", roomID) != null) {
          //this.canvas.getItemByAttr('id', "room1").remove();
          var textObject = this.canvas.getItemByAttr("id", roomID);
          console.log("got textObject - ", textObject);

          textObject.set(
            "left",
            areaLabelLeft - textObject.getBoundingRect().width / 2
          );

          textObject.set(
            "top",
            areaLabelTop - textObject.getBoundingRect().height / 2
          );

          // this.canvas.renderAll();
        } else {
          //Add label
          console.log("not found add");

          var text = new fabric.Text(roomArea, {
            fontFamily: "Delicious_500",
            fontSize: 10,
            left: areaLabelLeft,
            top: areaLabelTop,
            angle: 0,
            fill: "Red",
            id: roomID,
            objectCaching: false,
          });

          this.canvas.add(text);
        }

        /*
        for (let roomArrayIndex = 0; roomArrayIndex < roomArray.length; roomArrayIndex++) {

          let roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];

        
  

          for (let roomObjectArrayIndex = 0; roomObjectArrayIndex < roomObjectArray.length; roomObjectArrayIndex++) {


            let wallObject = roomObjectArray[roomObjectArrayIndex];


            if (wallObject.LINE == null) {
              continue;
            }
            //For multiple rooms get line group by rooms.
            //console.log("wallObject - ",wallObject);
            console.log("roomLinesGroup - ", roomLinesGroup);

            let roomCenterPointX = 0;
            let roomCenterPointY = 0;

            for (let roomLinesGroupIndex = 0; roomLinesGroupIndex < roomLinesGroup.length; roomLinesGroupIndex++) {
              
              roomCenterPointX += (roomLinesGroup[roomLinesGroupIndex].x1 + roomLinesGroup[roomLinesGroupIndex].x2)/2;
              roomCenterPointY += (roomLinesGroup[roomLinesGroupIndex].y1 + roomLinesGroup[roomLinesGroupIndex].y2)/2;
              


            }

            let totalPoints = (roomLinesGroup.length);
            console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
            console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

            let areaLabelLeft = roomCenterPointX / totalPoints;
            let areaLabelTop = roomCenterPointY / totalPoints;

            if (this.canvas.getItemByAttr('id', "room1") != null) {
              //this.canvas.getItemByAttr('id', "room1").remove();
              var textObject = this.canvas.getItemByAttr('id', "room1");
              console.log("got textObject - ",textObject);
              
              textObject.set(
                "left",
                areaLabelLeft - textObject.getBoundingRect().width / 2
              );
  
              textObject.set(
                "top",
                areaLabelTop - textObject.getBoundingRect().height / 2
              );

             // this.canvas.renderAll();

              
            }else{

              //Add label
              console.log("not found add");

              var text = new fabric.Text("Center", {
                fontFamily: "Delicious_500",
                fontSize: 10,
                left: areaLabelLeft,
                top: areaLabelTop,
                angle: 0,
                fill: "Red",
                id: "room1",
              });
  
              this.canvas.add(text);
              

            }

           


           

            




          }

        }
        */

        this.canvas.renderAll();
      }.bind(this)
    );

    this.canvas.on(
      "mouse:wheel",
      function (opt) {
        var delta = opt.e.deltaY;
        var zoom = this.canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        this.canvas.setZoom(zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }.bind(this)
    );

    /* 
   this.canvas.on({

     'object:scaling': this.onObjectChange,
     'object:rotating': this.onObjectChange,
   });
   */

    // this.canvas.toggleDragMode(true);
  }

  editArea = () => {
    //Iterate canvas and get all lines , room wise...
    console.log("ratioX - ", ratioX);
    console.log("ratioY - ", ratioY);

    console.log("this.minX - ", this.minX);
    console.log("this.minY - ", this.minY);

    /* Need to do reverse of drawing points
    
        (points[0].x + this.minX) / ratioX,
        (points[0].y + this.minY) / ratioY,
        (points[1].x + this.minX) / ratioX,
        (points[1].y + this.minY) / ratioY,
    
    */

    // console.log("updatedFloorPlan Before changes - ",updatedFloorPlan);

    var facesArray =
      updatedFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    var roofPoints =
      updatedFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

    var object = null,
      objects = this.canvas.getObjects();
    for (var i = 0, len = this.canvas.size(); i < len; i++) {
      object = objects[i];

      if (object.type == "WALL-LINE") {
        console.log(" object ", object);

        // console.log("facesArray with objec - ",facesArray);

        for (let facesIndex = 0; facesIndex < facesArray.length; facesIndex++) {
          let faceObject = facesArray[facesIndex];

          if (faceObject["@id"] == object.id) {
            faceObject["POLYGON"]["@unroundedsize"] = object.unroundedsize;
            facesArray[facesIndex] = faceObject;

            //Now update the points

            let linePointObjectArray = object.linePointObjectArray;

            for (
              let linePointObjectArrayIndex = 0;
              linePointObjectArrayIndex < linePointObjectArray.length;
              linePointObjectArrayIndex++
            ) {
              var pointObject = linePointObjectArray[linePointObjectArrayIndex];
              //console.log("pointObject - ",pointObject);
              //Iterate points

              for (
                let roofPointsIndex = 0;
                roofPointsIndex < roofPoints.length;
                roofPointsIndex++
              ) {
                let roofPointObject = roofPoints[roofPointsIndex];

                if (pointObject["@id"] == roofPointObject["@id"]) {
                  if (linePointObjectArrayIndex == 0) {
                    var dataX = (object.x1 + this.minX) / ratioX;
                    var dataY = (object.y1 + this.minY) / ratioY;

                    roofPointObject["@dataXY"] = dataX + "," + dataY;
                  } else {
                    var dataX = (object.x2 + this.minX) / ratioX;
                    var dataY = (object.y2 + this.minY) / ratioY;

                    // console.log("id - ",roofPointObject["@id"]);
                    // console.log("dataX - ",dataX);
                    // console.log("dataY - ",dataY);

                    roofPointObject["@dataXY"] = dataX + "," + dataY;
                  }
                }

                roofPoints[roofPointsIndex] = roofPointObject;
              }
            }

            // break;
          }
        }
      }
    }

    updatedFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
    updatedFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;

    console.log("updatedFloorPlan - ", updatedFloorPlan);

    //this.canvas.requestRenderAll();
  };

  onObjectChange = (options) => {
    options.target.setCoords();
    this.canvas.forEachObject(
      function (obj) {
        console.log("obj - ", obj);

        if (obj === options.target) return;
        //obj.set('opacity', options.target.intersectsWithObject(obj) ? 0.5 : 1);
      }.bind(this)
    );
  };

  makeCircle(left, top, line1, line2, color = "red") {
    var c = new fabric.Circle({
      left: left,
      top: top,
      strokeWidth: 5,
      radius: 3,
      fill: "#fff",
      stroke: color,
    });
    c.hasControls = c.hasBorders = false;

    c.line1 = line1;
    c.line2 = line2;

    return c;
  }

  // x0 = x coordinate of first point
  // y0 = y coordinate of first point
  // x1 = x coordinate of Second point
  // y1 = y coordinate of Second point
  approximateDistanceFromLine = 0.3;
  coordinateForlable(x0, x1, y0, y1, centreX, centreY, length) {
    let midPointX = (x0 + x1) / 2; //mid-point of line
    let midPointY = (y0 + y1) / 2;
    let distanceFromMidpoint = Math.sqrt(
      Math.pow(centreX - midPointX, 2) + Math.pow(centreY - midPointY, 2)
    );
    let lambda =
      this.approximateDistanceFromLine /
      (distanceFromMidpoint - this.approximateDistanceFromLine);
    let lablePointX = (lambda * centreX + midPointX) / (lambda + 1);
    let lablePointY = (lambda * centreY + midPointY) / (lambda + 1);
    let orientation = Math.atan2(y1 - y0, x1 - x0) * (180.0 / Math.PI);
    // console.error(orientation);
    // if(orientation < 0){
    //   orientation = orientation + 360;
    // }else{}
    // if(orientation > 90 && orientation < 270){
    //   var tempOrientation =  orientation + 180;
    //   if(tempOrientation > 360){
    //     orientation = tempOrientation - 360;
    //   }else{}
    // }else{}

    return {
      x: lablePointX,
      y: lablePointY,
      orientation,
    };
  }

  render() {
    return (
      <div>
        <button
          onClick={() => {
            this.editArea();
          }}
        >
          Edit
        </button>
        <canvas id="measurementcanvas" />
      </div>
    );
  }
}
