import React, { Component } from "react";
import { saveMeasurementJson } from "./../../../../actions/measurementAction";
import { connect } from "react-redux";
import { fabric } from "fabric";
import "fabric-history";
import * as THREE from "three";
import _ from "lodash";
import bgimg from "./../../../../images/box-pattern.png";
import "./index.scss";
import AreaDetails from "./areaDetails";

const STATE_IDLE = "idle";
const STATE_PANNING = "panning";

let modifiedEagleViewJson = {};

let designatorWiseObjectArray = {};
var roomWiseLineAndTextObjects = {};

var roomLinesGroup = [];
var roomTextGroup = [];
var roomConnectorGroup = [];

let ratioX = 1;
let ratioY = 1;

let originalFloorPlan = null;
let updatedFloorPlan = null;

// let PIXEL_TO_FOOT_CONSTANT = 0.015625;
let PIXEL_TO_FOOT_CONSTANT = 0.035;

let editedRoomID = 0;
let editedRoomTop = 0;
let editedRoomLeft = 0;
let editedRoomAngle = 0;
let isEditMode = false;

let editedRoomInitialLeft = 0;
let editedRoomInitialTop = 0;

let editedRoomEndlLeft = 0;
let editedRoomEndTop = 0;

let editedRoomFinalLeftDist = 0;
let editedRoomFinalTopDist = 0;

class MeasurementTab extends Component {
  canvas = null;
  maxX = 0;
  maxY = 0;
  minX = null;
  minY = null;
  canvasWidth = window.innerHeight - 400;
  canvasHeight = window.innerWidth - 400;

  constructor(props) {
    super();

    this.state = {
      areaDetails: {},
      floorList: [{ floorId: "", floorName: "" }],
      selectedFloor: 0,
    };
    this.onObjectChange = this.onObjectChange.bind(this);
    this.editArea = this.editArea.bind(this);
    this.createEditableRoom = this.createEditableRoom.bind(this);
  }
  async componentDidMount() {
    let canvas;

    this.canvasHeight = document.querySelector(
      "div.open.tab-content"
    ).clientHeight;

    this.canvasWidth = document.querySelector(
      "div.open.tab-content"
    ).clientWidth;

    canvas = new fabric.Canvas("measurementcanvas", {
      height: this.canvasHeight,
      width: this.canvasWidth,
      selection: false,
    });

    canvas.setBackgroundColor(
      {
        source: bgimg,
      },
      canvas.renderAll.bind(canvas)
    );

    fabric.Canvas.prototype.toggleDragMode = function (dragMode) {
      // Remember the previous X and Y coordinates for delta calculations
      let lastClientX;
      let lastClientY;
      // Keep track of the state
      let state = STATE_IDLE;
      // We're entering dragmode
      if (dragMode) {
        // Discard any active object
        this.discardActiveObject();
        // Set the cursor to 'move'
        this.defaultCursor = "move";
        // Loop over all objects and disable events / selectable. We remember its value in a temp variable stored on each object
        this.forEachObject(function (object) {
          object.prevEvented = object.evented;
          object.prevSelectable = object.selectable;
          object.evented = false;
          object.selectable = false;
        });
        // Remove selection ability on the canvas
        this.selection = false;
        // When MouseUp fires, we set the state to idle
        this.on("mouse:up", function (e) {
          state = STATE_IDLE;
        });
        // When MouseDown fires, we set the state to panning
        this.on("mouse:down", (e) => {
          state = STATE_PANNING;
          lastClientX = e.e.clientX;
          lastClientY = e.e.clientY;
        });
        // When the mouse moves, and we're panning (mouse down), we continue
        this.on("mouse:move", (e) => {
          if (state === STATE_PANNING && e && e.e) {
            // let delta = new fabric.Point(e.e.movementX, e.e.movementY); // No Safari support for movementX and movementY
            // For cross-browser compatibility, I had to manually keep track of the delta

            // Calculate deltas
            let deltaX = 0;
            let deltaY = 0;
            if (lastClientX) {
              deltaX = e.e.clientX - lastClientX;
            }
            if (lastClientY) {
              deltaY = e.e.clientY - lastClientY;
            }
            // Update the last X and Y values
            lastClientX = e.e.clientX;
            lastClientY = e.e.clientY;

            let delta = new fabric.Point(deltaX, deltaY);
            this.relativePan(delta);
            //   this.trigger('moved');
          }
        });
      } else {
        // When we exit dragmode, we restore the previous values on all objects
        this.forEachObject(function (object) {
          object.evented =
            object.prevEvented !== undefined
              ? object.prevEvented
              : object.evented;
          object.selectable =
            object.prevSelectable !== undefined
              ? object.prevSelectable
              : object.selectable;
        });
        // Reset the cursor
        this.defaultCursor = "default";
        // Remove the event listeners
        this.off("mouse:up");
        this.off("mouse:down");
        this.off("mouse:move");
        // Restore selection ability on the canvas
        this.selection = true;
      }
    };

    fabric.Canvas.prototype.getItemByAttr = function (attr, name) {
      var object = null,
        objects = this.getObjects();
      for (var i = 0, len = this.size(); i < len; i++) {
        if (objects[i][attr] && objects[i][attr] === name) {
          object = objects[i];
          break;
        }
      }
      return object;
    };

    this.canvas = canvas;

    /* */
    var xhr = new XMLHttpRequest();
    // xhr.open("GET", "/room_22_06.json", true);
    xhr.open("GET", "/multifloor_json.json", true);

    xhr.responseType = "json";
    xhr.send(null);
    xhr.onload = function (response) {
      console.log(response.target.response);

      console.log("response.target.response - ", response.target.response);

      originalFloorPlan = _.cloneDeep(response.target.response);
      updatedFloorPlan = _.cloneDeep(response.target.response);
      this.showTheListFromJsonRoomWise(response.target.response);
    }.bind(this);

    console.log(this.props.mesurementData.jsonData);
    // console.log("this.props.mesurementData.jsonData - ", JSON.stringify(this.props.mesurementData.jsonData));

    /* Live 

    if (_.isObject(this.props.mesurementData.jsonData)) {
      //updatedFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);

      //console.log("newJson - ", newJson);
      originalFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);
      updatedFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);

      this.showTheListFromJsonRoomWise(updatedFloorPlan);
    } else {
      // console.log("show error - ");
    }*/
  }

  async showTheListFromJsonRoomWise(json) {
    // console.log("showTheListFromJsonRoomWise - ", json);

    var jsonObject = json;
    var floorArray = [];

    // originalFloorPlan = json;
    //updatedFloorPlan = _.cloneDeep(originalFloorPlan);

    if (jsonObject.EAGLEVIEW_EXPORT.STRUCTURES == null) {
      // console.log("err");
      return;
    }

    var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    var roofPointsArray = roofPoints[0]["POINT"];

    var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    var linesArray = lines[0].LINE;

    var faceArray = roofObject[0]["FACES"]["FACE"];

    designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = faceArray[faceArrayIndex];

      // console.log("roomFaceObject - ", roomFaceObject);

      if (
        designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
        roomFaceObject["@type"] == "ROOM"
      ) {
        //Get walls of room

        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");
        // console.log("roomChildrenArray - ", roomChildrenArray);

        //Not iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];
            // console.log("faceObject - ", faceObject);

            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              var lineId = faceObject["POLYGON"]["@path"];

              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  var linePointObjectArray = [];
                  var linePoints = lineObject["@path"].split(",");
                  for (
                    var linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];
                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        linePointObjectArray.push(roofPointObject);

                        break;
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["LINE"] = lineObject;
                  faceArray[faceArrayIndex] = faceObject;
                }
              }

              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            }
          }
        }
      } else {
        //TBD. NOT IN USE.
      }
    }

    // // console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    this.canvas.viewportTransform[4] = 0;
    this.canvas.viewportTransform[5] = 0;

    this.canvas.isDrawingMode = false;
    this.canvas.freeDrawingBrush.width = 5;
    this.canvas.freeDrawingBrush.color = "red";

    var pointer = {
      x: 0,
      y: 0,
    };

    let options = { pointer, e: {} }; // required for Fabric 4.3.1

    this.canvas.freeDrawingBrush.onMouseDown(pointer, options);

    // console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    let roomArray = Object.keys(designatorWiseObjectArray);
    // console.log("roomArray 1 - ", roomArray);

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      // console.log("roomObject - ", roomObjectArray);

      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];

        if (wallObject.LINE == null) {
          floorArray.push({
            floorId: parseInt(wallObject["@floorindex"]),
            floorName: "Floor " + parseInt(wallObject["@floorindex"]),
          });
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];
          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

          if (parseFloat(v1[0]) > this.maxX) {
            this.maxX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) > this.maxY) {
            this.maxY = parseFloat(v1[1]);
          }

          if (this.minX == null) {
            this.minX = this.maxX;
          }
          if (this.minY == null) {
            this.minY = this.maxY;
          }

          if (parseFloat(v1[0]) < this.minX) {
            this.minX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) < this.minY) {
            this.minY = parseFloat(v1[1]);
          }
        }
      }
    }

    // this.canvasHeight = this.maxY - this.minY;
    // this.canvasWidth = this.maxX - this.minX;

    // console.log("canvasWidth starting - ",this.canvasWidth);
    // console.log("canvasHeight starting - ",this.canvasHeight);

    this.canvas.setHeight(this.canvasHeight + 50);
    this.canvas.setWidth(this.canvasWidth + 50);

    ratioX = 1;
    ratioY = 1;

    let multiplierX = 1;
    if (this.maxX - this.minX < this.canvasWidth) {
      ratioX = (this.canvasWidth / (this.maxX - this.minX)) * multiplierX;
    } else {
      ratioX = ((this.maxX - this.minX) / this.canvasWidth) * multiplierX;
    }

    if (this.maxY - this.minY < this.canvasHeight) {
      ratioY =
        (this.canvasHeight / (this.maxY - this, this.minY)) * multiplierX;
    } else {
      ratioY = ((this.maxY - this.minY) / this.canvasHeight) * multiplierX;
    }

    ratioX = Math.ceil(ratioX);
    ratioY = Math.ceil(ratioY);

    const maxRatio = ratioX > ratioY ? ratioX : ratioY;

    this.ratioX = ratioX = 1 / maxRatio;
    this.ratioY = ratioY = 1 / maxRatio;
    PIXEL_TO_FOOT_CONSTANT *= 1 / ratioX;

    floorArray = _.uniq(floorArray);
    floorArray = _.uniqBy(floorArray, "floorId");

    floorArray = _.sortBy(floorArray, ["floorId"]);
    console.log("floorArray - ", floorArray);
    console.log(
      "designatorWiseObjectArray before draw - ",
      designatorWiseObjectArray
    );

    this.setState(
      {
        floorList: floorArray,
        selectedFloor: floorArray[0].floorId,
      },
      () => {}
    );

    let selectedFloorIndex = 3;

    //Now only get those room which has specific floor index;

    let selectedFloorRooms = [];
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      if (roomObjectArray[0]["@floorindex"] == selectedFloorIndex) {
        selectedFloorRooms.push(roomArray[roomArrayIndex]);
      }
    }

    console.log("selectedFloorRooms - ", selectedFloorRooms);

    //Now start drawing

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < selectedFloorRooms.length;
      roomArrayIndex++
    ) {
      var areaName = "";
      var roomArea = "";
      var roomID = "";

      let roomObjectArray =
        designatorWiseObjectArray[selectedFloorRooms[roomArrayIndex]];

      //if(roomLinesGroup[""])

      roomLinesGroup = [];
      roomTextGroup = [];
      roomConnectorGroup = [];

      var connectorCircleGroup = [];

      var wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];

        console.log("wallObject - ", wallObject);

        let wallID = wallObject["@id"];

        if (wallObject.LINE == null) {
          areaName = wallObject["@areaname"];
          roomArea = wallObject["@area"];
          roomID = wallObject["@id"];

          roomWiseLineAndTextObjects[roomID] = {};
          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomCircleGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          //TBD
        } else {
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;
        var poligonObject = wallObject.POLYGON;

        let points = [];

        // console.log("linePointObjectArray - ", linePointObjectArray);

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];

          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }

        // console.log("points - ", points);
        //Add line
        if (points.length < 2) {
          break;
        }

        var line = null;

        //var color = wallNo % 2 == 0 ? "#fe741f" : "black";
        var color = "black";

        // console.log("wallNo - ", wallNo);
        // console.log("color - ", color);

        // console.log("points - ", points);

        line = new fabric.Line(
          [
            (points[0].x - this.minX) * ratioX,
            (points[0].y - this.minY) * ratioY,
            (points[1].x - this.minX) * ratioX,
            (points[1].y - this.minY) * ratioY,
          ],
          {
            stroke: color,
            strokeWidth: 2,
            selectable: false,
            evented: false,
            id: wallID,
            roomID: roomID,
            type: "WALL-LINE",
            linePointObjectArray: linePointObjectArray,
            unroundedsize: wallObject["POLYGON"]["@unroundedsize"],
            size: wallObject["POLYGON"]["@size"],
            areaName: areaName,
            roomArea: roomArrayIndex,
          }
        );

        // console.log("line - ", line);

        let textLeftPosition = line.get("x1");
        let textTopPosition = line.get("y1");
        let moveLeft = false;
        let moveTop = false;

        var unRoundedSize = parseFloat(poligonObject["@unroundedsize"]);

        var unRoundedSizeFeet =
          parseFloat(unRoundedSize * 3.28084).toFixed(2) + " ft";

        let sizes = poligonObject["@unroundedsize"].split(".");
        let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";
        let tempPoints = sizes && sizes.length > 1 ? sizes[1] : "";
        // let inch = (tempPoints * 12) / 100;
        // inch = parseInt(inch * 100);
        let unRoundedSizeFeetLabel = tempFoot + "' " + tempPoints + "''";

        var text = new fabric.Text(unRoundedSizeFeetLabel, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: 10,
          left: textLeftPosition,
          top: textTopPosition,
          angle: wallNo == 2 || wallNo == 4 ? 90 : 0,
          fill: color,
          id: wallID,
          roomID: roomID,
          objectCaching: false,
          type: "LABEL",
          selectable: false,
          textAlign: "center",
          visible: false,
        });

        var coordinateForLable = this.coordinateForlable(
          line.x1,
          line.x2,
          line.y1,
          line.y2,
          text.left,
          text.top
        );

        text.set("left", coordinateForLable.x);
        text.set("top", coordinateForLable.y);
        text.set("angle", coordinateForLable.orientation);

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);

        //We don't want wall label in group
        roomTextGroup.push(text);
        roomLinesGroup.push(line);

        //this.canvas.add(text);

        if (isWallPenetration == false) {
          wallNo++;
        } else {
        }
      }

      // this.canvas.renderAll();
      // console.log("roomLinesGroup.length - ", roomLinesGroup.length);

      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        //var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";
        var color = "black";

        // Connectors

        var circle = null;
        if (roomLinesGroupArrayIndex == 0) {
          // console.log("else 0");
          circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color
          );

          // this.canvas.add(circle);
        } else {
          // console.log("else");
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            // console.log("else 1");

            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            // this.canvas.add(circle);
            //roomConnectorGroup.push(circle);
          } else {
            // console.log("else 2 - ", roomLinesGroupArrayIndex);
            // console.log("else 2 - ", roomLinesGroup[roomLinesGroupArrayIndex]);

            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            //connectorCircleGroup.push(circle);
            //roomConnectorGroup.push(circle);
          }

          // this.canvas.add(circle);
        }

        //roomWiseLineAndTextObjects[roomID]["roomCircleGroup"].push(circle);
        // connectorCircleGroup.push(circle);

        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }

      let totalPoints = roomLinesGroup.length;

      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        var textObject = this.canvas.getItemByAttr("id", roomID);
        // console.log("got textObject - ", textObject);

        textObject.set(
          "left",
          areaLabelLeft - textObject.getBoundingRect().width / 2
        );

        textObject.set(
          "top",
          areaLabelTop - textObject.getBoundingRect().height / 2
        );

        // this.canvas.renderAll();
      } else {
        //Add label
        // console.log("not found add");

        if (roomArea.trim().length == 0) {
          roomArea = ".";
        }
        let roomAreaSpilts = roomArea.split(".");
        let tempCalculatedAreaInFoot =
          roomAreaSpilts && roomAreaSpilts.length > 0 ? roomAreaSpilts[0] : "";
        let tempCalculatedAreaPoints =
          roomAreaSpilts && roomAreaSpilts.length > 1 ? roomAreaSpilts[1] : "";
        // let calculatedAreaInch = (tempCalculatedAreaPoints * 12) / 100;
        // calculatedAreaInch = parseInt(calculatedAreaInch * 100);
        let calculatedArea =
          tempCalculatedAreaInFoot != ""
            ? tempCalculatedAreaInFoot + "' " + tempCalculatedAreaPoints + "''"
            : "";

        let centerBoxText = calculatedArea + "\n" + areaName;
        var text = new fabric.Text(centerBoxText, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: 10,
          left: areaLabelLeft,
          top: areaLabelTop,
          angle: 0,
          fill: "#000",
          id: roomID,
          objectCaching: false,
          textAlign: "center",
          selectable: false,
          textAlign: "center",
          type: "CENTRE-BOX-TEXT",
        });

        // this.canvas.add(text);
        roomTextGroup.push(text);
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
      }

      var roomDrawingObjectArray = roomLinesGroup.concat(roomTextGroup);
      //roomDrawingObjectArray = roomDrawingObjectArray.concat(roomConnectorGroup);

      var group = new fabric.Group(roomDrawingObjectArray, {
        id: "GROUP-" + roomID,
        roomID: roomID,
        lockScalingX: true,
        lockScalingY: true,
        objectCaching: false,
        selectable: true,
        type: "GROUP",
        subTargetCheck: true,
        backgroundColor: "red",
        fill: "blue",
      });

      group.setControlsVisibility({
        mt: false,
        mb: false,
        ml: false,
        mr: false,
      });

      this.canvas.add(group);

      group.initialLeft = group.left;
      group.initialTop = group.top;
    }

    this.canvas.renderAll();

    this.canvas.on(
      "mouse:dblclick",
      function (e) {
        // console.log("mouse click - ", e);
        console.log("mouse dblclick target - ", e.target);
        console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

        if (e.target == null) {
          return;
        }
        isEditMode = true;

        //Add this object in canvas....
        // let roomObjects = e.target._objects;

        editedRoomID = e.target.roomID;

        editedRoomTop = e.target.top;
        editedRoomLeft = e.target.left;

        editedRoomFinalTopDist = e.target.top - e.target.initialTop;
        editedRoomFinalLeftDist = e.target.left - e.target.initialLeft;

        editedRoomAngle = e.target.angle ? e.target.angle : 0;

        let targetRoomId = e.target.roomID;

        console.log("targetRoomId - ", targetRoomId);

        this.canvas.remove(
          this.canvas.getItemByAttr("id", "GROUP-" + targetRoomId)
        );

        // this.canvas.renderAll();

        this.createEditableRoom(targetRoomId);
        console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);
      }.bind(this)
    );

    // mousedown:before

    // mousemove:before

    this.canvas.on(
      "mouse:up",
      function (e) {
        this.canvas.renderAll();

        if (e.target != null) {
          editedRoomEndlLeft = e.target.left;
          editedRoomEndTop = e.target.top;

          if (e.target.type == "GROUP") {
            let roomID = e.target.roomID;

            editedRoomFinalLeftDist =
              editedRoomEndlLeft - editedRoomInitialLeft;
            editedRoomFinalTopDist = editedRoomEndTop - editedRoomInitialTop;

            let absoluteDistanceLeft = Math.abs(editedRoomFinalLeftDist);
            let absoluteDistanceTop = Math.abs(editedRoomFinalTopDist);
            if (absoluteDistanceLeft < 3 && absoluteDistanceTop < 3) {
              return;
            }

            //Update json here...

            this.updateFloorPlanOnMove(roomID, linesArray);
          }
        }
      }.bind(this)
    );

    this.canvas.on(
      "mouse:down",
      function (e) {
        // clicked item will be
        // console.log("mouse down - ", e);
        console.log("mouse down - ", e.target);
        console.log(
          "designatorWiseObjectArray 1 - ",
          designatorWiseObjectArray
        );

        if (e.target != null) {
          editedRoomInitialLeft = e.target.left;
          editedRoomInitialTop = e.target.top;

          // console.log("mouse down id - ", e.target.id);
          console.log(
            "designatorWiseObjectArray 2 - ",
            designatorWiseObjectArray
          );

          // console.log("editedRoomInitialLeft - ", editedRoomInitialLeft);
          // console.log("editedRoomInitialTop - ", editedRoomInitialTop);
        }

        if (e.target == null) {
          console.log("mouse:down isEditMode - ", isEditMode);
          console.log("mouse:down editedRoomID - ", editedRoomID);

          if (isEditMode == true && editedRoomID != 0) {
            this.editArea();

            let roomObject = roomWiseLineAndTextObjects[editedRoomID];

            let roomLinesGroup = roomObject["roomLinesGroup"];
            let roomTextGroup = roomObject["roomTextGroup"];

            let roomCircleGroup = roomObject["roomCircleGroup"];

            for (
              let roomCircleGroupIndex = 0;
              roomCircleGroupIndex < roomCircleGroup.length;
              roomCircleGroupIndex++
            ) {
              let circleObject = roomCircleGroup[roomCircleGroupIndex];
              this.canvas.remove(circleObject);
            }

            var roomDrawingObjectArray = roomLinesGroup.concat(roomTextGroup);
            //roomDrawingObjectArray = roomDrawingObjectArray.concat(roomConnectorGroup);

            var group = new fabric.Group(roomDrawingObjectArray, {
              // left: 150,
              // top: 100,
              // angle: -10

              id: "GROUP-" + editedRoomID,
              roomID: editedRoomID,
              lockScalingX: true,
              lockScalingY: true,
              objectCaching: false,
              selectable: true,
              type: "GROUP",
              subTargetCheck: true,
              backgroundColor: "red",
              fill: "blue",
            });

            group.setControlsVisibility({
              mt: false,
              mb: false,
              ml: false,
              mr: false,
            });

            this.canvas.add(group);

            group.initialLeft = group.left;
            group.initialTop = group.top;

            for (
              let roomTextGroupIndex = 0;
              roomTextGroupIndex < roomTextGroup.length;
              roomTextGroupIndex++
            ) {
              let textObject = roomTextGroup[roomTextGroupIndex];
              this.canvas.remove(textObject);
            }

            for (
              let roomLineGroupIndex = 0;
              roomLineGroupIndex < roomLinesGroup.length;
              roomLineGroupIndex++
            ) {
              let lineObject = roomLinesGroup[roomLineGroupIndex];
              this.canvas.remove(lineObject);
            }

            isEditMode = false;
            editedRoomID = 0;
            // console.log("originalFloorPlan after mouse down - ", originalFloorPlan);
          }
        }
      }.bind(this)
    );

    let canvasHeight = document.querySelector(
      "div.open.tab-content"
    ).clientHeight;

    let canvasWidth = document.querySelector(
      "div.open.tab-content"
    ).clientWidth;

    this.canvas.setHeight(canvasHeight);
    this.canvas.setWidth(canvasWidth);

    this.canvas.renderAll();

    // Ends drawing

    var printedAreaName = [];

    this.canvas.on(
      "object:moving",
      function (e) {
        var p = e.target;

        // console.log("p - ", p);
        if (p.type == "GROUP") {
          return;
        }

        let roomID = p.line1.roomID;
        let areaName = p.line1.areaName;
        let roomArea = p.line1.roomArea;

        // console.log("roomID - ", roomID);

        let roomTextGroup = roomWiseLineAndTextObjects[roomID]["roomTextGroup"];

        p.line1 && p.line1.set({ x2: p.left, y2: p.top });
        p.line2 && p.line2.set({ x1: p.left, y1: p.top });

        /*
        CALCULATION: Calculating width of first wall connected with point wall
        */
        var width1 =
          Math.sqrt(
            p.line1.width * p.line1.width + p.line1.height * p.line1.height
          ) * PIXEL_TO_FOOT_CONSTANT;

        let tempFoot = parseInt(width1);
        let tempPoints = width1 - tempFoot;
        let inch = (tempPoints * 100 * 12) / 100;
        inch = parseInt(inch);

        let unroundedSize = tempFoot + "." + inch;

        //Now based on id of wall find label and update position

        // console.log("roomTextGroup -", roomTextGroup);

        for (
          let roomTextGroupIndex = 0;
          roomTextGroupIndex < roomTextGroup.length;
          roomTextGroupIndex++
        ) {
          let label = roomTextGroup[roomTextGroupIndex];

          if (label.id == p.line1.id) {
            // console.log("label  -", label);

            var left = (p.line1.x1 + p.line1.x2) / 2;
            var top = (p.line1.y1 + p.line1.y2) / 2;

            var textObject = this.canvas.getItemByAttr("id", roomID);
            var coordinateForLable = this.coordinateForlable(
              p.line1.x1,
              p.line1.x2,
              p.line1.y1,
              p.line1.y2,
              textObject.left,
              textObject.top
            );

            label.set("left", coordinateForLable.x);
            label.set("top", coordinateForLable.y);
            label.set("angle", coordinateForLable.orientation);

            //p.line1.unroundedsize = width1;
            p.line1.unroundedsize = unroundedSize;
            p.line1.size = Math.ceil(parseFloat(unroundedSize));

            //let wallLabel = parseFloat(width1).toFixed(2) + " ft";
            let wallLabel = tempFoot + "' " + inch + "''";

            label.set("text", wallLabel);

            break;
          }
        }

        /*
        CALCULATION: Calculating width of second wall connected with point wall
        */

        var width2 =
          Math.sqrt(
            p.line2.width * p.line2.width + p.line2.height * p.line2.height
          ) * PIXEL_TO_FOOT_CONSTANT;

        tempFoot = parseInt(width2);
        tempPoints = width2 - tempFoot;
        inch = (tempPoints * 100 * 12) / 100;
        inch = parseInt(inch);
        unroundedSize = tempFoot + "." + inch;

        for (
          let roomTextGroupIndex = 0;
          roomTextGroupIndex < roomTextGroup.length;
          roomTextGroupIndex++
        ) {
          let label = roomTextGroup[roomTextGroupIndex];

          if (label.id == p.line2.id) {
            // console.log("label  -", label);

            var left = (p.line2.x1 + p.line2.x2) / 2;
            var top = (p.line2.y1 + p.line2.y2) / 2;
            var textObject = this.canvas.getItemByAttr("id", roomID);
            var coordinateForLable = this.coordinateForlable(
              p.line2.x1,
              p.line2.x2,
              p.line2.y1,
              p.line2.y2,
              textObject.left,
              textObject.top
            );

            // console.log("label2 left -", left);
            // console.log("label2 top -", top);

            label.set("left", coordinateForLable.x);

            label.set("top", coordinateForLable.y);
            label.set("angle", coordinateForLable.orientation);

            // p.line2.unroundedsize = width2;
            p.line2.unroundedsize = unroundedSize;
            p.line2.size = Math.ceil(parseFloat(unroundedSize));

            //let wallLabel = parseFloat(width2).toFixed(2) + " ft";

            let wallLabel = tempFoot + "' " + inch + "''";

            label.set("text", wallLabel);

            break;
          }
        }

        //Now based on Rooms, calculate the center point of label

        // designatorWiseObjectArray

        let roomArray = Object.keys(designatorWiseObjectArray);
        // console.log("roomArray 1 - ", roomArray);
        // console.log("roomWiseLineAndTextObjects - ",roomWiseLineAndTextObjects);

        roomLinesGroup = roomWiseLineAndTextObjects[roomID]["roomLinesGroup"];
        roomTextGroup = roomWiseLineAndTextObjects[roomID]["roomTextGroup"];
        roomArea = roomWiseLineAndTextObjects[roomID]["roomArea"];

        let roomCenterPointX = 0;
        let roomCenterPointY = 0;

        for (
          let roomLinesGroupIndex = 0;
          roomLinesGroupIndex < roomLinesGroup.length;
          roomLinesGroupIndex++
        ) {
          roomCenterPointX +=
            (roomLinesGroup[roomLinesGroupIndex].x1 +
              roomLinesGroup[roomLinesGroupIndex].x2) /
            2;
          roomCenterPointY +=
            (roomLinesGroup[roomLinesGroupIndex].y1 +
              roomLinesGroup[roomLinesGroupIndex].y2) /
            2;
        }

        let totalPoints = roomLinesGroup.length;

        // console.log("roomCenterPointX - ", roomCenterPointX / totalPoints);
        // console.log("roomCenterPointY - ", roomCenterPointY / totalPoints);

        let areaLabelLeft = roomCenterPointX / totalPoints;
        let areaLabelTop = roomCenterPointY / totalPoints;

        /*
        CALCULATION: Calculating area based on Wall of Room
        */

        var object = null;
        var objects = this.canvas.getObjects();
        var cordinateArray = [];

        for (var i = 0, len = this.canvas.size(); i < len; i++) {
          object = objects[i];

          if (object.type == "WALL-LINE") {
            if (object.roomID == roomID) {
              cordinateArray.push(object.x1);
              cordinateArray.push(object.y1);

              cordinateArray.push(object.x2);
              cordinateArray.push(object.y2);
            }
          }
        }

        var areaSum = 0;

        //Sample from net for Numbers
        //cordinateArray = [1,1,3,1,3,3,1,3,1,1];

        // Process pairs, increment by 2 and stop at length - 2
        for (
          var i = 0, cordinateArrayIndex = cordinateArray.length - 2;
          i < cordinateArrayIndex;
          i += 2
        ) {
          areaSum +=
            cordinateArray[i] * cordinateArray[i + 3] -
            cordinateArray[i + 2] * cordinateArray[i + 1];
        }

        // console.log("areaSum - ", areaSum);

        // CALCULATION OF AREA

        var calculatedArea =
          Math.abs(areaSum / 2) *
          PIXEL_TO_FOOT_CONSTANT *
          PIXEL_TO_FOOT_CONSTANT;
        // var calculatedArea =  Math.abs(areaSum / 2);

        //console.log("calculatedArea - ", calculatedArea);

        let tempCalculatedAreaInFoot = parseInt(calculatedArea);
        let tempCalculatedAreaPoints =
          calculatedArea - tempCalculatedAreaInFoot;
        let calculatedAreaInch = (tempCalculatedAreaPoints * 12) / 100;
        calculatedAreaInch = parseInt(calculatedAreaInch * 100);

        let calculatedAreaInchPoints =
          tempCalculatedAreaInFoot + "." + calculatedAreaInch;

        //calculatedArea = calculatedArea.toFixed(2);
        //calculatedArea = calculatedArea.toFixed(2);
        calculatedArea =
          tempCalculatedAreaInFoot + "' " + calculatedAreaInch + "''";

        //Ends

        if (this.canvas.getItemByAttr("id", roomID) != null) {
          //this.canvas.getItemByAttr('id', "room1").remove();
          var textObject = this.canvas.getItemByAttr("id", roomID);
          // console.log("got textObject - ", textObject);

          textObject.set(
            "left",
            areaLabelLeft - textObject.getBoundingRect().width / 2
          );

          textObject.set(
            "top",
            areaLabelTop - textObject.getBoundingRect().height / 2
          );

          //let sub = "2".sup();

          let calculatedAreaText = calculatedArea + " ";
          let centerBoxText = calculatedAreaText + "\n" + areaName;

          textObject.set("text", centerBoxText);
          textObject.set("area", calculatedAreaInchPoints);

          // this.canvas.renderAll();
        } else {
          //Add label
          console.log("not found add");

          var text = new fabric.Text(roomArea, {
            fontFamily: '"Roboto", sans-serif',
            fontSize: 10,
            left: areaLabelLeft,
            top: areaLabelTop,
            angle: 0,
            fill: "Red",
            id: roomID,
            objectCaching: false,
            textAlign: "center",
            selectable: false,
          });

          this.canvas.add(text);
        }
        this.canvas.renderAll();
      }.bind(this)
    );

    /* */
    this.canvas.on(
      "mouse:wheel",
      function (opt) {
        var delta = opt.e.deltaY;
        var zoom = this.canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        this.canvas.setZoom(zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }.bind(this)
    );

    this.canvas.on({
      "object:scaling": this.onObjectChange,
      "object:rotated": this.onObjectChange,
      "object:rotating": this.onObjectChange,
    });

    // this.canvas.toggleDragMode(true);
  }

  drawFloorPlan = () => {};

  editArea = () => {
    //Iterate canvas and get all lines , room wise...

    // console.log("ratioX - ", ratioX);
    // console.log("ratioY - ", ratioY);

    // console.log("this.minX - ", this.minX);
    // console.log("this.minY - ", this.minY);

    /* Need to do reverse of drawing points
    
        (points[0].x + this.minX) / ratioX,
        (points[0].y + this.minY) / ratioY,
        (points[1].x + this.minX) / ratioX,
        (points[1].y + this.minY) / ratioY,
    
    */

    // console.log("originalFloorPlan Before changes - ", originalFloorPlan);
    let copyOriginal = _.cloneDeep(originalFloorPlan);

    var facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    var roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

    var object = null;
    var objects = this.canvas.getObjects();

    //  console.log("objects - ",objects);

    // console.log(" facesArray ", facesArray);

    let ratioX = this.ratioX;
    let ratioY = this.ratioX;

    for (var i = 0, len = this.canvas.size(); i < len; i++) {
      object = objects[i];

      if (object.type == "CENTRE-BOX-TEXT") {
        for (let facesIndex = 0; facesIndex < facesArray.length; facesIndex++) {
          let faceObject = facesArray[facesIndex];

          if (faceObject["@type"] == "ROOM" && faceObject["@id"] == object.id) {
            faceObject["@area"] = object.area;
            facesArray[facesIndex] = faceObject;
            break;
          }
        }
      } else if (object.type == "WALL-LINE") {
        // console.log("facesArray with objec - ",facesArray);

        for (let facesIndex = 0; facesIndex < facesArray.length; facesIndex++) {
          let faceObject = facesArray[facesIndex];

          if (faceObject["@id"] == object.id) {
            // console.log("matching face object ", faceObject);

            faceObject["POLYGON"]["@unroundedsize"] = object.unroundedsize;
            faceObject["POLYGON"]["@size"] = object.size;
            facesArray[facesIndex] = faceObject;

            //Now update the points

            let linePointObjectArray = object.linePointObjectArray;

            for (
              let linePointObjectArrayIndex = 0;
              linePointObjectArrayIndex < linePointObjectArray.length;
              linePointObjectArrayIndex++
            ) {
              var pointObject = linePointObjectArray[linePointObjectArrayIndex];
              //console.log("pointObject - ",pointObject);
              //Iterate points

              for (
                let roofPointsIndex = 0;
                roofPointsIndex < roofPoints.length;
                roofPointsIndex++
              ) {
                let roofPointObject = roofPoints[roofPointsIndex];

                if (pointObject["@id"] == roofPointObject["@id"]) {
                  if (linePointObjectArrayIndex == 0) {
                    var dataX = object.x1 / ratioX + this.minX;
                    var dataY = object.y1 / ratioY + this.minY;
                    roofPointObject["@dataXY"] = dataX + "," + dataY;
                  } else {
                    var dataX = object.x2 / ratioX + this.minX;
                    var dataY = object.y2 / ratioY + this.minY;
                    roofPointObject["@dataXY"] = dataX + "," + dataY;
                  }
                }

                roofPoints[roofPointsIndex] = roofPointObject;
              }
            }
          }
        }
      }
    }

    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;

    originalFloorPlan = _.cloneDeep(copyOriginal);

    // console.log("updatedFloorPlan - ", updatedFloorPlan);

    var roofObject = [copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    var roofPoints = [copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    var roofPointsArray = roofPoints[0]["POINT"];

    var lines = [copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    var linesArray = lines[0].LINE;

    var faceArray = roofObject[0]["FACES"]["FACE"];

    // console.log("updatedFloorPlan faceArray - ", faceArray);

    designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = faceArray[faceArrayIndex];

      // console.log("roomFaceObject - ", roomFaceObject);

      if (
        designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
        roomFaceObject["@type"] == "ROOM"
      ) {
        //Get walls of room

        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");
        // console.log("roomChildrenArray - ", roomChildrenArray);

        //Now iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];

            // console.log("faceObject - ", faceObject);

            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              var lineId = faceObject["POLYGON"]["@path"];

              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  var linePointObjectArray = [];
                  var linePoints = lineObject["@path"].split(",");
                  for (
                    var linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];
                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        linePointObjectArray.push(roofPointObject);

                        break;
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["LINE"] = lineObject;
                  faceArray[wallFaceObjectIndex] = faceObject;
                }
              }

              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            }
          }
        }
      }
    }

    // console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    //console.log("Edit Area designatorWiseObjectArray - ", designatorWiseObjectArray);

    //Ends
    editedRoomLeft = 0;
    editedRoomTop = 0;

    // this.canvas.clear();
    // this.showTheListFromJsonRoomWise(updatedFloorPlan);
  };

  saveArea = () => {
    const data = {
      jobOrderId: this.props.jobOrderId,
      jsonData: originalFloorPlan,
    };

    this.props.saveMeasurementJson(data);
  };

  createEditableRoom = (targetRoomId) => {
    //Now start drawing
    let roomArray = Object.keys(designatorWiseObjectArray);
    console.log("createEditableRoom roomArray - ", roomArray);
    console.log("createEditableRoom targetRoomId - ", targetRoomId);
    console.log("createEditableRoom editedRoomID - ", editedRoomID);

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      var areaName = "";
      var roomArea = "";
      var roomID = "";

      if (roomArray[roomArrayIndex] != editedRoomID) {
        continue;
      }

      editedRoomLeft = editedRoomLeft;
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];

      console.log("roomObjectArray - ", roomObjectArray);

      //if(roomLinesGroup[""])

      roomLinesGroup = [];
      roomTextGroup = [];
      roomConnectorGroup = [];

      var wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];

        let wallID = wallObject["@id"];

        console.log("wallID - ", wallID);

        if (wallObject.LINE == null) {
          console.log("found main room - ");

          areaName = wallObject["@areaname"];
          roomArea = wallObject["@area"];
          roomID = wallObject["@id"];

          roomWiseLineAndTextObjects[roomID] = {};
          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomCircleGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          //TBD
        } else {
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;
        var poligonObject = wallObject.POLYGON;

        let points = [];

        console.log("linePointObjectArray - ", linePointObjectArray);

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];

          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }

        console.log("points - ", points);
        //Add line
        if (points.length < 2) {
          break;
        }

        var line = null;

        //var color = wallNo % 2 == 0 ? "#fe741f" : "black";
        var color = "black";

        editedRoomLeft = editedRoomFinalLeftDist;
        editedRoomTop = editedRoomFinalTopDist;

        let ratioX = this.ratioX;
        let ratioY = this.ratioX;

        console.log("ratioX - ", ratioX);
        console.log("minX - ", this.minX);
        console.log("points[0].x - ", points[0].x);

        let point0X = (points[0].x - this.minX) * ratioX;
        let point1X = (points[1].x - this.minX) * ratioX;

        let point0Y = (points[0].y - this.minY) * ratioY;
        let point1Y = (points[1].y - this.minY) * ratioY;

        console.log("points1 - ", [point0X, point0Y]);
        console.log("points2 - ", [point1X, point1Y]);

        line = new fabric.Line([point0X, point0Y, point1X, point1Y], {
          stroke: color,
          strokeWidth: 2,
          selectable: false,
          evented: false,
          id: wallID,
          roomID: roomID,
          type: "WALL-LINE",
          linePointObjectArray: linePointObjectArray,
          unroundedsize: wallObject["POLYGON"]["@unroundedsize"],
          size: wallObject["POLYGON"]["@size"],
          areaName: areaName,
          roomArea: roomArrayIndex,
          // angle: editedRoomAngle,
          // angle: 0,
        });

        console.log("edit line - ", line);

        // line.rotate(editedRoomAngle);

        let textLeftPosition = line.get("x1");
        let textTopPosition = line.get("y1");

        var unRoundedSize = parseFloat(poligonObject["@unroundedsize"]);

        var unRoundedSizeFeet =
          parseFloat(unRoundedSize * 3.28084).toFixed(2) + " ft";

        //unRoundedSize = unRoundedSize.toFixed(2) + " ft";
        let sizes = poligonObject["@unroundedsize"].split(".");

        let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";

        let tempPoints = unRoundedSize - tempFoot;

        // let inch = (tempPoints * 12) / 100;
        let inch = sizes && sizes.length > 1 ? sizes[1] : "";
        let tempfootstring = tempFoot != "" ? tempFoot + "' " : "";
        let unRoundedSizeFeetLabel =
          tempfootstring + (inch != "" ? inch + "''" : "");
        var text = new fabric.Text(unRoundedSizeFeetLabel, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: 10,
          left: textLeftPosition,
          top: textTopPosition,
          angle: wallNo == 2 || wallNo == 4 ? 90 : 0,
          fill: color,
          id: wallID,
          roomID: roomID,
          objectCaching: false,
          type: "LABEL",
          selectable: false,
          textAlign: "center",
        });

        var coordinateForLable = this.coordinateForlable(
          line.x1,
          line.x2,
          line.y1,
          line.y2,
          text.left,
          text.top
        );

        text.set("left", coordinateForLable.x);
        text.set("top", coordinateForLable.y);
        text.set("angle", coordinateForLable.orientation);

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);

        roomTextGroup.push(text);
        roomLinesGroup.push(line);

        this.canvas.add(line);
        this.canvas.add(text);

        if (isWallPenetration == false) {
          wallNo++;
        } else {
        }
      }

      // console.log("EDIT room roomLinesGroup - ", roomLinesGroup);
      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        //var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";
        var color = "black";

        // Connectors

        var circle = null;
        if (roomLinesGroupArrayIndex == 0) {
          // console.log("else 0");
          circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color,
            editedRoomAngle
          );
        } else {
          // console.log("else");
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            // console.log("else 1");

            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            // this.canvas.add(circle);
            //roomConnectorGroup.push(circle);
          } else {
            // console.log("else 2 - ", roomLinesGroupArrayIndex);
            // console.log("else 2 - ", roomLinesGroup[roomLinesGroupArrayIndex]);

            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );
          }
        }

        // console.log("Edit circle - ", circle);
        this.canvas.add(circle);
        roomWiseLineAndTextObjects[roomID]["roomCircleGroup"].push(circle);

        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }

      let totalPoints = roomLinesGroup.length;

      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        var textObject = this.canvas.getItemByAttr("id", roomID);
        // console.log("got textObject - ", textObject);

        textObject.set(
          "left",
          areaLabelLeft - textObject.getBoundingRect().width / 2
        );

        textObject.set(
          "top",
          areaLabelTop - textObject.getBoundingRect().height / 2
        );

        // this.canvas.renderAll();
      } else {
        //Add label

        let centerBoxText = roomArea + "\n" + areaName;

        let unRoundedArea = parseFloat(roomArea);
        let tempFoot = parseInt(unRoundedArea);

        let tempPoints = unRoundedArea - tempFoot;

        let inch = (tempPoints * 12) / 100;
        inch = parseInt(inch * 100);

        let unRoundedSizeFeetLabel = !(isNaN(tempPoints) && isNaN(inch))
          ? tempFoot + "' " + inch + "''"
          : "";

        // console.log("unRoundedSizeFeetLabel - ",unRoundedSizeFeetLabel);

        centerBoxText = unRoundedSizeFeetLabel + "\n" + areaName;

        var text = new fabric.Text(centerBoxText, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: 10,
          left: areaLabelLeft,
          top: areaLabelTop,
          angle: 0,
          fill: "#000",
          id: roomID,
          objectCaching: false,
          textAlign: "center",
          selectable: false,
          textAlign: "center",
          type: "CENTRE-BOX-TEXT",
          area: roomArea,
        });

        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
        roomTextGroup.push(text);
        this.canvas.add(text);
      }
    }

    this.canvas.renderAll();
  };

  onObjectChange = (options) => {
    console.log("onObjectChange - ", options);

    options.target.setCoords();
    this.canvas.forEachObject(
      function (obj) {
        // console.log("obj - ", obj);

        if (obj === options.target) return;
        //obj.set('opacity', options.target.intersectsWithObject(obj) ? 0.5 : 1);
      }.bind(this)
    );
  };

  makeCircle(left, top, line1, line2, color = "red", editedRoomAngle = 0) {
    var c = new fabric.Circle({
      left: left,
      top: top,
      strokeWidth: 5,
      radius: 3,
      fill: "#fff",
      stroke: color,
      type: "connector",
      angle: editedRoomAngle,
    });
    c.hasControls = c.hasBorders = false;

    c.line1 = line1;
    c.line2 = line2;

    return c;
  }

  // x0 = x coordinate of first point
  // y0 = y coordinate of first point
  // x1 = x coordinate of Second point
  // y1 = y coordinate of Second point

  approximateDistanceFromLine = 0.3;
  coordinateForlable(x0, x1, y0, y1, centreX, centreY, length) {
    let midPointX = (x0 + x1) / 2; //mid-point of line
    let midPointY = (y0 + y1) / 2;
    let distanceFromMidpoint = Math.sqrt(
      Math.pow(centreX - midPointX, 2) + Math.pow(centreY - midPointY, 2)
    );
    let lambda =
      this.approximateDistanceFromLine /
      (distanceFromMidpoint - this.approximateDistanceFromLine);
    let lablePointX = (lambda * centreX + midPointX) / (lambda + 1);
    let lablePointY = (lambda * centreY + midPointY) / (lambda + 1);
    let orientation = Math.atan2(y1 - y0, x1 - x0) * (180.0 / Math.PI);

    return {
      x: lablePointX,
      y: lablePointY,
      orientation,
    };
  }

  updateFloorPlanOnMove = (roomID, linesArray) => {
    let processedPionts = [];
    // console.log("mouse:up originalFloorPlan - ", originalFloorPlan);
    let copyOriginal = _.cloneDeep(originalFloorPlan);

    var faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    var roofPointsArray =
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

    // designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);

      // console.log("mouse:up roomFaceObject - ", roomFaceObject);

      if (
        roomFaceObject["@type"] == "ROOM" &&
        roomFaceObject["@id"] == roomID
      ) {
        //Update area of room

        //Get walls of room

        // console.log("mouse:up roomFaceObject - ", roomFaceObject);
        // console.log("mouse:up match Facerray Index = ", faceArrayIndex);

        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");
        // console.log("mouse:up roomChildrenArray - ", roomChildrenArray);

        //Not iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          // console.log("mouse:up roomId - ", roomId);
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];

            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              // console.log("mouse:up faceObject for matching room/Wall- ", faceObject);

              var lineId = faceObject["POLYGON"]["@path"];
              // console.log("mouse:up lineId - ", lineId);

              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  // console.log("mouse:up lineObject for matching room/Wall/line - ", lineObject);

                  var linePointObjectArray = [];
                  var linePoints = lineObject["@path"].split(",");

                  for (
                    var linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    // console.log("processedPionts - ", processedPionts);

                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];

                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        if (
                          processedPionts.includes(linePoints[linePointsIndex])
                        ) {
                          let dataXY = roofPointObject["@dataXY"];
                          roofPointObject["@dataXY"] = dataXY;
                        } else {
                          let dataXY = roofPointObject["@dataXY"].split(",");
                          // console.log("mouse:up roofPointObject for matching point before - ", dataXY);
                          let updatedX =
                            parseFloat(dataXY[0]) + editedRoomFinalLeftDist;
                          let updatedY =
                            parseFloat(dataXY[1]) + editedRoomFinalTopDist;
                          dataXY = updatedX + "," + updatedY;
                          roofPointObject["@dataXY"] = dataXY;
                          processedPionts.push(linePoints[linePointsIndex]);
                        }

                        // console.log("mouse:up roofPointObject for matching point - ", roofPointObject);

                        linePointObjectArray.push(roofPointObject);
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["LINE"] = lineObject;

                  // console.log("mouse:up faceObjectBeingSet - ", faceObject);
                  // console.log("mouse:up faceObjectBeingSet faceArrayIndex - ", wallFaceObjectIndex);

                  faceArray[wallFaceObjectIndex] = faceObject;
                }
              }

              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            } else {
              //TBD:Not in use.
            }
          }
        }
      }
    }

    // console.log("mouse:up designatorWiseObjectArray - ", designatorWiseObjectArray);
    // console.log("mouse:up copyOriginal - ", copyOriginal);

    originalFloorPlan = _.cloneDeep(copyOriginal);
  };

  doZoom = (type) => {
    const currentZoom = this.canvas.getZoom();
    let fontScale = 1;
    let nextZoom = currentZoom;
    if (type == "in") {
      nextZoom = currentZoom * 1.1;
      fontScale = fontScale / 1.1;
      if (nextZoom > 20) nextZoom = 20;
    } else if (type == "out") {
      nextZoom = currentZoom / 1.1;
      fontScale = fontScale * 1.1;
      if (nextZoom < 0.01) nextZoom = 0.01;
    }
    const zoompoint = new fabric.Point(
      this.canvas.width / 2,
      this.canvas.height / 2
    );
    this.canvas.setZoom(nextZoom);

    var object = null;
    var objects = this.canvas.getObjects();

    for (
      let canvasObjectIndex = 0;
      canvasObjectIndex < objects.length;
      canvasObjectIndex++
    ) {
      let groupWidth = objects[canvasObjectIndex].width;
      let groupHeight = objects[canvasObjectIndex].height;

      let groupObject = objects[canvasObjectIndex].getObjects();

      // console.log("groupObject - ",groupObject);

      for (
        let groupSubObjectIndex = 0;
        groupSubObjectIndex < groupObject.length;
        groupSubObjectIndex++
      ) {
        let object = groupObject[groupSubObjectIndex];

        //object.calcTransformMatrix()

        if (object.type == "CENTRE-BOX-TEXT") {
          let fontSize = parseFloat(object["fontSize"]);

          let width = object.width;
          let height = object.height;

          object.set("left", (width / 2) * -1);
          object.set("top", (height / 2) * -1);

          object.set("color", "red");
          if (width + 50 <= groupWidth) {
            fontSize *= fontScale;
            object.set("fontSize", fontSize);
          }
        }
      }
    }

    this.canvas.renderAll();
  };
  doNavigate = (side) => {
    const units = 10;
    let delta = null;
    if (side == "left") {
      delta = new fabric.Point(-units, 0);
    } else if (side == "right") {
      delta = new fabric.Point(units, 0);
    } else if (side == "up") {
      delta = new fabric.Point(0, -units);
    } else if (side == "down") {
      delta = new fabric.Point(0, units);
    }
    if (delta != null) {
      this.canvas.relativePan(delta);
    }
  };

  toggleAreaDetails = () => {
    this.setState({ areaDetails: designatorWiseObjectArray });
  };

  render() {
    return (
      <>
        <div className="measurement-container">
          <div className="measurement-head">
            <div className="menu-list">
              <div className="menu-items">
                <ul>
                  <li>
                    <button className="">
                      <i className="icon-back"></i>Back
                    </button>
                  </li>
                  <li>
                    <button className="">
                      <i className="icon-bookmark-edit"></i>Edit
                    </button>
                  </li>
                  <li>
                    <button
                      className="active"
                      onClick={() => {
                        this.saveArea();
                      }}
                    >
                      <i className="icon-save-file"></i>Save
                    </button>
                  </li>
                  <li>
                    <button className="">
                      <i className="icon-rotate-left"></i>Rotate Left
                    </button>
                  </li>
                  <li>
                    <button className="">
                      <i className="icon-rotate-right"></i>Rotate Right
                    </button>
                  </li>
                  <li>
                    <button className="disable">
                      <i className="icon-delete"></i>Delete{" "}
                      <i className="icon-information"></i>
                    </button>
                  </li>
                  <li>
                    <button className="">
                      <i className="icon-undo"></i>Undo
                    </button>
                  </li>
                </ul>
              </div>
              <div className="select-floor">
                <select
                  className="form-control"
                  name="floornumber"
                  value=""
                  onChange={(e) => {
                    //this.handleOnchange(e)
                  }}
                >
                  {this.state.floorList.map((floor) => (
                    <option key={floor.floorId} value={floor.floorId}>
                      {floor.floorName}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          <div className="measurement-view">
            <div className="induction-measurment">
              <ul>
                <li className="gla">
                  <span></span>GLA
                </li>
                <li className="non-gla">
                  <span></span>NON-GLA
                </li>
              </ul>
            </div>
            <div className="direction-view">
              <div className="arrow">
                <div className="row-one">
                  <button onClick={() => this.doNavigate("left")}>
                    <i className="icon-arrow-left"></i>
                  </button>
                </div>
                <div className="row-one">
                  <button onClick={() => this.doNavigate("up")}>
                    <i className="icon-arow-top"></i>
                  </button>
                  <button onClick={() => this.doNavigate("down")}>
                    <i className="icon-arrow-bottom"></i>
                  </button>
                </div>
                <div className="row-one">
                  <button onClick={() => this.doNavigate("right")}>
                    <i className="icon-arrow-right"></i>
                  </button>
                </div>
              </div>
              <div className="zoom-level">
                <div className="level">
                  <button onClick={() => this.doZoom("in")}>
                    <i className="icon-measurement-plus"></i>
                  </button>
                  <button onClick={() => this.doZoom("out")}>
                    <i className="icon-measurement-minus"></i>
                  </button>
                </div>
              </div>
            </div>
            <div className="inner-measurement">
              <canvas id="measurementcanvas" />
            </div>
          </div>
        </div>
        <AreaDetails
          toggleAreaDetails={this.toggleAreaDetails}
          areaDetails={this.state.areaDetails}
        ></AreaDetails>
      </>
    );
  }
}

export default connect(null, {
  saveMeasurementJson,
})(MeasurementTab);
