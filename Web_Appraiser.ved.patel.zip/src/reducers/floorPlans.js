import * as actionTypes from "../actions/actionTypes";

const floorPlanState = {
  fetchFloorPlansStart: false,
  fetchFloorPlansSuccess: [],
  fetchFloorPlansError: null,
  downloadZipStart: false,
  downloadZipSuccess: {},
  downloadZipError: null,
  downloadImageStart: false,
  downloadImageSuccess: {},
  downloadImageError: null,
};

const defaultStates = {
  ...floorPlanState,
};

// eslint-disable-next-line import/no-anonymous-default-export
export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_FLOORPLANS_START:
      return {
        ...state,
        fetchFloorPlansStart: true,
        fetchFloorPlansSuccess: [],
        fetchFloorPlansError: null,
      };
    case actionTypes.FETCH_FLOORPLANS_SUCCESS:
      return {
        ...state,
        fetchFloorPlansStart: false,
        fetchFloorPlansSuccess: action.payload,
        fetchFloorPlansError: null,
      };
    case actionTypes.FETCH_FLOORPLANS_ERROR:
      return {
        ...state,
        fetchFloorPlansStart: false,
        fetchFloorPlansSuccess: [],
        fetchFloorPlansError: action.payload,
      };
    case actionTypes.DOWNLOAD_ZIP_START:
      return {
        ...state,
        downloadZipStart: true,
        downloadZipSuccess: {},
        downloadZipError: null,
      };
    case actionTypes.DOWNLOAD_ZIP_SUCCESS:
      return {
        ...state,
        downloadZipStart: false,
        downloadZipSuccess: action.payload,
        downloadZipError: null,
      };
    case actionTypes.DOWNLOAD_ZIP_ERROR:
      return {
        ...state,
        downloadZipStart: false,
        downloadZipSuccess: {},
        downloadZipError: action.payload,
      };
    case actionTypes.DOWNLOAD_IMAGE_START:
      return {
        ...state,
        downloadImageStart: true,
        downloadImageSuccess: {},
        downloadImageError: null,
      };
    case actionTypes.DOWNLOAD_IMAGE_SUCCESS:
      return {
        ...state,
        downloadImageStart: false,
        downloadImageSuccess: action.payload,
        downloadImageError: null,
      };
    case actionTypes.DOWNLOAD_IMAGE_ERROR:
      return {
        ...state,
        downloadImageStart: false,
        downloadImageSuccess: {},
        downloadImageError: action.payload,
      };
    default:
      return state;
  }
};
