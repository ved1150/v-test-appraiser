import * as actionTypes from "../actions/actionTypes";

const PDRDetailsState = {
  fetchNotesStart: false,
  fetchNotesSuccess: [],
  fetchNotesError: null,
};

const defaultStates = {
  ...PDRDetailsState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_PDRDETAILS_START:
      return {
        ...state,
        fetchPDRDetailsStart: true,
        fetchPDRDetailsSuccess: [],
        fetchPDRDetailsError: null,
      };
    case actionTypes.FETCH_PDRDETAILS_SUCCESS:
      return {
        ...state,
        fetchPDRDetailsStart: false,
        fetchPDRDetailsSuccess: action.payload,
        fetchPDRDetailsError: null,
      };
    case actionTypes.FETCH_PDRDETAILS_ERROR:
      return {
        ...state,
        fetchPDRDetailsStart: false,
        fetchPDRDetailsSuccess: [],
        fetchPDRDetailsError: action.payload,
      };
    default:
      return state;
  }
};
