//React & Redux
import React from "react";

class MesurementTab extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div className="call-history"></div>;
  }
}

export default MesurementTab;
