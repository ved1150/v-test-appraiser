import { useState } from "react";

const Owner = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Owner{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {Object.keys(props.estatedData.data.owner).map((key) => (
          <li key={key}>
            <div style={{ textTransform: "capitalize" }}>
              {key.split("_").join(" ")}
            </div>
            <div>{props.estatedData.data.owner[key] ?? "N/A"}</div>
          </li>
        ))}
      </ul>
    </>
  );
};

export default Owner;
