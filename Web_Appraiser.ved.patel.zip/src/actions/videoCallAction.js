import * as actionTypes from "./actionTypes";
import videoCallService from "../services/videoCallService";
import { StartLoading, StopLoading } from "./UIAction";
const startgetVideoCallURL = () => {
  return {
    type: actionTypes.GENERATE_QUICK_CALL_LINK_START,
  };
};

const successGeVideoCallURL = (data) => {
  return {
    type: actionTypes.GENERATE_QUICK_CALL_LINK_SUCCESS,
    payload: data,
  };
};
const errorgetVideoCallURL = (error) => {
  return {
    type: actionTypes.GENERATE_QUICK_CALL_LINK_ERROR,
    payload: error,
  };
};

export function getVideoCallURL(requestData) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startgetVideoCallURL());
    return videoCallService
      .createQuickCall(requestData)
      .then(function (data) {
        dispatch(StopLoading());
        dispatch(successGeVideoCallURL(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorgetVideoCallURL(err));
        throw err;
      });
  };
}
