import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { connect, useSelector } from "react-redux";
import { logIn } from "../../actions/authenticationAction";
import { Formik } from "formik";
import * as Yup from "yup";
import TextInput from "../common/TextInput";
import Button from "./../common/Button";
import Logo from "../../images/blue-logo.svg";
import "./index.scss";
import { useTranslation } from "react-i18next";
import AsyncImage from "./../common/AsyncImage";
import DisplayErrorModal from "./../../components/common/DisplayErrorModal/DisplayErrorModal";
import { get, isEmpty } from "lodash";
import { getSubDomainFromURL, redirectToUnAuthPage } from "../../helpers";

import LanguageSwitcher from "./LanguageSwitcher";
import authService from "../../services/authService";
import authenticationService from "../../services/authenticationService";

const SignIn = (props) => {
  const { t } = useTranslation();
  const [submitloading, setSubmitLoading] = useState(false);
  const [passwordType, setPasswordType] = useState("password");
  const token = authenticationService.getToken();
  const subDomain = getSubDomainFromURL();
  useEffect(() => {
    if (!props.authentication.authLoading) {
      if (subDomain && token) {
        props.history.push("/");
      } else {
        redirectToUnAuthPage(props.history, false);
      }
    }
  }, [props.authentication.authLoading]);

  useEffect(() => {
    setSubmitLoading(props.authentication.loading);
  }, [props.authentication]);

  const togglePasswordVisibility = (type) => {
    setPasswordType(type);
  };

  const tenantLogo = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess?.tenantLogo;
  });

  return (
    <>
      {props.errorModalloading && <DisplayErrorModal />}
      <section className="main-authaticatoin-wraper">
        <div className="auth-center-segment">
          <div className="auth-logo-top">
            {!isEmpty(tenantLogo) ? (
              <AsyncImage useStaticToken={true} imageUrl={tenantLogo} />
            ) : (
              <img src={Logo} alt="Logo" />
            )}
          </div>
          <div className="auth-form-field-section">
            <Formik
              initialValues={{ email: "", password: "" }}
              onSubmit={(values, { setSubmitting }) => {
                const tenant = getSubDomainFromURL();
                props.logIn({ ...values, tenant }, props.history, !!tenant);
                setSubmitting(false);
              }}
              validationSchema={Yup.object().shape({
                email: Yup.string()
                  .email(t("ERROR_MESSAGES.signInMessages.emailValid"))
                  .required(t("ERROR_MESSAGES.signInMessages.emailRequired")),
                password: Yup.string().required(
                  t("ERROR_MESSAGES.signInMessages.passwordRequired")
                ),
              })}
            >
              {(props) => {
                const {
                  values,
                  touched,
                  errors,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                } = props;
                return (
                  <form className="authatication-form" onSubmit={handleSubmit}>
                    <div className="inner-authaticatio-form">
                      <TextInput
                        type="text"
                        name="email"
                        placeholder={t("WEB_LABELS.Email")}
                        value={values.email}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={errors.email}
                        touched={touched.email}
                        icon={
                          <div className="auth-icons font-email-set">
                            <i className="icon-email"></i>
                          </div>
                        }
                      />
                      <TextInput
                        type={passwordType}
                        name="password"
                        placeholder={t("WEB_LABELS.Password")}
                        value={values.password}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={errors.password}
                        touched={touched.password}
                        icon={
                          <div
                            className={`auth-icons ${
                              values.password ? "font-eye" : ""
                            }`}
                          >
                            {values.password ? (
                              <>
                                {passwordType === "text" ? (
                                  <i
                                    className="icon-eye"
                                    onClick={() =>
                                      togglePasswordVisibility("password")
                                    }
                                  ></i>
                                ) : (
                                  <i
                                    className="icon-cross-eye"
                                    onClick={() =>
                                      togglePasswordVisibility("text")
                                    }
                                  ></i>
                                )}
                              </>
                            ) : (
                              <i className="icon-change-password"></i>
                            )}
                          </div>
                        }
                      />
                      <div className="form-group text-center">
                        <Link to="/forgot-password" className="forgot-password">
                          {t("WEB_LABELS.Forgot_Password")}
                        </Link>
                      </div>
                      <div className="form-group-btn text-center">
                        <Button
                          disabled={submitloading}
                          className="blue-btn"
                          type="submit"
                        >
                          {t("BUTTONS.Sign_In")}{" "}
                          {submitloading && <div className="loader-spin"></div>}
                        </Button>
                        <LanguageSwitcher />
                      </div>
                    </div>
                  </form>
                );
              }}
            </Formik>
          </div>
        </div>
      </section>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    authentication: state.authentication,
    errorModalloading: get(state, ["errorReducer", "errorModalloading"]),
  };
};

export default connect(mapStateToProps, {
  logIn,
})(SignIn);
