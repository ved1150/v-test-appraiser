import { fabric } from "fabric";
import _ from "lodash";
import { hasIntersectWall } from "../../../FloorScanJob/View3DFloorPlan/UtilityThreejs";

export function isInside(polygon, n, p) {
  if (n < 3) {
    return false;
  }

  let extreme = { x: p.x, y: p.y };
  let count = 0,
    i = 0;
  do {
    let next = (i + 1) % n;
    if (doIntersect(polygon[i], polygon[next], p, extreme)) {
      if (orientation(polygon[i], p, polygon[next]) == 0) {
        return onSegment(polygon[i], p, polygon[next]);
      }
      count++;
    }
    i = next;
  } while (i != 0);
  return count % 2 == 1;
}

function onSegment(p, q, r) {
  if (
    q.x <= Math.max(p.x, r.x) &&
    q.x >= Math.min(p.x, r.x) &&
    q.y <= Math.max(p.y, r.y) &&
    q.y >= Math.min(p.y, r.y)
  ) {
    return true;
  }
  return false;
}

// To find orientation of ordered triplet (p, q, r).
// The function returns following values
// 0 --> p, q and r are collinear
// 1 --> Clockwise
// 2 --> Counterclockwise
function orientation(p, q, r) {
  let val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);

  if (val == 0) {
    return 0; // collinear
  }
  return val > 0 ? 1 : 2; // clock or counterclock wise
}

// The function that returns true if
// line segment 'p1q1' and 'p2q2' intersect.
function doIntersect(p1, q1, p2, q2) {
  // Find the four orientations needed for
  // general and special cases
  let o1 = orientation(p1, q1, p2);
  let o2 = orientation(p1, q1, q2);
  let o3 = orientation(p2, q2, p1);
  let o4 = orientation(p2, q2, q1);

  // General case
  if (o1 != o2 && o3 != o4) {
    return true;
  }

  // Special Cases
  // p1, q1 and p2 are collinear and
  // p2 lies on segment p1q1
  if (o1 == 0 && onSegment(p1, p2, q1)) {
    return true;
  }

  // p1, q1 and p2 are collinear and
  // q2 lies on segment p1q1
  if (o2 == 0 && onSegment(p1, q2, q1)) {
    return true;
  }

  // p2, q2 and p1 are collinear and
  // p1 lies on segment p2q2
  if (o3 == 0 && onSegment(p2, p1, q2)) {
    return true;
  }

  // p2, q2 and q1 are collinear and
  // q1 lies on segment p2q2
  if (o4 == 0 && onSegment(p2, q1, q2)) {
    return true;
  }

  // Doesn't fall in any of the above cases
  return false;
}

export function getRoomData(
  designatorWiseObjectArray,
  selectedFloor,
  minX,
  minY,
  ratio
) {
  let roomArray = Object.keys(designatorWiseObjectArray);
  let selectedFloorRooms = [];
  let roomWiseLineAndTextObjects = {};
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < roomArray.length;
    roomArrayIndex++
  ) {
    let roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];
    if (roomObjectArray[0]["@floorindex"] == selectedFloor) {
      selectedFloorRooms.push(roomArray[roomArrayIndex]);
    }
  }
  let roomID = "";
  //Now start drawing

  for (
    let roomArrayIndex = 0;
    roomArrayIndex < selectedFloorRooms.length;
    roomArrayIndex++
  ) {
    let roomObjectArray =
      designatorWiseObjectArray[selectedFloorRooms[roomArrayIndex]];

    let polygonpoints = [];

    for (
      let roomObjectArrayIndex = 0;
      roomObjectArrayIndex < roomObjectArray.length;
      roomObjectArrayIndex++
    ) {
      let wallObject = roomObjectArray[roomObjectArrayIndex];
      if (wallObject.LINE == null) {
        roomID = wallObject["@id"];
        roomWiseLineAndTextObjects[roomID] = {};
        roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = {};
        continue;
      }

      let isWallPenetration =
        wallObject["@type"] == "WALLPENETRATION" ? true : false;
      if (isWallPenetration == false) {
      } else {
        continue;
      }

      let linePointObjectArray = wallObject.LINE.linePointObjectArray;
      let points = [];

      for (
        let linePointObjectArrayInedex = 0;
        linePointObjectArrayInedex < linePointObjectArray.length;
        linePointObjectArrayInedex++
      ) {
        let value1 =
          linePointObjectArray[linePointObjectArrayInedex]["@autoSnappedXY"];

        if (value1 == null) {
          break;
        }
        let id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
        let v1 = value1.split(",");
        let fval = { id: id, x: v1[0], y: v1[1], z: 0 };
        points.push(fval);
      }

      if (points.length < 2) {
        break;
      }
      polygonpoints.push({
        x: (points[0].x - minX) * ratio,
        y: (points[0].y - minY) * ratio,
      });
      polygonpoints.push({
        x: (points[1].x - minX) * ratio,
        y: (points[1].y - minY) * ratio,
      });
    }
    polygonpoints = _.uniqWith(polygonpoints, _.isEqual);
    const poly = new fabric.Polygon(polygonpoints, {
      strokeWidth: 4,
      stroke: "black",
      cornerColor: "black",
      roomID: roomID,
      ID: "POLY-" + roomID,
    });

    roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = poly;
  }
  return roomWiseLineAndTextObjects;
}

export function getLabelPositionOuter(
  text,
  midPointX,
  midPointY,
  angleDeg,
  polygonpointsclone,
  roomWiseLineAndTextObjects,
  indexedLine
) {
  let middelPointText = validatePoints(
    text,
    midPointX,
    midPointY,
    angleDeg,
    polygonpointsclone,
    roomWiseLineAndTextObjects,
    indexedLine
  );
  // if (middelPointText) return middelPointText
  // let startPointText = validatePoints(text, indexedLine.x1, indexedLine.y1, angleDeg, polygonpointsclone, roomWiseLineAndTextObjects);
  // if (startPointText) return startPointText
  // return validatePoints(text, indexedLine.x2, indexedLine.y2, angleDeg, polygonpointsclone, roomWiseLineAndTextObjects);
  return middelPointText;
}

function validatePoints(
  text,
  midPointX,
  midPointY,
  angleDeg,
  polygonpointsclone,
  roomWiseLineAndTextObjects,
  indexedLine
) {
  text = getLabelPosition(
    text,
    midPointX,
    midPointY,
    angleDeg,
    polygonpointsclone.points,
    indexedLine,
    midPointX,
    midPointY
  );

  let rooms = Object.keys(roomWiseLineAndTextObjects);
  rooms.forEach((element) => {
    let croom = roomWiseLineAndTextObjects[element]["roomPolyGroup"];
    if (
      text &&
      (isInside(
        croom.points,
        croom.points.length,
        new fabric.Point(text.left, text.top)
      ) ||
        insidePoly(new fabric.Point(text.left, text.top), croom.points))
    ) {
      text = null;
    }
  });
  return text;
}

export function insidePoly(p, vs) {
  var inside = false;
  for (var i = 0, j = vs.length - 1; i < vs.length; j = i++) {
    var xi = vs[i].x,
      yi = vs[i].y;
    var xj = vs[j].x,
      yj = vs[j].y;
    var intersect =
      yi > p.y !== yj > p.y && p.x < ((xj - xi) * (p.y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

/**
 * Purpose : This function will return position of labels to be display in editmode
 * @param {Text} text label whose position needs to change
 * @param {float} midPointX center point x of line
 * @param {float} midPointY center point y of line
 * @param {float} angleDeg degree of angle to the label to be rotated
 * @return {Text} with new position
 */
export function getLabelPosition(
  text,
  midPointX,
  midPointY,
  angleDeg,
  points = [],
  indexedLine = null,
  areaLabelLeft = null,
  areaLabelTop = null
) {
  let textRef = text;
  text.set("flipY", false);
  text.set("flipX", false);
  if (angleDeg >= -45 && angleDeg < 45) {
    text.set("left", midPointX);
    text.set("top", midPointY + 15);
  } else if (angleDeg >= 45 && angleDeg < 135) {
    text.set("left", midPointX - 13);
    text.set("top", midPointY);
  } else if (angleDeg >= 135 || angleDeg < -135) {
    text.set("left", midPointX);
    text.set("top", midPointY - 13);
    text.set("flipY", true);
    text.set("flipX", true);
  } else if (angleDeg >= -135 && angleDeg < -45) {
    text.set("left", midPointX + 15);
    text.set("top", midPointY);
  }

  if (points.length > 0) {
    if (insidePoly(new fabric.Point(text.left, text.top), points)) {
      const coordinateForLable = coordinateForlable(
        indexedLine.x2,
        indexedLine.x1,
        indexedLine.y2,
        indexedLine.y1,
        areaLabelLeft,
        areaLabelTop
      );
      textRef.set("left", coordinateForLable.x);
      textRef.set("top", coordinateForLable.y);
      textRef.set("angle", coordinateForLable.orientation);
      return getLabelPosition(
        textRef,
        midPointX,
        midPointY,
        coordinateForLable.orientation,
        [],
        indexedLine,
        areaLabelLeft,
        areaLabelTop
      );
    }
  }
  return text;
}

/**
 * Purpose : This function will return position of labels to be display in editmode
 * @param {Text} text label whose position needs to change
 * @param {float} midPointX center point x of line
 * @param {float} midPointY center point y of line
 * @param {float} angleDeg degree of angle to the label to be rotated
 * @return {Text} with new position
 */
export function getDoorShapePosition(
  text,
  midPointX,
  midPointY,
  angleDeg,
  points = [],
  indexedLine = null,
  areaLabelLeft = null,
  areaLabelTop = null
) {
  let textRef = text;
  text.set("flipY", false);
  text.set("flipX", false);
  if (angleDeg >= -45 && angleDeg < 45) {
    text.set("left", midPointX);
    text.set("top", midPointY + 15);
  } else if (angleDeg >= 45 && angleDeg < 135) {
    text.set("left", midPointX - 13);
    text.set("top", midPointY);
  } else if (angleDeg >= 135 || angleDeg < -135) {
    text.set("left", midPointX);
    text.set("top", midPointY - 13);
    text.set("flipY", true);
    text.set("flipX", true);
  } else if (angleDeg >= -135 && angleDeg < -45) {
    text.set("left", midPointX + 15);
    text.set("top", midPointY);
  }

  if (points.length > 0) {
    if (insidePoly(new fabric.Point(text.left, text.top), points)) {
      const coordinateForLable = coordinateForlable(
        indexedLine.x2,
        indexedLine.x1,
        indexedLine.y2,
        indexedLine.y1,
        areaLabelLeft,
        areaLabelTop
      );
      textRef.set("left", coordinateForLable.x);
      textRef.set("top", coordinateForLable.y);
      textRef.set("angle", coordinateForLable.orientation);
      return getDoorShapePosition(
        textRef,
        midPointX,
        midPointY,
        coordinateForLable.orientation,
        [],
        indexedLine,
        areaLabelLeft,
        areaLabelTop
      );
    }
  }
  return text;
}

/**
 * Purpose : This function will calculate and return new label position from provided cooedinates
 * @param {float} x0 x coordinate
 * @param {float} x1 x coordinate
 * @param {float} y0 y coordinate
 * @param {float} y1 y coordinate
 * @param {float} centreX y coordinate center point
 * @param {float} centreY y coordinate center point
 * @param {int} length length of label
 * @return {Point} center point
 */
// approximateDistanceFromLine = 0.3;
export function coordinateForlable(x0, x1, y0, y1, centreX, centreY, length) {
  let midPointX = (x0 + x1) / 2; //mid-point of line
  let midPointY = (y0 + y1) / 2;
  let distanceFromMidpoint = Math.sqrt(
    Math.pow(centreX - midPointX, 2) + Math.pow(centreY - midPointY, 2)
  );
  let lambda = 0.1;
  // let lambda = this.approximateDistanceFromLine /(distanceFromMidpoint - this.approximateDistanceFromLine);
  let lablePointX = (lambda * centreX + midPointX) / (lambda + 1);
  let lablePointY = (lambda * centreY + midPointY) / (lambda + 1);
  let orientation = Math.atan2(y1 - y0, x1 - x0) * (180.0 / Math.PI);

  return {
    x: lablePointX,
    y: lablePointY,
    orientation,
  };
}

export const isIntersectObject = (
  thisState,
  target,
  point1Calc,
  point2Calc
) => {
  let isIntersect = false;
  if (target.parentRoomCordinates) {
    target.parentRoomCordinates?.forEach((element, index) => {
      if (!isIntersect) {
        isIntersect = hasIntersectWall(
          point1Calc.x,
          point1Calc.y,
          point2Calc.x,
          point2Calc.y,
          element.x,
          element.y,
          target.parentRoomCordinates[
            target.parentRoomCordinates.length - 1 === index ? 0 : index + 1
          ].x,
          target.parentRoomCordinates[
            target.parentRoomCordinates.length - 1 === index ? 0 : index + 1
          ].y
        );
        thisState.setState({ isIntersectPartitionWall: isIntersect });
      }
    });
  } else if (!thisState.state.isIntersectPartitionWall) {
    thisState.setState({ isIntersectPartitionWall: true });
  }
  if (target.partitionWallCordinates && !isIntersect) {
    target.partitionWallCordinates?.forEach((element) => {
      if (!isIntersect) {
        let isIntersect = hasIntersectWall(
          point1Calc.x,
          point1Calc.y,
          point2Calc.x,
          point2Calc.y,
          element.x1,
          element.y1,
          element.x2,
          element.y2
        );
        thisState.setState({ isIntersectPartitionWall: isIntersect });
      }
    });
  }
  return isIntersect;
};
