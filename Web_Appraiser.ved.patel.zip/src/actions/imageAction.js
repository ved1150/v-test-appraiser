import * as actionTypes from "./actionTypes";
import imageService from "../services/imageService";
import { StartLoading, StopLoading } from "./UIAction";
const startFetchImage = () => {
  return {
    type: actionTypes.FETCH_IMAGE_START,
  };
};

const successFetchImage = (data) => {
  return {
    type: actionTypes.FETCH_IMAGE_SUCCESS,
    payload: data,
  };
};

const errorFetchImage = (error) => {
  return {
    type: actionTypes.FETCH_IMAGE_ERROR,
    payload: error,
  };
};

const startDownloadImage = () => {
  return {
    type: actionTypes.DOWNLOAD_IMAGE_START,
  };
};

const successDownloadImage = (data) => {
  return {
    type: actionTypes.DOWNLOAD_IMAGE_SUCCESS,
    payload: data,
  };
};

const errorDownloadImage = (error) => {
  return {
    type: actionTypes.DOWNLOAD_IMAGE_ERROR,
    payload: error,
  };
};

const startDeleteImage = () => {
  return {
    type: actionTypes.DELETE_IMAGE_START,
  };
};

const successDeleteImage = (data) => {
  return {
    type: actionTypes.DELETE_IMAGE_SUCCESS,
    payload: data,
  };
};

const errorDeleteImage = (error) => {
  return {
    type: actionTypes.DELETE_IMAGE_ERROR,
    payload: error,
  };
};

export const fetchImages = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchImage());
    return imageService
      .getImages(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchImage(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchImage(err));
      });
  };
};

export const downloadImages = (data) => {
  return (dispatch) => {
    // dispatch(startDownloadImage());
    return imageService
      .downloadImages(data)
      .then((data) => {
        // dispatch(successDownloadImage(data));
        return data;
      })
      .catch((err) => {
        // dispatch(errorDownloadImage(err));
      });
  };
};

export const deleteImages = (data) => {
  return (dispatch) => {
    dispatch(startDeleteImage());
    return imageService
      .deleteImages(data)
      .then((data) => {
        dispatch(successDeleteImage(data));
        return data;
      })
      .catch((err) => {
        dispatch(errorDeleteImage(err));
      });
  };
};
