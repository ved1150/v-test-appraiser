import api from "./api";

export default class JobAPI {
  deleteAppointmentSlot(data) {
    return api.delete(`/deleteslot/${data}`);
  }

  cancelAppointmentSlot(data) {
    const queryParam = data.reason ? `?reason=${data.reason}` : "";
    return api.put(
      `/appointment/changeStatus/${data.appointmentId}/${data.status}${queryParam}`
    );
  }
}
