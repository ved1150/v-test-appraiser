export function deHydrateJobOrdersManagement(data) {
  const _data = { ...data, assignee: data.userId };
  delete _data.jobOrderAssignee;
  delete _data.userId;
  return _data;
}

export function hydrateJobOrdersManagement(data) {
  return data;
}
