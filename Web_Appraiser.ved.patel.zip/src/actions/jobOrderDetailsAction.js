import * as actionTypes from "./actionTypes";
import jobOrderDetailsService from "./../services/jobOrderDetailsService";
import { customToast } from "./../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "./../constants/commonMessages";

const startCompleteJobOrder = () => {
  return {
    type: actionTypes.COMPLETE_JOBORDER_START,
  };
};

const successCompleteJobOrder = (data) => {
  return {
    type: actionTypes.COMPLETE_JOBORDER_SUCCESS,
    payload: data,
  };
};

const errorCompleteJobOrder = (error) => {
  return {
    type: actionTypes.COMPLETE_JOBORDER_ERROR,
    payload: error,
  };
};

export const completeJobOrder = (data, joborderId) => {
  return (dispatch) => {
    dispatch(startCompleteJobOrder());
    return jobOrderDetailsService
      .completeJO(data, joborderId)
      .then((data) => {
        if (data.data) {
          dispatch(successCompleteJobOrder(data));
          return data;
        }
      })
      .catch((err) => {
        dispatch(errorCompleteJobOrder(err));
        throw err;
      });
  };
};

const startSetPrimaryPictureForReportsPDF = () => {
  return {
    type: actionTypes.SET_PRIMARY_PICTURE_FOR_REPORTS_PDF_START,
  };
};

const successSetPrimaryPictureForReportsPDF = (data) => {
  return {
    type: actionTypes.SET_PRIMARY_PICTURE_FOR_REPORTS_PDF_SUCCESS,
    payload: data,
  };
};

const errorSetPrimaryPictureForReportsPDF = (error) => {
  return {
    type: actionTypes.SET_PRIMARY_PICTURE_FOR_REPORTS_PDF_ERROR,
    payload: error,
  };
};

export const setPrimaryPictureForReportPDF = (data) => {
  return (dispatch) => {
    dispatch(startSetPrimaryPictureForReportsPDF());
    return jobOrderDetailsService
      .setPrimaryPictureForReportPDF(data)
      .then((data) => {
        if (data.data) {
          dispatch(successSetPrimaryPictureForReportsPDF(data));
          return data;
        }
      })
      .catch((err) => {
        dispatch(errorSetPrimaryPictureForReportsPDF(err));
        throw err;
      });
  };
};
