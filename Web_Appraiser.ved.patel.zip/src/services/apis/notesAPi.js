import api from "./api";

export default class NotesAPI {
  getNotes(data) {
    return api.get(`/notes/get/${data}`);
  }
}
