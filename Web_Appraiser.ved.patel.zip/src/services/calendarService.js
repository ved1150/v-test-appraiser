import api from "./apis/api";

class CalendarService {
  deleteAppointmentSlot(data) {
    return api.calendar.deleteAppointmentSlot(data);
  }

  cancelAppointmentSlot(data) {
    return api.calendar.cancelAppointmentSlot(data);
  }
}

export default new CalendarService();
