import { useState } from "react";

const Valuation = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Valuation{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {Object.keys(props.estatedData.data.valuation).map((key) => (
          <li key={key}>
            <div style={{ textTransform: "capitalize" }}>
              {key.split("_").join(" ")}
            </div>
            <div>{props.estatedData.data.valuation[key] ?? "N/A"}</div>
          </li>
        ))}
      </ul>
    </>
  );
};

export default Valuation;
