/* eslint-disable import/no-anonymous-default-export */
import {
  START_LOAD_ATTACHMENTS,
  LOAD_ATTACHMENTS_SUCCESS,
  LOAD_ATTACHMENTS_ERROR,
  START_UPLOAD_ATTACHMENT,
  UPLOAD_ATTACHMENT_SUCCESS,
  UPLOAD_ATTACHMENT_ERROR,
  START_DELETE_ATTACHMENT,
  DELETE_ATTACHMENT_SUCCESS,
  DELETE_ATTACHMENT_ERROR,
  START_DOWNLOAD_ATTACHMENTS,
  DOWNLOAD_ATTACHMENTS_SUCCESS,
  DOWNLOAD_ATTACHMENTS_ERROR,
  START_DOWNLOAD_ATTACHMENT,
  DOWNLOAD_ATTACHMENT_SUCCESS,
  DOWNLOAD_ATTACHMENT_ERROR,
} from "../actions/actionTypes";

export const downloadAttachmentDefaultState = {
  downloading: false,
  downloaded: {},
  downloadingError: null,
};

export const uploadAttachmentDefaultState = {
  uploading: false,
  uploaded: {},
  uploadingError: null,
};

export const deleteAttachmentDefaultState = {
  deleting: false,
  deleted: {},
  deletingError: null,
};

export const defaultState = {
  attachments: [],
  loading: false,
  error: null,
  ...uploadAttachmentDefaultState,
  ...downloadAttachmentDefaultState,
};

export default function (
  state = defaultState,
  action = { type: null, payload: {} }
) {
  switch (action.type) {
    case START_LOAD_ATTACHMENTS: {
      return {
        ...state,
        loading: true,
        attachments: [],
        error: null,
      };
    }

    case LOAD_ATTACHMENTS_SUCCESS: {
      return {
        ...state,
        loading: false,
        attachments: action.payload,
        error: null,
      };
    }

    case LOAD_ATTACHMENTS_ERROR: {
      return {
        ...state,
        loading: false,
        attachments: [],
        error: action.payload,
      };
    }

    case START_UPLOAD_ATTACHMENT: {
      return {
        ...state,
        uploading: true,
        uploaded: {},
        uploadingError: null,
      };
    }

    case UPLOAD_ATTACHMENT_SUCCESS: {
      return {
        ...state,
        uploading: false,
        uploaded: {
          ...action.payload,
        },
        uploadingError: null,
      };
    }

    case UPLOAD_ATTACHMENT_ERROR: {
      return {
        ...state,
        uploading: false,
        uploaded: {},
        uploadingError: action.payload,
      };
    }

    case START_DELETE_ATTACHMENT: {
      return {
        ...state,
        deleting: true,
        deleted: {},
        deletingError: null,
      };
    }

    case DELETE_ATTACHMENT_SUCCESS: {
      return {
        ...state,
        deleting: false,
        deleted: {
          ...action.payload,
        },
        deletingError: null,
      };
    }

    case DELETE_ATTACHMENT_ERROR: {
      return {
        ...state,
        deleting: false,
        deleted: {},
        deletingError: action.payload,
      };
    }

    case START_DOWNLOAD_ATTACHMENT:
    case START_DOWNLOAD_ATTACHMENTS:
      return {
        ...state,
        downloading: true,
        downloaded: {},
        downloadingError: null,
      };

    case DOWNLOAD_ATTACHMENT_SUCCESS:
    case DOWNLOAD_ATTACHMENTS_SUCCESS:
      return {
        ...state,
        downloading: false,
        // downloaded: {
        //   ...action.payload,
        // },
        downloadingError: null,
      };

    case DOWNLOAD_ATTACHMENT_ERROR:
    case DOWNLOAD_ATTACHMENTS_ERROR:
      return {
        ...state,
        downloading: false,
        downloaded: {},
        downloadingError: action.payload,
      };

    default: {
      return state;
    }
  }
}
