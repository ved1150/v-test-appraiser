import api from "./apis/api";
import {
  hydrateRecordings,
  hydrateDownloadRecording,
  deHydrateRecordings,
} from "./transformers/jobOrderDetailsTransformer";

class RecordingsService {
  getRecordings(data) {
    return api.recordings
      .getRecordings(deHydrateRecordings(data))
      .then(hydrateRecordings);
  }

  downloadRecording(data) {
    return api.recordings
      .downloadRecording(data)
      .then(hydrateDownloadRecording);
  }
}

export default new RecordingsService();
