import _ from "lodash";
import moment from "moment";
import { DATE_FORMAT } from "../../constants/appConstant";
import { hydratePagination } from "./paginationTransformer";
export function dehydrateTechnicianJobOrders(params) {
  return {
    user_id: params.userId,
  };
}

export function hydrateTechnicianJobOrder(data) {
  return {
    address: `${data.address1}${
      !_.isEmpty(data.address2) ? `, ${data.address2}` : ""
    }, ${data.city}, ${data.state}, ${data.country}.`,
    clientName: data.clientName,
    customerName: data.customerName,
    orderNumber: data.orderNumber,
    floorScanStatusList: data.floorScanStatusList,
    jobOrderId: data.jobOrderId,
    orderId: data.orderId,
    technicianName: data.technicianName,
    technicianAssignDate: moment(data.assignDate).isValid()
      ? moment.utc(data.assignDate).local().format(DATE_FORMAT)
      : "--",
    latestScanCreatedDate: moment(data.latestScanCreatedDate).isValid()
      ? moment.utc(data.latestScanCreatedDate).local().format(DATE_FORMAT)
      : "--",
    jobOrderSource: data.jobOrderSource,
    jobOrderStatus: data.status,
    isDemoJobOrder: data.isDemoJobOrder,
    jobOrderType: !_.isEmpty(data.jobOrderType) ? data.jobOrderType : "--",
  };
}

export const hydrateTechnicianJobOrders = (data) => {
  const list = _.get(data, "list", []);
  return {
    data: list.map((d) => hydrateTechnicianJobOrder(d)),
    pagination: hydratePagination(_.get(data, ["page"], {})),
  };
};

export const dyHydrateTechnicianJobOrders = (data) => {
  return {
    direction: data?.direction?.toUpperCase(),
    page: data.pageNo - 1,
    size: data.pageSize,
    sortBy: data?.sortBy,
    searchText: data.searchText,
  };
};

export const dyHydrateFloorscanList = (data) => {
  return {
    id: data.id,
    direction: data.direction,
    sortBy: data.sortBy,
  };
};

export const dyHydrateFloorScanStatus = (data) => {
  let formdata = new FormData();
  formdata.append(
    "details",
    JSON.stringify({
      floorScanId: data.id,
      floorScanStatus: data.status,
      floorPlanFailedReason: data?.floorPlanFailedReason,
    })
  );
  data?.files?.forEach((element) => {
    formdata.append("files", element);
  });
  return formdata;
};

export const dyHydrateFloorscanDetails = (id) => {
  return {
    id: id,
  };
};

export const dyHydrateFloorscanImage = (data) => {
  return {
    file: data.file,
  };
};
export function hydrateFloorScanItem(jobData) {
  return {
    id: jobData.floorScanId,
    FloorScan: jobData.floorScanNumber,
    FloorNumber: jobData.floorIndex,
    FloorScanType: jobData.floorScanType,
    CreatedOn: moment(jobData.createdAt).isValid()
      ? moment.utc(jobData.createdAt).local().format(DATE_FORMAT)
      : "--",
    zipPath: jobData.zipPath,
    floorPlanPath: jobData.floorPlanPath,
    Status: jobData.status,
    retryAvaliable: jobData.retryAvaliable,
    retryLimitReach: jobData.retryLimitReach,
    wallThickness: jobData.wallThickness,
    orderNumber: jobData.orderNumber,
  };
}

export const hydrateFloorscanList = (data) => {
  const list = data?.floorScanList;
  return {
    floorList: list.map((d) => hydrateFloorScanItem(d)),
    jobOrderSource: data.jobOrderSource,
    jobOrderId: data.jobOrderId,
    jobOrderStatus: data.jobOrderStatus,
    name: data.name || "Mayur",
  };
};

export const hydrateFloorscanDetail = (data) => {
  return {
    floorScanId: data.floorScanId,
    zipPath: data.zipPath,
    videoPath: data.videoPath,
    plyPath: data.plyPath,
    pdfPath: data.pdfPath,
    floorPlanPath: data.floorPlanPath,
    floorPlanViewPath: data.floorPlanViewPath,
    floorScanObjPoints: data.floorScanObjPoints,
    floorScanType: data.floorScanType,
    floorIndex: data.floorIndex,
    status: data.status,
    floorScanNumber: data.floorScanNumber,
    orderNumber: data.orderNumber,
    jobOrderId: data.jobOrderId,
    vsiScanIsOkay: data.vsiScanIsOkay,
    jobOrderSource: data.jobOrderSource,
    jobOrderStatus: data.jobOrderStatus,
  };
};

export const deHydratePlyRetryData = (data) => {
  return {
    floorScanID: data.floorScanID,
  };
};
