import * as actionTypes from "./actionTypes";
import PDRReportsService from "./../services/PDRReportsService";
import { StartLoading, StopLoading } from "./UIAction";

const startFetchPDRDetails = () => {
  return {
    type: actionTypes.FETCH_PDRDETAILS_START,
  };
};

const successFetchPDRDetails = (data) => {
  return {
    type: actionTypes.FETCH_PDRDETAILS_SUCCESS,
    payload: data,
  };
};

const errorFetchPDRDetails = (error) => {
  return {
    type: actionTypes.FETCH_PDRDETAILS_ERROR,
    payload: error,
  };
};

export const fetchPDRDetails = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchPDRDetails());
    return PDRReportsService.fetchPDRDetails(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchPDRDetails(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchPDRDetails(err));
      });
  };
};
