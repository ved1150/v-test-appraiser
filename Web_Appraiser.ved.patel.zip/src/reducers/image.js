import * as actionTypes from "../actions/actionTypes";

const imageState = {
  fetchImageStart: false,
  fetchImageSuccess: null,
  fetchImageError: null,
};

const downloadImageState = {
  downloadImageStart: false,
  downloadImageSuccess: null,
  downloadImageError: null,
};

const deleteImageState = {
  deleteImageStart: false,
  deleteImageSuccess: null,
  deleteImageError: null,
};

const defaultStates = {
  ...imageState,
  ...downloadImageState,
  ...deleteImageState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_IMAGE_START:
      return {
        ...state,
        fetchImageStart: true,
        fetchImageSuccess: null,
        fetchImageError: null,
      };
    case actionTypes.FETCH_IMAGE_SUCCESS:
      return {
        ...state,
        fetchImageStart: false,
        fetchImageSuccess: action.payload,
        fetchImageError: null,
      };
    case actionTypes.FETCH_IMAGE_ERROR:
      return {
        ...state,
        fetchImageStart: false,
        fetchImageSuccess: null,
        fetchImageError: action.payload,
      };
    case actionTypes.DOWNLOAD_IMAGE_START:
      return {
        ...state,
        downloadImageStart: true,
        downloadImageSuccess: null,
        downloadImageError: null,
      };
    case actionTypes.DOWNLOAD_IMAGE_SUCCESS:
      return {
        ...state,
        downloadImageStart: false,
        downloadImageSuccess: action.payload,
        downloadImageError: null,
      };
    case actionTypes.DOWNLOAD_IMAGE_ERROR:
      return {
        ...state,
        downloadImageStart: false,
        downloadImageSuccess: null,
        downloadImageError: action.payload,
      };
    case actionTypes.DELETE_IMAGE_START:
      return {
        ...state,
        deleteImageStart: true,
        deleteImageSuccess: null,
        deleteImageError: null,
      };
    case actionTypes.DELETE_IMAGE_SUCCESS:
      return {
        ...state,
        deleteImageStart: false,
        deleteImageSuccess: action.payload,
        deleteImageError: null,
      };
    case actionTypes.DELETE_IMAGE_ERROR:
      return {
        ...state,
        deleteImageStart: false,
        deleteImageSuccess: null,
        deleteImageError: action.payload,
      };
    default:
      return state;
  }
};
