import * as actionTypes from "./actionTypes";
import notesService from "./../services/notesService";
import { StartLoading, StopLoading } from "./UIAction";
const startFetchNotes = () => {
  return {
    type: actionTypes.FETCH_NOTES_START,
  };
};

const successFetchNotes = (data) => {
  return {
    type: actionTypes.FETCH_NOTES_SUCCESS,
    payload: data,
  };
};

const errorFetchNotes = (error) => {
  return {
    type: actionTypes.FETCH_NOTES_ERROR,
    payload: error,
  };
};

export const fetchNotes = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchNotes());
    return notesService
      .getNotes(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchNotes(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchNotes(err));
      });
  };
};
