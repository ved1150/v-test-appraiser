import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useParams } from "react-router-dom";
import {
  logIn,
  switchTechnician,
  switchTenant,
} from "../../actions/authenticationAction";
import { profileUpdate } from "../../actions/profileAction";
import { storageTypes, TempX_TenantKey } from "../../constants/appConstant";
import authenticationService from "../../services/authenticationService";
import localStorage from "../../services/storage";
import sessionStorage from "../../services/sessionStorage";

export default function SwitchTenant() {
  const history = useHistory();
  const params = useParams();
  let searchParams = new URLSearchParams(history.location.search);
  const authCode = searchParams.get("auth");
  const xtenant = searchParams.get("xtenant");
  const tenantToken = searchParams.get("tenantToken");
  const switchTechnicianToken = searchParams.get("switch-technician");
  const subDomain = searchParams.get("subDomain");
  const storageType = searchParams.get("type");
  const dispatch = useDispatch();
  useEffect(() => {
    if (authCode && authCode !== "null") {
      if (storageType == storageTypes.sessionStorage) {
        sessionStorage.clearAll();
      } else {
        localStorage.clearAll();
        sessionStorage.clearAll();
      }
      const userData = {
        ...JSON.parse(authenticationService.getDecAuthData(authCode)),
        tenant: params.tenantDomain,
      };
      dispatch(logIn(userData, history, true)).then((res) => {
        if (Array.isArray(res.tenantList)) {
          dispatch(profileUpdate({ selectedTenant: res.tenantList[0] }));
        }
      });
    }
    if (xtenant && tenantToken) {
      const headerData = {
        headers: {
          Authorization: `Bearer ${tenantToken}`,
          "X-Tenant": xtenant,
        },
      };
      dispatch(
        switchTenant(params.tenantDomain, headerData, storageType, history)
      );
    }
    if (switchTechnicianToken) {
      const headerData = {
        useCatalogMaster: true,
        token: switchTechnicianToken,
        xTenant: TempX_TenantKey,
      };
      dispatch(switchTechnician(headerData, subDomain, storageType, history));
    }
  }, []);

  return null;
}
