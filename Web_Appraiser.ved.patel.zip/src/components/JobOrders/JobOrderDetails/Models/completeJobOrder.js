import React, { useState, useEffect } from "react";
import { JOB_ORDER_COMPLETED_MESSSAGE } from "../../../../constants/commonMessages";
import { customToast } from "../../../../helpers/customToast";
import Button from "../../../common/Button";
import { useTranslation } from "react-i18next";
const CompleteJobOrder = (props) => {
  const { t } = useTranslation();
  const [virtualCall, setVirtualCall] = useState(true);
  const [fieldInspection, setFieldInspection] = useState(true);
  const [inspectionForm, setInspectionForm] = useState(true);
  const [questionnaire, setQuestionnaire] = useState(true);
  const [measurement, setMeasurement] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const completeJobOrder = () => {
    setSubmitting(true);
    props
      .completeJobOrder(props.completeData, props.jobOrderId)
      .then((res) => {
        setSubmitting(false);
        props.setCompleteJobOrder(false);
        customToast.success(t("COMMON_MESSAGES.JOB_ORDER_COMPLETED_MESSSAGE"));
        props.history.push("/");
      })
      .catch((err) => {
        setSubmitting(false);
        props.setCompleteJobOrder(false);
      });
  };

  return (
    <div className="comman-modal complete-job-order right-side open">
      <div className="comman-modal-main">
        <div className="side-head">
          <span className="icon">
            <i className="icon-complete-job-order"></i>
          </span>
          {t("BUTTONS.Inspection_Completed")}
          <button
            className="close-modal"
            onClick={() => props.setCompleteJobOrder(false)}
          >
            <i className="icon-close-image"></i>
          </button>
        </div>
        <div className="comman-modal-body scroll-bar-style">
          <div className="toggle-list">
            <div className="toggle">
              <div className="toggle-box">
                <label className="radio-button">
                  <input
                    type="radio"
                    name="yes1"
                    onChange={() => setVirtualCall(!virtualCall)}
                    checked={virtualCall}
                  />
                  <span>{t("COMMON_MESSAGES.Yes")}</span>
                </label>
                <label className="radio-button">
                  <input type="radio" name="yes1" />
                  <span>{t("COMMON_MESSAGES.No")}</span>
                </label>
              </div>
              <span className="text">{t("WEB_LABELS.Virtual_call_taken")}</span>
            </div>
            <div className="toggle">
              <div className="toggle-box">
                <label className="radio-button">
                  <input
                    type="radio"
                    name="yes2"
                    onChange={() => setFieldInspection(!fieldInspection)}
                    checked={fieldInspection}
                  />
                  <span>{t("COMMON_MESSAGES.Yes")}</span>
                </label>
                <label className="radio-button">
                  <input type="radio" name="yes2" />
                  <span>{t("COMMON_MESSAGES.No")}</span>
                </label>
              </div>
              <span className="text">
                {t("WEB_LABELS.Have_done_field_inspection")}
              </span>
            </div>
            <div className="toggle">
              <div className="toggle-box">
                <label className="radio-button">
                  <input
                    type="radio"
                    name="yes3"
                    onChange={() => setInspectionForm(!inspectionForm)}
                    checked={inspectionForm}
                  />
                  <span>{t("COMMON_MESSAGES.Yes")}</span>
                </label>
                <label className="radio-button">
                  <input type="radio" name="yes3" />
                  <span>{t("COMMON_MESSAGES.No")}</span>
                </label>
              </div>
              <span className="text">
                {t("WEB_LABELS.Inspection_form_1004_submitted")}
              </span>
            </div>
            <div className="toggle">
              <div className="toggle-box">
                <label className="radio-button">
                  <input
                    type="radio"
                    name="yes4"
                    onChange={() => setQuestionnaire(!questionnaire)}
                    checked={questionnaire}
                  />
                  <span>{t("COMMON_MESSAGES.Yes")}</span>
                </label>
                <label className="radio-button">
                  <input type="radio" name="yes4" />
                  <span>{t("COMMON_MESSAGES.No")}</span>
                </label>
              </div>
              <span className="text">
                {t("WEB_LABELS.Questionnaire_submitted")}
              </span>
            </div>
            <div className="toggle">
              <div className="toggle-box">
                <label className="radio-button">
                  <input
                    type="radio"
                    name="yes5"
                    onChange={() => setMeasurement(!measurement)}
                    checked={measurement}
                  />
                  <span>{t("COMMON_MESSAGES.Yes")}</span>
                </label>
                <label className="radio-button">
                  <input type="radio" name="yes5" />
                  <span>{t("COMMON_MESSAGES.No")}</span>
                </label>
              </div>
              <span className="text">{t("WEB_LABELS.Measurement_done")}</span>
            </div>
          </div>

          <div className="text-center">
            <Button
              className="blue-btn"
              disabled={submitting}
              onClick={() => completeJobOrder()}
            >
              {t("BUTTONS.Save")}{" "}
              {submitting && <div className="loader-spin"></div>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompleteJobOrder;
