import api from "./api";

export default class PDRReportsAPI {
  fetchPDRDetails(data) {
    return api.get(`/joborder/pdr-details/${data}`);
  }
}
