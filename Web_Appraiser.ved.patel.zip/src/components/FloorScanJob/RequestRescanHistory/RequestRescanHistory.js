import { useSelector } from "react-redux";
import AsyncImage from "../../common/AsyncImage";
import _ from "lodash";
import NoDataView from "../../JobOrders/JobOrderDetails/Common/noDataView";
import { useTranslation } from "react-i18next";
import moment from "moment";

const RequestRescanHistory = (props) => {
  const requestRescanHistoryData = useSelector(
    (state) =>
      state?.technicianJob?.requestRescanHistoryStateSuccess?.data?.data
  );

  const requestRescanHistoryLoading = useSelector(
    (state) => state?.technicianJob?.requestRescanHistoryStateStart
  );

  const { t } = useTranslation();

  return (
    <div className="comman-modal-body attach-document-modal scroll-bar-style">
      {requestRescanHistoryLoading && (
        <div className="no-data-found-container">
          <div className="no-data-found">
            <div className="box">
              <div className="loader-spin"></div>
            </div>
          </div>
        </div>
      )}
      {!requestRescanHistoryLoading && _.isEmpty(requestRescanHistoryData) && (
        <div className="no-data-found-container">
          <div className="no-data-found">
            <div className="box">
              <p>{t("There_Is_No_History_Available")}</p>
            </div>
          </div>
        </div>
      )}
      <div className="attach-list">
        {requestRescanHistoryData?.map((data) => {
          return (
            <div className="box">
              <div className="title">
                <i className="icon-Attach-Document"></i>
                {data?.floorRescanReason}
              </div>
              <br />
              <div
                className="rrh-image-container"
                onClick={() => {
                  props.setShowRequestRescanHistoryImagesModal(true);
                  props.setRequestRescanHistoryImagesModalData(
                    data?.floorRescanImageList
                  );
                }}
              >
                {data?.floorRescanImageList?.map((img) => (
                  <div className="rrh-image-box">
                    <div className="rrh-small-image">
                      <AsyncImage imageUrl={img} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="bottom-list">
                <div className="rigit-info rescan-time">
                  <span className="time">
                    <i className="icon-Time"></i>
                    {data?.createdAt &&
                      moment
                        .utc(data?.createdAt)
                        .local()
                        .format("MM/DD/YYYY hh:mm A")}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RequestRescanHistory;
