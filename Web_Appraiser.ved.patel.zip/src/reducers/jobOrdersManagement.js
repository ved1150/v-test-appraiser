import * as actionTypes from "../actions/actionTypes";

const jobOrdersManagementState = {
  createJobOrderStart: false,
  createJobOrderSuccess: {},
  createJobOrderError: null,
  editJobOrderStart: false,
  editJobOrderSuccess: {},
  editJobOrderError: null,
};

export const defaultState = {
  ...jobOrdersManagementState,
};

const jobOrdersManagementReducer = (state = defaultState, action = {}) => {
  switch (action.type) {
    case actionTypes.CREATE_JOBORDER_START:
      return {
        ...state,
        createJobOrderStart: true,
        createJobOrderSuccess: {},
        createJobOrderError: null,
      };
    case actionTypes.CREATE_JOBORDER_SUCCESS:
      return {
        ...state,
        createJobOrderStart: false,
        createJobOrderSuccess: action.payload,
        createJobOrderError: null,
      };
    case actionTypes.CREATE_JOBORDER_ERROR:
      return {
        ...state,
        createJobOrderStart: false,
        createJobOrderSuccess: {},
        createJobOrderError: action.payload,
      };
    case actionTypes.EDIT_JOBORDER_START:
      return {
        ...state,
        editJobOrderStart: true,
        editJobOrderSuccess: {},
        editJobOrderError: null,
      };
    case actionTypes.EDIT_JOBORDER_SUCCESS:
      return {
        ...state,
        editJobOrderStart: false,
        editJobOrderSuccess: action.payload,
        editJobOrderError: null,
      };
    case actionTypes.EDIT_JOBORDER_ERROR:
      return {
        ...state,
        editJobOrderStart: false,
        editJobOrderSuccess: {},
        editJobOrderError: action.payload,
      };
    default:
      return state;
  }
};

export default jobOrdersManagementReducer;
