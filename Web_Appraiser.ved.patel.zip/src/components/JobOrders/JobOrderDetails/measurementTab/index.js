import React, { Component } from "react";
import { saveMeasurementJson } from "./../../../../actions/measurementAction";
import { connect } from "react-redux";
import { fabric } from "fabric";
import CustomSwitch from "./../../../common/CustomSwitch/index";
import "fabric-history";
import * as THREE from "three";
import _ from "lodash";
import debounce from "lodash.debounce";
import bgimg from "./../../../../images/box-pattern.png";
import "./index.scss";
import AreaDetails from "./areaDetails";
import ConfirmationModal from "./../../../common/confirmationModal";
import classnames from "classnames";
import { customToast } from "../../../../helpers/customToast";
import moment from "moment";
import { withTranslation } from "react-i18next";
import {
  AUTOSNAP_INSIDE_DOOR,
  DELETEROOM_CONFIRMATION_MESSAGE,
  DELETE_ROOM_MESSAGE,
  MEASUREMENT_SAVE_MESSAGE,
  REQUIRED_ROOM_SELECTION,
} from "../../../../constants/commonMessages";
import Tooltip from "@mui/material/Tooltip";
import {
  measurementTypes,
  measurementResponseFormat,
  AREA_TYPES,
  screenModeTypes,
  threeDFloorScan,
} from "../../../../constants/appConstant";
import { MEASUREMENTS_ICON } from "../Common/commonText.js";
import {
  getLabelPositionOuter,
  getRoomData,
  coordinateForlable,
  getLabelPosition,
  isIntersectObject,
  insidePoly,
} from "./Intersection";
import {
  doorDirection,
  doorDirectionEnum,
  floorName,
} from "../../../../constants/enums";
import {
  StartCenterLoading,
  StartLoading,
  StopCenterLoading,
  StopLoading,
} from "./../../../../actions/UIAction";
import {
  FindNewCoordinates,
  hasIntersectWall,
  IsInside,
} from "../../../FloorScanJob/View3DFloorPlan/UtilityThreejs";
import {
  createEditablePartition,
  removePartitionCircle,
  deselectPartition,
  dragPartitionDoor,
  createPartitionDoor,
  addPartitionCircle,
  addPartitionDoorFromBuildMenu,
  createPartitionWindow,
  dragPartitionWindow,
  PARTITION_WINDOW_COLOR,
  PARTITION_DOOR_COLOR,
  updateOldJSON,
  PARTITION_INSIDE_DOOR_COLOR,
  partitionLineStokeWidth,
  lineStokeWidth,
  ROOM_WALL_DOOR_COLOR,
  PARTITION_COLOR,
  NON_ADDITIONAL_BORDER_COLOR,
  GLA_BORDER_COLOR,
  EXTERIOR_BORDER_COLOR,
  NON_GLA_BORDER_COLOR,
  PARTITION_WINDOW_COLOR_BORDER,
} from "./utilityTwoD";
import { createTextGroup, getLocation } from "./addLineArrow";
import store from "../../../../store";
let fontSize = 14,
  degree = 0,
  modifiedEagleViewJson = {},
  designatorWiseObjectArray = {},
  roomWiseLineAndTextObjects = {},
  roomLinesGroup = [],
  roomTextGroup = [],
  roomConnectorGroup = [],
  ratioX = 1,
  ratioY = 1,
  ratio = null,
  zoomlevel = 100, // this is 1 meter = 100 pixels , based on ios auto conversation.
  originalFloorPlan = null,
  updatedFloorPlan = null,
  PIXEL_TO_FOOT_CONSTANT = 0.035, // let PIXEL_TO_FOOT_CONSTANT = 0.015625;
  selectedRoom = "",
  editModeDataXYKey = ["@editedXY", "@autoSnappedXY"],
  roomArray = [],
  editedRoomID = 0,
  currentCircleEvent = null,
  editedRoomTop = 0,
  editedRoomLeft = 0,
  editedRoomAngle = 0,
  isEditMode = false,
  EditModeChanges = [],
  editedRoomInitialLeft = 0,
  editedRoomInitialTop = 0,
  editedRoomEndlLeft = 0,
  editedRoomEndTop = 0,
  editedRoomFinalLeftDist = 0,
  editedRoomFinalTopDist = 0,
  rotatedAngle = 0,
  isGroupMoving = false,
  FloorRotation = 0,
  roomWiseFontSize = {},
  isDoorEdited = false,
  isWindowEdited = false,
  isLineEdited = false,
  isStairCaseEdited = false;

const MAX_FONT_SIZE = 18,
  MIN_FONT_SIZE = 6,
  STATE_IDLE = "idle",
  STATE_PANNING = "panning",
  stairCasePath =
    "M0 0 50 0 50 100 0 100ZM0 10 50 10M0 20 50 20M0 30 50 30M0 40 50 40M0 50 50 50M0 60 50 60M0 70 50 70M0 80 50 80M0 90 50 90";
class MeasurementTab extends Component {
  baseState = {};
  canvas = null;
  isnewline = null;
  maxX = 0;
  maxY = 0;
  minX = null;
  minY = null;
  canvasWidth = window.innerHeight - 400;
  canvasHeight = window.innerWidth - 400;

  // variables used for drawing a polyline (Add Polyline) from buid menu
  addPolylineVariables = {
    mouse: null,
    polyline: null,
    mouseDown: false,
    pts: [],
    lastPt: 1,
    obj: null,
    poly: false,
  };

  // variables used for drawing a line (Add Line) from buid menu
  addLineVariables = {
    mouseDown: null,
    point1: null,
    line: null,
  };

  // variables used for drawing a partition door (Add Door) from buid menu
  addPartitionDoorVariables = {
    mouseDown: null,
    point1: null,
    line: null,
  };

  constructor(props) {
    super();
    this.state = {
      areaDetails: {},
      floorList: [{ floorId: "", floorName: "" }],
      selectedFloor: 0,
      selectedFloorName: "",
      selectedCustomFloorName: "",
      confirmationModal: false,
      enableDelete: false,
      showAreaDetails: false,
      isShowAreaName: true,
      baseFontSize: 14,
      roomWiseScale: {},
      wallThickness: 6,
      wallThicknessError: false,
      is90Degree: true,
      isEditMode: false,
      isDoorAvailable: true,
      style: {},
      undocount: 0,
      doundo: false,
      isEditModeEnabled: false,
      selectedRoomType: "",
      selectedRoom: "",
      isAddLabel: false,
      enableLabelDelete: false,
      selectedLabel: "",
      enableLineDelete: false,
      selectedLine: "",
      enablePartitionDoorDelete: false,
      selectedPartitionDoor: "",
      enablePartitionWindowDelete: false,
      selectedPartitionWindow: "",
      isAddLineFromBuildMenu: false,
      isAddPolylineFromBuildMenu: false,
      selectedMeasurementType: "1",
      showErrorPage: false,
      isMajourmentData: true,
      lineselected: false,
      linestyle: {},
      selectedModifiedLine: null,
      newline: null,
      isDown: false,
      drawMode: false,
      isModifiableRoom: false,
      isAddDoorFromBuildMenu: false,
      isAddWindowFromBuildMenu: false,
      showCanvasGrid: false,
      enableDoorDelete: false,
      selectedDoor: "",
      lastLinePoints: null,
      isIntersectPartitionWall: null,
      partitionMoveRoomID: null,
      doorDirection: doorDirectionEnum.inside,
      loadDropdownJsonFlag: false,
      wallLinePointerArray: [],
      extractedWallLineID: null,
      isAddStairCase: false,
      enableStairCaseDelete: false,
      selectedStairCase: "",
      textSize: 12,
    };
    this.baseState = { ...this.state };
    this.onObjectChange = this.onObjectChange.bind(this);
    this.restrictObject = this.restrictObject.bind(this);
    this.editArea = this.editArea.bind(this);
    this.createEditableRoom = this.createEditableRoom.bind(this);
    this.drawFloorPlan = this.drawFloorPlan.bind(this);
    this.handleMeasurementTypeChange =
      this.handleMeasurementTypeChange.bind(this);
    this.loadCanvasWithData = this.loadCanvasWithData.bind(this);
  }

  componentWillMount() {
    if (
      !this?.props?.newMeasurementTypes?.remoteVal &&
      !this.props.isTechnician?.create &&
      !this.props?.isTechnician?.edit
    ) {
      this.setState({
        selectedMeasurementType: this?.props?.newMeasurementTypes
          ?.remoteValVideo
          ? "4"
          : "1",
      });
    } else if (
      this.props.isTechnician?.create ||
      this.props?.isTechnician?.edit
    ) {
      this.setState({
        selectedMeasurementType: "4",
      });
    }
  }
  toggleCanvasGrid = () => {
    if (this.state.isEditModeEnabled) {
      this.canvas.setBackgroundColor(
        {
          source: bgimg,
        },
        this.canvas.renderAll.bind(this.canvas)
      );
    } else {
      this.canvas.setBackgroundColor(
        "white",
        this.canvas.renderAll.bind(this.canvas)
      );
    }
  };

  resetAllVariables = () => {
    fontSize = 14;
    degree = 0;
    modifiedEagleViewJson = {};
    designatorWiseObjectArray = {};
    roomWiseLineAndTextObjects = {};
    roomLinesGroup = [];
    roomTextGroup = [];
    roomConnectorGroup = [];
    ratioX = 1;
    ratioY = 1;
    ratio = null;
    zoomlevel = 100;
    originalFloorPlan = null;
    updatedFloorPlan = null;
    PIXEL_TO_FOOT_CONSTANT = 0.035;
    selectedRoom = "";
    editModeDataXYKey = ["@editedXY", "@autoSnappedXY"];
    roomArray = [];
    editedRoomID = 0;
    currentCircleEvent = null;
    editedRoomTop = 0;
    editedRoomLeft = 0;
    editedRoomAngle = 0;
    isEditMode = false;
    EditModeChanges = [];
    editedRoomInitialLeft = 0;
    editedRoomInitialTop = 0;
    editedRoomEndlLeft = 0;
    editedRoomEndTop = 0;
    editedRoomFinalLeftDist = 0;
    editedRoomFinalTopDist = 0;
    rotatedAngle = 0;
    isGroupMoving = false;
    FloorRotation = 0;
    roomWiseFontSize = {};
    isDoorEdited = false;
    isWindowEdited = false;
    isLineEdited = false;
    isStairCaseEdited = false;

    this.canvas = null;
    this.maxX = 0;
    this.maxY = 0;
    this.minX = null;
    this.minY = null;
    this.canvasWidth = window.innerHeight - 400;
    this.canvasHeight = window.innerWidth - 400;

    // variables used for drawing a polyline (Add Polyline) from buid menu
    this.addPolylineVariables = {
      mouse: null,
      polyline: null,
      mouseDown: false,
      pts: [],
      lastPt: 1,
      obj: null,
      poly: false,
    };

    // variables used for drawing a line (Add Line) from buid menu
    this.addLineVariables = {
      mouseDown: null,
      point1: null,
      line: null,
    };

    // variables used for drawing a partition door (Add Door) from buid menu
    this.addPartitionDoorVariables = {
      mouseDown: null,
      point1: null,
      line: null,
    };
  };

  componentDidUpdate(prevProps) {
    if (
      this.props.isTechnician?.create &&
      prevProps.screenMode != this.props.screenMode
    ) {
      let canvasHeight = document.querySelector(
        "div.open.tab-content"
      ).clientHeight;

      let canvasWidth = document.querySelector(
        "div.open.tab-content"
      ).clientWidth;
      this.canvas.setHeight(canvasHeight);
      if (this.props.screenMode == screenModeTypes.maximize) {
        this.canvas.setWidth(canvasWidth + 200);
      } else {
        this.canvas.setWidth(canvasWidth);
      }
      this.canvas.renderAll();
    }
    if (!_.isEqual(prevProps.mesurementData, this.props.mesurementData)) {
      const _measurementTypeState = this.state.selectedMeasurementType;
      this.setState(
        {
          ...this.baseState,
          selectedMeasurementType: _measurementTypeState,
        },
        () => {
          this.resetAllVariables();
          this.loadCanvasWithData();
        }
      );
    }
  }
  async componentDidMount() {
    this.loadCanvasWithData();
  }

  loadCanvasWithData() {
    let jsonData;
    if (this.state.selectedMeasurementType == measurementTypes[0].id) {
      jsonData = this.props.mesurementData.jsonData;
    } else if (this.state.selectedMeasurementType == measurementTypes[1].id) {
      jsonData = this.props.mesurementData.eagleViewCommonFormatJsonData;
    } else if (this.state.selectedMeasurementType == measurementTypes[2].id) {
      jsonData = this.props.mesurementData.estatedCommonFormatJsonData;
    } else if (this.state.selectedMeasurementType == measurementTypes[3].id) {
      if (this.props.isTechnician?.create) {
        jsonData = this.props.JsonObject;
      } else {
        jsonData = this.props.mesurementData.floorScanJsonData;
      }
    } else {
      jsonData = null;
    }
    _.isEmpty(jsonData) && this.setState({ showErrorPage: true });
    if (
      !jsonData?.EAGLEVIEW_EXPORT?.STRUCTURES?.ROOF?.FACES?.FACE ||
      jsonData?.EAGLEVIEW_EXPORT?.STRUCTURES?.ROOF?.FACES?.FACE?.length === 0
    ) {
      jsonData = null;
      this.setState({ showErrorPage: true });
    }
    if (jsonData && jsonData?.EAGLEVIEW_EXPORT?.STRUCTURES) {
      let roofPoints = [jsonData.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT];
      if (!roofPoints[0][0] || !roofPoints[0][0]["@autoSnappedXY"]) {
        this.setState({ isMajourmentData: false });
      }
    }
    let canvas;

    if (this.props.isTechnician?.edit) {
      this.canvasHeight = document.querySelector(
        ".measurement-container.technician-container"
      ).clientHeight;

      this.canvasWidth = document.querySelector(
        ".measurement-container.technician-container"
      ).clientWidth;
    } else {
      this.canvasHeight = document.querySelector(
        "div.open.tab-content"
      ).clientHeight;

      this.canvasWidth = document.querySelector(
        "div.open.tab-content"
      ).clientWidth;
    }

    canvas = new fabric.Canvas("measurementcanvas", {
      height: this.canvasHeight,
      width: this.canvasWidth,
      selection: false,
    });

    /*
    canvas.setBackgroundColor(
      {
        source: bgimg,
      },
      canvas.renderAll.bind(canvas)
    );
    */

    fabric.Canvas.prototype.toggleDragMode = function (dragMode) {
      // Remember the previous X and Y coordinates for delta calculations
      let lastClientX;
      let lastClientY;
      // Keep track of the state
      let state = STATE_IDLE;
      // We're entering dragmode
      if (dragMode) {
        // Discard any active object
        this.discardActiveObject();
        // Set the cursor to 'move'
        this.defaultCursor = "move";
        // Loop over all objects and disable events / selectable. We remember its value in a temp variable stored on each object
        this.forEachObject(function (object) {
          object.prevEvented = object.evented;
          object.prevSelectable = object.selectable;
          object.evented = false;
          object.selectable = false;
        });
        // Remove selection ability on the canvas
        this.selection = false;
        // When MouseUp fires, we set the state to idle
        this.on("mouse:up", function (e) {
          state = STATE_IDLE;
        });
        // When MouseDown fires, we set the state to panning
        this.on("mouse:down", (e) => {
          state = STATE_PANNING;
          lastClientX = e.e.clientX;
          lastClientY = e.e.clientY;
        });
        // When the mouse moves, and we're panning (mouse down), we continue
        this.on("mouse:move", (e) => {
          if (state === STATE_PANNING && e && e.e) {
            // let delta = new fabric.Point(e.e.movementX, e.e.movementY); // No Safari support for movementX and movementY
            // For cross-browser compatibility, I had to manually keep track of the delta

            // Calculate deltas
            let deltaX = 0;
            let deltaY = 0;
            if (lastClientX) {
              deltaX = e.e.clientX - lastClientX;
            }
            if (lastClientY) {
              deltaY = e.e.clientY - lastClientY;
            }
            // Update the last X and Y values
            lastClientX = e.e.clientX;
            lastClientY = e.e.clientY;

            let delta = new fabric.Point(deltaX, deltaY);
            this.relativePan(delta);
            //   this.trigger('moved');
          }
        });
      } else {
        // When we exit dragmode, we restore the previous values on all objects
        this.forEachObject(function (object) {
          object.evented =
            object.prevEvented !== undefined
              ? object.prevEvented
              : object.evented;
          object.selectable =
            object.prevSelectable !== undefined
              ? object.prevSelectable
              : object.selectable;
        });
        // Reset the cursor
        this.defaultCursor = "default";
        // Remove the event listeners
        this.off("mouse:up");
        this.off("mouse:down");
        this.off("mouse:move");
        // Restore selection ability on the canvas
        this.selection = true;
      }
    };

    fabric.Canvas.prototype.getItemByAttr = function (attr, name) {
      let object = null,
        objects = this.getObjects();
      for (let i = 0, len = this.size(); i < len; i++) {
        if (objects[i][attr] && objects[i][attr] === name) {
          object = objects[i];
          break;
        }
      }
      return object;
    };

    this.canvas = canvas;
    //dwnew
    if (this.state.selectedMeasurementType == measurementTypes[0].id) {
      if (_.isObject(this.props.mesurementData.jsonData)) {
        //updatedFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);
        originalFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);
        originalFloorPlan = updateOldJSON(originalFloorPlan)
          ? updateOldJSON(originalFloorPlan)
          : originalFloorPlan;
        updatedFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);

        //dwnew
        this.showTheListFromJsonRoomWise(updatedFloorPlan);
      }
    } else if (this.state.selectedMeasurementType == measurementTypes[1].id) {
      if (_.isObject(this.props.mesurementData.eagleViewCommonFormatJsonData)) {
        //updatedFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);
        originalFloorPlan = _.cloneDeep(
          this.props.mesurementData.eagleViewCommonFormatJsonData
        );
        originalFloorPlan = updateOldJSON(originalFloorPlan)
          ? updateOldJSON(originalFloorPlan)
          : originalFloorPlan;
        updatedFloorPlan = _.cloneDeep(
          this.props.mesurementData.eagleViewCommonFormatJsonData
        );
        this.showTheListFromJsonRoomWise(updatedFloorPlan);
      }
    } else if (this.state.selectedMeasurementType == measurementTypes[2].id) {
      if (_.isObject(this.props.mesurementData.estatedCommonFormatJsonData)) {
        //updatedFloorPlan = _.cloneDeep(this.props.mesurementData.jsonData);
        originalFloorPlan = _.cloneDeep(
          this.props.mesurementData.estatedCommonFormatJsonData
        );
        originalFloorPlan = updateOldJSON(originalFloorPlan)
          ? updateOldJSON(originalFloorPlan)
          : originalFloorPlan;
        updatedFloorPlan = _.cloneDeep(
          this.props.mesurementData.estatedCommonFormatJsonData
        );
        this.showTheListFromJsonRoomWise(updatedFloorPlan);
      }
    } else if (this.state.selectedMeasurementType == measurementTypes[3].id) {
      if (
        !this.props.isTechnician?.create &&
        _.isObject(this.props.mesurementData.floorScanJsonData)
      ) {
        originalFloorPlan = _.cloneDeep(
          this.props.mesurementData.floorScanJsonData
        );
        originalFloorPlan = updateOldJSON(originalFloorPlan)
          ? updateOldJSON(originalFloorPlan)
          : originalFloorPlan;
        updatedFloorPlan = _.cloneDeep(
          this.props.mesurementData.floorScanJsonData
        );

        this.showTheListFromJsonRoomWise(updatedFloorPlan);
      } else if (this.props.isTechnician?.create) {
        originalFloorPlan = _.cloneDeep(this.props.JsonObject);
        updatedFloorPlan = _.cloneDeep(this.props.JsonObject);

        originalFloorPlan = updateOldJSON(originalFloorPlan)
          ? updateOldJSON(originalFloorPlan)
          : originalFloorPlan;
        this.showTheListFromJsonRoomWise(updatedFloorPlan);
      }
    } else {
    }
  }
  /**
   * Purpose : This function will loop each element from JSON and will prepare another object
   * which will be used to show floor plan
   * @param {Object} JSON which contains all the details about floor plan
   */
  async showTheListFromJsonRoomWise(json, isResetJsontoOriginal = false) {
    // clean-up event-listeners
    [
      "mouse:dblclick",
      "mouse:up",
      "mouse:move",
      "mouse:down",
      "text:editing:entered",
      "text:editing:exited",
      "object:moving",
      "object:rotated",
      "object:scaling",
      "object:rotating",
    ].forEach((event) => {
      this.canvas.off(event);
    });

    let jsonObject = json;
    let floorArray = [];

    // originalFloorPlan = json;
    //updatedFloorPlan = _.cloneDeep(originalFloorPlan);
    if (
      !jsonObject?.EAGLEVIEW_EXPORT?.STRUCTURES?.ROOF?.FACES?.FACE ||
      jsonObject?.EAGLEVIEW_EXPORT?.STRUCTURES?.ROOF?.FACES?.FACE?.length === 0
    ) {
      jsonObject = null;
      this.setState({ showErrorPage: true });
      return;
    }
    let dataStructure = _.get(
      jsonObject,
      ["EAGLEVIEW_EXPORT", "STRUCTURES"],
      {}
    );
    this.setState({
      wallThickness: _.get(dataStructure, ["@exteriorWallThickness"], 6),
    });
    let roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    let roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    let roofPointsArray = roofPoints[0]["POINT"];

    let lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    let linesArray = lines[0].LINE;

    let faceArray = roofObject[0]["FACES"]["FACE"];

    designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = faceArray[faceArrayIndex];
      if (
        designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
        roomFaceObject["@type"] == "ROOM"
      ) {
        //Get walls of room

        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");

        //Not iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];
            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              let lineId = faceObject["POLYGON"]["@path"];

              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  var linePointObjectArray = [];
                  let linePoints = lineObject["@path"].split(",");
                  for (
                    let linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];
                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        linePointObjectArray.push(roofPointObject);

                        break;
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["LINE"] = lineObject;
                  faceArray[wallFaceObjectIndex] = faceObject;
                }
              }

              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            }
          }
        }
      } else {
        //TBD. NOT IN USE.
      }
    }

    this.canvas.viewportTransform[4] = 0;
    this.canvas.viewportTransform[5] = 0;

    this.canvas.isDrawingMode = false;
    this.canvas.freeDrawingBrush.width = 5;
    this.canvas.freeDrawingBrush.color = "red";

    let pointer = {
      x: 0,
      y: 0,
    };

    let options = { pointer, e: {} }; // required for Fabric 4.3.1

    this.canvas.freeDrawingBrush.onMouseDown(pointer, options);

    roomArray = Object.keys(designatorWiseObjectArray);

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      roomWiseFontSize[roomArray[roomArrayIndex]] = this.state.baseFontSize;

      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        if (wallObject.LINE == null) {
          floorArray.push({
            floorId: parseInt(wallObject["@floorindex"]),
            floorName: wallObject["@floor"],
          });
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          let value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@editedXY"];
          if (value1 == null) {
            break;
          }
          let id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          let v1 = value1.split(",");
          let fval = { id: id, x: v1[0], y: v1[1], z: 0 };

          if (parseFloat(v1[0]) > this.maxX) {
            this.maxX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) > this.maxY) {
            this.maxY = parseFloat(v1[1]);
          }

          if (this.minX == null) {
            this.minX = this.maxX;
          }
          if (this.minY == null) {
            this.minY = this.maxY;
          }

          if (parseFloat(v1[0]) < this.minX) {
            this.minX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) < this.minY) {
            this.minY = parseFloat(v1[1]);
          }
        }
      }
    }

    if (!isResetJsontoOriginal) {
      this.minX = this.minX - 120;
      this.minY = this.minY - 120;

      //Original
      this.canvas.setHeight(this.canvasHeight + 50);
      this.canvas.setWidth(this.canvasWidth + 50);
    }

    ratioX = 1;
    ratioY = 1;

    let multiplierX = 1;
    if (this.maxX - this.minX < this.canvasWidth) {
      ratioX = (this.canvasWidth / (this.maxX - this.minX)) * multiplierX;
    } else {
      ratioX = ((this.maxX - this.minX) / this.canvasWidth) * multiplierX;
    }

    if (this.maxY - this.minY < this.canvasHeight) {
      ratioY =
        (this.canvasHeight / (this.maxY - this, this.minY)) * multiplierX;
    } else {
      ratioY = ((this.maxY - this.minY) / this.canvasHeight) * multiplierX;
    }

    ratioX = Math.ceil(ratioX);
    ratioY = Math.ceil(ratioY);

    let maxRatio = ratioX > ratioY ? ratioX : ratioY;

    this.ratio = 1 / maxRatio;
    // this.ratio = 1 ;

    zoomlevel =
      _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"]) &&
      !_.isNaN(
        _.parseInt(
          _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"])
        )
      )
        ? _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"])
        : zoomlevel;
    let metertofeet = 3.28084;
    let pixeltometer = 1 / zoomlevel;
    let pixeltofeet = pixeltometer * metertofeet;
    PIXEL_TO_FOOT_CONSTANT = pixeltofeet;

    floorArray = _.uniq(floorArray);
    floorArray = _.uniqBy(floorArray, "floorId");

    floorArray = _.sortBy(floorArray, ["floorId"]);
    this.setState(
      {
        floorList: floorArray,
        selectedFloor: floorArray?.[0]?.floorId,
        selectedFloorName: floorArray?.[0]?.floorName,
      },
      () => {
        if (this.state.selectedFloor == "4") {
          this.setState({ isShowAreaName: false });
        }
        this.drawFloorPlan();
      }
    );
    EditModeChanges = [];
    EditModeChanges.push({
      originalFloorPlan: _.cloneDeep(originalFloorPlan),
      designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
      floorId: floorArray[0].floorId,
    });
    this.setState({ undocount: EditModeChanges.length });
    //Now only get those room which has specific floor index;

    this.canvas.on("mouse:down", (e) => {
      if (e.target == null) {
        return;
      }
      if (e.target.type == "DW") {
        this.canvas._objects = this.canvas._objects.filter(
          (val) => val.id != "doorobject_" + e.target.id
        );
      } else if (e.target.type == "GROUP") {
        this.canvas._objects = this.canvas._objects.filter(
          (val) => val.type != "doorobject"
        );
        this.canvas._objects = this.canvas._objects.filter(
          (val) => val.type != "Clone-DW"
        );
      }
    });
    this.canvas.on("mouse:up", (e) => {
      if (e.target == null) {
        return;
      }
      if (
        (e.target?.isDoor || e.target.type == "PARTITION_DOOR") &&
        !this.state.isEditModeEnabled
      ) {
        this.createDoorShapeObject(e.target);
      } else if (e.target.type == "GROUP") {
        this.createDoorsAndWindows(true);
        createPartitionDoor(this, originalFloorPlan, false);
      }
    });
    // mousedown:dblclick
    this.canvas.on(
      "mouse:dblclick",
      function (e) {
        if (e.target == null || isEditMode == true) {
          return;
        }
        if (e.target.type == "textLabel" || e.target.type === "stair-case") {
          return;
        }
        if (e.target.type == "LINE" && this.state.isEditModeEnabled) {
          createEditablePartition(this, e.target);
          return;
        }
        if (this.state.isAddPolylineFromBuildMenu) {
          this.setState({
            isAddPolylineFromBuildMenu: false,
          });
          this.canvas.forEachObject((obj) => {
            if (obj.name === "temp-line-from-build") {
              this.canvas.remove(obj);
            }
          });
          // remove duplicate points
          this.addPolylineVariables.pts = _.uniqWith(
            this.addPolylineVariables.pts,
            _.isEqual
          );
          let polyObj = new fabric.Polyline(this.addPolylineVariables.pts, {
            objectCaching: false,
            roomID: selectedRoom,
            type: "LINE",
            stroke: "black",
            fill: "",
            originX: "center",
            originY: "center",
            selectable: true,
          });
          this.canvas.add(polyObj);
          this.addPolylineVariables.lastPt = 1;
          this.addPolylineVariables.mouseDown = false;
          this.addPolylineVariables.pts = [];
          return;
        } else if (this.state.isAddLineFromBuildMenu) {
        } else if (this.state.isAddDoorFromBuildMenu) {
        }
        if (
          e.target?.type !== "textLabel" &&
          e.target?.type !== "stair-case" &&
          e.target?.type !== "LINE" &&
          e.target?.type !== "PARTITION_DOOR" &&
          this.state.isEditModeEnabled
        ) {
          isEditMode = true;
          this.setState({ isEditMode: true });
          this.setState({ isDoorAvailable: false });
          //Add this object in canvas....
          // let roomObjects = e.target._objects;

          editedRoomID = e.target.roomID;

          editedRoomTop = e.target.top;
          editedRoomLeft = e.target.left;

          editedRoomFinalTopDist = e.target.top - e.target.initialTop;
          editedRoomFinalLeftDist = e.target.left - e.target.initialLeft;

          editedRoomAngle = e.target.angle ? e.target.angle : 0;

          let targetRoomId = e.target.roomID;

          this.canvas.remove(
            this.canvas.getItemByAttr("id", "GROUP-" + targetRoomId)
          );
          let childdata = designatorWiseObjectArray[targetRoomId]
            .filter((el) => el["@id"] != targetRoomId)
            .map((el) => {
              return el["@children"].length > 0
                ? el["@children"].split(",")
                : [];
            });
          let childdataLabel = designatorWiseObjectArray[targetRoomId]
            .filter((el) => el["@id"] == targetRoomId)
            .map((el) => {
              return el["@childrenLabel"] && el["@childrenLabel"].length > 0
                ? el["@childrenLabel"].split(",")
                : [];
            });
          childdata = childdata.concat(childdataLabel);
          let childdataLine = designatorWiseObjectArray[targetRoomId]
            .filter((el) => el["@id"] == targetRoomId)
            .map((el) => {
              return el["@childrenLine"] && el["@childrenLine"].length > 0
                ? el["@childrenLine"].split(",")
                : [];
            });
          childdata = childdata.concat(childdataLine);
          let childDataPartitionDoor = designatorWiseObjectArray[targetRoomId]
            .filter((el) => el["@id"] == targetRoomId)
            .map((el) => {
              return el["@partitionDoor"] && el["@partitionDoor"].length > 0
                ? el["@partitionDoor"].split(",")
                : [];
            });
          childdata = childdata.concat(childDataPartitionDoor);
          let childDataPartitionWindow = designatorWiseObjectArray[targetRoomId]
            .filter((el) => el["@id"] == targetRoomId)
            .map((el) => {
              return el["@partitionWindow"] && el["@partitionWindow"].length > 0
                ? el["@partitionWindow"].split(",")
                : [];
            });
          childdata = childdata.concat(childDataPartitionWindow);
          let childdataStairCase = designatorWiseObjectArray[targetRoomId]
            .filter((el) => el["@id"] == targetRoomId)
            .map((el) => {
              return el["@childrenStairCase"] &&
                el["@childrenStairCase"].length > 0
                ? el["@childrenStairCase"].split(",")
                : [];
            });
          childdata = childdata.concat(childdataStairCase);

          let childIds = Object.keys(childdata).reduce(function (arr, key) {
            return arr.concat(childdata[key]);
          }, []);
          childIds.forEach((childIdsEl) => {
            this.canvas
              .getObjects()
              .filter((x) => x.id === childIdsEl)
              .forEach((x) => {
                this.canvas.remove(x);
              });
          });

          this.canvas.requestRenderAll();

          this.createEditableRoom(targetRoomId);
        }
      }.bind(this)
    );

    // mousemove:up
    this.canvas.on(
      "mouse:up",
      function (e) {
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "circle"
        ) {
          let p = e.target;
          let connectedDoor = p?.connectedDoor;
          if (
            (this.state.isIntersectPartitionWall &&
              this.state.lastLinePoints !== null) ||
            (this.state.partitionMoveRoomID &&
              e.target.roomID &&
              this.state.partitionMoveRoomID !== e.target.roomID)
          ) {
            let selectedpartition = e.target.targetedPartitionId;
            selectedpartition.set({
              x1: this.state.lastLinePoints.x1,
              y1: this.state.lastLinePoints.y1,
              x2: this.state.lastLinePoints.x2,
              y2: this.state.lastLinePoints.y2,
            });
            selectedpartition.setCoords();
            selectedpartition.saveState();
            let obj = this.canvas.getObjects();
            let basePoint, currentPoint, currentTouchablePoint;
            obj.forEach((element) => {
              if (
                p?.targetedPartitionId?.id &&
                selectedpartition?.type === "LINE" &&
                element.type === "LINE"
              ) {
                if (element.id === selectedpartition.id) {
                  obj.forEach((circleEl) => {
                    if (p?.type === "circle" && circleEl.type === "circle") {
                      if (circleEl.id && circleEl.id !== p.name) {
                        basePoint = [
                          circleEl.left + circleEl.radius,
                          circleEl.top + circleEl.radius,
                        ];
                        currentTouchablePoint = [
                          p.left + p.radius,
                          p.top + p.radius,
                        ];
                        if (p.name == "partitionSelector1") {
                          currentPoint = [
                            this.state.lastLinePoints.x1,
                            this.state.lastLinePoints.y1,
                          ];
                          element.set({
                            x1: this.state.lastLinePoints.x1,
                            y1: this.state.lastLinePoints.y1,
                            x2: this.state.lastLinePoints.x2,
                            y2: this.state.lastLinePoints.y2,
                          });
                          p.set({
                            left: this.state.lastLinePoints.x1 - 5,
                            top: this.state.lastLinePoints.y1 - 5,
                          });
                          p.setCoords();
                        } else if (p.name == "partitionSelector2") {
                          currentPoint = [
                            this.state.lastLinePoints.x2,
                            this.state.lastLinePoints.y2,
                          ];
                          p.set({
                            left: this.state.lastLinePoints.x2 - 5,
                            top: this.state.lastLinePoints.y2 - 5,
                          });
                          p.setCoords();
                        }
                        element.setCoords();
                      }
                    }
                  });
                }
              } else {
                connectedDoor?.forEach((doorEl) => {
                  if (element.id === doorEl?.[1]) {
                    obj
                      .filter(
                        (partitionDoorEl) =>
                          partitionDoorEl?.type === "PARTITION_DOOR"
                      )
                      .forEach((circleEl) => {
                        if (p?.type === "circle") {
                          if (circleEl.id && circleEl.id !== p.name) {
                            if (doorEl?.[2] == "x1,y1") {
                              element.set({
                                x1:
                                  p.name == "partitionSelector1"
                                    ? this.state.lastLinePoints.x1
                                    : this.state.lastLinePoints.x2,
                                y1:
                                  p.name == "partitionSelector1"
                                    ? this.state.lastLinePoints.y1
                                    : this.state.lastLinePoints.y2,
                                x2: element.x2,
                                y2: element.y2,
                              });
                            } else if (doorEl?.[2] == "x2,y2") {
                              element.set({
                                x1: element.x1,
                                y1: element.y1,
                                x2:
                                  p.name == "partitionSelector1"
                                    ? this.state.lastLinePoints.x1
                                    : this.state.lastLinePoints.x2,
                                y2:
                                  p.name == "partitionSelector1"
                                    ? this.state.lastLinePoints.y1
                                    : this.state.lastLinePoints.y2,
                              });
                            }
                            element.setCoords();
                          }
                        }
                      });
                  }
                });
                if (
                  p.targetedPartitionId?.id &&
                  element.parentPartitionId &&
                  p.targetedPartitionId.id === element.parentPartitionId
                ) {
                  let newWindowStartXY = FindNewCoordinates(
                    basePoint,
                    { x: currentPoint[0], y: currentPoint[1] },
                    currentTouchablePoint,
                    [element.x1, element.y1]
                  );
                  let newWindowEndXY = FindNewCoordinates(
                    basePoint,
                    { x: currentPoint[0], y: currentPoint[1] },
                    currentTouchablePoint,
                    [element.x2, element.y2]
                  );
                  originalFloorPlan = dragPartitionWindow(
                    originalFloorPlan,
                    p?.targetedPartitionId?.id,
                    element?.id,
                    newWindowStartXY,
                    newWindowEndXY,
                    this.ratio,
                    this.minX,
                    this.minY
                  );
                  element.set({
                    x1: newWindowStartXY.x,
                    y1: newWindowStartXY.y,
                    x2: newWindowEndXY.x,
                    y2: newWindowEndXY.y,
                  });
                  element.setCoords();
                }
              }
            });
            if (this.state.isIntersectPartitionWall) {
              const { t } = this.props;
              customToast.error(
                t("COMMON_MESSAGES.Cannot_Extended_Outside_Room")
              );
            }
            this.canvas.discardActiveObject();
            this.canvas.renderAll();
          } else {
            if (this.state.isAddDoorFromBuildMenu) {
              const { t } = this.props;
              customToast.error(t("COMMON_MESSAGES.Add_Door_On_Same_Wall"));
            }
            return;
          }
          this.canvas.clear();
          this.drawFloorPlan();
        }
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "textLabel"
        ) {
          this.setState({
            enableLabelDelete: true,
            selectedLabel: e.target.id,
          });
        } else {
          this.setState({ enableLabelDelete: false });
        }
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "stair-case"
        ) {
          this.setState({
            enableStairCaseDelete: true,
            selectedStairCase: e.target.id,
          });
        } else {
          this.setState({ enableStairCaseDelete: false });
        }
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "LINE"
        ) {
          this.setState({
            enableLineDelete: true,
            selectedLine: e.target.id,
          });
        } else {
          this.setState({ enableLineDelete: false });
        }
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "PARTITION_DOOR"
        ) {
          this.setState({
            enablePartitionDoorDelete: true,
            selectedPartitionDoor: e.target.id,
          });
        } else {
          this.setState({ enablePartitionDoorDelete: false });
        }
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "PARTITION_WINDOW"
        ) {
          this.setState({
            enablePartitionWindowDelete: true,
            selectedPartitionWindow: e.target.id,
          });
        } else {
          this.setState({ enablePartitionWindowDelete: false });
        }
        if (
          e.target != null &&
          isEditMode == false &&
          (e.target.type == "DW" || e.target.type == "PARTITION_DOOR")
        ) {
          this.setState({
            enableDoorDelete: true,
            selectedDoor: e.target.id,
          });
        } else {
          this.setState({ enableDoorDelete: false });
        }
        if (
          e.target != null &&
          isEditMode == false &&
          e.target.type == "GROUP"
        ) {
          this.canvas.renderAll();
          this.setState({ enableDelete: true });
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;

          for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
            if (
              facesArray[faceIndex]["@id"] != e.target.id.replace("GROUP-", "")
            ) {
              continue;
            }
            this.setState({
              selectedRoomType: facesArray[faceIndex]["@measuretype"],
              selectedRoom: facesArray[faceIndex]["@id"],
            });
          }
          if (e.target.type == "GROUP" && isGroupMoving == true) {
            isGroupMoving = false;
            editedRoomEndlLeft = e.target.left;
            editedRoomEndTop = e.target.top;

            let roomID = e.target.roomID;

            let centrePoint = this.calculateCentrePoint(
              e.target.aCoords.bl.x,
              e.target.aCoords.br.x,
              e.target.aCoords.tl.x,
              e.target.aCoords.tr.x,

              e.target.aCoords.bl.y,
              e.target.aCoords.br.y,
              e.target.aCoords.tl.y,
              e.target.aCoords.tr.y
            );

            editedRoomFinalLeftDist =
              editedRoomEndlLeft - editedRoomInitialLeft;
            editedRoomFinalTopDist = editedRoomEndTop - editedRoomInitialTop;

            let absoluteDistanceLeft = Math.abs(editedRoomFinalLeftDist);
            let absoluteDistanceTop = Math.abs(editedRoomFinalTopDist);
            // if (absoluteDistanceLeft < 3 && absoluteDistanceTop < 3) {
            //   return;
            // }

            //Update json here...

            this.updateFloorPlanOnMove(roomID, linesArray);
            this.canvas.clear();
            this.drawFloorPlan();
          }
        } else {
          this.setState({ enableDelete: false });
        }
        if (isDoorEdited || isWindowEdited) {
          if (
            !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
              originalFloorPlan,
              designatorWiseObjectArray,
              floorId: this.state.selectedFloor,
            })
          ) {
            EditModeChanges.push({
              originalFloorPlan: _.cloneDeep(originalFloorPlan),
              designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
              floorId: this.state.selectedFloor,
            });
            this.setState({
              undocount: EditModeChanges.length,
            });
          }
          if (isDoorEdited) {
            this.editArea(isDoorEdited);
            isDoorEdited = false;
          } else {
            this.editArea(isWindowEdited);
            isWindowEdited = false;
          }
        }
        if (isEditMode && isLineEdited) {
          this.editArea(isLineEdited);
          if (
            !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
              originalFloorPlan,
              designatorWiseObjectArray,
              floorId: this.state.selectedFloor,
            })
          ) {
            EditModeChanges.push({
              originalFloorPlan: _.cloneDeep(originalFloorPlan),
              designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
              floorId: this.state.selectedFloor,
            });
            this.setState({
              undocount: EditModeChanges.length,
            });
          }
          isLineEdited = false;
        }
        if (isStairCaseEdited) {
          if (
            !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
              originalFloorPlan,
              designatorWiseObjectArray,
              floorId: this.state.selectedFloor,
            })
          ) {
            EditModeChanges.push({
              originalFloorPlan: _.cloneDeep(originalFloorPlan),
              designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
              floorId: this.state.selectedFloor,
            });
            this.setState({
              undocount: EditModeChanges.length,
            });
          }
          this.editArea();
          isStairCaseEdited = false;
        }
      }.bind(this)
    );

    this.canvas.on(
      "mouse:move",
      function (e) {
        this.setState({
          partitionMoveRoomID: e?.target?.roomID ? e.target.roomID : null,
        });
        // change canvas's hover-cursor while adding label/line.
        if (
          this.state.isAddLineFromBuildMenu ||
          this.state.isAddPolylineFromBuildMenu ||
          this.state.isAddDoorFromBuildMenu ||
          this.state.isAddWindowFromBuildMenu
        ) {
          this.canvas.hoverCursor = "crosshair";
        } else if (this.state.isAddLabel) {
          this.canvas.hoverCursor = "text";
        } else {
          this.canvas.hoverCursor = "move"; // reset to default-value as found in fabric.js library.
        }

        // discards any pre-selected fabric.js object if any option from "Build" menu is selected.
        if (
          !isEditMode &&
          (this.state.isAddLabel ||
            this.state.isAddLineFromBuildMenu ||
            this.state.isAddPolylineFromBuildMenu ||
            this.state.isAddDoorFromBuildMenu ||
            this.state.isAddWindowFromBuildMenu ||
            this.state.isAddStairCase)
        ) {
          this.canvas.discardActiveObject();
          this.canvas.renderAll();
        }

        // prevents selection of any fabric.js object if any option from "Build" menu is selected.
        if (!isEditMode) {
          this.canvas.getObjects().forEach((e) => {
            if (e.type != "doorobject") {
              e.set({
                selectable:
                  !this.state.isAddLabel &&
                  !this.state.isAddLineFromBuildMenu &&
                  !this.state.isAddPolylineFromBuildMenu &&
                  !this.state.isAddDoorFromBuildMenu &&
                  !this.state.isAddWindowFromBuildMenu &&
                  !this.state.isAddStairCase,
              });
            }
          });
        }

        if (this.state.isAddPolylineFromBuildMenu) {
          this.addPolylineVariables.mouse = this.canvas.getPointer(e.e);
          if (this.addPolylineVariables.mouseDown) {
            this.addPolylineVariables.polyline.points[
              this.addPolylineVariables.lastPt - 1
            ] = {
              x: this.addPolylineVariables.mouse.x,
              y: this.addPolylineVariables.mouse.y,
            };
            this.canvas.renderAll();
          }
        } else if (this.state.isAddLineFromBuildMenu) {
          if (!this.addLineVariables.isDown) {
            return;
          }
          if (
            e?.target?.roomID &&
            selectedRoom === e?.target?.roomID &&
            (e?.subTargets?.[0]?.points?.length ||
              e?.target?.type === "LINE" ||
              e?.target?.type === "textLabel" ||
              e?.target?.type === "PARTITION_DOOR" ||
              e?.target?.type === "PARTITION_WINDOW" ||
              e?.target?.type === "stair-case" ||
              e?.subTargets?.[0]?.type === "CENTRE-BOX-TEXT")
          ) {
            let pointer = this.canvas.getPointer(e.e);
            let isIntersectPartitionWall = null;
            this.canvas.getObjects().forEach((x) => {
              x.set({ padding: 0 });
              if (!isIntersectPartitionWall) {
                isIntersectPartitionWall = hasIntersectWall(
                  this.addLineVariables.line.x1,
                  this.addLineVariables.line.y1,
                  pointer.x,
                  pointer.y,
                  x.x1,
                  x.y1,
                  x.x2,
                  x.y2
                );
              }
            });
            e.subTargets[0]?.points?.length &&
              e.subTargets[0].points.forEach((elm, index) => {
                if (!isIntersectPartitionWall) {
                  isIntersectPartitionWall = hasIntersectWall(
                    this.addLineVariables.line.x1,
                    this.addLineVariables.line.y1,
                    pointer.x,
                    pointer.y,
                    elm.x,
                    elm.y,
                    e.subTargets[0].points[
                      e.subTargets[0].points.length - 1 === index
                        ? 0
                        : index + 1
                    ].x,
                    e.subTargets[0].points[
                      e.subTargets[0].points.length - 1 === index
                        ? 0
                        : index + 1
                    ].y
                  );
                }
              });
            if (!isIntersectPartitionWall) {
              this.addLineVariables.line.set({
                x2: pointer.x,
                y2: pointer.y,
                padding: 0,
                parentRoomCordinates:
                  e.target.canvas?.targets?.[0]?.group?._objects?.[0]?.points,
              });
            }
          }
          this.canvas.renderAll();
        } else if (this.state.isAddDoorFromBuildMenu) {
          if (!this.addPartitionDoorVariables.isDown) {
            return;
          }
          if (
            e?.target?.roomID &&
            selectedRoom === e?.target?.roomID &&
            (e?.subTargets?.[0]?.points?.length ||
              e?.target?.type === "LINE" ||
              e?.target?.type === "textLabel" ||
              e?.target?.type === "PARTITION_DOOR" ||
              e?.target?.type === "PARTITION_WINDOW" ||
              e?.target?.type === "partitionLine" ||
              e?.target?.type === "stair-case" ||
              e?.subTargets?.[0]?.type === "CENTRE-BOX-TEXT")
          ) {
            let pointer = this.canvas.getPointer(e.e);
            this.addPartitionDoorVariables.line.set({
              x2: pointer.x,
              y2: pointer.y,
              padding: 0,
              parentRoomCordinates:
                e.target.canvas?.targets?.[0]?.group?._objects?.[0]?.points,
              partitionWallCordinates: [],
            });
          }
          this.canvas.renderAll();
        }
      }.bind(this)
    );

    // mousemove:down
    this.canvas.on(
      "mouse:down",
      function (e) {
        if (e?.target?.type !== "circle") {
          removePartitionCircle(this);
        }
        this.setState({
          lastLinePoints: null,
          isIntersectPartitionWall: null,
        });
        if (e?.target?.type === "LINE") {
          let objectOfElement = e.target?.canvas?._objects;
          objectOfElement?.forEach((element) => {
            if (
              !e.target.parentRoomCordinates &&
              element.roomID === e.target.roomID
            ) {
              e.target.parentRoomCordinates = element._objects?.[0]?.points;
            } else if (
              element.roomID === e.target.roomID &&
              element.type === "LINE" &&
              element.id !== e.target.id
            ) {
              e.target.partitionWallCordinates?.push({
                x1: element.x1,
                x2: element.x2,
                y1: element.y1,
                y2: element.y2,
              });
            }
          });
        }
        let obj = this.canvas.getObjects();
        obj.forEach((element) => {
          if (
            !this.state.isAddLineFromBuildMenu &&
            !this.state.isAddDoorFromBuildMenu &&
            !this.state.isAddWindowFromBuildMenu
          ) {
            if (
              e.target?.id &&
              e.target?.type === "LINE" &&
              element.type === "LINE"
            ) {
              if (
                e.target?.id &&
                element?.id !== e.target.id &&
                element.stroke === "red"
              ) {
                element.stroke = !this.state.isEditModeEnabled
                  ? PARTITION_COLOR
                  : "black";
              } else if (e.target?.id && element?.id === e.target.id) {
                element.stroke = "red";
              }
            } else if (
              element.type === "LINE" &&
              this.state.isEditModeEnabled
            ) {
              element.stroke = !this.state.isEditModeEnabled
                ? PARTITION_COLOR
                : "black";
            }
          }
          if (element.isEditing) {
            element.exitEditing();
          }
        });
        this.canvas.renderAll();

        // clicked item will be
        if (!this.state.isAddLineFromBuildMenu) {
          selectedRoom = "";
        }
        if (e.target != null) {
          editedRoomInitialLeft = e.target.left;
          editedRoomInitialTop = e.target.top;
          selectedRoom = e.target.roomID;
          if (this.state.isAddLabel) {
            let copyOriginal = _.cloneDeep(originalFloorPlan);
            let facesArray =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
            let roofPoints =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
            let rooflines =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
            const labelid = this.getMaxId(facesArray, "LABEL") + 1;
            const cid = this.getMaxId(roofPoints, "C") + 1;
            const lid = this.getMaxId(rooflines, "L") + 1;
            let datax =
              e.pointer.x / this.canvas.getZoom() / this.ratio + this.minX;
            let datay =
              e.pointer.y / this.canvas.getZoom() / this.ratio + this.minY;
            let facedata = {
              "@floorindex": "",
              "@floor": "",
              "@areaname": "",
              "@measuretype": "",
              "@type": "LABEL",
              "@text": "Tap and type",
              "@area": "",
              "@editedArea": "",
              "@designator": "",
              POLYGON: {
                "@orientation": "",
                "@pitch": "",
                "@unroundedsize": "0",
                "@path": "L" + lid,
                "@editedUnroundedsize": "0",
                "@size": "1.0",
                "@editedSize": "1.0",
                "@id": "",
              },
              "@children": "",
              "@id": "LABEL" + labelid,
              "@mode": "LABEL",
            };
            facesArray.push(_.cloneDeep(facedata));
            let ldata = {
              "@id": "L" + lid,
              "@path": "C" + cid,
              "@type": "LABEL",
            };
            rooflines.push(_.cloneDeep(ldata));
            let cdata = {
              "@id": "C" + cid,
              "@data": "0,0",
              "@dataXY": datax + "," + datay,
              "@autoSnappedXY": datax + "," + datay,
              "@editedXY": datax + "," + datay,
            };
            roofPoints.push(_.cloneDeep(cdata));
            const textLabel = new fabric.IText("Tap and type", {
              fontFamily: '"Roboto", sans-serif',
              fill: "black",
              id: "LABEL" + labelid,
              roomID: selectedRoom,
              type: "textLabel",
              fontSize: this.state.textSize,
              left: e.pointer.x / this.canvas.getZoom(),
              top: e.pointer.y / this.canvas.getZoom(),
              padding: 5,
              hasControls: true,
              // lockScalingX: true,
              // lockScalingY: true,
            });
            this.canvas.add(textLabel);
            textLabel.enterEditing();
            textLabel.hiddenTextarea.focus();

            for (let i = 0; i < facesArray.length; i++) {
              if (facesArray[i]["@id"] == selectedRoom) {
                if (!facesArray[i]["@childrenLabel"]) {
                  facesArray[i]["@childrenLabel"] = "";
                }
                let child = facesArray[i]["@childrenLabel"].split(",");
                if (facesArray[i]["@childrenLabel"].length == 0) {
                  child = [];
                }
                child.push("LABEL" + labelid);
                facesArray[i]["@childrenLabel"] = child.join(",");
                break;
              }
            }
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE =
              _.cloneDeep(facesArray);
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
              _.cloneDeep(roofPoints);
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE =
              _.cloneDeep(rooflines);
            originalFloorPlan = _.cloneDeep(copyOriginal);
            if (
              !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
                originalFloorPlan,
                designatorWiseObjectArray,
                floorId: this.state.selectedFloor,
              })
            ) {
              EditModeChanges.push({
                originalFloorPlan: _.cloneDeep(originalFloorPlan),
                designatorWiseObjectArray: _.cloneDeep(
                  designatorWiseObjectArray
                ),
                floorId: this.state.selectedFloor,
              });
              this.setState({
                undocount: EditModeChanges.length,
                isAddLabel: false,
              });
            }
            this.editArea(false);
          } else if (this.state.isAddStairCase) {
            let copyOriginal = _.cloneDeep(originalFloorPlan);
            let facesArray =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
            let roofPoints =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
            let rooflines =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
            const stairCaseId = this.getMaxId(facesArray, "STAIR_CASE") + 1;
            const cid = this.getMaxId(roofPoints, "C") + 1;
            const lid = this.getMaxId(rooflines, "L") + 1;
            let datax =
              e.pointer.x / this.canvas.getZoom() / this.ratio + this.minX;
            let datay =
              e.pointer.y / this.canvas.getZoom() / this.ratio + this.minY;
            let facedata = {
              "@floorindex": "",
              "@floor": "",
              "@areaname": "",
              "@measuretype": "",
              "@type": "STAIR_CASE",
              "@area": "",
              "@editedArea": "",
              "@designator": "",
              POLYGON: {
                "@orientation": "",
                "@pitch": "",
                "@unroundedsize": "0",
                "@path": "L" + lid,
                "@editedUnroundedsize": "0",
                "@size": "1.0",
                "@editedSize": "1.0",
                "@id": "",
              },
              "@children": "",
              "@id": "STAIR_CASE" + stairCaseId,
              "@mode": "STAIR_CASE",
            };
            facesArray.push(_.cloneDeep(facedata));
            let ldata = {
              "@id": "L" + lid,
              "@path": "C" + cid,
              "@type": "STAIR_CASE",
            };
            rooflines.push(_.cloneDeep(ldata));
            let cdata = {
              "@id": "C" + cid,
              "@data": "0,0",
              "@dataXY": datax + "," + datay,
              "@autoSnappedXY": datax + "," + datay,
              "@editedXY": datax + "," + datay,
              "@scaleX": 1 / this.ratio,
              "@scaleY": 1 / this.ratio,
            };
            roofPoints.push(_.cloneDeep(cdata));
            const stairCase = new fabric.Path(stairCasePath, {
              fill: false,
              id: "STAIR_CASE" + stairCaseId,
              roomID: selectedRoom,
              type: "stair-case",
              left: e.pointer.x / this.canvas.getZoom(),
              top: e.pointer.y / this.canvas.getZoom(),
              stroke: "black",
              scaleX: 1,
              scaleY: 1,
            });
            this.canvas.add(stairCase);

            for (let i = 0; i < facesArray.length; i++) {
              if (facesArray[i]["@id"] == selectedRoom) {
                if (!facesArray[i]["@childrenStairCase"]) {
                  facesArray[i]["@childrenStairCase"] = "";
                }
                let child = facesArray[i]["@childrenStairCase"].split(",");
                if (facesArray[i]["@childrenStairCase"].length == 0) {
                  child = [];
                }
                child.push("STAIR_CASE" + stairCaseId);
                facesArray[i]["@childrenStairCase"] = child.join(",");
                break;
              }
            }
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE =
              _.cloneDeep(facesArray);
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
              _.cloneDeep(roofPoints);
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE =
              _.cloneDeep(rooflines);
            originalFloorPlan = _.cloneDeep(copyOriginal);
            if (
              !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
                originalFloorPlan,
                designatorWiseObjectArray,
                floorId: this.state.selectedFloor,
              })
            ) {
              EditModeChanges.push({
                originalFloorPlan: _.cloneDeep(originalFloorPlan),
                designatorWiseObjectArray: _.cloneDeep(
                  designatorWiseObjectArray
                ),
                floorId: this.state.selectedFloor,
              });
              this.setState({
                undocount: EditModeChanges.length,
                isAddStairCase: false,
              });
            }
            this.editArea(false);
          } else if (this.state.isAddPolylineFromBuildMenu) {
            this.addPolylineVariables.polyline = new fabric.Polyline(
              this.addPolylineVariables.pts,
              {
                objectCaching: false,
                type: "LINE",
                name: "temp-line-from-build",
                fill: "",
                stroke: PARTITION_COLOR,
                originX: "center",
                originY: "center",
                lockScalingX: true,
                lockScalingY: true,
                lockRotation: false,
                hasControls: false,
                lockMovementX: true,
                lockMovementY: true,
              }
            );
            this.canvas.add(this.addPolylineVariables.polyline);
            this.addPolylineVariables.polyline.points[
              this.addPolylineVariables.pts.length
            ] = {
              x: this.addPolylineVariables.mouse.x,
              y: this.addPolylineVariables.mouse.y,
            };
            this.addPolylineVariables.lastPt++;
            this.addPolylineVariables.mouseDown = true;
            this.editArea(false);
          } else if (this.state.isAddLineFromBuildMenu) {
            if (this.addLineVariables.line) {
              if (
                e?.subTargets.length === 0 &&
                e?.target?.type !== "stair-case"
              ) {
                const { t } = this.props;
                customToast.error(
                  t("COMMON_MESSAGES.Cannot_Extended_Outside_Room")
                );
                return;
              }
              this.canvas
                .getObjects()
                .filter((x) => x.id && x.type === "LINE")
                .forEach((x) => {
                  x.set({ padding: 4, stroke: PARTITION_COLOR });
                });
              this.setState({ isAddLineFromBuildMenu: false });
              this.addLineVariables.line.setCoords();
              this.addLineVariables.isDown = false;
              // prepare JSON for line added via "Add Line" from Build Menu.
              let copyOriginal = _.cloneDeep(originalFloorPlan);
              let facesArray =
                copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
              let roofPoints =
                copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
              let rooflines =
                copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
              const lineId = this.getMaxId(facesArray, "LINE") + 1;
              this.addLineVariables.line.id = "LINE" + lineId;
              const cid = this.getMaxId(roofPoints, "C") + 1;
              const lid = this.getMaxId(rooflines, "L") + 1;
              let datax1 =
                this.addLineVariables.line.x1 / this.ratio + this.minX;
              let datay1 =
                this.addLineVariables.line.y1 / this.ratio + this.minY;
              let datax2 =
                this.addLineVariables.line.x2 / this.ratio + this.minX;
              let datay2 =
                this.addLineVariables.line.y2 / this.ratio + this.minY;

              // prepare face data
              let facedata = {
                "@floorindex": "",
                "@floor": "",
                "@areaname": "",
                "@measuretype": "",
                "@type": "LINE",
                "@text": "",
                "@area": "",
                "@editedArea": "",
                "@designator": "",
                POLYGON: {
                  "@orientation": "",
                  "@pitch": "",
                  "@unroundedsize": "",
                  "@path": "L" + lid,
                  "@editedUnroundedsize": "",
                  "@size": "",
                  "@editedSize": "",
                  "@id": "",
                },
                "@children": "",
                "@id": "LINE" + lineId,
                "@mode": "LINE",
              };
              facesArray.push(_.cloneDeep(facedata));

              // prepare points data
              let cdata1 = {
                "@id": "C" + cid,
                "@data": "0,0",
                "@dataXY": datax1 + "," + datay1,
                "@autoSnappedXY": datax1 + "," + datay1,
                "@editedXY": datax1 + "," + datay1,
              };
              roofPoints.push(_.cloneDeep(cdata1));
              let cdata2 = {
                "@id": "C" + (cid + 1),
                "@data": "0,0",
                "@dataXY": datax2 + "," + datay2,
                "@autoSnappedXY": datax2 + "," + datay2,
                "@editedXY": datax2 + "," + datay2,
              };
              roofPoints.push(_.cloneDeep(cdata2));

              // prepare line data
              let ldata = {
                "@angle": "",
                "@distance": "",
                "@id": "L" + lid,
                "@path": "C" + cid + ",C" + (cid + 1),
                "@type": "LINE",
                linePointObjectArray: [cdata1, cdata2],
              };
              rooflines.push(_.cloneDeep(ldata));

              for (let i = 0; i < facesArray.length; i++) {
                if (facesArray[i]["@id"] == selectedRoom) {
                  if (!facesArray[i]["@childrenLine"]) {
                    facesArray[i]["@childrenLine"] = "";
                  }
                  let child = facesArray[i]["@childrenLine"].split(",");
                  if (facesArray[i]["@childrenLine"].length == 0) {
                    child = [];
                  }
                  child.push("LINE" + lineId);
                  facesArray[i]["@childrenLine"] = child.join(",");
                  break;
                }
              }
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE =
                _.cloneDeep(facesArray);
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
                _.cloneDeep(roofPoints);
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE =
                _.cloneDeep(rooflines);
              originalFloorPlan = _.cloneDeep(copyOriginal);
              if (
                !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
                  originalFloorPlan,
                  designatorWiseObjectArray,
                  floorId: this.state.selectedFloor,
                })
              ) {
                EditModeChanges.push({
                  originalFloorPlan: _.cloneDeep(originalFloorPlan),
                  designatorWiseObjectArray: _.cloneDeep(
                    designatorWiseObjectArray
                  ),
                  floorId: this.state.selectedFloor,
                });
                this.setState({
                  undocount: EditModeChanges.length,
                });
              }

              this.addLineVariables.line = null;
              this.editArea(false);
              return;
            }
            let roompointarray = e?.subTargets?.[0]?.points?.map((el) => {
              return Object.values(el);
            });
            if (
              (e?.subTargets?.[0]?.type?.toLowerCase() === "polygon" ||
                e?.subTargets?.[0]?.type === "CENTRE-BOX-TEXT" ||
                e?.target?.type === "LINE") &&
              IsInside(this.canvas.getPointer(e.e), roompointarray)
            ) {
              this.addLineVariables.isDown = true;
              let pointer = this.canvas.getPointer(e.e);
              let points = [pointer.x, pointer.y, pointer.x, pointer.y];
              this.addLineVariables.line = new fabric.Line(points, {
                roomID: selectedRoom,
                stroke: PARTITION_COLOR,
                type: "LINE",
                objectCaching: false,
                originX: "center",
                originY: "center",
                strokeUniform: true,
                strokeWidth: partitionLineStokeWidth,
                padding: 4,
                lockScalingX: true,
                lockScalingY: true,
                lockRotation: false,
                hasControls: false,
                lockMovementX: true,
                lockMovementY: true,
              });
              this.canvas.add(this.addLineVariables.line);
            } else {
              const { t } = this.props;
              customToast.error(
                t("COMMON_MESSAGES.Cannot_Extended_Outside_Room")
              );
            }
          } else if (this.state.isAddDoorFromBuildMenu) {
            if (e.target?.type === "partitionLine") {
              if (this.addPartitionDoorVariables.line) {
                if (
                  e.target.roomID != this.addPartitionDoorVariables.line.roomID
                ) {
                  selectedRoom = this.addPartitionDoorVariables.line.roomID;
                  editedRoomInitialLeft =
                    this.addPartitionDoorVariables.line.left;
                  editedRoomInitialTop =
                    this.addPartitionDoorVariables.line.top;
                  customToast.error(
                    threeDFloorScan.Add_Partition_Door_In_Same_Room
                  );
                  return;
                }
                if (
                  e.target.id?.split("_")[0] ==
                  this.addPartitionDoorVariables.line.pointId
                ) {
                  selectedRoom = this.addPartitionDoorVariables.line.roomID;
                  editedRoomInitialLeft =
                    this.addPartitionDoorVariables.line.left;
                  editedRoomInitialTop =
                    this.addPartitionDoorVariables.line.top;
                  customToast.error(
                    threeDFloorScan.Add_Partition_Door_In_Different_Partition
                  );
                  return;
                }
                this.canvas
                  .getObjects()
                  .filter((x) => x.id && x.type === "PARTITION_DOOR")
                  .forEach((x) => {
                    x.set({
                      padding: 4,
                      stroke:
                        x.doorDirection == doorDirectionEnum.inside
                          ? PARTITION_INSIDE_DOOR_COLOR
                          : PARTITION_DOOR_COLOR,
                    });
                  });
                this.addPartitionDoorVariables.line.set({
                  x1: this.addPartitionDoorVariables.line.x1,
                  y1: this.addPartitionDoorVariables.line.y1,
                  x2: e.target.customLineCoords?.x1
                    ? e.target.customLineCoords.x1
                    : e.target.customLineCoords?.x2,
                  y2: e.target.customLineCoords?.y1
                    ? e.target.customLineCoords.y1
                    : e.target.customLineCoords?.y2,
                });
                this.addPartitionDoorVariables.line.setCoords();
                this.addPartitionDoorVariables.isDown = false;
                // prepare JSON for line added via "Add Line" from Build Menu.
                originalFloorPlan = addPartitionDoorFromBuildMenu(
                  this,
                  originalFloorPlan,
                  selectedRoom
                );
                this.setState({
                  isAddLabel: false,
                  isAddPolylineFromBuildMenu: false,
                  isAddLineFromBuildMenu: false,
                  isAddDoorFromBuildMenu: false,
                  isAddWindowFromBuildMenu: false,
                });
                this.canvas
                  .getObjects()
                  .filter((x) => x.type === "partitionLine")
                  .forEach((x) => {
                    this.canvas.remove(x);
                  });

                if (
                  !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
                    originalFloorPlan,
                    designatorWiseObjectArray,
                    floorId: this.state.selectedFloor,
                  })
                ) {
                  EditModeChanges.push({
                    originalFloorPlan: _.cloneDeep(originalFloorPlan),
                    designatorWiseObjectArray: _.cloneDeep(
                      designatorWiseObjectArray
                    ),
                    floorId: this.state.selectedFloor,
                  });
                  this.setState({
                    undocount: EditModeChanges.length,
                  });
                }
                this.addPartitionDoorVariables.line = null;
                this.canvas.renderAll();
                this.editArea(false);
                return;
              }
              if (e?.target?.type === "partitionLine") {
                this.addPartitionDoorVariables.isDown = true;
                // let pointer = this.canvas.getPointer(e.e);
                let points = [];
                if (e?.target?.customLineCoords?.x1) {
                  points.push(
                    e.target.customLineCoords.x1,
                    e.target.customLineCoords.y1,
                    e.target.customLineCoords.x1,
                    e.target.customLineCoords.y1
                  );
                } else {
                  points.push(
                    e.target.customLineCoords?.x2,
                    e.target.customLineCoords?.y2,
                    e.target.customLineCoords?.x2,
                    e.target.customLineCoords?.y2
                  );
                }
                // make a copy of the object which has fabric wall-line objects.
                const ___roomWiseLineAndTextObjectsCopy = {
                  ...roomWiseLineAndTextObjects,
                };
                const ___roomWiseLineAndTextObjects = {};
                this.canvas
                  .getObjects()
                  .filter((x) => x.type === "GROUP")
                  .forEach((x) => {
                    ___roomWiseLineAndTextObjects[x.roomID] =
                      ___roomWiseLineAndTextObjectsCopy[x.roomID];
                  });
                // remove all wall-lines from the canvas.
                Object.keys(___roomWiseLineAndTextObjects).forEach((rwl) => {
                  ___roomWiseLineAndTextObjects[rwl].roomLinesGroup.forEach(
                    (exw) => this.canvas.remove(exw)
                  );
                });

                // reset perPixelTargetFind to original value after door placement.
                this.canvas.set({
                  perPixelTargetFind: false,
                  targetFindTolerance: 0,
                });

                // bring back GROUP objects back on screen.
                this.canvas
                  .getObjects()
                  .filter((x) => x.type === "GROUP")
                  .forEach((x) => {
                    x.set({ visible: true });
                  });
                this.addPartitionDoorVariables.line = new fabric.Line(points, {
                  roomID: e.target?.roomID,
                  objectCaching: false,
                  type: "PARTITION_DOOR",
                  stroke: PARTITION_DOOR_COLOR,
                  originX: "center",
                  originY: "center",
                  strokeUniform: true,
                  strokeWidth: partitionLineStokeWidth,
                  padding: 4,
                  parentRoomCordinates: null,
                  partitionWallCordinates: [],
                  lockScalingX: true,
                  lockScalingY: true,
                  lockRotation: false,
                  hasControls: false,
                  lockMovementX: true,
                  lockMovementY: true,
                  doorDirection: this.state.doorDirection,
                  pointId: e.target.id.split("_")[0],
                });
                this.canvas.add(this.addPartitionDoorVariables.line);
              }
            } else if (this.addPartitionDoorVariables.line) {
              const { t } = this.props;
              selectedRoom = this.addPartitionDoorVariables.line.roomID;
              editedRoomInitialLeft = this.addPartitionDoorVariables.line.left;
              editedRoomInitialTop = this.addPartitionDoorVariables.line.top;
              customToast.error(t("ERROR_MESSAGES.add_partition_door"));
            } else if (e.target?.type === "LINE") {
              const { t } = this.props;
              customToast.error(t("COMMON_MESSAGES.Add_Door_On_Same_Wall"));
            }
          } else if (this.state.isAddWindowFromBuildMenu) {
            if (e.target?.type === "LINE") {
              this.addDoorOnStrokeDetection(e.target, e, true, true);
            }
          }
        }
        if (e.target == null) {
          if (isEditMode == true && editedRoomID != 0) {
            this.editArea(isLineEdited || isDoorEdited || isWindowEdited);
            this.canvas.clear();
            this.drawFloorPlan();
            isEditMode = false;
            this.setState({ isEditMode: false });
            this.setState({ isDoorAvailable: true });
            editedRoomID = 0;
            return;
          }
          if (this.state.isAddLineFromBuildMenu) {
            const { t } = this.props;
            customToast.error(
              t("COMMON_MESSAGES.Cannot_Extended_Outside_Room")
            );
          }
        }
      }.bind(this)
    );

    this.RotateFloor = () => {
      this.updateFloorPlanOnRotate(this.state.selectedFloor, linesArray);
    };

    let canvasHeight = 3000;
    let canvasWidth = 3000;

    if (this.props.isTechnician?.edit) {
      canvasHeight = document.querySelector(
        ".measurement-container.technician-container"
      ).clientHeight;

      canvasWidth = document.querySelector(
        ".measurement-container.technician-container"
      ).clientWidth;
    } else {
      canvasHeight = document.querySelector(
        "div.open.tab-content"
      ).clientHeight;

      canvasWidth = document.querySelector("div.open.tab-content").clientWidth;
    }

    this.canvas.setHeight(canvasHeight);
    this.canvas.setWidth(canvasWidth);

    this.canvas.renderAll();

    // Ends drawing

    let printedAreaName = [];
    this.canvas.on("text:editing:entered", (e) => {
      if (e.target.type == "textLabel" && e.target.text == "Tap and type") {
        e.target.selectAll();
        e.target.removeChars();
      }
    });
    this.canvas.on("text:editing:exited", (e) => {
      let p = e.target;
      if (p.type === "textLabel") {
        if (e.target.text.trim().length == 0) {
          e.target.text = "Tap and type";
        }
        let copyOriginal = _.cloneDeep(originalFloorPlan);
        let facesArray =
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
        for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
          if (facesArray[faceIndex]["@id"] != e.target.id) {
            continue;
          }
          facesArray[faceIndex]["@text"] = e.target.text;
        }
        copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
        originalFloorPlan = copyOriginal;
      }
      if (
        !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
          originalFloorPlan,
          designatorWiseObjectArray,
          floorId: this.state.selectedFloor,
        })
      ) {
        EditModeChanges.push({
          originalFloorPlan: _.cloneDeep(originalFloorPlan),
          designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
          floorId: this.state.selectedFloor,
        });
        this.setState({
          undocount: EditModeChanges.length,
        });
      }
    });

    function getCoords(rect) {
      let coords = [];
      coords.push(rect.aCoords.tl);
      coords.push(rect.aCoords.tr);
      coords.push(rect.aCoords.br);
      coords.push(rect.aCoords.bl);
      coords.push(rect.aCoords.tl);
      return coords;
    }

    this.canvas.on(
      "object:moving",
      function (e) {
        if (e.target.type == "GROUP") {
          this.canvas._objects = this.canvas._objects.filter(
            (val) =>
              !(val.type == "CENTRE-BOX-TEXT" && val.id == e.target.roomID)
          );
        }
        let p = e.target;
        let connectedDoor = p?.connectedDoor;
        if (p.type == "textLabel") {
          if (!this.restrictObject(e)) {
            e.target.left = e.target._stateProperties
              ? e.target._stateProperties.left
              : e.target.left;
            e.target.top = e.target._stateProperties
              ? e.target._stateProperties.top
              : e.target.top;
          }
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          let roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          let rooflines =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
          for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
            if (facesArray[faceIndex]["@id"] != p.id) {
              continue;
            }
            for (
              let rooflineIndex = 0;
              rooflineIndex < rooflines.length;
              rooflineIndex++
            ) {
              if (
                facesArray[faceIndex].POLYGON["@path"] ==
                rooflines[rooflineIndex]["@id"]
              ) {
                for (
                  let roofPointIndex = 0;
                  roofPointIndex < roofPoints.length;
                  roofPointIndex++
                ) {
                  if (
                    rooflines[rooflineIndex]["@path"] ==
                    roofPoints[roofPointIndex]["@id"]
                  ) {
                    let datax = p.left / this.ratio + this.minX;
                    let datay = p.top / this.ratio + this.minY;
                    roofPoints[roofPointIndex]["@editedXY"] =
                      datax + "," + datay;
                  }
                }
              }
            }
          }
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
            roofPoints;
          originalFloorPlan = copyOriginal;
          isDoorEdited = true;
        } else if (p.type == "CENTRE-BOX-TEXT") {
          if (!this.restrictObject(e)) {
            e.target.left = e.target._stateProperties
              ? e.target._stateProperties.left
              : e.target.left;
            e.target.top = e.target._stateProperties
              ? e.target._stateProperties.top
              : e.target.top;
          }
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
            if (facesArray[faceIndex]["@id"] != p.id) {
              continue;
            }
            facesArray[faceIndex]["@areaLabelLeft"] =
              p.left / this.ratio + this.minX;
            facesArray[faceIndex]["@areaLabelTop"] =
              p.top / this.ratio + this.minY;
          }
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
          originalFloorPlan = copyOriginal;
          isDoorEdited = true;
        } else if (p.type === "circle") {
          let selectedpartition = p.targetedPartitionId;
          const _points = selectedpartition.calcLinePoints();
          const matrix = selectedpartition.calcTransformMatrix();
          const point1Calc = fabric.util.transformPoint(
            { x: _points.x1, y: _points.y1 },
            matrix
          );
          const point2Calc = fabric.util.transformPoint(
            { x: _points.x2, y: _points.y2 },
            matrix
          );
          let obj = this.canvas.getObjects();
          let basePoint, currentPoint, currentTouchablePoint;
          obj.forEach((element) => {
            if (
              p?.targetedPartitionId?.id &&
              selectedpartition?.type === "LINE" &&
              element.type === "LINE"
            ) {
              if (element.id === selectedpartition.id) {
                obj.forEach((circleEl) => {
                  if (p?.type === "circle" && circleEl.type === "circle") {
                    if (circleEl.id && circleEl.id !== p.name) {
                      basePoint = [
                        circleEl.left + circleEl.radius,
                        circleEl.top + circleEl.radius,
                      ];
                      currentPoint = [p.left + p.radius, p.top + p.radius];
                      if (p.name == "partitionSelector1") {
                        currentTouchablePoint = [element.x1, element.y1];
                        element.set({
                          x1: p.left + p.radius,
                          y1: p.top + p.radius,
                          x2: circleEl.left + circleEl.radius,
                          y2: circleEl.top + circleEl.radius,
                        });
                      } else if (p.name == "partitionSelector2") {
                        currentTouchablePoint = [element.x2, element.y2];
                        element.set({
                          x1: circleEl.left + circleEl.radius,
                          y1: circleEl.top + circleEl.radius,
                          x2: p.left + p.radius,
                          y2: p.top + p.radius,
                        });
                      }
                      element.setCoords();
                    }
                  }
                });
              }
            } else {
              connectedDoor?.forEach((doorEl) => {
                if (element.id === doorEl?.[1]) {
                  obj
                    .filter(
                      (partitionDoorEl) =>
                        partitionDoorEl?.type === "circle" ||
                        partitionDoorEl?.type === "PARTITION_DOOR"
                    )
                    .forEach((circleEl) => {
                      if (p?.type === "circle" && circleEl.type === "circle") {
                        if (circleEl.id && circleEl.id !== p.name) {
                          if (doorEl?.[2] == "x1,y1") {
                            element.set({
                              x1: p.left + p.radius,
                              y1: p.top + p.radius,
                              x2: element.x2,
                              y2: element.y2,
                            });
                          } else if (doorEl?.[2] == "x2,y2") {
                            element.set({
                              x1: element.x1,
                              y1: element.y1,
                              x2: p.left + p.radius,
                              y2: p.top + p.radius,
                            });
                          }
                          element.setCoords();
                        }
                      }
                    });
                }
              });
              if (
                p.targetedPartitionId?.id &&
                element.parentPartitionId &&
                p.targetedPartitionId.id === element.parentPartitionId
              ) {
                let newWindowStartXY = FindNewCoordinates(
                  basePoint,
                  { x: currentPoint[0], y: currentPoint[1] },
                  currentTouchablePoint,
                  [element.x1, element.y1]
                );
                let newWindowEndXY = FindNewCoordinates(
                  basePoint,
                  { x: currentPoint[0], y: currentPoint[1] },
                  currentTouchablePoint,
                  [element.x2, element.y2]
                );
                originalFloorPlan = dragPartitionWindow(
                  originalFloorPlan,
                  p?.targetedPartitionId?.id,
                  element?.id,
                  newWindowStartXY,
                  newWindowEndXY,
                  this.ratio,
                  this.minX,
                  this.minY
                );
                element.set({
                  x1: newWindowStartXY.x,
                  y1: newWindowStartXY.y,
                  x2: newWindowEndXY.x,
                  y2: newWindowEndXY.y,
                });
                element.setCoords();
              }
            }
          });
          this.canvas.renderAll();
          isIntersectObject(this, selectedpartition, point1Calc, point2Calc);
          if (!this.state.isIntersectPartitionWall) {
            this.setState({
              lastLinePoints: {
                x1: point1Calc.x,
                y1: point1Calc.y,
                x2: point2Calc.x,
                y2: point2Calc.y,
                basePoint: basePoint,
                currentTouchablePoint: currentTouchablePoint,
              },
            });

            let copyOriginal = _.cloneDeep(originalFloorPlan);
            let facesArray =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
            let roofPoints =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
            let rooflines =
              copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
            for (
              let faceIndex = 0;
              faceIndex < facesArray.length;
              faceIndex++
            ) {
              if (facesArray[faceIndex]["@id"] != selectedpartition?.id) {
                continue;
              }
              for (
                let rooflineIndex = 0;
                rooflineIndex < rooflines.length;
                rooflineIndex++
              ) {
                if (
                  facesArray[faceIndex].POLYGON["@path"] ==
                    rooflines[rooflineIndex]["@id"] &&
                  facesArray[faceIndex]["@type"] == "LINE"
                ) {
                  let pointPathSplit =
                    rooflines[rooflineIndex]["@path"].split(",");
                  if (pointPathSplit.length === 2) {
                    for (
                      let roofPointIndex = 0;
                      roofPointIndex < roofPoints.length;
                      roofPointIndex++
                    ) {
                      if (
                        pointPathSplit[0] == roofPoints[roofPointIndex]["@id"]
                      ) {
                        let datax = point1Calc.x / this.ratio + this.minX;
                        let datay = point1Calc.y / this.ratio + this.minY;

                        if (
                          facesArray[faceIndex]?.LINE?.linePointObjectArray?.[0]
                        ) {
                          facesArray[faceIndex].LINE.linePointObjectArray[0][
                            "@editedXY"
                          ] = datax + "," + datay;
                          facesArray[faceIndex].LINE.linePointObjectArray[0][
                            "@autoSnappedXY"
                          ] = datax + "," + datay;
                        }

                        if (
                          rooflines[rooflineIndex]?.linePointObjectArray?.[0]
                        ) {
                          rooflines[rooflineIndex].linePointObjectArray[0][
                            "@editedXY"
                          ] = datax + "," + datay;
                          rooflines[rooflineIndex].linePointObjectArray[0][
                            "@autoSnappedXY"
                          ] = datax + "," + datay;
                        }

                        roofPoints[roofPointIndex]["@editedXY"] =
                          datax + "," + datay;
                        roofPoints[roofPointIndex]["@autoSnappedXY"] =
                          datax + "," + datay;
                      }
                      if (
                        pointPathSplit[1] == roofPoints[roofPointIndex]["@id"]
                      ) {
                        let datax = point2Calc.x / this.ratio + this.minX;
                        let datay = point2Calc.y / this.ratio + this.minY;

                        if (
                          facesArray[faceIndex]?.LINE?.linePointObjectArray?.[1]
                        ) {
                          facesArray[faceIndex].LINE.linePointObjectArray[1][
                            "@editedXY"
                          ] = datax + "," + datay;
                          facesArray[faceIndex].LINE.linePointObjectArray[1][
                            "@autoSnappedXY"
                          ] = datax + "," + datay;
                        }

                        if (
                          rooflines[rooflineIndex]?.linePointObjectArray?.[1]
                        ) {
                          rooflines[rooflineIndex].linePointObjectArray[1][
                            "@editedXY"
                          ] = datax + "," + datay;
                          rooflines[rooflineIndex].linePointObjectArray[1][
                            "@autoSnappedXY"
                          ] = datax + "," + datay;
                        }

                        roofPoints[roofPointIndex]["@editedXY"] =
                          datax + "," + datay;
                        roofPoints[roofPointIndex]["@autoSnappedXY"] =
                          datax + "," + datay;
                      }
                    }
                  }
                }
              }
            }
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
              roofPoints;
            originalFloorPlan = copyOriginal;
            originalFloorPlan = dragPartitionDoor(
              originalFloorPlan,
              selectedpartition
            );
            isDoorEdited = true;
          }
        } else if (p.type === "custom-line") {
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          for (let i = 0; i < roofPoints.length; i++) {
            if (roofPoints[i]["@id"] == p.linePointObjectArray.split(",")[1]) {
              roofPoints[i]["@editedXY"] =
                p.x1 / this.ratio +
                this.minX +
                "," +
                (p.y1 / this.ratio + this.minY);
              roofPoints[i]["@autoSnappedXY"] = roofPoints[i]["@editedXY"];
            } else if (
              roofPoints[i]["@id"] == p.linePointObjectArray.split(",")[0]
            ) {
              roofPoints[i]["@editedXY"] =
                p.x2 / this.ratio +
                this.minX +
                "," +
                (p.y2 / this.ratio + this.minY);
              roofPoints[i]["@autoSnappedXY"] = roofPoints[i]["@editedXY"];
              originalFloorPlan = _.cloneDeep(copyOriginal);

              p.setCoords();
              this.canvas.renderAll();
            }
          }
        } else if (p.type === "DW") {
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          const wall = designatorWiseObjectArray[p.roomID].filter(
            (el) => el["@id"] == p.wallID
          );
          const walllinepoints = wall[0].LINE.linePointObjectArray;
          const whichXy = isEditMode ? "@editedXY" : "@autoSnappedXY";
          const data1 = walllinepoints[0][whichXy].split(",");
          const data2 = walllinepoints[1][whichXy].split(",");
          const x1 = (parseFloat(data1[0]) - this.minX) * this.ratio;
          const x2 = (parseFloat(data2[0]) - this.minX) * this.ratio;
          const y1 = (parseFloat(data1[1]) - this.minY) * this.ratio;
          const y2 = (parseFloat(data2[1]) - this.minY) * this.ratio;
          const boundry = {
            x1: p.left - (p.x2 - p.x1) / 2,
            y1: p.top - (p.y2 - p.y1) / 2,
            x2: p.left + (p.x2 - p.x1) / 2,
            y2: p.top + (p.y2 - p.y1) / 2,
          };
          let angleDeg = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
          let radians = fabric.util.degreesToRadians(angleDeg);

          const doorpoints1 = roofPoints.filter(
            (el) => el["@id"] == p.linePointObjectArray.split(",")[0]
          );
          const doorpoints2 = roofPoints.filter(
            (el) => el["@id"] == p.linePointObjectArray.split(",")[1]
          );
          const doordata1 = doorpoints1[0][whichXy].split(",");
          const doordata2 = doorpoints2[0][whichXy].split(",");
          const doorx1 = (parseFloat(doordata1[0]) - this.minX) * this.ratio;
          const doorx2 = (parseFloat(doordata2[0]) - this.minX) * this.ratio;
          const doory1 = (parseFloat(doordata1[1]) - this.minY) * this.ratio;
          const doory2 = (parseFloat(doordata2[1]) - this.minY) * this.ratio;
          const linediff = Math.sqrt(
            Math.pow(doorx2 - doorx1, 2) + Math.pow(doory2 - doory1, 2)
          );
          const diff1 = Math.sqrt(
            Math.pow(boundry.x1 - x1, 2) + Math.pow(boundry.y1 - y1, 2)
          );
          const maxdiff = Math.sqrt(
            Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)
          );
          const diff11 = boundry.x1 - x1 + (boundry.y1 - y1);
          const diff22 = boundry.x2 - x2 + (boundry.y2 - y2);

          const diff12 = x1 - boundry.x1 + (y1 - boundry.y1);
          const diff23 = x2 - boundry.x2 + (y2 - boundry.y2);

          const dx1 = x1 + diff1 * Math.cos(radians);
          const dy1 = y1 + diff1 * Math.sin(radians);
          const dx2 = x1 + (diff1 + linediff) * Math.cos(radians);
          const dy2 = y1 + (diff1 + linediff) * Math.sin(radians);
          const line = new fabric.Line([x1, y1, x2, y2], {
            strokeWidth: lineStokeWidth,
          });
          const cpoints = line.getCenterPoint();
          const cpdiffb = Math.sqrt(
            Math.pow(x1 - cpoints.x, 2) + Math.pow(y1 - cpoints.y, 2)
          );
          const cpdifft = Math.sqrt(
            Math.pow(x2 - cpoints.x, 2) + Math.pow(y2 - cpoints.y, 2)
          );
          const cpdiffbc = Math.sqrt(
            Math.pow(dx1 - cpoints.x, 2) + Math.pow(dy1 - cpoints.y, 2)
          );
          const cpdifftc = Math.sqrt(
            Math.pow(dx2 - cpoints.x, 2) + Math.pow(dy2 - cpoints.y, 2)
          );
          if (
            ((diff11 > 0 &&
              diff22 < 0 &&
              diff11 < maxdiff &&
              diff22 < maxdiff) ||
              (diff12 > 0 &&
                diff23 < 0 &&
                diff12 < maxdiff &&
                diff23 < maxdiff)) &&
            cpdiffbc <= cpdiffb &&
            cpdifftc <= cpdifft
          ) {
            for (let i = 0; i < roofPoints.length; i++) {
              if (
                roofPoints[i]["@id"] == p.linePointObjectArray.split(",")[1]
              ) {
                roofPoints[i][whichXy] =
                  dx1 / this.ratio +
                  this.minX +
                  "," +
                  (dy1 / this.ratio + this.minY);
                // roofPoints[i]["@autoSnappedXY"] = roofPoints[i]["@editedXY"];
              } else if (
                roofPoints[i]["@id"] == p.linePointObjectArray.split(",")[0]
              ) {
                roofPoints[i][whichXy] =
                  dx2 / this.ratio +
                  this.minX +
                  "," +
                  (dy2 / this.ratio + this.minY);
                // roofPoints[i]["@autoSnappedXY"] = roofPoints[i]["@editedXY"];
              }
            }
            p.set({ x1: dx1, y1: dy1, x2: dx2, y2: dy2 });
            const cloneLine = this.canvas.getItemByAttr("id", "wclone-" + p.id);
            cloneLine.set({ x1: dx1, y1: dy1, x2: dx2, y2: dy2 });
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
              roofPoints;
            originalFloorPlan = _.cloneDeep(copyOriginal);
          } else {
            const walllinepoints1 = roofPoints.filter(
              (el) => el["@id"] == p.linePointObjectArray.split(",")[0]
            );
            const walllinepoints2 = roofPoints.filter(
              (el) => el["@id"] == p.linePointObjectArray.split(",")[1]
            );
            const data1 = walllinepoints1[0][whichXy].split(",");
            const data2 = walllinepoints2[0][whichXy].split(",");
            const x1 = (parseFloat(data1[0]) - this.minX) * this.ratio;
            const x2 = (parseFloat(data2[0]) - this.minX) * this.ratio;
            const y1 = (parseFloat(data1[1]) - this.minY) * this.ratio;
            const y2 = (parseFloat(data2[1]) - this.minY) * this.ratio;
            p.set({ x1: x1, y1: y1, x2: x2, y2: y2 });
          }
          p.setCoords();
          this.canvas.renderAll();
          if (e.target.id.toString().toLowerCase().includes("door")) {
            isDoorEdited = true;
          } else if (e.target.id.toString().toLowerCase().includes("window")) {
            isWindowEdited = true;
          }
        } else if (p.type === "modifiable-box") {
          this.setState({ lineselected: false, linestyle: {} });
        } else if (p.type == "stair-case") {
          if (!this.restrictObject(e)) {
            e.target.left = e.target._stateProperties
              ? e.target._stateProperties.left
              : e.target.left;
            e.target.top = e.target._stateProperties
              ? e.target._stateProperties.top
              : e.target.top;
          }
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          let roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          let rooflines =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
          for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
            if (facesArray[faceIndex]["@id"] != p.id) {
              continue;
            }
            for (
              let rooflineIndex = 0;
              rooflineIndex < rooflines.length;
              rooflineIndex++
            ) {
              if (
                facesArray[faceIndex].POLYGON["@path"] ==
                rooflines[rooflineIndex]["@id"]
              ) {
                for (
                  let roofPointIndex = 0;
                  roofPointIndex < roofPoints.length;
                  roofPointIndex++
                ) {
                  if (
                    rooflines[rooflineIndex]["@path"] ==
                    roofPoints[roofPointIndex]["@id"]
                  ) {
                    let datax = p.left / this.ratio + this.minX;
                    let datay = p.top / this.ratio + this.minY;
                    roofPoints[roofPointIndex]["@editedXY"] =
                      datax + "," + datay;
                  }
                }
              }
            }
          }
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
            roofPoints;
          originalFloorPlan = copyOriginal;
          isStairCaseEdited = true;
        } else if (p.type == "LINE") {
          if (!this.restrictObject(e)) {
            e.target.left = e.target._stateProperties
              ? e.target._stateProperties.left
              : e.target.left;
            e.target.top = e.target._stateProperties
              ? e.target._stateProperties.top
              : e.target.top;
          }
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          let roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          let winowRoofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          let rooflines =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
          let parentID = false;
          for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
            if (facesArray[faceIndex]["@id"] != p.id) {
              console.log("yes move and now for loop ");
              continue;
            }

            for (
              let rooflineIndex = 0;
              rooflineIndex < rooflines.length;
              rooflineIndex++
            ) {
              if (
                facesArray[faceIndex].POLYGON["@path"] ==
                rooflines[rooflineIndex]["@id"]
              ) {
                let linePoints = rooflines[rooflineIndex]["@path"].split(",");
                // console.log("linePoints ==", linePoints);
                let point1 = linePoints[0];
                // console.log("point1 ==", point1);
                let point2 = linePoints[1];
                // console.log("point2 ==", point2);
                for (
                  let roofPointIndex = 0;
                  roofPointIndex < roofPoints.length;
                  roofPointIndex++
                ) {
                  if (roofPoints[roofPointIndex]["@id"] == point1) {
                    roofPoints[roofPointIndex]["@editedXY"] =
                      p.left / this.ratio +
                      this.minX +
                      "," +
                      (p.top / this.ratio + this.minY);
                  } else if (roofPoints[roofPointIndex]["@id"] == point2) {
                    roofPoints[roofPointIndex]["@editedXY"] =
                      (p.left + p.width) / this.ratio +
                      this.minX +
                      "," +
                      (p.top / this.ratio + this.minY);
                  }
                }

                let object = this.canvas.getObjects();
                // .find((obj) => obj.type === "PARTITION_WINDOW");
                const filteredArray = object.filter(
                  (el) => el.parentPartitionId == facesArray[faceIndex]["@id"]
                );
                console.log("!!!!!  ", filteredArray);
                console.log("object 1", object);

                console.log("id=>", facesArray[faceIndex]["@id"]);
                if (
                  filteredArray[0]?.parentPartitionId ==
                  facesArray[faceIndex]["@id"]
                ) {
                  parentID = true;
                  console.log("hi thire ==");
                  // p = filteredArray[0]
                  // filteredArray[0].set({ x1: 1, y1:1, x2:1, y2:1 });
                  // filteredArray[0].setCoords();

                  // this.canvas.renderAll();
                  const parentPartitionlineid = facesArray.filter(
                    (el) => el["@id"] === filteredArray[0].id
                  )[0].POLYGON["@path"];
                  console.log("parentPartitionlineid ", parentPartitionlineid);
                  const linePointObjectArray = rooflines.filter(
                    (el) => el["@id"] === parentPartitionlineid
                  )[0].linePointObjectArray;
                  console.log("linePointObjectArray ", linePointObjectArray);
                  let point1 = linePointObjectArray[0]["@id"];
                  let point2 = linePointObjectArray[1]["@id"];
                  console.log("point1=> ", point1, " point2  =>", point2);
                  for (
                    let roofPointIndex = 0;
                    roofPointIndex < roofPoints.length;
                    roofPointIndex++
                  ) {
                    if (roofPoints[roofPointIndex]["@id"] == point1) {
                      console.log("in");
                      roofPoints[roofPointIndex]["@editedXY"] =
                        filteredArray[0].left / this.ratio +
                        this.minX +
                        "," +
                        (filteredArray[0].top / this.ratio + this.minY);
                    } else if (roofPoints[roofPointIndex]["@id"] == point2) {
                      console.log("in");
                      roofPoints[roofPointIndex]["@editedXY"] =
                        (filteredArray[0].left + filteredArray[0].width) /
                          this.ratio +
                        this.minX +
                        "," +
                        (filteredArray[0].top / this.ratio + this.minY);
                    }
                  }
                }
                // let isDoorPartition = facesArray.filter((el) => {
                //   let test = (el["@parentPartition"])
                //   test.map((el) => {
                //     if(el.line == facesArray[faceIndex]["@id"])
                //       console.log("yooooooo yooo")
                //   })
                // })
                // console.log("Door => " ,isDoorPartition)
              } else {
                console.log("not enter");
              }
            }
          }
          // if(parentID){
          //   let windowObject = this.canvas
          //         .getObjects()
          //         .find((obj) => obj.type === "PARTITION_WINDOW");
          //   p = windowObject
          //   p.set({ x1: -100, y1: 0, x2: 0, y2: 0 });
          //   p.setCoords();
          //   this.canvas.renderAll();
          //   const parentPartitionlineid = faceArray.filter(
          //     (el) => el["@id"] === p.parentPartitionId
          //   )[0].POLYGON["@path"];
          //   console.log("parentPartitionlineid ", parentPartitionlineid);
          //   const linePointObjectArray = linesArray.filter(
          //     (el) => el["@id"] === parentPartitionlineid
          //   )[0].linePointObjectArray;
          //   console.log("linePointObjectArray ", linePointObjectArray);

          //   const partitionlinepoints = linePointObjectArray;
          //   const whichXy = "@editedXY";
          //   const data1 = partitionlinepoints[0][whichXy].split(",");
          //   const data2 = partitionlinepoints[1][whichXy].split(",");
          //   const x1 = (parseFloat(data1[0]) - this.minX) * this.ratio;
          //   const x2 = (parseFloat(data2[0]) - this.minX) * this.ratio;
          //   const y1 = (parseFloat(data1[1]) - this.minY) * this.ratio;
          //   const y2 = (parseFloat(data2[1]) - this.minY) * this.ratio;
          //   const boundry = {
          //     x1: p.left - (p.x2 - p.x1) / 2,
          //     y1: p.top - (p.y2 - p.y1) / 2,
          //     x2: p.left + (p.x2 - p.x1) / 2,
          //     y2: p.top + (p.y2 - p.y1) / 2,
          //   };
          //   let angleDeg = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
          //   let radians = fabric.util.degreesToRadians(angleDeg);

          //   const window = faceArray.filter((el) => el["@id"] === p.id)[0]
          //     .POLYGON["@path"];
          //   const WPointObjectArray = linesArray.filter(
          //     (el) => el["@id"] === window
          //   )[0].linePointObjectArray;

          //   const doorpoints1 = WPointObjectArray[0];
          //   const doorpoints2 = WPointObjectArray[1];
          //   const doordata1 = doorpoints1[whichXy].split(",");
          //   const doordata2 = doorpoints2[whichXy].split(",");
          //   const doorx1 = (parseFloat(doordata1[0]) - this.minX) * this.ratio;
          //   const doorx2 = (parseFloat(doordata2[0]) - this.minX) * this.ratio;
          //   const doory1 = (parseFloat(doordata1[1]) - this.minY) * this.ratio;
          //   const doory2 = (parseFloat(doordata2[1]) - this.minY) * this.ratio;
          //   const linediff = Math.sqrt(
          //     Math.pow(doorx2 - doorx1, 2) + Math.pow(doory2 - doory1, 2)
          //   );
          //   const diff1 = Math.sqrt(
          //     Math.pow(boundry.x1 - x1, 2) + Math.pow(boundry.y1 - y1, 2)
          //   );
          //   const maxdiff = Math.sqrt(
          //     Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)
          //   );
          //   const diff11 = boundry.x1 - x1 + (boundry.y1 - y1);
          //   const diff22 = boundry.x2 - x2 + (boundry.y2 - y2);

          //   const diff12 = x1 - boundry.x1 + (y1 - boundry.y1);
          //   const diff23 = x2 - boundry.x2 + (y2 - boundry.y2);

          //   const dx1 = x1 + diff1 * Math.cos(radians);
          //   const dy1 = y1 + diff1 * Math.sin(radians);
          //   const dx2 = x1 + (diff1 + linediff) * Math.cos(radians);
          //   const dy2 = y1 + (diff1 + linediff) * Math.sin(radians);
          //   const line = new fabric.Line([x1, y1, x2, y2], {
          //     strokeWidth: lineStokeWidth,
          //   });
          //   const cpoints = line.getCenterPoint();
          //   const cpdiffb = Math.sqrt(
          //     Math.pow(x1 - cpoints.x, 2) + Math.pow(y1 - cpoints.y, 2)
          //   );
          //   const cpdifft = Math.sqrt(
          //     Math.pow(x2 - cpoints.x, 2) + Math.pow(y2 - cpoints.y, 2)
          //   );
          //   const cpdiffbc = Math.sqrt(
          //     Math.pow(dx1 - cpoints.x, 2) + Math.pow(dy1 - cpoints.y, 2)
          //   );
          //   const cpdifftc = Math.sqrt(
          //     Math.pow(dx2 - cpoints.x, 2) + Math.pow(dy2 - cpoints.y, 2)
          //   );
          //   if (
          //     ((diff11 > 0 &&
          //       diff22 < 0 &&
          //       diff11 < maxdiff &&
          //       diff22 < maxdiff) ||
          //       (diff12 > 0 &&
          //         diff23 < 0 &&
          //         diff12 < maxdiff &&
          //         diff23 < maxdiff)) &&
          //     cpdiffbc <= cpdiffb &&
          //     cpdifftc <= cpdifft
          //   ) {
          //     for (let i = 0; i < roofPoints.length; i++) {
          //       if (roofPoints[i]["@id"] === doorpoints2["@id"]) {
          //         roofPoints[i][whichXy] =
          //           dx1 / this.ratio +
          //           this.minX +
          //           "," +
          //           (dy1 / this.ratio + this.minY);
          //       } else if (roofPoints[i]["@id"] === doorpoints1["@id"]) {
          //         roofPoints[i][whichXy] =
          //           dx2 / this.ratio +
          //           this.minX +
          //           "," +
          //           (dy2 / this.ratio + this.minY);
          //       }
          //     }
          //     p.set({ x1: dx1, y1: dy1, x2: dx2, y2: dy2 });
          //     copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
          //       roofPoints;
          //     originalFloorPlan = _.cloneDeep(copyOriginal);
          //   } else {
          //     const window = faceArray.filter((el) => el["@id"] === p.id)[0]
          //       .POLYGON["@path"];
          //     const WPointObjectArray = linesArray.filter(
          //       (el) => el["@id"] === window
          //     )[0].linePointObjectArray;

          //     const walllinepoints1 = WPointObjectArray[0];
          //     const walllinepoints2 = WPointObjectArray[1];
          //     const data1 = walllinepoints1[whichXy].split(",");
          //     const data2 = walllinepoints2[whichXy].split(",");
          //     const x1 = (parseFloat(data1[0]) - this.minX) * this.ratio;
          //     const x2 = (parseFloat(data2[0]) - this.minX) * this.ratio;
          //     const y1 = (parseFloat(data1[1]) - this.minY) * this.ratio;
          //     const y2 = (parseFloat(data2[1]) - this.minY) * this.ratio;
          //     p.set({ x1: -100, y1: 0, x2: 0, y2: 0 });
          //   }
          //   p.setCoords();
          //   this.canvas.renderAll();
          //   isDoorEdited = true;
          //   isWindowEdited = true;
          // }
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
            roofPoints;
          originalFloorPlan = copyOriginal;
          isLineEdited = true;
        } else if (p.type === "PARTITION_WINDOW") {
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let faceArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          let linesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
          let roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          const parentPartitionlineid = faceArray.filter(
            (el) => el["@id"] === p.parentPartitionId
          )[0].POLYGON["@path"];
          console.log("parentPartitionlineid ", parentPartitionlineid);
          const linePointObjectArray = linesArray.filter(
            (el) => el["@id"] === parentPartitionlineid
          )[0].linePointObjectArray;
          console.log("linePointObjectArray ", linePointObjectArray);

          const partitionlinepoints = linePointObjectArray;
          const whichXy = "@editedXY";
          const data1 = partitionlinepoints[0][whichXy].split(",");
          const data2 = partitionlinepoints[1][whichXy].split(",");
          const x1 = (parseFloat(data1[0]) - this.minX) * this.ratio;
          const x2 = (parseFloat(data2[0]) - this.minX) * this.ratio;
          const y1 = (parseFloat(data1[1]) - this.minY) * this.ratio;
          const y2 = (parseFloat(data2[1]) - this.minY) * this.ratio;
          const boundry = {
            x1: p.left - (p.x2 - p.x1) / 2,
            y1: p.top - (p.y2 - p.y1) / 2,
            x2: p.left + (p.x2 - p.x1) / 2,
            y2: p.top + (p.y2 - p.y1) / 2,
          };
          let angleDeg = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
          let radians = fabric.util.degreesToRadians(angleDeg);

          const window = faceArray.filter((el) => el["@id"] === p.id)[0]
            .POLYGON["@path"];
          const WPointObjectArray = linesArray.filter(
            (el) => el["@id"] === window
          )[0].linePointObjectArray;

          const doorpoints1 = WPointObjectArray[0];
          const doorpoints2 = WPointObjectArray[1];
          const doordata1 = doorpoints1[whichXy].split(",");
          const doordata2 = doorpoints2[whichXy].split(",");
          const doorx1 = (parseFloat(doordata1[0]) - this.minX) * this.ratio;
          const doorx2 = (parseFloat(doordata2[0]) - this.minX) * this.ratio;
          const doory1 = (parseFloat(doordata1[1]) - this.minY) * this.ratio;
          const doory2 = (parseFloat(doordata2[1]) - this.minY) * this.ratio;
          const linediff = Math.sqrt(
            Math.pow(doorx2 - doorx1, 2) + Math.pow(doory2 - doory1, 2)
          );
          const diff1 = Math.sqrt(
            Math.pow(boundry.x1 - x1, 2) + Math.pow(boundry.y1 - y1, 2)
          );
          const maxdiff = Math.sqrt(
            Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)
          );
          const diff11 = boundry.x1 - x1 + (boundry.y1 - y1);
          const diff22 = boundry.x2 - x2 + (boundry.y2 - y2);

          const diff12 = x1 - boundry.x1 + (y1 - boundry.y1);
          const diff23 = x2 - boundry.x2 + (y2 - boundry.y2);

          const dx1 = x1 + diff1 * Math.cos(radians);
          const dy1 = y1 + diff1 * Math.sin(radians);
          const dx2 = x1 + (diff1 + linediff) * Math.cos(radians);
          const dy2 = y1 + (diff1 + linediff) * Math.sin(radians);
          const line = new fabric.Line([x1, y1, x2, y2], {
            strokeWidth: lineStokeWidth,
          });
          const cpoints = line.getCenterPoint();
          const cpdiffb = Math.sqrt(
            Math.pow(x1 - cpoints.x, 2) + Math.pow(y1 - cpoints.y, 2)
          );
          const cpdifft = Math.sqrt(
            Math.pow(x2 - cpoints.x, 2) + Math.pow(y2 - cpoints.y, 2)
          );
          const cpdiffbc = Math.sqrt(
            Math.pow(dx1 - cpoints.x, 2) + Math.pow(dy1 - cpoints.y, 2)
          );
          const cpdifftc = Math.sqrt(
            Math.pow(dx2 - cpoints.x, 2) + Math.pow(dy2 - cpoints.y, 2)
          );
          if (
            ((diff11 > 0 &&
              diff22 < 0 &&
              diff11 < maxdiff &&
              diff22 < maxdiff) ||
              (diff12 > 0 &&
                diff23 < 0 &&
                diff12 < maxdiff &&
                diff23 < maxdiff)) &&
            cpdiffbc <= cpdiffb &&
            cpdifftc <= cpdifft
          ) {
            for (let i = 0; i < roofPoints.length; i++) {
              if (roofPoints[i]["@id"] === doorpoints2["@id"]) {
                roofPoints[i][whichXy] =
                  dx1 / this.ratio +
                  this.minX +
                  "," +
                  (dy1 / this.ratio + this.minY);
              } else if (roofPoints[i]["@id"] === doorpoints1["@id"]) {
                roofPoints[i][whichXy] =
                  dx2 / this.ratio +
                  this.minX +
                  "," +
                  (dy2 / this.ratio + this.minY);
              }
            }
            p.set({ x1: dx1, y1: dy1, x2: dx2, y2: dy2 });
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
              roofPoints;
            originalFloorPlan = _.cloneDeep(copyOriginal);
          } else {
            const window = faceArray.filter((el) => el["@id"] === p.id)[0]
              .POLYGON["@path"];
            const WPointObjectArray = linesArray.filter(
              (el) => el["@id"] === window
            )[0].linePointObjectArray;

            const walllinepoints1 = WPointObjectArray[0];
            const walllinepoints2 = WPointObjectArray[1];
            const data1 = walllinepoints1[whichXy].split(",");
            const data2 = walllinepoints2[whichXy].split(",");
            const x1 = (parseFloat(data1[0]) - this.minX) * this.ratio;
            const x2 = (parseFloat(data2[0]) - this.minX) * this.ratio;
            const y1 = (parseFloat(data1[1]) - this.minY) * this.ratio;
            const y2 = (parseFloat(data2[1]) - this.minY) * this.ratio;
            p.set({ x1: x1, y1: y1, x2: x2, y2: y2 });
          }
          p.setCoords();
          this.canvas.renderAll();
          isDoorEdited = true;
          isWindowEdited = true;
        } else if (
          p.type !== "doorobject" &&
          p.type !== "partitionLine" &&
          p.type !== "PARTITION_WINDOW"
        ) {
          //remove line for door while moving room #start
          if (
            (designatorWiseObjectArray[p?.roomID] &&
              designatorWiseObjectArray[p?.roomID]?.length > 0) ||
            (designatorWiseObjectArray[p?.line1?.roomID] &&
              designatorWiseObjectArray[p?.line1?.roomID]?.length > 0)
          ) {
            let _roomid = p.roomID ?? p.line1.roomID;
            let childdata = designatorWiseObjectArray[_roomid]
              .filter((el) => el["@id"] != _roomid)
              .map((el) => {
                return el["@children"].length > 0
                  ? el["@children"].split(",")
                  : [];
              });
            let childdataLabel = designatorWiseObjectArray[_roomid]
              .filter((el) => el["@id"] == _roomid)
              .map((el) => {
                return el["@childrenLabel"] && el["@childrenLabel"].length > 0
                  ? el["@childrenLabel"].split(",")
                  : [];
              });
            let childdataLine = designatorWiseObjectArray[_roomid]
              .filter((el) => el["@id"] == _roomid)
              .map((el) => {
                return el["@childrenLine"] && el["@childrenLine"].length > 0
                  ? el["@childrenLine"].split(",")
                  : [];
              });
            let childDataPartitionDoor = designatorWiseObjectArray[_roomid]
              .filter((el) => el["@id"] == _roomid)
              .map((el) => {
                return el["@partitionDoor"] && el["@partitionDoor"].length > 0
                  ? el["@partitionDoor"].split(",")
                  : [];
              });
            let childDataPartitionWindow = designatorWiseObjectArray[_roomid]
              .filter((el) => el["@id"] == _roomid)
              .map((el) => {
                return el["@partitionWindow"] &&
                  el["@partitionWindow"].length > 0
                  ? el["@partitionWindow"].split(",")
                  : [];
              });
            let childdataStaircase = designatorWiseObjectArray[_roomid]
              .filter((el) => el["@id"] == _roomid)
              .map((el) => {
                return el["@childrenStairCase"] &&
                  el["@childrenStairCase"].length > 0
                  ? el["@childrenStairCase"].split(",")
                  : [];
              });
            if (
              !this.state.isAddLineFromBuildMenu &&
              !this.state.isAddPolylineFromBuildMenu &&
              !this.state.isAddLabel &&
              e &&
              e.pointer &&
              e.transform &&
              (Math.abs(e.pointer.x - e.transform.lastX) > 5 ||
                Math.abs(e.pointer.y - e.transform.lastY) > 5)
            ) {
              childdata = childdata.concat(childdataLabel);
              childdata = childdata.concat(childdataLine);
              childdata = childdata.concat(childDataPartitionDoor);
              childdata = childdata.concat(childDataPartitionWindow);
              childdata = childdata.concat(childdataStaircase);
            }
            let childIds = Object.keys(childdata).reduce(function (arr, key) {
              return arr.concat(childdata[key]);
            }, []);
            childIds.forEach((element) => {
              this.canvas.remove(this.canvas.getItemByAttr("id", element));
            });
          }
          //remove line for door while moving room #end

          if (p.type == "GROUP" || p.type == "polygon") {
            isGroupMoving = true;
            return;
          }

          let copyOriginal = _.cloneDeep(originalFloorPlan);

          var facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          var roofPoints =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
          var rooflines =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
          let basex = 0,
            basey = 0,
            maxdiff = 0,
            basexline2 = 0,
            baseyline2 = 0,
            maxdiffline2 = 0;
          let childdataline1 = facesArray
            .filter((el) => el["@id"] == p.line1?.id)
            .map((el) => {
              return el["@children"].length > 0
                ? el["@children"].split(",")
                : [];
            });
          let childIdsline1 = Object.keys(childdataline1).reduce(function (
            arr,
            key
          ) {
            return arr.concat(childdataline1[key]);
          },
          []);

          let wallObj = facesArray.filter((el) => el["@id"] == p.line1.id);
          const wallLineObj = rooflines.filter(
            (el) => el["@id"] == wallObj[0].POLYGON["@path"]
          );
          let wallRoofPoints1 = roofPoints
            .filter(
              (el) => el["@id"] == wallLineObj[0]["@path"].split(",")[0]
            )[0]
            ["@editedXY"].split(",");
          let wallRoofPoints2 = roofPoints
            .filter(
              (el) => el["@id"] == wallLineObj[0]["@path"].split(",")[1]
            )[0]
            ["@editedXY"].split(",");
          let dxline1 =
            (parseFloat(wallRoofPoints1[0]) - this.minX) * this.ratio;
          let dxline2 =
            (parseFloat(wallRoofPoints2[0]) - this.minX) * this.ratio;
          let dyline1 =
            (parseFloat(wallRoofPoints1[1]) - this.minY) * this.ratio;
          let dyline2 =
            (parseFloat(wallRoofPoints2[1]) - this.minY) * this.ratio;

          const childObjarray1 = facesArray
            .filter((el) => childIdsline1.includes(el["@id"]))
            .map((el) => {
              return el.POLYGON["@path"];
            });
          const rooflinesarray1 = rooflines.filter((el) =>
            childObjarray1.includes(el["@id"])
          );
          if (!(p.line1.x1 == p.line2.x1 && p.line1.y1 == p.line2.y1)) {
            basex = dxline1;
            basey = dyline1;
          } else {
            basex = dxline2;
            basey = dyline2;
          }
          rooflinesarray1.forEach((element) => {
            const roofPointsarray = roofPoints.filter((el) =>
              element["@path"].split(",").includes(el["@id"])
            );
            roofPointsarray.forEach((roofPointsarrayelm) => {
              let x =
                (parseFloat(roofPointsarrayelm["@editedXY"].split(",")[0]) -
                  this.minX) *
                this.ratio;
              let y =
                parseFloat(
                  roofPointsarrayelm["@editedXY"].split(",")[1] - this.minY
                ) * this.ratio;
              const diff = Math.sqrt(
                Math.pow(x - basex, 2) + Math.pow(y - basey, 2)
              );
              if (diff > maxdiff) {
                maxdiff = diff;
              }
            });
          });
          if (!(p.line1.x1 == p.line2.x2 && p.line1.y1 == p.line2.y2)) {
            const diff1 = Math.sqrt(
              Math.pow(p.getCenterPoint().x - basex, 2) +
                Math.pow(p.getCenterPoint().y - basey, 2)
            );
            if (maxdiff > diff1) {
              p.set({ left: p.line1.x2, top: p.line1.y2 });
              p.setCoords();
              return;
            }
          } else {
            const diff1 = Math.sqrt(
              Math.pow(p.getCenterPoint().x - basex, 2) +
                Math.pow(p.getCenterPoint().y - basey, 2)
            );
            if (maxdiff > diff1) {
              p.set({ left: p.line1.x2, top: p.line1.y2 });
              p.setCoords();
              return;
            }
          }

          let childdataline2 = facesArray
            .filter((el) => el["@id"] == p.line2.id)
            .map((el) => {
              return el["@children"].length > 0
                ? el["@children"].split(",")
                : [];
            });
          let childIdsline2 = Object.keys(childdataline2).reduce(function (
            arr,
            key
          ) {
            return arr.concat(childdataline2[key]);
          },
          []);
          const childObjarray = facesArray
            .filter((el) => childIdsline2.includes(el["@id"]))
            .map((el) => {
              return el.POLYGON["@path"];
            });
          const rooflinesarray = rooflines.filter((el) =>
            childObjarray.includes(el["@id"])
          );
          let wallObjl2 = facesArray.filter((el) => el["@id"] == p.line2.id);
          const wallLineObjl2 = rooflines.filter(
            (el) => el["@id"] == wallObjl2[0].POLYGON["@path"]
          );
          wallRoofPoints1 = roofPoints
            .filter(
              (el) => el["@id"] == wallLineObjl2[0]["@path"].split(",")[0]
            )[0]
            ["@editedXY"].split(",");
          wallRoofPoints2 = roofPoints
            .filter(
              (el) => el["@id"] == wallLineObjl2[0]["@path"].split(",")[1]
            )[0]
            ["@editedXY"].split(",");
          const dxline21 =
            (parseFloat(wallRoofPoints1[0]) - this.minX) * this.ratio;
          const dxline22 =
            (parseFloat(wallRoofPoints2[0]) - this.minX) * this.ratio;
          const dyline21 =
            (parseFloat(wallRoofPoints1[1]) - this.minY) * this.ratio;
          const dyline22 =
            (parseFloat(wallRoofPoints2[1]) - this.minY) * this.ratio;

          if (!(p.line1.x1 == p.line2.x2 && p.line1.y1 == p.line2.y2)) {
            basexline2 = dxline22;
            baseyline2 = dyline22;
          } else {
            basexline2 = dxline21;
            baseyline2 = dyline21;
          }
          rooflinesarray.forEach((element) => {
            const roofPointsarray = roofPoints.filter((el) =>
              element["@path"].split(",").includes(el["@id"])
            );
            roofPointsarray.forEach((roofPointsarrayelm) => {
              let x =
                (parseFloat(roofPointsarrayelm["@editedXY"].split(",")[0]) -
                  this.minX) *
                this.ratio;
              let y =
                parseFloat(
                  roofPointsarrayelm["@editedXY"].split(",")[1] - this.minY
                ) * this.ratio;
              const diff = Math.sqrt(
                Math.pow(x - basexline2, 2) + Math.pow(y - baseyline2, 2)
              );
              if (diff > maxdiffline2) {
                maxdiffline2 = diff;
              }
            });
          });
          if (!(p.line1.x1 == p.line2.x2 && p.line1.y1 == p.line2.y2)) {
            const diff1 = Math.sqrt(
              Math.pow(p.getCenterPoint().x - basexline2, 2) +
                Math.pow(p.getCenterPoint().y - baseyline2, 2)
            );
            if (maxdiffline2 > diff1) {
              p.set({ left: p.line1.x2, top: p.line1.y2 });
              this.createDoorsAndWindowsEditable();
              p.setCoords();
              return;
            }
          } else {
            const diff1 = Math.sqrt(
              Math.pow(p.getCenterPoint().x - basexline2, 2) +
                Math.pow(p.getCenterPoint().y - baseyline2, 2)
            );
            if (maxdiffline2 > diff1) {
              p.set({ left: p.line1.x2, top: p.line1.y2 });
              p.setCoords();
              this.createDoorsAndWindowsEditable();
              return;
            }
          }
          let roomID = p.line1.roomID;
          let areaName = p.line1.areaName;
          let roomArea = p.line1.roomArea;
          let roomTextGroup =
            roomWiseLineAndTextObjects[roomID]["roomTextGroup"];

          p.line1 && p.line1.set({ x2: p.left, y2: p.top });
          p.line2 && p.line2.set({ x1: p.left, y1: p.top });

          /*
          CALCULATION: Calculating width of first wall connected with point wall
          */
          let width1 =
            Math.sqrt(
              p.line1.width * p.line1.width + p.line1.height * p.line1.height
            ) * PIXEL_TO_FOOT_CONSTANT;

          width1 /= this.ratio;

          let tempFoot = parseInt(width1);
          let tempPoints = width1 - tempFoot;
          let inch = (tempPoints * 100 * 12) / 100;
          inch = parseInt(inch);

          let unroundedSize = tempFoot + "." + inch;

          //Now based on id of wall find label and update position
          for (
            let roomTextGroupIndex = 0;
            roomTextGroupIndex < roomTextGroup.length;
            roomTextGroupIndex++
          ) {
            let label = roomTextGroup[roomTextGroupIndex];

            if (label.id == p.line1.id) {
              let left = (p.line1.x1 + p.line1.x2) / 2;
              let top = (p.line1.y1 + p.line1.y2) / 2;

              let textObject = this.canvas.getItemByAttr("id", roomID);
              let coordinateForLable = coordinateForlable(
                p.line1.x1,
                p.line1.x2,
                p.line1.y1,
                p.line1.y2,
                textObject.left,
                textObject.top
              );

              label = getLabelPosition(
                label,
                left,
                top,
                coordinateForLable.orientation
              );
              label.set("angle", coordinateForLable.orientation);

              //p.line1.unroundedsize = width1;
              p.line1.unroundedsize = unroundedSize;
              p.line1.size = "" + Math.ceil(parseFloat(unroundedSize));

              //let wallLabel = parseFloat(width1).toFixed(2) + " ft";
              let wallLabel =
                tempFoot + "' " + (inch != "" && inch > 0 ? inch + "''" : "");

              label.set("text", wallLabel);

              let degree_angle = 0;

              let angleDeg =
                (Math.atan2(p.line1.y2 - p.line1.y1, p.line1.x2 - p.line1.x1) *
                  180) /
                Math.PI;
              degree_angle = angleDeg;

              childIdsline1.forEach((element) => {
                const childObj = facesArray.filter(
                  (el) => el["@id"] == element
                );
                for (
                  let lineindex = 0;
                  lineindex < rooflines.length;
                  lineindex++
                ) {
                  if (
                    rooflines[lineindex]["@id"] == childObj[0].POLYGON["@path"]
                  ) {
                    for (
                      let roofPointsindex = 0;
                      roofPointsindex < roofPoints.length;
                      roofPointsindex++
                    ) {
                      if (
                        rooflines[lineindex]["@path"]
                          .split(",")
                          .includes(roofPoints[roofPointsindex]["@id"])
                      ) {
                        const childRoofPoints =
                          roofPoints[roofPointsindex]["@editedXY"].split(",");

                        if (
                          !(
                            p.line1.x1 == p.line2.x2 && p.line1.y1 == p.line2.y2
                          )
                        ) {
                          let angleDeg =
                            (Math.atan2(
                              p.line1.y2 - p.line1.y1,
                              p.line1.x2 - p.line1.x1
                            ) *
                              180) /
                            Math.PI;
                          degree_angle = angleDeg;
                        } else {
                          let angleDeg =
                            (Math.atan2(
                              p.line1.y2 - p.line1.y1,
                              p.line1.x2 - p.line1.x1
                            ) *
                              180) /
                            Math.PI;
                          degree_angle = angleDeg;
                        }
                        let radians =
                          fabric.util.degreesToRadians(degree_angle);
                        let x =
                          (parseFloat(childRoofPoints[0]) - this.minX) *
                          this.ratio;
                        let y =
                          parseFloat(childRoofPoints[1] - this.minY) *
                          this.ratio;
                        const diff = Math.sqrt(
                          Math.pow(x - basex, 2) + Math.pow(y - basey, 2)
                        );
                        const updatedX =
                          (basex + diff * Math.cos(radians)) / this.ratio +
                          this.minX;
                        const updatedY =
                          (basey + diff * Math.sin(radians)) / this.ratio +
                          this.minY;
                        roofPoints[roofPointsindex]["@editedXY"] =
                          updatedX + "," + updatedY;
                        roofPoints[roofPointsindex]["@autoSnappedXY"] =
                          updatedX + "," + updatedY;
                      }
                    }
                  }
                }
              });

              break;
            }
          }

          /*
          CALCULATION: Calculating width of second wall connected with point wall
          */

          let width2 =
            Math.sqrt(
              p.line2.width * p.line2.width + p.line2.height * p.line2.height
            ) * PIXEL_TO_FOOT_CONSTANT;

          width2 = width2 / this.ratio;

          tempFoot = parseInt(width2);
          tempPoints = width2 - tempFoot;
          inch = (tempPoints * 100 * 12) / 100;
          inch = parseInt(inch);
          unroundedSize = tempFoot + "." + inch;

          for (
            let roomTextGroupIndex = 0;
            roomTextGroupIndex < roomTextGroup.length;
            roomTextGroupIndex++
          ) {
            let label = roomTextGroup[roomTextGroupIndex];

            if (label.id == p.line2.id) {
              let left = (p.line2.x1 + p.line2.x2) / 2;
              let top = (p.line2.y1 + p.line2.y2) / 2;
              let textObject = this.canvas.getItemByAttr("id", roomID);
              let coordinateForLable = coordinateForlable(
                p.line2.x1,
                p.line2.x2,
                p.line2.y1,
                p.line2.y2,
                textObject.left,
                textObject.top
              );

              label = getLabelPosition(
                label,
                left,
                top,
                coordinateForLable.orientation
              );
              label.set("angle", coordinateForLable.orientation);

              // p.line2.unroundedsize = width2;
              p.line2.unroundedsize = unroundedSize;
              p.line2.size = "" + Math.ceil(parseFloat(unroundedSize));

              //let wallLabel = parseFloat(width2).toFixed(2) + " ft";

              let wallLabel =
                tempFoot + "' " + (inch != "" && inch > 0 ? inch + "''" : "");
              label.set("text", wallLabel);

              let degree_angle = 0;
              let angleDeg =
                (Math.atan2(p.line2.y2 - p.line2.y1, p.line2.x2 - p.line2.x1) *
                  180) /
                Math.PI;
              degree_angle = angleDeg;

              childIdsline2.forEach((element) => {
                const childObj = facesArray.filter(
                  (el) => el["@id"] == element
                );
                for (
                  let lineindex = 0;
                  lineindex < rooflines.length;
                  lineindex++
                ) {
                  if (
                    rooflines[lineindex]["@id"] == childObj[0].POLYGON["@path"]
                  ) {
                    for (
                      let roofPointsindex = 0;
                      roofPointsindex < roofPoints.length;
                      roofPointsindex++
                    ) {
                      if (
                        rooflines[lineindex]["@path"]
                          .split(",")
                          .includes(roofPoints[roofPointsindex]["@id"])
                      ) {
                        const childRoofPoints =
                          roofPoints[roofPointsindex]["@editedXY"].split(",");

                        if (
                          !(
                            p.line1.x1 == p.line2.x2 && p.line1.y1 == p.line2.y2
                          )
                        ) {
                          let angleDeg =
                            (Math.atan2(
                              p.line2.y2 - p.line2.y1,
                              p.line2.x2 - p.line2.x1
                            ) *
                              180) /
                            Math.PI;
                          degree_angle = angleDeg;
                        } else {
                          let angleDeg =
                            (Math.atan2(
                              p.line1.y2 - p.line1.y1,
                              p.line1.x2 - p.line1.x1
                            ) *
                              180) /
                            Math.PI;
                          degree_angle = angleDeg;
                        }
                        let radians =
                          fabric.util.degreesToRadians(degree_angle);
                        let x =
                          (parseFloat(childRoofPoints[0]) - this.minX) *
                          this.ratio;
                        let y =
                          parseFloat(childRoofPoints[1] - this.minY) *
                          this.ratio;
                        const diff = Math.sqrt(
                          Math.pow(x - basexline2, 2) +
                            Math.pow(y - baseyline2, 2)
                        );
                        const updatedX =
                          (basexline2 - diff * Math.cos(radians)) / this.ratio +
                          this.minX;
                        const updatedY =
                          (baseyline2 - diff * Math.sin(radians)) / this.ratio +
                          this.minY;
                        roofPoints[roofPointsindex]["@editedXY"] =
                          updatedX + "," + updatedY;
                        roofPoints[roofPointsindex]["@autoSnappedXY"] =
                          updatedX + "," + updatedY;
                      }
                    }
                  }
                }
              });

              break;
            }
          }
          p.line1.linePointObjectArray[0]["@autoSnappedXY"] =
            p.line1.x1 / this.ratio +
            this.minX +
            "," +
            (p.line1.y1 / this.ratio + this.minY);
          p.line1.linePointObjectArray[1]["@autoSnappedXY"] =
            p.line1.x2 / this.ratio +
            this.minX +
            "," +
            (p.line1.y2 / this.ratio + this.minY);
          p.line2.linePointObjectArray[0]["@autoSnappedXY"] =
            p.line2.x1 / this.ratio +
            this.minX +
            "," +
            (p.line2.y1 / this.ratio + this.minY);
          p.line2.linePointObjectArray[1]["@autoSnappedXY"] =
            p.line2.x2 / this.ratio +
            this.minX +
            "," +
            (p.line2.y2 / this.ratio + this.minY);
          //Now based on Rooms, calculate the center point of label

          // designatorWiseObjectArray
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
            roofPoints;
          originalFloorPlan = _.cloneDeep(copyOriginal);

          roomArray = Object.keys(designatorWiseObjectArray);
          roomLinesGroup = roomWiseLineAndTextObjects[roomID]["roomLinesGroup"];
          roomTextGroup = roomWiseLineAndTextObjects[roomID]["roomTextGroup"];
          roomArea = roomWiseLineAndTextObjects[roomID]["roomArea"];

          let roomCenterPointX = 0;
          let roomCenterPointY = 0;

          for (
            let roomLinesGroupIndex = 0;
            roomLinesGroupIndex < roomLinesGroup.length;
            roomLinesGroupIndex++
          ) {
            roomCenterPointX +=
              (roomLinesGroup[roomLinesGroupIndex].x1 +
                roomLinesGroup[roomLinesGroupIndex].x2) /
              2;
            roomCenterPointY +=
              (roomLinesGroup[roomLinesGroupIndex].y1 +
                roomLinesGroup[roomLinesGroupIndex].y2) /
              2;
          }

          let totalPoints = roomLinesGroup.length;
          let areaLabelLeft = roomCenterPointX / totalPoints;
          let areaLabelTop = roomCenterPointY / totalPoints;

          /*
          CALCULATION: Calculating area based on Wall of Room
          */

          let object = null;
          let objects = this.canvas.getObjects();
          let cordinateArray = [];
          let polygonpointsOnMove = [];

          for (let i = 0, len = this.canvas.size(); i < len; i++) {
            object = objects[i];

            if (object.type == "WALL-LINE") {
              if (object.roomID == roomID) {
                cordinateArray.push(object.x1);
                cordinateArray.push(object.y1);

                cordinateArray.push(object.x2);
                cordinateArray.push(object.y2);

                polygonpointsOnMove.push({
                  x: object.x1,
                  y: object.y1,
                });

                polygonpointsOnMove.push({
                  x: object.x2,
                  y: object.y2,
                });
              }
            }
          }

          polygonpointsOnMove = _.uniqWith(polygonpointsOnMove, _.isEqual);

          const tempPoly = new fabric.Polygon(polygonpointsOnMove, {
            strokeWidth: lineStokeWidth,
            stroke: "black",
            cornerColor: "black",
            visible: false,
          });

          let polygonCenter = tempPoly.getCenterPoint();

          let areaSum = 0;
          // Process pairs, increment by 2 and stop at length - 2
          for (
            var i = 0, cordinateArrayIndex = cordinateArray.length - 2;
            i < cordinateArrayIndex;
            i += 2
          ) {
            areaSum +=
              cordinateArray[i] * cordinateArray[i + 3] -
              cordinateArray[i + 2] * cordinateArray[i + 1];
          }
          // CALCULATION OF AREA

          let calculatedArea =
            (Math.abs(areaSum / 2) *
              PIXEL_TO_FOOT_CONSTANT *
              PIXEL_TO_FOOT_CONSTANT) /
            (this.ratio * this.ratio);
          let tempCalculatedAreaInFoot = parseInt(calculatedArea);
          let tempCalculatedAreaPoints =
            calculatedArea - tempCalculatedAreaInFoot;
          let calculatedAreaInch = (tempCalculatedAreaPoints * 12) / 100;
          calculatedAreaInch = parseInt(calculatedAreaInch * 100);

          let calculatedAreaInchPoints =
            tempCalculatedAreaInFoot + "." + calculatedAreaInch;

          /*
          calculatedArea =
            tempCalculatedAreaInFoot + "' " + calculatedAreaInch + "''";
            */
          calculatedArea = calculatedArea.toFixed(2);

          //Ends

          let centreTextObject = null;
          if (this.canvas.getItemByAttr("id", roomID) != null) {
            //this.canvas.getItemByAttr('id', "room1").remove();
            centreTextObject = this.canvas.getItemByAttr("id", roomID);
            centreTextObject.set(
              "left",
              areaLabelLeft - centreTextObject.getBoundingRect().width / 2
            );

            centreTextObject.set(
              "top",
              areaLabelTop - centreTextObject.getBoundingRect().height / 2
            );
            let calculatedAreaText = calculatedArea + " ";
            //For Alpha release hiding the Area name at time of edit.
            // let centerBoxText = calculatedAreaText + "\n" + areaName;
            let centerBoxText = calculatedAreaText;

            centreTextObject.set("text", centerBoxText);
            centreTextObject.set("area", calculatedArea);
          }

          centreTextObject.set(
            "left",
            polygonCenter.x - centreTextObject.getBoundingRect().width / 2
          );
          centreTextObject.set(
            "top",
            polygonCenter.y - centreTextObject.getBoundingRect().height / 2
          );

          this.canvas.renderAll();
          isLineEdited = true;
          this.createDoorsAndWindowsEditable();
        }
      }.bind(this)
    );

    /*
    this.canvas.on(
      "mouse:wheel",
      function (opt) {
        var delta = opt.e.deltaY;
        var zoom = this.canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        this.canvas.setZoom(zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }.bind(this)
    );
    */

    this.canvas.on(
      "object:rotated",
      function (options) {
        let object = options.target;
        let angle = object.angle;
        rotatedAngle = angle;
        let roomID = options.target.roomID;

        if (
          object.type !== "textLabel" &&
          object.type !== "LINE" &&
          object.type !== "stair-case" &&
          object.type !== "CENTRE-BOX-TEXT"
        ) {
          this.updateFloorPlanOnMove(roomID, linesArray);
        } else if (object.type === "stair-case") {
          if (this.restrictObject(options)) {
            options.e.preventDefault();
          } else {
            this.manageStairCasePosition(options);
          }
        } else if (object.type === "CENTRE-BOX-TEXT") {
          let copyOriginal = _.cloneDeep(originalFloorPlan);
          let facesArray =
            copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
          for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
            if (facesArray[faceIndex]["@id"] != options.target.id) {
              continue;
            }
            facesArray[faceIndex]["@labelAngle"] = rotatedAngle;
            facesArray[faceIndex]["@areaLabelLeft"] =
              options.target.left / this.ratio + this.minX;
            facesArray[faceIndex]["@areaLabelTop"] =
              options.target.top / this.ratio + this.minY;
          }
          copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
          originalFloorPlan = copyOriginal;
          isDoorEdited = true;
        } else {
          if (this.restrictObject(options)) {
            options.e.preventDefault();
          } else {
            this.manageLabelPosition(options);
          }
        }
        options.target.initialTop = options.target.top;
        options.target.initialLeft = options.target.Left;
        rotatedAngle = 0;
        this.canvas.clear();
        this.drawFloorPlan();
        // options.target.angle = 0;
      }.bind(this)
    );
    this.canvas.on({
      "object:scaling": this.onObjectChange,
      "object:rotating": this.onObjectChange,
    });

    this.canvas.on(
      "object:scaled",
      function (options) {
        if (this.restrictObject(options)) {
          options.e.preventDefault();
        } else {
          this.manageStairCasePosition(options);
          options.target.initialTop = options.target.top;
          options.target.initialLeft = options.target.Left;
        }
        this.canvas.clear();
        this.drawFloorPlan();
      }.bind(this)
    );
  }

  manageLabelPosition = (options) => {
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let roofPointsArray =
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let labelid = options.target.id;
    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
      if (
        roomFaceObject["@type"] == "LABEL" &&
        roomFaceObject["@id"] == labelid
      ) {
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];
        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);
        let processedPionts = [];
        for (
          let wallFaceObjectIndex = 0;
          wallFaceObjectIndex < faceArray.length;
          wallFaceObjectIndex++
        ) {
          let faceObject = faceArray[wallFaceObjectIndex];

          if (
            faceObject["POLYGON"]["@path"].trim().length > 0 &&
            labelid == faceObject["@id"]
          ) {
            faceObject["@height"] = options.target.getBoundingRect().height;
            faceObject["@width"] = options.target.getBoundingRect().width;
            if (rotatedAngle > 0) {
              faceObject["@angle"] = rotatedAngle;
            }
            let lineId = faceObject["POLYGON"]["@path"];
            for (
              let lineArrayIndex = 0;
              lineArrayIndex < linesArray.length;
              lineArrayIndex++
            ) {
              let lineObject = linesArray[lineArrayIndex];
              if (lineObject["@id"] == lineId) {
                let linePointObjectArray = [];
                let linePoints = lineObject["@path"].split(",");
                for (
                  let linePointsIndex = 0;
                  linePointsIndex < linePoints.length;
                  linePointsIndex++
                ) {
                  for (
                    let roofPointsArrayIndex = 0;
                    roofPointsArrayIndex < roofPointsArray.length;
                    roofPointsArrayIndex++
                  ) {
                    let roofPointObject = roofPointsArray[roofPointsArrayIndex];

                    if (roofPointObject["@id"] == linePoints[linePointsIndex]) {
                      if (
                        processedPionts.includes(linePoints[linePointsIndex])
                      ) {
                        roofPointObject["@editedXY"] =
                          roofPointObject["@editedXY"];
                      } else {
                        const editModeDataXYKeyCLone = ["@editedXY"];
                        editModeDataXYKeyCLone.forEach((element) => {
                          let dataXY = roofPointObject[element].split(",");
                          let updatedX =
                            (parseFloat(dataXY[0]) - this.minX) * this.ratio;
                          let updatedY =
                            (parseFloat(dataXY[1]) - this.minY) * this.ratio;
                          updatedX =
                            options.target.left / this.ratio + this.minX;
                          updatedY =
                            options.target.top / this.ratio + this.minY;
                          dataXY = updatedX + "," + updatedY;
                          roofPointObject[element] = dataXY;
                        });
                        processedPionts.push(linePoints[linePointsIndex]);
                      }
                      linePointObjectArray.push(roofPointObject);
                    }
                  }
                }
                lineObject["linePointObjectArray"] = linePointObjectArray;
                linesArray[lineArrayIndex] = lineObject;
              }
            }
            faceArray[wallFaceObjectIndex] = faceObject;
            if (faceObject["@type"] != "LABEL") {
              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            }
          } else {
            //TBD:Not in use.
          }
        }
      }
    }
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = faceArray;
    originalFloorPlan = _.cloneDeep(copyOriginal);
    rotatedAngle = editedRoomAngle = 0;
    if (
      !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
        originalFloorPlan,
        designatorWiseObjectArray,
        floorId: this.state.selectedFloor,
      })
    ) {
      EditModeChanges.push({
        originalFloorPlan: _.cloneDeep(originalFloorPlan),
        designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
        floorId: this.state.selectedFloor,
      });
      this.setState({
        undocount: EditModeChanges.length,
      });
    }
  };

  manageStairCasePosition = (options) => {
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let roofPointsArray =
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let stairCaseId = options.target.id;
    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
      if (
        roomFaceObject["@type"] == "STAIR_CASE" &&
        roomFaceObject["@id"] == stairCaseId
      ) {
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];
        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);
        let processedPionts = [];
        for (
          let wallFaceObjectIndex = 0;
          wallFaceObjectIndex < faceArray.length;
          wallFaceObjectIndex++
        ) {
          let faceObject = faceArray[wallFaceObjectIndex];

          if (
            faceObject["POLYGON"]["@path"].trim().length > 0 &&
            stairCaseId == faceObject["@id"]
          ) {
            faceObject["@height"] = options.target.getBoundingRect().height;
            faceObject["@width"] = options.target.getBoundingRect().width;
            if (rotatedAngle > 0) {
              faceObject["@angle"] = rotatedAngle;
            }
            let lineId = faceObject["POLYGON"]["@path"];
            for (
              let lineArrayIndex = 0;
              lineArrayIndex < linesArray.length;
              lineArrayIndex++
            ) {
              let lineObject = linesArray[lineArrayIndex];
              if (lineObject["@id"] == lineId) {
                let linePointObjectArray = [];
                let linePoints = lineObject["@path"].split(",");
                for (
                  let linePointsIndex = 0;
                  linePointsIndex < linePoints.length;
                  linePointsIndex++
                ) {
                  for (
                    let roofPointsArrayIndex = 0;
                    roofPointsArrayIndex < roofPointsArray.length;
                    roofPointsArrayIndex++
                  ) {
                    let roofPointObject = roofPointsArray[roofPointsArrayIndex];

                    if (roofPointObject["@id"] == linePoints[linePointsIndex]) {
                      roofPointObject["@scaleX"] =
                        options.target.scaleX / this.ratio;
                      roofPointObject["@scaleY"] =
                        options.target.scaleY / this.ratio;
                      if (
                        processedPionts.includes(linePoints[linePointsIndex])
                      ) {
                        roofPointObject["@editedXY"] =
                          roofPointObject["@editedXY"];
                      } else {
                        const editModeDataXYKeyCLone = ["@editedXY"];
                        editModeDataXYKeyCLone.forEach((element) => {
                          let dataXY = roofPointObject[element].split(",");
                          let updatedX =
                            (parseFloat(dataXY[0]) - this.minX) * this.ratio;
                          let updatedY =
                            (parseFloat(dataXY[1]) - this.minY) * this.ratio;
                          updatedX =
                            options.target.left / this.ratio + this.minX;
                          updatedY =
                            options.target.top / this.ratio + this.minY;
                          dataXY = updatedX + "," + updatedY;
                          roofPointObject[element] = dataXY;
                        });
                        processedPionts.push(linePoints[linePointsIndex]);
                      }
                      linePointObjectArray.push(roofPointObject);
                    }
                  }
                }
                lineObject["linePointObjectArray"] = linePointObjectArray;
                linesArray[lineArrayIndex] = lineObject;
              }
            }
            faceArray[wallFaceObjectIndex] = faceObject;
            if (faceObject["@type"] != "STAIR_CASE") {
              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            }
          } else {
            //TBD:Not in use.
          }
        }
      }
    }
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = faceArray;
    originalFloorPlan = _.cloneDeep(copyOriginal);
    rotatedAngle = editedRoomAngle = 0;
    if (
      !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
        originalFloorPlan,
        designatorWiseObjectArray,
        floorId: this.state.selectedFloor,
      })
    ) {
      EditModeChanges.push({
        originalFloorPlan: _.cloneDeep(originalFloorPlan),
        designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
        floorId: this.state.selectedFloor,
      });
      this.setState({
        undocount: EditModeChanges.length,
      });
    }
  };

  rotateStairCaseOnRotateRoom = (roomID) => {
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let stairCaseId = faceArray
      .filter((el) => el["@type"] === "ROOM" && el["@id"] === roomID)?.[0]
      ["@childrenStairCase"]?.split(",");
    if (!_.isEmpty(stairCaseId)) {
      for (
        let faceArrayIndex = 0;
        faceArrayIndex < faceArray.length;
        faceArrayIndex++
      ) {
        let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
        if (
          roomFaceObject["@type"] == "STAIR_CASE" &&
          stairCaseId.includes(roomFaceObject["@id"])
        ) {
          designatorWiseObjectArray[roomFaceObject["@id"]] = [];
          designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);
          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];

            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              stairCaseId.includes(roomFaceObject["@id"])
            ) {
              if (rotatedAngle > 0) {
                faceObject["@angle"] = !_.isNil(faceObject["@angle"])
                  ? parseFloat(faceObject["@angle"]) + rotatedAngle
                  : rotatedAngle;
              }
              faceArray[wallFaceObjectIndex] = faceObject;
              if (faceObject["@type"] != "STAIR_CASE") {
                designatorWiseObjectArray[roomFaceObject["@id"]].push(
                  faceObject
                );
              }
            }
          }
        }
      }
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = faceArray;
      originalFloorPlan = _.cloneDeep(copyOriginal);
    }
  };

  /**
   * Purpose : This function will call whenever object will move or scale
   * @param {Event} e it'll be an object of event contain scalling information
   */
  handleOnchange = async (e) => {
    const { name, value } = e.target;
    const floorName = this.state.floorList.filter((el) => el.floorId == value);
    if (value == "4") {
      this.setState({ isShowAreaName: false });
    }
    this.setState(
      {
        selectedFloor: value,
        selectedFloorName: floorName[0].floorName,
        isAddLabel: false,
        isAddLineFromBuildMenu: false,
        isAddPolylineFromBuildMenu: false,
        isAddDoorFromBuildMenu: false,
        isAddWindowFromBuildMenu: false,
      },
      () => {
        originalFloorPlan = _.cloneDeep(
          EditModeChanges[EditModeChanges.length - 1].originalFloorPlan
        );
        designatorWiseObjectArray = _.cloneDeep(
          EditModeChanges[EditModeChanges.length - 1].designatorWiseObjectArray
        );
        this.canvas.clear();
        this.drawFloorPlan();
        this.setState({
          undocount: EditModeChanges.length,
        });
        isEditMode = false;
        isLineEdited = false;
        isDoorEdited = false;
        isWindowEdited = false;
        this.setState({ isEditMode: false, doundo: false });
      }
    );
  };

  handleOnchangeForRemoteValVideo = async (e) => {
    store.dispatch(StartCenterLoading());
    const { value } = e.target;
    this.props.setSelectedFloorScanName(value);
    let selectedFloorListID =
      e?.target?.options?.[e.target.selectedIndex]?.attributes
        ?.selectedfloorindex?.value;
    let floorScanId = e?.target?.options?.[e.target.selectedIndex]?.id;
    this.props.setSelectedFloorScanId(floorScanId);
    this.props
      .loadMeasurementJson({
        jobOrderId: this.props.jobOrderId,
        type: measurementTypes[3].name,
        format: measurementResponseFormat.original,
        floorScanId: floorScanId,
        floorTagName: value,
      })
      .then((data) => {
        store.dispatch(StopCenterLoading());
        setTimeout(() => {
          this.setState({
            selectedFloor: selectedFloorListID,
            selectedCustomFloorName: value,
          });
        }, 100);
      })
      .catch((err) => {
        store.dispatch(StopCenterLoading());
      });
  };

  /**
   * Purpose : This function will call whenever Room Type changed for selected Room
   * @param {Event} e it'll be an object of event
   */
  handleOnchangeRoomType = async (e) => {
    const { name, value } = e.target;
    this.props.setSelectedFloorScanName(value);
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;

    for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
      if (facesArray[faceIndex]["@id"] != this.state.selectedRoom) {
        continue;
      }
      facesArray[faceIndex]["@measuretype"] = value;
    }
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
    originalFloorPlan = _.cloneDeep(copyOriginal);
    this.editArea();
    this.canvas.clear();
    this.drawFloorPlan();
    this.setState({ selectedRoomType: "", enableDelete: false });
    this.setState({
      enableLabelDelete: false,
      enableLineDelete: false,
      enableDoorDelete: false,
      enablePartitionDoorDelete: false,
      enablePartitionWindowDelete: false,
      enableStairCaseDelete: false,
    });
  };

  /**
   * Purpose : This function will used to create and draw floor plan
   */
  drawFloorPlan = debounce(() => {
    const { isShowAreaName } = this.state;
    setTimeout(() => {
      this.toggleCanvasGrid();
    }, 10);

    roomArray = Object.keys(designatorWiseObjectArray);

    let currentZoomLevel = this.canvas.getZoom();
    let calculatedFontSize = this.state.baseFontSize * currentZoomLevel;
    let roomWiseLineAndTextObjectsRef = getRoomData(
      designatorWiseObjectArray,
      this.state.selectedFloor,
      this.minX,
      this.minY,
      this.ratio
    );
    let selectedFloorRooms = [];
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      if (roomObjectArray[0]["@floorindex"] == this.state.selectedFloor) {
        selectedFloorRooms.push(roomArray[roomArrayIndex]);
      }
    }

    //Now start drawing

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < selectedFloorRooms.length;
      roomArrayIndex++
    ) {
      let areaName = "";
      let roomArea = "";
      let roomID = "";
      let additionalType = "";
      let isExterior = null;
      let measureType = "";
      let roomFontSize = 0;
      let roomAreaLabelLeft = 0;
      let roomAreaLabelTop = 0;
      let roomLabelAngle = 0;

      let roomObjectArray =
        designatorWiseObjectArray[selectedFloorRooms[roomArrayIndex]];

      //if(roomLinesGroup[""])

      roomLinesGroup = [];
      roomTextGroup = [];
      roomConnectorGroup = [];

      let connectorCircleGroup = [];
      let polygonpoints = [];
      let wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        if (
          !["LINE", "PARTITION_DOOR", "PARTITION_WINDOW"].includes(
            wallObject["@type"]
          )
        ) {
          let wallID = wallObject["@id"];

          if (wallObject.LINE == null) {
            additionalType = wallObject["@additionalType"];
            isExterior =
              wallObject["@floor"] === AREA_TYPES[0]
                ? true
                : !this.props.isTechnician?.create &&
                  this.props.selectedFloorScanName?.split("_")?.[1]?.trim() ===
                    AREA_TYPES[0]
                ? true
                : false;
            areaName = wallObject["@areaname"];
            roomArea = wallObject["@editedArea"];
            roomID = wallObject["@id"];
            measureType = wallObject["@measuretype"];

            roomAreaLabelLeft = wallObject["@areaLabelLeft"]
              ? (parseFloat(wallObject["@areaLabelLeft"]) - this.minX) *
                this.ratio
              : 0;
            roomAreaLabelTop = wallObject["@areaLabelTop"]
              ? (parseFloat(wallObject["@areaLabelTop"]) - this.minY) *
                this.ratio
              : 0;
            roomLabelAngle = wallObject["@labelAngle"];

            roomFontSize = roomWiseFontSize[roomID];

            roomWiseLineAndTextObjects[roomID] = {};
            roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
            roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
            roomWiseLineAndTextObjects[roomID]["roomCircleGroup"] = [];
            roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = {};
            roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

            continue;
          }

          let isWallPenetration =
            wallObject["@type"] == "WALLPENETRATION" ? true : false;
          if (isWallPenetration == false) {
            //TBD
          } else {
            continue;
          }

          let linePointObjectArray = wallObject.LINE.linePointObjectArray;
          let poligonObject = wallObject.POLYGON;

          let points = [];

          for (
            let linePointObjectArrayInedex = 0;
            linePointObjectArrayInedex < linePointObjectArray.length;
            linePointObjectArrayInedex++
          ) {
            let value1 =
              linePointObjectArray[linePointObjectArrayInedex][
                "@autoSnappedXY"
              ];

            if (value1 == null) {
              break;
            }
            let id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
            let v1 = value1.split(",");
            let fval = { id: id, x: v1[0], y: v1[1], z: 0 };
            points.push(fval);
          }
          //Add line
          if (points.length < 2) {
            break;
          }

          let line = null;

          //var color = wallNo % 2 == 0 ? "#fe741f" : "black";
          var color = "black";
          polygonpoints.push({
            x: (points[0].x - this.minX) * this.ratio,
            y: (points[0].y - this.minY) * this.ratio,
          });
          polygonpoints.push({
            x: (points[1].x - this.minX) * this.ratio,
            y: (points[1].y - this.minY) * this.ratio,
          });

          line = new fabric.Line(
            [
              (points[0].x - this.minX) * this.ratio,
              (points[0].y - this.minY) * this.ratio,
              (points[1].x - this.minX) * this.ratio,
              (points[1].y - this.minY) * this.ratio,
            ],
            {
              stroke: color,
              strokeWidth: lineStokeWidth,
              selectable: false,
              evented: false,
              id: wallID,
              roomID: roomID,
              type: "WALL-LINE",
              linePointObjectArray: linePointObjectArray,
              unroundedsize: wallObject["POLYGON"]["@editedUnroundedsize"],
              size: wallObject["POLYGON"]["@editedSize"],
              areaName: areaName,
              roomArea: roomArrayIndex,
            }
          );

          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
          roomLinesGroup.push(line);

          if (isWallPenetration == false) {
            wallNo++;
          }
        }
      }

      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        var color = "black";

        // Connectors
        let circle = null;
        if (roomLinesGroupArrayIndex == 0) {
          circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color
          );

          // this.canvas.add(circle);
        } else {
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );
          } else {
            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );
          }
        }
        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }

      let totalPoints = roomLinesGroup.length;

      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      let centreTextObject = null;
      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        centreTextObject = this.canvas.getItemByAttr("id", roomID);
        centreTextObject.set(
          "left",
          areaLabelLeft - centreTextObject.getBoundingRect().width / 2
        );

        centreTextObject.set(
          "top",
          areaLabelTop - centreTextObject.getBoundingRect().height / 2
        );

        // this.canvas.renderAll();
      } else {
        //Add label
        let displayRoomArea = "";
        if (roomArea.trim().length == 0) {
          roomArea = ".";
        } else {
          displayRoomArea = roomArea;
        }

        let roomAreaSpilts = roomArea.split(".");
        let tempCalculatedAreaInFoot =
          roomAreaSpilts && roomAreaSpilts.length > 0 ? roomAreaSpilts[0] : "";
        let tempCalculatedAreaPoints =
          roomAreaSpilts && roomAreaSpilts.length > 1 ? roomAreaSpilts[1] : "";
        // let calculatedAreaInch = (tempCalculatedAreaPoints * 12) / 100;
        // calculatedAreaInch = parseInt(calculatedAreaInch * 100);
        let calculatedArea =
          tempCalculatedAreaInFoot != ""
            ? tempCalculatedAreaInFoot + "' " + tempCalculatedAreaPoints + "''"
            : "";

        let AreaNameLabel = isShowAreaName ? "\n" + areaName : "";
        // let centerBoxText = calculatedArea + AreaNameLabel;
        let centerBoxText =
          (displayRoomArea.length > 0 && !isNaN(displayRoomArea)
            ? parseFloat(displayRoomArea).toFixed(1)
            : displayRoomArea) + AreaNameLabel;
        centreTextObject = new fabric.Text(centerBoxText, {
          fontFamily: '"Roboto", sans-serif',
          //fontSize: this.state.baseFontSize,
          area: roomArea,
          fontSize: roomFontSize + 1,
          selectable: true,
          evented: true,
          hasControls: true,
          lockScalingX: true,
          lockScalingY: true,
          left: roomAreaLabelLeft || areaLabelLeft,
          top: roomAreaLabelTop || areaLabelTop,
          angle: roomLabelAngle || 0,
          fill: "#555555",
          id: roomID,
          objectCaching: false,
          textAlign: "center",
          textAlign: "center",
          type: "CENTRE-BOX-TEXT",
          // backgroundColor:"red",
        });
        if (!roomAreaLabelLeft) {
          centreTextObject.set(
            "left",
            areaLabelLeft - centreTextObject.getBoundingRect().width / 2
          );

          centreTextObject.set(
            "top",
            areaLabelTop - centreTextObject.getBoundingRect().height / 2
          );
        }
        // this.canvas.add(text);
        //roomTextGroup.push(centreTextObject);
        // roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(
        //   centreTextObject
        // );
      }

      polygonpoints = _.uniqWith(polygonpoints, _.isEqual);

      const poly = new fabric.Polygon(polygonpoints, {
        fill: "transparent",
        strokeWidth: lineStokeWidth,
        stroke: !this.state.isEditModeEnabled
          ? additionalType != "1"
            ? measureType == "GLA"
              ? GLA_BORDER_COLOR
              : NON_GLA_BORDER_COLOR
            : NON_ADDITIONAL_BORDER_COLOR
          : "black",
        cornerColor: "black",
        roomID: roomID,
        ID: "POLY-" + roomID,
      });

      // var roomDrawingObjectArray = roomLinesGroup.concat(roomTextGroup);
      roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = poly;

      // Draw Line Label on Group
      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        let indexedLine = roomLinesGroup[roomLinesGroupArrayIndex];
        let wallID = indexedLine.get("id");
        let sizes = indexedLine.get("unroundedsize").split(".");
        let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";
        let tempPoints = sizes && sizes.length > 1 ? sizes[1] : "";
        let unRoundedSizeFeetLabel = tempFoot + "' " + tempPoints + "''";

        let polygonpointsclone =
          roomWiseLineAndTextObjects[indexedLine.roomID]["roomPolyGroup"];
        let midPointX = (indexedLine.x1 + indexedLine.x2) / 2; //mid-point of line
        let midPointY = (indexedLine.y1 + indexedLine.y2) / 2;
        let coordinateForLable = coordinateForlable(
          indexedLine.x1,
          indexedLine.x2,
          indexedLine.y1,
          indexedLine.y2,
          midPointX,
          midPointY
        );

        let text = new fabric.Text(unRoundedSizeFeetLabel, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: roomFontSize,
          left: midPointX,
          top: midPointY,
          angle: coordinateForLable.orientation,
          fill: color,
          id: "l" + wallID,
          wallID: wallID,
          roomID: roomID,
          objectCaching: false,
          type: "LABEL",
          selectable: false,
          textAlign: "center",
          visible: true,
        });

        text = getLabelPositionOuter(
          text,
          midPointX,
          midPointY,
          coordinateForLable.orientation,
          polygonpointsclone,
          roomWiseLineAndTextObjectsRef,
          indexedLine
        );
        if (text && !this.state.isEditModeEnabled) {
          if (parseFloat(indexedLine.get("unroundedsize")) > 2.5) {
            const locations = getLocation(
              text,
              indexedLine,
              midPointX,
              midPointY
            );
            const lineZ = new fabric.Line(
              [locations.x1, locations.y1, locations.x2, locations.y2],
              {
                strokeWidth: 1,
                fill: "black",
                stroke: "black",
                originX: "center",
                originY: "center",
              }
            );
            text = createTextGroup(
              lineZ,
              unRoundedSizeFeetLabel,
              text.angle,
              coordinateForLable.orientation,
              roomFontSize - 2
            );
            roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
            roomTextGroup.push(text);
          }
        } else if (text) {
          if (parseFloat(indexedLine.get("unroundedsize")) > 2.5) {
            roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
            //for alha release we are hiding the wall label.
            roomTextGroup.push(text);
          }
        }
      }

      let roomDrawingObjectArray = [poly].concat(roomTextGroup);

      let group = new fabric.Group(roomDrawingObjectArray, {
        id: "GROUP-" + roomID,
        roomID: roomID,
        lockScalingX: true,
        lockScalingY: true,
        objectCaching: false,
        selectable: true,
        type: "GROUP",
        subTargetCheck: true,
        backgroundColor: "red",
        fill: "blue",
      });

      group.setControlsVisibility({
        mt: false,
        mb: false,
        ml: false,
        mr: false,
      });

      this.canvas.add(group);
      this.canvas.add(centreTextObject);
      group.initialLeft = group.left;
      group.initialTop = group.top;
    }
    this.createDoorsAndWindows();
    this.createLableForExterior();
    this.createLinesForExterior();
    createPartitionDoor(this, originalFloorPlan);
    createPartitionWindow(this, originalFloorPlan);
    this.createStaircase();
    this.canvas.renderAll();
  }, 50);

  /**
   * Purpose : This function will display exterior lines on floor plan
   */
  createLinesForExterior = () => {
    let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    let roofPoints = [
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS,
    ];
    let roofPointsArray = roofPoints[0]["POINT"];
    let linesObject = [
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES,
    ];
    let linesArray = linesObject[0].LINE;
    let faceArray = roofObject[0]["FACES"]["FACE"];
    let lines = faceArray.filter((el) => el["@type"] == "LINE");
    for (let i = 0; i < lines.length; i++) {
      const parentroom = faceArray.filter(
        (el) =>
          el["@childrenLine"] &&
          el["@childrenLine"].split(",").includes(lines[i]["@id"])
      );
      if (
        parentroom[0] &&
        parentroom[0]["@floorindex"] == this.state.selectedFloor
      ) {
        let linePath = linesArray.filter(
          (el) => el["@id"] == lines[i].POLYGON["@path"]
        );
        let pointpath = linePath[0]["@path"].split(",");
        if (pointpath.length === 2) {
          let point1 = roofPointsArray.filter(
            (el) => el["@id"] == pointpath[0]
          )[0];
          point1 = point1["@editedXY"].split(",");

          let point2 = roofPointsArray.filter(
            (el) => el["@id"] == pointpath[1]
          )[0];
          point2 = point2["@editedXY"].split(",");

          const fabricLine = new fabric.Line(
            [
              (parseFloat(point1[0]) - this.minX) * this.ratio,
              (parseFloat(point1[1]) - this.minY) * this.ratio,
              (parseFloat(point2[0]) - this.minX) * this.ratio,
              (parseFloat(point2[1]) - this.minY) * this.ratio,
            ],
            {
              id: lines[i]["@id"],
              roomID: parentroom[0]["@id"],
              objectCaching: false,
              type: "LINE",
              stroke: !this.state.isEditModeEnabled ? PARTITION_COLOR : "black",
              originX: "center",
              originY: "center",
              strokeUniform: true,
              strokeWidth: partitionLineStokeWidth,
              padding: 4,
              parentRoomCordinates: null,
              partitionWallCordinates: [],
              lockScalingX: true,
              lockScalingY: true,
              lockRotation: false,
              hasControls: false,
              lockMovementX: false,
              lockMovementY: false,
            }
          );
          fabricLine.setCoords();
          this.canvas.add(fabricLine);
        }
      }
    }
  };

  /**
   * Purpose : This function will display exterior labels on floor plan
   */
  createLableForExterior = () => {
    let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    let roofPoints = [
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS,
    ];
    let roofPointsArray = roofPoints[0]["POINT"];
    let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    let linesArray = lines[0].LINE;
    let faceArray = roofObject[0]["FACES"]["FACE"];
    let labels = faceArray.filter((el) => el["@type"] == "LABEL");
    for (let labelindex = 0; labelindex < labels.length; labelindex++) {
      const parentroom = faceArray.filter(
        (el) =>
          el["@childrenLabel"] &&
          el["@childrenLabel"].split(",").includes(labels[labelindex]["@id"])
      );
      if (
        parentroom[0] &&
        parentroom[0]["@floorindex"] == this.state.selectedFloor
      ) {
        let doorline = linesArray.filter(
          (el) => el["@id"] == labels[labelindex].POLYGON["@path"]
        );
        let pointpath = doorline[0]["@path"].split(",");
        let point = roofPointsArray.filter(
          (el) => el["@id"] == pointpath[0]
        )[0];
        point = point["@editedXY"].split(",");
        let RectX = (parseFloat(point[0]) - this.minX) * this.ratio;
        let RectY = (parseFloat(point[1]) - this.minY) * this.ratio;
        const textLabel = new fabric.IText(labels[labelindex]["@text"], {
          fontFamily: '"Roboto", sans-serif',
          fill: "black",
          id: labels[labelindex]["@id"],
          roomID: parentroom[0]["@id"],
          type: "textLabel",
          fontSize: this.state.textSize,
          left: RectX,
          top: RectY,
          padding: 5,
          angle: labels[labelindex]["@angle"]
            ? labels[labelindex]["@angle"]
            : 0,
          textAlign: "center",
          visible: true,
          hasControls: true,
          // lockScalingX: true,
          // lockScalingY: true,
        });
        this.canvas.add(textLabel);
      }
    }
  };

  /**
   * Purpose : This function will display staircase on floor plan
   */
  createStaircase = () => {
    let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    let roofPoints = [
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS,
    ];
    let roofPointsArray = roofPoints[0]["POINT"];
    let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    let linesArray = lines[0].LINE;
    let faceArray = roofObject[0]["FACES"]["FACE"];
    let labels = faceArray.filter((el) => el["@type"] == "STAIR_CASE");
    for (let labelindex = 0; labelindex < labels.length; labelindex++) {
      const parentroom = faceArray.filter(
        (el) =>
          el["@childrenStairCase"] &&
          el["@childrenStairCase"]
            .split(",")
            .includes(labels[labelindex]["@id"])
      );
      if (
        parentroom[0] &&
        parentroom[0]["@floorindex"] == this.state.selectedFloor
      ) {
        let doorline = linesArray.filter(
          (el) => el["@id"] == labels[labelindex].POLYGON["@path"]
        );
        let pointpath = doorline[0]["@path"].split(",");
        let point = roofPointsArray.filter(
          (el) => el["@id"] == pointpath[0]
        )[0];
        let scaleXY = roofPointsArray.filter(
          (el) => el["@id"] == pointpath[0]
        )[0];
        point = point["@editedXY"].split(",");
        let RectX = (parseFloat(point[0]) - this.minX) * this.ratio;
        let RectY = (parseFloat(point[1]) - this.minY) * this.ratio;
        const stairCase = new fabric.Path(stairCasePath, {
          fill: false,
          id: labels[labelindex]["@id"],
          roomID: parentroom[0]["@id"],
          type: "stair-case",
          left: RectX,
          top: RectY,
          stroke: "black",
          angle: labels[labelindex]["@angle"]
            ? labels[labelindex]["@angle"]
            : 0,
          scaleX: scaleXY["@scaleX"] * this.ratio,
          scaleY: scaleXY["@scaleY"] * this.ratio,
        });
        this.canvas.add(stairCase);
      }
    }
  };

  /**
   * Purpose : This function will show doors and windows for autosnapXY/RenderMode
   */
  createDoorsAndWindows = (addDoorLine = true) => {
    let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    let roofPoints = [
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS,
    ];
    let roofPointsArray = roofPoints[0]["POINT"];
    let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    let linesArray = lines[0].LINE;
    let faceArray = roofObject[0]["FACES"]["FACE"];
    let doors = faceArray.filter((el) => el["@type"] == "WALLPENETRATION");
    for (let doorindex = 0; doorindex < doors.length; doorindex++) {
      const parentwall = faceArray.filter((el) =>
        el["@children"].split(",").includes(doors[doorindex]["@id"])
      );
      const parentroom = faceArray.filter((el) =>
        el["@children"].split(",").includes(parentwall[0]["@id"])
      );
      if (parentroom[0]["@floorindex"] == this.state.selectedFloor) {
        let doorline = linesArray.filter(
          (el) => el["@id"] == doors[doorindex].POLYGON["@path"]
        );
        let pointpath = doorline[0]["@path"].split(",");
        let point1 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[0])[0]
          ["@autoSnappedXY"].split(",");
        let point2 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[1])[0]
          ["@autoSnappedXY"].split(",");
        let pointspos = [
          (point1[0] - this.minX) * this.ratio,
          (point1[1] - this.minY) * this.ratio,
          (point2[0] - this.minX) * this.ratio,
          (point2[1] - this.minY) * this.ratio,
        ];
        let anglePipePoints = [];
        let circlePoint = new fabric.Circle({
          radius: 2,
          fill: "rgba(0,0,0,0)",
          //fill: 'white',
          left: pointspos[0],
          top: pointspos[1],
          selectable: false,
          originX: "center",
          originY: "center",
          hoverCursor: "auto",
        });

        this.canvas.add(circlePoint);

        let circlePoint1 = new fabric.Circle({
          radius: 2,
          fill: "rgba(0,0,0,0)",
          //fill: 'white',
          left: pointspos[2],
          top: pointspos[3],
          selectable: false,
          originX: "center",
          originY: "center",
          hoverCursor: "auto",
        });

        this.canvas.add(circlePoint1);

        anglePipePoints.push(circlePoint);
        anglePipePoints.push(circlePoint1);
        if (anglePipePoints.length > 1) {
          let startPoint = anglePipePoints[anglePipePoints.length - 2];
          let endPoint = anglePipePoints[anglePipePoints.length - 1];

          let line = new fabric.Line(
            [
              startPoint.get("left"),
              startPoint.get("top"),
              endPoint.get("left"),
              endPoint.get("top"),
            ],
            {
              stroke: ROOM_WALL_DOOR_COLOR,
              strokeWidth: lineStokeWidth - 2,
              hasControls: false,
              hasBorders: true,
              selectable: false,
              type: "DW",
              isDoor: doors[doorindex]["@mode"] == "DOOR",
              linePointObjectArray: doorline[0]["@path"],
              wallID: parentwall[0]["@id"],
              originX: "center",
              originY: "center",
              roomID: parentroom[0]["@id"],
              id: doors[doorindex]["@id"],
              unroundedsize:
                doors[doorindex]["POLYGON"]["@editedUnroundedsize"],
              size: doors[doorindex]["POLYGON"]["@editedSize"],
              doorDirection:
                doors[doorindex]["@mode"] == "DOOR" &&
                doors[doorindex]["@doorDirection"]
                  ? doors[doorindex]["@doorDirection"]
                  : doors[doorindex]["@mode"] == "DOOR" &&
                    doorDirectionEnum.inside,
              objectCaching: false,
            }
          );
          if (!this.state.isEditModeEnabled) {
            if (doors[doorindex]["@mode"] == "DOOR") {
              this.createDoorShapeObject(line, addDoorLine);
            }
          }

          if (doors[doorindex]["@mode"] !== "DOOR") {
            const wline = _.cloneDeep(line);
            wline.type = "Clone-DW";
            wline.stroke = PARTITION_WINDOW_COLOR_BORDER;
            wline.strokeWidth = lineStokeWidth;
            wline.id = "wclone-" + doors[doorindex]["@id"];
            this.canvas.add(wline);
          }

          if (addDoorLine) {
            this.canvas.add(line);
          }
        }
      }
    }
  };
  createDoorShapeObject = (line, addDoorLine = true) => {
    this.canvas
      .getObjects()
      .filter((x) => x.id === "doorobject_" + line.id)
      .forEach((x) => {
        this.canvas.remove(x);
      });
    let centerOrigin = new fabric.Point(line.x1, line.y1);
    let radians = fabric.util.degreesToRadians(90);
    let objectOrigin = new fabric.Point(line.x2, line.y2);
    let new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);
    let x1 = line.x1,
      y1 = line.y1,
      x2 = line.x2,
      y2 = line.y2;
    let polygonpointsclone =
      roomWiseLineAndTextObjects[line.roomID]["roomPolyGroup"];
    if (line.doorDirection && line.doorDirection == doorDirectionEnum.inside) {
      if (
        !insidePoly(
          new fabric.Point(new_loc.x, new_loc.y),
          polygonpointsclone.points
        )
      ) {
        x1 = line.x2;
        y1 = line.y2;
        x2 = line.x1;
        y2 = line.y1;
        centerOrigin = new fabric.Point(x1, y1);
        radians = fabric.util.degreesToRadians(90);
        objectOrigin = new fabric.Point(x2, y2);
        new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);
      }
    } else {
      if (
        insidePoly(
          new fabric.Point(new_loc.x, new_loc.y),
          polygonpointsclone.points
        )
      ) {
        x1 = line.x2;
        y1 = line.y2;
        x2 = line.x1;
        y2 = line.y1;
        centerOrigin = new fabric.Point(x1, y1);
        radians = fabric.util.degreesToRadians(90);
        objectOrigin = new fabric.Point(x2, y2);
        new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);
      }
    }
    let doorArc = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    let doorShape = new fabric.Path(
      `M ${x1} ${y1} L ${x2} ${y2} M ${x1} ${y1} L ${new_loc.x} ${new_loc.y} M ${x2} ${y2}, A ${doorArc}, ${doorArc}, 0 0 1 ${new_loc.x}, ${new_loc.y}`,
      {
        stroke: "black",
        strokeWidth: 1,
        fill: "transparent",
        originX: "center",
        height: line.height,
        width: line.width,
        type: "doorobject",
        selectable: false,
        id: "doorobject_" + line.id,
      }
    );
    let lineD = this.canvas.getItemByAttr("id", line.id);
    if (lineD && addDoorLine) {
      this.canvas.remove(this.canvas.getItemByAttr("id", line.id));
      this.canvas.add(doorShape);
      this.canvas.add(line);
      this.canvas.setActiveObject(this.canvas.getItemByAttr("id", line.id));
    } else {
      this.canvas.add(doorShape);
    }
  };

  /**
   * Purpose : This function will show doors and windows for editedXY/EditMode
   */
  createDoorsAndWindowsEditable = () => {
    let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    let roofPoints = [
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS,
    ];
    let roofPointsArray = roofPoints[0]["POINT"];
    let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    let linesArray = lines[0].LINE;
    let faceArray = roofObject[0]["FACES"]["FACE"];
    let doors = faceArray.filter((el) => el["@type"] == "WALLPENETRATION");
    for (let doorindex = 0; doorindex < doors.length; doorindex++) {
      const parentwall = faceArray.filter((el) =>
        el["@children"].split(",").includes(doors[doorindex]["@id"])
      );
      const parentroom = faceArray.filter((el) =>
        el["@children"].split(",").includes(parentwall[0]["@id"])
      );
      if (parentroom[0]["@id"] == editedRoomID) {
        let doorline = linesArray.filter(
          (el) => el["@id"] == doors[doorindex].POLYGON["@path"]
        );
        let pointpath = doorline[0]["@path"].split(",");
        let point1 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[0])[0]
          ["@editedXY"].split(",");
        let point2 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[1])[0]
          ["@editedXY"].split(",");
        let pointspos = [
          (point1[0] - this.minX) * this.ratio,
          (point1[1] - this.minY) * this.ratio,
          (point2[0] - this.minX) * this.ratio,
          (point2[1] - this.minY) * this.ratio,
        ];
        let anglePipePoints = [];
        let circlePoint = new fabric.Circle({
          radius: 2,
          fill: "rgba(0,0,0,0)",
          //fill: 'white',
          left: pointspos[0],
          top: pointspos[1],
          selectable: false,
          hoverCursor: "auto",
        });

        this.canvas.add(circlePoint);

        let circlePoint1 = new fabric.Circle({
          radius: 2,
          fill: "rgba(0,0,0,0)",
          //fill: 'white',
          left: pointspos[2],
          top: pointspos[3],
          selectable: false,
          hoverCursor: "auto",
        });

        this.canvas.add(circlePoint1);

        anglePipePoints.push(circlePoint);
        anglePipePoints.push(circlePoint1);
        if (anglePipePoints.length > 1) {
          let startPoint = anglePipePoints[anglePipePoints.length - 2];
          let endPoint = anglePipePoints[anglePipePoints.length - 1];

          let line = new fabric.Line(
            [
              startPoint.get("left"),
              startPoint.get("top"),
              endPoint.get("left"),
              endPoint.get("top"),
            ],
            {
              stroke: ROOM_WALL_DOOR_COLOR,
              strokeWidth: lineStokeWidth - 2,
              hasControls: false,
              hasBorders: true,
              type: "DW",
              isDoor: doors[doorindex]["@mode"] == "DOOR",
              linePointObjectArray: doorline[0]["@path"],
              wallID: parentwall[0]["@id"],
              roomID: parentroom[0]["@id"],
              id: doors[doorindex]["@id"],
              unroundedsize:
                doors[doorindex]["POLYGON"]["@editedUnroundedsize"],
              size: doors[doorindex]["POLYGON"]["@editedSize"],
              objectCaching: false,
            }
          );
          if (doors[doorindex]["@mode"] !== "DOOR") {
            const wline = _.cloneDeep(line);
            wline.type = "Clone-DW";
            wline.stroke = PARTITION_WINDOW_COLOR_BORDER;
            wline.strokeWidth = lineStokeWidth;
            wline.id = "wclone-" + doors[doorindex]["@id"];
            this.canvas.add(wline);
          }
          line = this.setHoverCusror(line);
          this.canvas.add(line);
        }
      }
    }
  };

  /**
   * Purpose : This function will add cursor on doors and windows when we hover on it
   * @param {Line} line a object of line/Doors and windows
   */
  setHoverCusror(line) {
    let angleDeg =
      (Math.atan2(line.y2 - line.y1, line.x2 - line.x1) * 180) / Math.PI;
    if (angleDeg >= -45 && angleDeg < 45) {
      line.set("hoverCursor", "col-resize");
    } else if (angleDeg >= 45 && angleDeg < 135) {
      line.set("hoverCursor", "row-resize");
    } else if (angleDeg >= 135 || angleDeg < -135) {
      line.set("hoverCursor", "col-resize");
    } else if (angleDeg >= -135 && angleDeg < -45) {
      line.set("hoverCursor", "row-resize");
    }
    return line;
  }

  /**
   * Purpose : This function will calculate and set size of walls and areas to the JSON
   * @param {Boolean} isLineEdited a boolean value indecates whether to replace calculation or not for the area
   */
  editArea = (isLineEdited = false) => {
    //Iterate canvas and get all lines , room wise...
    /* Need to do reverse of drawing points

        (points[0].x + this.minX) / ratioX,
        (points[0].y + this.minY) / ratioY,
        (points[1].x + this.minX) / ratioX,
        (points[1].y + this.minY) / ratioY,

    */
    this.setState({ is90Degree: true });
    let roomID = 0;
    let copyOriginal = _.cloneDeep(originalFloorPlan);

    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    var roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    var lines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES;

    let object = null;
    let objects = this.canvas.getObjects();
    for (let i = 0, len = this.canvas.size(); i < len; i++) {
      object = objects[i];
      if (object.type == "CENTRE-BOX-TEXT") {
        for (let facesIndex = 0; facesIndex < facesArray.length; facesIndex++) {
          let faceObject = facesArray[facesIndex];

          if (faceObject["@type"] == "ROOM" && faceObject["@id"] == object.id) {
            faceObject["@editedArea"] = object.area;
            facesArray[facesIndex] = faceObject;
            break;
          }
        }
      } else if (object.type == "WALL-LINE" || object.isautosnapline) {
        for (let facesIndex = 0; facesIndex < facesArray.length; facesIndex++) {
          let faceObject = facesArray[facesIndex];
          if (faceObject["@id"] == object.id) {
            faceObject["POLYGON"]["@editedUnroundedsize"] =
              object.unroundedsize;
            faceObject["POLYGON"]["@editedSize"] = object.size;
            facesArray[facesIndex] = faceObject;
            roomID = object.roomID;
            //Now update the points

            let linePointObjectArray = object.linePointObjectArray;
            for (
              let linePointObjectArrayIndex = 0;
              linePointObjectArrayIndex < linePointObjectArray.length;
              linePointObjectArrayIndex++
            ) {
              let pointObject = linePointObjectArray[linePointObjectArrayIndex];
              //Iterate points
              for (
                let roofPointsIndex = 0;
                roofPointsIndex < roofPoints.length;
                roofPointsIndex++
              ) {
                let roofPointObject = roofPoints[roofPointsIndex];
                if (pointObject["@id"] == roofPointObject["@id"]) {
                  if (linePointObjectArrayIndex == 0) {
                    let dataX = object.x1 / this.ratio + this.minX;
                    let dataY = object.y1 / this.ratio + this.minY;
                    if (isLineEdited) {
                      roofPointObject["@editedXY"] = dataX + "," + dataY;
                      roofPointObject["@autoSnappedXY"] =
                        roofPointObject["@editedXY"];
                      object.linePointObjectArray.filter(
                        (el) => el["@id"] == roofPointObject["@id"]
                      )[0]["@autoSnappedXY"] = roofPointObject["@editedXY"];
                    } else {
                      let d = object.linePointObjectArray.filter(
                        (el) => el["@id"] == roofPointObject["@id"]
                      );
                      roofPointObject["@autoSnappedXY"] =
                        d[0]["@autoSnappedXY"];
                      if (
                        ["LINE", "PARTITION_DOOR", "PARTITION_WINDOW"].includes(
                          object.type
                        )
                      ) {
                        roofPointObject["@editedXY"] = d[0]["@editedXY"];
                      }
                    }
                  } else {
                    let dataX = object.x2 / this.ratio + this.minX;
                    let dataY = object.y2 / this.ratio + this.minY;
                    if (isLineEdited) {
                      roofPointObject["@editedXY"] = dataX + "," + dataY;
                      roofPointObject["@autoSnappedXY"] =
                        roofPointObject["@editedXY"];
                      object.linePointObjectArray.filter(
                        (el) => el["@id"] == roofPointObject["@id"]
                      )[0]["@autoSnappedXY"] = roofPointObject["@editedXY"];
                    } else {
                      let d = object.linePointObjectArray.filter(
                        (el) => el["@id"] == roofPointObject["@id"]
                      );
                      roofPointObject["@autoSnappedXY"] =
                        d[0]["@autoSnappedXY"];
                      if (
                        ["LINE", "PARTITION_DOOR", "PARTITION_WINDOW"].includes(
                          object.type
                        )
                      ) {
                        roofPointObject["@editedXY"] = d[0]["@editedXY"];
                      }
                    }
                  }
                }

                roofPoints[roofPointsIndex] = roofPointObject;
              }
            }
          }
        }
      }
    }

    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = facesArray;
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;

    originalFloorPlan = _.cloneDeep(copyOriginal);
    if (isLineEdited) {
      this.editDoorArea(roomID);
    }

    let roofObject = [copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    var roofPoints = [copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    let roofPointsArray = roofPoints[0]["POINT"];

    var lines = [copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    let linesArray = lines[0].LINE;

    let faceArray = roofObject[0]["FACES"]["FACE"];

    designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = faceArray[faceArrayIndex];

      if (
        designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
        roomFaceObject["@type"] == "ROOM"
      ) {
        //Get walls of room

        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");
        //Now iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];
            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              let lineId = faceObject["POLYGON"]["@path"];

              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  let linePointObjectArray = [];
                  let linePoints = lineObject["@path"].split(",");
                  for (
                    let linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];
                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        linePointObjectArray.push(roofPointObject);

                        break;
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["LINE"] = lineObject;
                  faceArray[wallFaceObjectIndex] = faceObject;
                }
              }

              // Find Partition Door
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  let linePointObjectArray = [];
                  let linePoints = lineObject["@path"].split(",");
                  for (
                    let linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];
                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        linePointObjectArray.push(roofPointObject);

                        break;
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["PARTITION_DOOR"] = lineObject;
                  faceObject["PARTITION_WINDOW"] = lineObject;
                  faceArray[wallFaceObjectIndex] = faceObject;
                }
              }

              designatorWiseObjectArray[roomFaceObject["@id"]].push(faceObject);
            }
          }
        }
      }
    }

    //Ends
    editedRoomLeft = 0;
    editedRoomTop = 0;
    rotatedAngle = 0;
    // this.canvas.clear();
    // this.showTheListFromJsonRoomWise(updatedFloorPlan);
  };

  /**
   * Purpose : This function will calculate and set size of walls and areas to the JSON only when we made
   * changes to doors and windows position by room
   * @param {String} editRoomID Room Id of current editmode
   */
  editDoorArea = (editRoomID) => {
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    roomArray = Object.keys(designatorWiseObjectArray);
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      if (roomArray[roomArrayIndex] == editRoomID) {
        let roomObjectArray =
          designatorWiseObjectArray[roomArray[roomArrayIndex]];
        for (
          let roomObjectArrayIndex = 0;
          roomObjectArrayIndex < roomObjectArray.length;
          roomObjectArrayIndex++
        ) {
          if (roomObjectArray[roomObjectArrayIndex]["@type"] == "WALL") {
            for (
              let facesIndex = 0;
              facesIndex < facesArray.length;
              facesIndex++
            ) {
              if (
                facesArray[facesIndex]["@id"] ==
                roomObjectArray[roomObjectArrayIndex]["@id"]
              ) {
                const childIdsline = facesArray.filter((el) =>
                  facesArray[facesIndex]["@children"]
                    .split(",")
                    .includes(el["@id"])
                );
                childIdsline.forEach((childObj) => {
                  for (
                    let lineindex = 0;
                    lineindex < rooflines.length;
                    lineindex++
                  ) {
                    if (
                      rooflines[lineindex]["@id"] == childObj.POLYGON["@path"]
                    ) {
                      for (
                        let roofPointsindex = 0;
                        roofPointsindex < roofPoints.length;
                        roofPointsindex++
                      ) {
                        if (
                          rooflines[lineindex]["@path"]
                            .split(",")
                            .includes(roofPoints[roofPointsindex]["@id"])
                        ) {
                          roofPoints[roofPointsindex]["@autoSnappedXY"] =
                            roofPoints[roofPointsindex]["@editedXY"];
                        }
                      }
                    }
                  }
                });
              }
            }
          }
        }
      }
    }
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;

    originalFloorPlan = _.cloneDeep(copyOriginal);
  };

  /**
   * Purpose : This function will save the changes to DB
   */
  saveArea = () => {
    let obj = this.canvas.getObjects();
    obj.forEach((element) => {
      if (element.isEditing) {
        element.exitEditing();
      }
    });
    this.props.StartLoading();
    setTimeout(() => {
      this.canvas.discardActiveObject();
      const { t } = this.props;
      let finalFloorPlan = _.cloneDeep(originalFloorPlan);
      let facesArray =
        finalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
      for (let facesIndex = 0; facesIndex < facesArray.length; facesIndex++) {
        delete facesArray[facesIndex].LINE;
      }
      if (!this.state.wallThicknessError) {
        finalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES["@exteriorWallThickness"] =
          this.state.wallThickness;
      }

      this.props
        .fetchProfileDetails()
        .then((pdata) => {
          if (
            this.state.selectedMeasurementType == "1" ||
            this.state.selectedMeasurementType == "4"
          ) {
            finalFloorPlan.EAGLEVIEW_EXPORT["METADATA"]["@updatedby"] =
              pdata.userId + "|" + pdata.userRole + "|" + pdata.fullName;
            finalFloorPlan.EAGLEVIEW_EXPORT["METADATA"]["@updatedon"] = moment(
              new Date()
            )
              .utc()
              .format("DD-MM-YYYY HH:mm:ss A");
          }
          if (this.props.isTechnician?.create) {
            this.props.setJsonObject(finalFloorPlan);
            this.props.setShowPublishSidebar(true);
            this.props.setIsLoading(false);
            this.props.StopLoading();
          } else {
            let type = measurementTypes.find(
              (el) => el.id == this.state.selectedMeasurementType
            );
            let floorData = this.state.selectedCustomFloorName;
            if (!floorData) {
              floorData = this.props.floorListForVideo?.find(
                (item) => item.floorTagNameList?.length
              );
            }
            const data = {
              jobOrderId: this.props.jobOrderId,
              floorScanId: this.props.selectedFloorScanId,
              jsonData: finalFloorPlan,
              type: type.name,
              floorTagName:
                measurementTypes[3].name !== type.name
                  ? undefined
                  : typeof floorData === "string"
                  ? floorData
                  : floorData?.floorTagNameList[0],
            };
            this.props
              .saveMeasurementJson(data)
              .then((res) => {
                res && this.props.toggleRefreshMeasurementJson();
                this.props.StopLoading();
                EditModeChanges = [];
                let selectedMeasurementType = "1";
                if (
                  !this.props.isTechnician?.create &&
                  this.props.newMeasurementTypes?.remoteValVideo &&
                  !this.props.newMeasurementTypes?.remoteVal
                ) {
                  selectedMeasurementType = "4";
                }
                if (this.props.isTechnician?.create) {
                  selectedMeasurementType = "4";
                }
                this.setState({
                  selectedMeasurementType: selectedMeasurementType,
                });
              })
              .catch((_) => this.props.StopLoading());
          }
        })
        .catch((_) => this.props.StopLoading());
    }, 500);
  };

  getCloseLine(activeLines, x, y, id, data = []) {
    let cordsArray = [];
    activeLines.forEach((element) => {
      if (element.id !== id) {
        const distancex1 = Math.abs(
          Math.max(Math.abs(element.x1 - x), Math.abs(element.y1 - y))
        );
        const distancex2 = Math.abs(
          Math.max(Math.abs(element.x2 - x), Math.abs(element.y2 - y))
        );
        cordsArray.push({
          distance: distancex1,
          cords: { x: element.x2, y: element.y2 },
          id: element.id,
        });
        cordsArray.push({
          distance: distancex2,
          cords: { x: element.x1, y: element.y1 },
          id: element.id,
        });
      }
    });
    let sortedcordsArray = _.sortBy(cordsArray, ["distance"]);
    // sortedcordsArray = sortedcordsArray.filter(
    //   (el) =>
    //     data.filter((elm) => elm.x == el.cords.x && elm.y == el.cords.y)
    //       .length == 0
    // );
    return sortedcordsArray;
  }

  saveModifiableRoom = () => {
    this.CloseOptions();
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

    let eachMatch = true;
    let activeLines = this.canvas
      .getObjects()
      .filter((el) => el.type == "custom-line");

    activeLines.forEach((element, i) => {
      const p1 = this.getCloseLine(
        activeLines,
        element.x1,
        element.y1,
        element.id
      )[0];
      const p2 = this.getCloseLine(
        activeLines,
        element.x2,
        element.y2,
        element.id
      )[0];

      if (!(p1.distance <= 10 && p2.distance <= 10)) {
        eachMatch = false;
      }
    });
    if (eachMatch) {
      let LINEARRAY = [],
        COARRAY = [];
      let cid = this.getMaxId(roofPoints, "C") + 1;
      let lid = this.getMaxId(linesArray, "L") + 1;
      let wallid = this.getMaxId(faceArray, "WALL") + 1;
      let cords = [];
      activeLines.forEach((element, i) => {
        if (i == 0) {
          cords.push({ x: element.x1, y: element.y1, id: element.id });
          cords.push({ x: element.x2, y: element.y2, id: element.id });
        } else {
          const gape = this.getCloseLine(
            activeLines,
            cords[cords.length - 1].x,
            cords[cords.length - 1].y,
            cords[cords.length - 1].id,
            cords
          )[0];
          cords.push({ x: gape.cords.x, y: gape.cords.y, id: gape.id });
        }
      });
      cords.forEach((element, i) => {
        let c1id = cid++;
        let cdata1 = {
          "@id": "C" + c1id,
          "@data": "0,0",
          "@dataXY":
            element.x / this.ratio +
            this.minX +
            "," +
            (element.y / this.ratio + this.minY),
          "@editedXY":
            element.x / this.ratio +
            this.minX +
            "," +
            (element.y / this.ratio + this.minY),
          "@autoSnappedXY":
            element.x / this.ratio +
            this.minX +
            "," +
            (element.y / this.ratio + this.minY),
        };
        if (cords.length - 1 != i) {
          COARRAY.push(cdata1);
        }
      });
      COARRAY.forEach((element, i) => {
        if (i > 0) {
          let ldata = {
            "@id": "L" + lid++,
            "@path": COARRAY[i - 1]["@id"] + "," + COARRAY[i]["@id"],
            "@type": "TOPWALL",
          };
          LINEARRAY.push(ldata);
        }
        if (i == COARRAY.length - 1) {
          let ldata = {
            "@id": "L" + lid++,
            "@path": COARRAY[i]["@id"] + "," + COARRAY[0]["@id"],
            "@type": "TOPWALL",
          };
          LINEARRAY.push(ldata);
        }
      });
      let faceids = [],
        lineids = [],
        cids = [];
      for (
        let faceArrayIndex = 0;
        faceArrayIndex < faceArray.length;
        faceArrayIndex++
      ) {
        let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
        if (roomFaceObject["@floorindex"] == this.state.selectedFloor) {
          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];
            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomFaceObject["@children"]
                .split(",")
                .includes(faceObject["@id"]) &&
              faceObject["@type"] == "WALL"
            ) {
              faceids.push(faceObject["@id"]);
              lineids.push(faceObject["POLYGON"]["@path"]);
              const lfarray = linesArray.filter(
                (el) => el["@id"] == faceObject["POLYGON"]["@path"]
              );
              cids.push(lfarray[0]["@path"].split(",")[0]);
              cids.push(lfarray[0]["@path"].split(",")[1]);
            }
          }
        }
      }
      faceArray = faceArray.filter((el) => !faceids.includes(el["@id"]));
      linesArray = linesArray.filter((el) => !lineids.includes(el["@id"]));
      roofPoints = roofPoints.filter((el) => !cids.includes(el["@id"]));

      roofPoints = roofPoints.concat(COARRAY);
      linesArray = linesArray.concat(LINEARRAY);
      let wallidarry = [];
      LINEARRAY.forEach((element) => {
        let facedata = {
          "@floorindex": "",
          "@floor": "",
          "@areaname": "",
          "@measuretype": "",
          "@type": "WALL",
          "@area": "",
          "@editedArea": "",
          "@designator": "",
          POLYGON: {
            "@orientation": "",
            "@pitch": "",
            "@unroundedsize": "0",
            "@path": element["@id"],
            "@editedUnroundedsize": "0",
            "@size": "1.0",
            "@editedSize": "1.0",
            "@id": "",
          },
          "@children": "",
          "@id": "WALL" + wallid,
          "@mode": "WALL",
        };
        wallidarry.push("WALL" + wallid);
        faceArray.push(facedata);
        wallid++;
      });
      let roomID = "";
      for (
        let faceArrayIndex = 0;
        faceArrayIndex < faceArray.length;
        faceArrayIndex++
      ) {
        let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
        if (roomFaceObject["@floorindex"] == this.state.selectedFloor) {
          faceArray[faceArrayIndex]["@children"] = roomFaceObject["@children"]
            .split(",")
            .filter((el) => !(el.indexOf("WALL") != -1))
            .concat(wallidarry)
            .join(",");
          roomID = faceArray[faceArrayIndex]["@id"];
        }
      }
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = faceArray;
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE = linesArray;
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
      originalFloorPlan = _.cloneDeep(copyOriginal);
      this.canvas.clear();
      this.showTheListFromJsonRoomWise(originalFloorPlan);
      this.calculateAreaByRoom(roomID);
      this.setState({ isModifiableRoom: false });
    } else {
      const { t } = this.props;
      customToast.error(t("ERROR_MESSAGES.Please_Connect_Every_Walls"));
    }
  };
  createModifiableRoom = () => {
    //Now start drawing
    this.setState({ isModifiableRoom: true });
    this.canvas.clear();
    this.toggleCanvasGrid();
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let roofPointsArray =
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
      if (roomFaceObject["@floorindex"] == this.state.selectedFloor) {
        for (
          let wallFaceObjectIndex = 0;
          wallFaceObjectIndex < faceArray.length;
          wallFaceObjectIndex++
        ) {
          let faceObject = faceArray[wallFaceObjectIndex];
          if (
            faceObject["POLYGON"]["@path"].trim().length > 0 &&
            roomFaceObject["@children"]
              .split(",")
              .includes(faceObject["@id"]) &&
            faceObject["@type"] == "WALL"
          ) {
            let lineId = faceObject["POLYGON"]["@path"];
            for (
              let lineArrayIndex = 0;
              lineArrayIndex < linesArray.length;
              lineArrayIndex++
            ) {
              let lineObject = linesArray[lineArrayIndex];
              if (lineObject["@id"] == lineId) {
                let lpoints = roofPointsArray.filter((el) =>
                  lineObject["@path"].split(",").includes(el["@id"])
                );
                let pointx0 =
                  (parseFloat(lpoints[0]["@editedXY"].split(",")[0]) -
                    this.minX) *
                  this.ratio;
                let pointy0 =
                  (parseFloat(lpoints[0]["@editedXY"].split(",")[1]) -
                    this.minY) *
                  this.ratio;
                let pointx1 =
                  (parseFloat(lpoints[1]["@editedXY"].split(",")[0]) -
                    this.minX) *
                  this.ratio;
                let pointy1 =
                  (parseFloat(lpoints[1]["@editedXY"].split(",")[1]) -
                    this.minY) *
                  this.ratio;
                let box1 = new fabric.Circle({
                  left: pointx0,
                  top: pointy0,
                  strokeWidth: 6,
                  radius: 3,
                  id: "m1" + lineId,
                  fill: "#fff",
                  stroke: "black",
                  type: "modifiable-box",
                  originX: "center",
                  originY: "center",
                });

                let box2 = new fabric.Circle({
                  left: pointx1,
                  top: pointy1,
                  strokeWidth: 6,
                  radius: 3,
                  fill: "#fff",
                  id: "m2" + lineId,
                  stroke: "black",
                  type: "modifiable-box",
                  originX: "center",
                  originY: "center",
                });
                let connector = new fabric.Line(
                  [
                    box1.get("left"),
                    box1.get("top"),
                    box2.get("left"),
                    box2.get("top"),
                  ],
                  {
                    linePointObjectArray: lineObject["@path"],
                    stroke: "black",
                    type: "custom-line",
                    evented: true,
                    selectable: true,
                    originX: "center",
                    originY: "center",
                    id: lineId,
                    strokeWidth: lineStokeWidth,
                    lockScalingX: true,
                    lockScalingY: true,
                    lockRotation: true,
                    hasControls: false,
                    hasBorders: false,
                    lockMovementX: true,
                    lockMovementY: true,
                  }
                );
                box1.hasControls = box1.hasBorders = false;
                box1.line1 = connector;
                box2.hasControls = box2.hasBorders = false;
                box2.line1 = connector;
                box2.on("mouseover", (e) => {
                  e.target.line1.set({ stroke: "red" });
                  this.setState({
                    lineselected: true,
                    linestyle: {
                      position: "fixed",
                      top: e.e.pageY + 10,
                      left: e.e.pageX + 10,
                    },
                    selectedModifiedLine: e.target.line1,
                  });

                  this.canvas.renderAll();
                });
                box2.on("mouseout", (e) => {
                  if (e.target) {
                    e.target.line1.set({ stroke: "black" });
                    this.canvas.renderAll();
                  }
                });
                box1.on("mouseover", (e) => {
                  e.target.line1.set({ stroke: "red" });
                  this.setState({
                    lineselected: true,
                    linestyle: {
                      position: "fixed",
                      top: e.e.pageY + 10,
                      left: e.e.pageX + 10,
                    },
                    selectedModifiedLine: e.target.line1,
                  });
                  this.canvas.renderAll();
                });
                box1.on("mouseout", (e) => {
                  if (e.target) {
                    e.target.line1.set({ stroke: "black" });
                    this.canvas.renderAll();
                  }
                });
                box1.on("moving", function (e) {
                  if (this.isnewline) {
                    e.preventDefault();
                    return;
                  }
                  const connectPoint = this.getPointByOrigin(
                    "center",
                    "bottom"
                  );
                  connector.set({
                    x1: connectPoint.x,
                    y1: connectPoint.y,
                  });
                  connector.setCoords();
                  this.canvas.renderAll();
                });
                box2.on("moving", function (e) {
                  if (this.isnewline) {
                    e.preventDefault();
                    return;
                  }
                  const connectPoint = this.getPointByOrigin("center", "top");
                  connector.set({
                    x2: connectPoint.x,
                    y2: connectPoint.y,
                  });
                  connector.setCoords();
                  this.canvas.renderAll();
                });
                this.canvas.add(box1, box2, connector);
                this.canvas.requestRenderAll();
              }
            }
          }
        }
      }
    }
  };
  addListener = () => {
    this.canvas.on("mouse:down", this.onMouseDown);
    this.canvas.on("mouse:dblclick", this.onDblClick);
    this.canvas.on("mouse:move", this.onMouseMove);
  };

  removeListener = () => {
    this.canvas.off("mouse:down", this.onMouseDown);
    this.canvas.off("mouse:dblclick", this.onDblClick);
    this.canvas.off("mouse:move", this.onMouseMove);
  };

  onMouseDown = debounce((options) => {
    let activeLines = this.canvas
      .getObjects()
      .filter((el) => el.type == "custom-line");

    var pointer = this.canvas.getPointer(options.e);
    const cp1 = this.getCloseLine(
      activeLines,
      pointer.x,
      pointer.y,
      (Math.random() + 1).toString(36).substring(7)
    );

    if (
      cp1[0].distance <= 10 &&
      cp1[1].distance <= 10 &&
      cp1[2].distance <= 10
    ) {
      const { t } = this.props;
      customToast.error(t("ERROR_MESSAGES.You_Cannot_Add_Wall"));
      this.CloseOptions();
      return;
    }

    var pointer = this.canvas.getPointer(options.e);
    let lineId = (Math.random() + 1).toString(36).substring(7);
    let box1 = new fabric.Circle({
      left: pointer.x,
      top: pointer.y,
      strokeWidth: 6,
      radius: 3,
      id: "m1" + lineId,
      fill: "#fff",
      stroke: "black",
      type: "modifiable-box",
      originX: "center",
      originY: "center",
    });

    let box2 = new fabric.Circle({
      left: pointer.x,
      top: pointer.y,
      strokeWidth: 6,
      radius: 3,
      fill: "#fff",
      id: "m2" + lineId,
      stroke: "black",
      type: "modifiable-box",
      originX: "center",
      originY: "center",
    });

    let connector = new fabric.Line(
      [box1.get("left"), box1.get("top"), box2.get("left"), box2.get("top")],
      {
        hasBorders: false,
        stroke: "black",
        type: "custom-line",
        evented: true,
        selectable: true,
        originX: "center",
        originY: "center",
        id: lineId,
        strokeWidth: lineStokeWidth,
        lockScalingX: true,
        lockScalingY: true,
        lockRotation: true,
        hasControls: false,
        lockMovementX: true,
        lockMovementY: true,
      }
    );

    box1.hasControls = box1.hasBorders = false;
    box1.line1 = connector;
    box2.hasControls = box2.hasBorders = false;
    box2.line1 = connector;
    box2.on("mouseover", (e) => {
      e.target.line1.set({ stroke: "red" });
      this.setState({
        lineselected: true,
        linestyle: {
          position: "fixed",
          top: e.e.pageY + 10,
          left: e.e.pageX + 10,
        },
        selectedModifiedLine: e.target.line1,
      });

      this.canvas.renderAll();
    });
    box2.on("mouseout", (e) => {
      if (e.target) {
        e.target.line1.set({ stroke: "black" });
        this.canvas.renderAll();
      }
    });
    box1.on("mouseover", (e) => {
      e.target.line1.set({ stroke: "red" });
      this.setState({
        lineselected: true,
        linestyle: {
          position: "fixed",
          top: e.e.pageY + 10,
          left: e.e.pageX + 10,
        },
        selectedModifiedLine: e.target.line1,
      });
      this.canvas.renderAll();
    });
    box1.on("mouseout", (e) => {
      if (e.target) {
        e.target.line1.set({ stroke: "black" });
        this.canvas.renderAll();
      }
    });
    box1.on("moving", function (e) {
      if (this.isnewline) {
        e.preventDefault();
        return;
      }
      const connectPoint = this.getPointByOrigin("center", "bottom");
      connector.set({
        x1: connectPoint.x,
        y1: connectPoint.y,
      });
      connector.setCoords();
      this.canvas.renderAll();
    });
    box2.on("moving", function (e) {
      if (this.isnewline) {
        e.preventDefault();
        return;
      }
      const connectPoint = this.getPointByOrigin("center", "top");
      connector.set({
        x2: connectPoint.x,
        y2: connectPoint.y,
      });
      connector.setCoords();
      this.canvas.renderAll();
    });
    if (this.state.newline) {
      this.setState({
        lineselected: false,
        linestyle: {},
        isDown: false,
        newline: null,
      });
      this.isnewline = null;
      this.removeListener();
    } else {
      this.canvas.add(box1, box2, connector);
      this.canvas.requestRenderAll();
      // this.canvas.add(line);

      this.setState({
        newline: connector,
        isDown: true,
        lineselected: false,
        linestyle: {},
      });
      this.isnewline = connector;
    }
  }, 100);

  onDblClick = () => {
    // this.state.newline && this.state.newline.setCoords();
    // this.setState({ newline: null, isDown: false });
    // this.edit();
  };

  onMouseMove = (o) => {
    if (!this.state.isDown) return;
    var pointer = this.canvas.getPointer(o.e);
    this.state.newline.set({
      x2: pointer.x,
      y2: pointer.y,
    });
    let connector = this.canvas.getItemByAttr(
      "id",
      "m2" + this.state.newline.id
    );
    connector.set({
      left: pointer.x,
      top: pointer.y,
    });
    connector.setCoords();
    this.canvas.renderAll();
  }; //end mouse:move

  edit = () => {
    // bool = false
    if (this.state.drawMode) {
      var canvas_objects = this.canvas._objects;
      var sel = canvas_objects[canvas_objects.length - 1]; //Get last object
      this.canvas.remove(sel);
      this.setState({ drawMode: false });
    }
    this.removeListener();
  };
  addLine = () => {
    this.setState({ drawMode: true, lineselected: false, linestyle: {} });
    this.addListener();
  };
  CloseOptions = () => {
    this.setState({
      lineselected: false,
      linestyle: {},
      isDown: false,
      drawMode: false,
    });
    this.removeListener();
    if (this.state.newline) {
      this.canvas.remove(
        this.canvas.getItemByAttr("id", this.state.newline.id)
      );
      this.canvas.remove(
        this.canvas.getItemByAttr("id", "m1" + this.state.newline.id)
      );
      this.canvas.remove(
        this.canvas.getItemByAttr("id", "m2" + this.state.newline.id)
      );
    }
  };
  deleteLine = () => {
    this.canvas.remove(
      this.canvas.getItemByAttr("id", this.state.selectedModifiedLine.id)
    );
    this.canvas.remove(
      this.canvas.getItemByAttr("id", "m1" + this.state.selectedModifiedLine.id)
    );
    this.canvas.remove(
      this.canvas.getItemByAttr("id", "m2" + this.state.selectedModifiedLine.id)
    );
    this.setState({ lineselected: false, linestyle: {} });
  };
  /**
   * Purpose : This function will create editable room where you can apply changes
   * @param {String } targetRoomId is of room to create editable object
   */
  createEditableRoom = (targetRoomId) => {
    //Now start drawing
    roomArray = Object.keys(designatorWiseObjectArray);
    this.canvas._objects = this.canvas._objects.filter(
      (val) => val.type != "Clone-DW"
    );
    setTimeout(() => {
      this.setState({ isEditMode: false });
    }, 5000);
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let areaName = "";
      let roomArea = "";
      let roomID = "";
      var measureType = "";

      if (roomArray[roomArrayIndex] != editedRoomID) {
        continue;
      }

      editedRoomLeft = editedRoomLeft;
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];

      //if(roomLinesGroup[""])

      roomLinesGroup = [];
      roomTextGroup = [];
      roomConnectorGroup = [];
      let polygonpoints = [];
      let wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];

        let wallID = wallObject["@id"];
        if (wallObject.LINE == null) {
          areaName = wallObject["@areaname"];
          roomArea = wallObject["@editedArea"];
          roomID = wallObject["@id"];
          measureType = wallObject["@measuretype"];

          roomWiseLineAndTextObjects[roomID] = {};
          roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomCircleGroup"] = [];
          roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = {};
          roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          //TBD
        } else {
          continue;
        }

        let linePointObjectArray = wallObject.LINE.linePointObjectArray;
        let poligonObject = wallObject.POLYGON;

        let points = [];
        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          let value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@editedXY"];

          if (value1 == null) {
            break;
          }
          let id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          let v1 = value1.split(",");
          let fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }
        //Add line
        if (points.length < 2) {
          break;
        }

        let line = null;
        //var color = wallNo % 2 == 0 ? "#fe741f" : "black";
        var color = "black";
        editedRoomLeft = editedRoomFinalLeftDist;
        editedRoomTop = editedRoomFinalTopDist;
        let point0X = (points[0].x - this.minX) * this.ratio;
        let point1X = (points[1].x - this.minX) * this.ratio;

        let point0Y = (points[0].y - this.minY) * this.ratio;
        let point1Y = (points[1].y - this.minY) * this.ratio;

        polygonpoints.push({
          x: point0X,
          y: point0Y,
        });

        polygonpoints.push({
          x: point1X,
          y: point1Y,
        });

        if (
          ["LINE", "PARTITION_DOOR", "PARTITION_WINDOW"].includes(
            wallObject["@type"]
          )
        ) {
          line = new fabric.Line([point0X, point0Y, point1X, point1Y], {
            id: wallID,
            roomID: roomID,
            stroke: ["PARTITION_DOOR", "PARTITION_WINDOW"].includes(
              wallObject["@type"]
            )
              ? PARTITION_DOOR_COLOR
              : "black",
            type: wallObject["@type"],
            objectCaching: false,
            originX: "center",
            originY: "center",
            strokeUniform: true,
            strokeWidth: partitionLineStokeWidth,
            padding: 4,
            lockScalingX: true,
            lockScalingY: true,
            lockRotation: false,
            hasControls: false,
            lockMovementX: false,
            lockMovementY: false,
            linePointObjectArray: linePointObjectArray,
            unroundedsize: wallObject["POLYGON"]["@editedUnroundedsize"],
            size: wallObject["POLYGON"]["@editedSize"],
            areaName: areaName,
            roomArea: roomArrayIndex,
            isautosnapline: true,
          });
        } else {
          line = new fabric.Line([point0X, point0Y, point1X, point1Y], {
            stroke: color,
            strokeWidth: lineStokeWidth,
            selectable: false,
            evented: false,
            id: wallID,
            roomID: roomID,
            type: "WALL-LINE",
            linePointObjectArray: linePointObjectArray,
            unroundedsize: wallObject["POLYGON"]["@editedUnroundedsize"],
            size: wallObject["POLYGON"]["@editedSize"],
            areaName: areaName,
            roomArea: roomArrayIndex,
          });
        }

        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
        roomLinesGroup.push(line);
        this.canvas.add(line);

        if (isWallPenetration == false) {
          wallNo++;
        }
      }
      let roomCenterPointX = 0;
      let roomCenterPointY = 0;

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        //var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";
        var color = "black";

        // Connectors

        let circle = null;
        if (roomLinesGroupArrayIndex == 0) {
          circle = this.makeCircle(
            roomLinesGroup[0].get("x1"),
            roomLinesGroup[0].get("y1"),
            roomLinesGroup[roomLinesGroup.length - 1],
            roomLinesGroup[0],
            color,
            editedRoomAngle
          );
        } else {
          if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );

            // this.canvas.add(circle);
            //roomConnectorGroup.push(circle);
          } else {
            circle = this.makeCircle(
              roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
              roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
              roomLinesGroup[roomLinesGroupArrayIndex - 1],
              roomLinesGroup[roomLinesGroupArrayIndex],
              color
            );
          }
        }

        circle.on("mousedblclick", (e) => {
          // e.target should be the circle
          this.discardAutoDegree();
          this.setState({
            style: {
              position: "fixed",
              top: e.e.pageY + 10,
              left: e.e.pageX + 10,
            },
          });
          currentCircleEvent = e;
          let line1 = e.target.line1;
          let line2 = e.target.line2;
          let basex = 0,
            basey = 0;
          const line1StartX = line1.x1,
            line1StartY = line1.y1,
            line1EndX = line1.x2,
            line1EndY = line1.y2,
            line2StartX = line2.x1,
            line2StartY = line2.y1,
            line2EndX = line2.x2,
            line2EndY = line2.y2;
          const denominator =
            (line2EndY - line2StartY) * (line1EndX - line1StartX) -
            (line2EndX - line2StartX) * (line1EndY - line1StartY);
          let a = line1StartY - line2StartY;
          let b = line1StartX - line2StartX;
          const numerator1 =
            (line2EndX - line2StartX) * a - (line2EndY - line2StartY) * b;
          const numerator2 =
            (line1EndX - line1StartX) * a - (line1EndY - line1StartY) * b;
          a = numerator1 / denominator;
          b = numerator2 / denominator;
          basex = line1StartX + a * (line1EndX - line1StartX);
          basey = line1StartY + a * (line1EndY - line1StartY);
          let angleDegl1 =
            (Math.atan2(line1.y2 - line1.y1, line1.x2 - line1.x1) * 180) /
            Math.PI;
          let angleDegl2 =
            (Math.atan2(line2.y1 - line2.y2, line2.x1 - line2.x2) * 180) /
            Math.PI;
          if (angleDegl1 % 45 != 0) {
            let x1, x2, y1, y2;
            let rad = 0;
            angleDegl1 = this.getAcurateAngle(angleDegl1);
            if (line1.x1 == basex && line1.y1 == basey) {
              rad = fabric.util.degreesToRadians(angleDegl1);
              const diff = Math.sqrt(
                Math.pow(line1.x2 - line1.x1, 2) +
                  Math.pow(line1.y2 - line1.y1, 2)
              );
              x2 = line1.x1 - diff * Math.cos(rad);
              y2 = line1.y1 - diff * Math.sin(rad);
              x1 = line1.x1;
              y1 = line1.y1;
            } else {
              rad = fabric.util.degreesToRadians(angleDegl1);
              const diff = Math.sqrt(
                Math.pow(line1.x1 - line1.x2, 2) +
                  Math.pow(line1.y1 - line1.y2, 2)
              );
              x1 = line1.x2 - diff * Math.cos(rad);
              y1 = line1.y2 - diff * Math.sin(rad);
              x2 = line1.x2;
              y2 = line1.y2;
            }
            const poly1 = new fabric.Line([x1, y1, x2, y2], {
              strokeWidth: 4,
              stroke: "orange",
              cornerColor: "orange",
              selectable: false,
              lockScalingX: true,
              lockScalingY: true,
              objectCaching: false,
              strokeDashArray: [3, 3],
              ID: "line1-" + editedRoomID,
            });
            poly1.setControlsVisibility({
              mt: false,
              mb: false,
              ml: false,
              mr: false,
            });
            this.setState({ is90Degree: false });
            this.canvas.add(poly1);
          }
          if (angleDegl2 % 45 != 0) {
            let x1, x2, y1, y2;
            let rad = 0;
            angleDegl2 = this.getAcurateAngle(angleDegl2);
            if (!(line1.x1 == basex && line1.y1 == basey)) {
              rad = fabric.util.degreesToRadians(angleDegl2);
              const diff = Math.sqrt(
                Math.pow(line2.x2 - line2.x1, 2) +
                  Math.pow(line2.y2 - line2.y1, 2)
              );
              x2 = line2.x1 - diff * Math.cos(rad);
              y2 = line2.y1 - diff * Math.sin(rad);
              x1 = line2.x1;
              y1 = line2.y1;
            } else {
              rad = fabric.util.degreesToRadians(angleDegl2);
              const diff = Math.sqrt(
                Math.pow(line2.x1 - line2.x2, 2) +
                  Math.pow(line2.y1 - line2.y2, 2)
              );
              x1 = line2.x2 - diff * Math.cos(rad);
              y1 = line2.y2 - diff * Math.sin(rad);
              x2 = line2.x2;
              y2 = line2.y2;
            }

            const poly2 = new fabric.Line([x1, y1, x2, y2], {
              strokeWidth: 4,
              stroke: "orange",
              cornerColor: "orange",
              selectable: false,
              lockScalingX: true,
              lockScalingY: true,
              objectCaching: false,
              strokeDashArray: [3, 3],
              ID: "line2-" + editedRoomID,
            });
            poly2.setControlsVisibility({
              mt: false,
              mb: false,
              ml: false,
              mr: false,
            });
            this.setState({ is90Degree: false });
            this.canvas.add(poly2);
          }
        });
        this.canvas.add(circle);
        roomWiseLineAndTextObjects[roomID]["roomCircleGroup"].push(circle);

        roomCenterPointX +=
          (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
            roomLinesGroup[roomLinesGroupArrayIndex].x2) /
          2;
        roomCenterPointY +=
          (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
            roomLinesGroup[roomLinesGroupArrayIndex].y2) /
          2;
      }

      polygonpoints = _.uniqWith(polygonpoints, _.isEqual);

      const poly = new fabric.Polygon(polygonpoints, {
        fill: "transparent",
        strokeWidth: lineStokeWidth,
        stroke: "black",
        cornerColor: "black",
        roomID: roomID,
        ID: "POLY-" + roomID,
      });

      let polygonCenter = poly.getCenterPoint();

      roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = poly;

      let totalPoints = roomLinesGroup.length;

      let areaLabelLeft = roomCenterPointX / totalPoints;
      let areaLabelTop = roomCenterPointY / totalPoints;

      let centreTextObject = null;
      if (this.canvas.getItemByAttr("id", roomID) != null) {
        //this.canvas.getItemByAttr('id', "room1").remove();
        centreTextObject = this.canvas.getItemByAttr("id", roomID);
        centreTextObject.set(
          "left",
          areaLabelLeft - centreTextObject.getBoundingRect().width / 2
        );

        centreTextObject.set(
          "top",
          areaLabelTop - centreTextObject.getBoundingRect().height / 2
        );
      } else {
        //Add label

        let centerBoxText =
          (roomArea.length > 0 && !isNaN(roomArea)
            ? parseFloat(roomArea).toFixed(1)
            : roomArea) +
          "\n" +
          (this.state.isShowAreaName ? areaName : "");

        let unRoundedArea = parseFloat(roomArea);
        let tempFoot = parseInt(unRoundedArea);

        let tempPoints = unRoundedArea - tempFoot;

        let inch = (tempPoints * 12) / 100;
        inch = parseInt(inch * 100);

        let unRoundedSizeFeetLabel = !(isNaN(tempPoints) && isNaN(inch))
          ? tempFoot + "' " + inch + "''"
          : "";

        if (unRoundedSizeFeetLabel != "") {
          let sizes = roomArea.split(".");
          let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";
          let tempPoints = sizes && sizes.length > 1 ? sizes[1] : "";
          unRoundedSizeFeetLabel = tempFoot + "' " + tempPoints + "''";
        }

        // For Alpha release we are hiding the area name
        // centerBoxText = unRoundedSizeFeetLabel + "\n" + areaName;
        //centerBoxText = unRoundedSizeFeetLabel;

        centreTextObject = new fabric.Text(centerBoxText, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: this.state.baseFontSize,
          left: areaLabelLeft,
          top: areaLabelTop,
          angle: 0,
          fill: "#000",
          id: roomID,
          objectCaching: false,
          textAlign: "center",
          selectable: false,
          textAlign: "center",
          type: "CENTRE-BOX-TEXT",
          area: roomArea,
        });

        centreTextObject.set(
          "left",
          areaLabelLeft - centreTextObject.getBoundingRect().width / 2
        );

        centreTextObject.set(
          "top",
          areaLabelTop - centreTextObject.getBoundingRect().height / 2
        );

        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(
          centreTextObject
        );
        roomTextGroup.push(centreTextObject);
        this.canvas.add(centreTextObject);
      }

      //Draw Line Label on canvas

      for (
        var roomLinesGroupArrayIndex = 0;
        roomLinesGroupArrayIndex < roomLinesGroup.length;
        roomLinesGroupArrayIndex++
      ) {
        const indexedLine = roomLinesGroup[roomLinesGroupArrayIndex];
        const wallID = indexedLine.get("id");
        let sizes = indexedLine.get("unroundedsize").split(".");
        let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";
        let inch = sizes && sizes.length > 1 ? sizes[1] : "";
        let tempfootstring = tempFoot != "" ? tempFoot + "' " : "";
        let unRoundedSizeFeetLabel =
          tempfootstring + (inch != "" && inch > 0 ? inch + "''" : "");
        const coordinateForLable = coordinateForlable(
          indexedLine.x1,
          indexedLine.x2,
          indexedLine.y1,
          indexedLine.y2,
          areaLabelLeft,
          areaLabelTop
        );

        let text = new fabric.Text(unRoundedSizeFeetLabel, {
          fontFamily: '"Roboto", sans-serif',
          fontSize: this.state.baseFontSize,
          left: coordinateForLable.x,
          top: coordinateForLable.y,
          angle: coordinateForLable.orientation,
          fill: "#707070",
          id: wallID,
          roomID: roomID,
          objectCaching: false,
          type: "LABEL",
          selectable: false,
          originX: "center",
          originY: "center",
        });
        let midPointX = (indexedLine.x1 + indexedLine.x2) / 2; //mid-point of line
        let midPointY = (indexedLine.y1 + indexedLine.y2) / 2;
        text = getLabelPosition(
          text,
          midPointX,
          midPointY,
          coordinateForLable.orientation,
          poly.points,
          indexedLine,
          areaLabelLeft,
          areaLabelTop
        );
        roomTextGroup.push(text);
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
        if (parseFloat(indexedLine.get("unroundedsize")) > 2.5) {
          this.canvas.add(text);
        }
      }
    }
    this.createDoorsAndWindowsEditable();
    this.canvas.requestRenderAll();
  };

  /**
   * Purpose : This function will discard changes applied by autosnap
   */
  discardAutoDegree() {
    this.canvas.remove(
      this.canvas.getItemByAttr("ID", "line1-" + editedRoomID)
    );
    this.canvas.remove(
      this.canvas.getItemByAttr("ID", "line2-" + editedRoomID)
    );
    currentCircleEvent = null;
    this.setState({ is90Degree: true });
  }

  /**
   * Purpose : This function will apply changes by autosnap
   * @param {Event} e event object which allows to access line info
   */
  acceptAutoDegree(e) {
    const { t } = this.props;
    let isfallinline = true;
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let copydesignatorWiseObjectArray = _.cloneDeep(designatorWiseObjectArray);
    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let copyRoofPoints = _.cloneDeep(roofPoints);
    roomArray = Object.keys(designatorWiseObjectArray);

    let line1 = e.target.line1;
    let line2 = e.target.line2;
    let connecteddata = [];
    let basex = 0,
      basey = 0,
      nbasex = 0,
      nbasey = 0;
    const line1StartX = line1.x1,
      line1StartY = line1.y1,
      line1EndX = line1.x2,
      line1EndY = line1.y2,
      line2StartX = line2.x1,
      line2StartY = line2.y1,
      line2EndX = line2.x2,
      line2EndY = line2.y2;
    const denominator =
      (line2EndY - line2StartY) * (line1EndX - line1StartX) -
      (line2EndX - line2StartX) * (line1EndY - line1StartY);
    let a = line1StartY - line2StartY;
    let b = line1StartX - line2StartX;
    const numerator1 =
      (line2EndX - line2StartX) * a - (line2EndY - line2StartY) * b;
    const numerator2 =
      (line1EndX - line1StartX) * a - (line1EndY - line1StartY) * b;
    a = numerator1 / denominator;
    b = numerator2 / denominator;
    basex = line1StartX + a * (line1EndX - line1StartX);
    basey = line1StartY + a * (line1EndY - line1StartY);
    let angleDegl1 =
      (Math.atan2(line1.y2 - line1.y1, line1.x2 - line1.x1) * 180) / Math.PI;
    let angleDegl2 =
      (Math.atan2(line2.y1 - line2.y2, line2.x1 - line2.x2) * 180) / Math.PI;
    if (angleDegl1 % 45 != 0) {
      let rad = 0;
      angleDegl1 = this.getAcurateAngle(angleDegl1);
      if (line1.x1 == basex && line1.y1 == basey) {
        rad = fabric.util.degreesToRadians(angleDegl1);
        const diff = Math.sqrt(
          Math.pow(line1.x2 - line1.x1, 2) + Math.pow(line1.y2 - line1.y1, 2)
        );
        const updatedX = line1.x1 - diff * Math.cos(rad);
        const updatedY = line1.y1 - diff * Math.sin(rad);
        nbasex = updatedX;
        nbasey = updatedY;
        e.target.line1.set({ x2: updatedX, y2: updatedY });
        e.target.line1.setCoords();
      } else {
        rad = fabric.util.degreesToRadians(angleDegl1);
        const diff = Math.sqrt(
          Math.pow(line1.x1 - line1.x2, 2) + Math.pow(line1.y1 - line1.y2, 2)
        );
        const updatedX = line1.x2 - diff * Math.cos(rad);
        const updatedY = line1.y2 - diff * Math.sin(rad);
        nbasex = updatedX;
        nbasey = updatedY;
        e.target.line1.set({ x1: updatedX, y1: updatedY });
        e.target.line1.setCoords();
      }
      for (
        let roomArrayIndex = 0;
        roomArrayIndex < roomArray.length;
        roomArrayIndex++
      ) {
        let roomObjectArray =
          designatorWiseObjectArray[roomArray[roomArrayIndex]];
        for (
          let roomObjectArrayIndex = 0;
          roomObjectArrayIndex < roomObjectArray.length;
          roomObjectArrayIndex++
        ) {
          let wallObject = roomObjectArray[roomObjectArrayIndex];
          if (wallObject["@type"] != "ROOM") {
            var linePointObjectArray = wallObject.LINE.linePointObjectArray;
            for (
              let linePointObjectArrayInedex = 0;
              linePointObjectArrayInedex < linePointObjectArray.length;
              linePointObjectArrayInedex++
            ) {
              if (
                line1.linePointObjectArray[0]["@id"] ==
                linePointObjectArray[linePointObjectArrayInedex]["@id"]
              ) {
                let x = line1.x1 / this.ratio + this.minX;
                let y = line1.y1 / this.ratio + this.minY;
                linePointObjectArray[linePointObjectArrayInedex][
                  "@autoSnappedXY"
                ] = x + "," + y;
                linePointObjectArray[linePointObjectArrayInedex]["@editedXY"] =
                  x + "," + y;
                if (
                  wallObject["@id"] != line1.id &&
                  wallObject["@id"] != line2.id
                ) {
                  connecteddata.push({
                    wallID: wallObject["@id"],
                    id: line1.id,
                    data: linePointObjectArray,
                    basex: nbasex,
                    basey: nbasey,
                  });
                }
              } else if (
                line1.linePointObjectArray[1]["@id"] ==
                linePointObjectArray[linePointObjectArrayInedex]["@id"]
              ) {
                let x = line1.x2 / this.ratio + this.minX;
                let y = line1.y2 / this.ratio + this.minY;
                linePointObjectArray[linePointObjectArrayInedex][
                  "@autoSnappedXY"
                ] = x + "," + y;
                linePointObjectArray[linePointObjectArrayInedex]["@editedXY"] =
                  x + "," + y;
                if (
                  wallObject["@id"] != line1.id &&
                  wallObject["@id"] != line2.id
                ) {
                  connecteddata.push({
                    wallID: wallObject["@id"],
                    id: line1.id,
                    data: linePointObjectArray,
                    basex: nbasex,
                    basey: nbasey,
                  });
                }
              }
            }
            wallObject.LINE.linePointObjectArray = linePointObjectArray;
          }
          roomObjectArray[roomObjectArrayIndex] = wallObject;
        }
        designatorWiseObjectArray[roomArray[roomArrayIndex]] = roomObjectArray;
      }
      const parantwall = facesArray.filter((el) => el["@id"] == line1.id);
      const childIdsline = facesArray.filter((el) =>
        parantwall[0]["@children"].split(",").includes(el["@id"])
      );
      childIdsline.forEach((childObj) => {
        for (let lineindex = 0; lineindex < rooflines.length; lineindex++) {
          if (rooflines[lineindex]["@id"] == childObj.POLYGON["@path"]) {
            for (
              let roofPointsindex = 0;
              roofPointsindex < roofPoints.length;
              roofPointsindex++
            ) {
              if (
                rooflines[lineindex]["@path"]
                  .split(",")
                  .includes(roofPoints[roofPointsindex]["@id"])
              ) {
                const childRoofPoints =
                  roofPoints[roofPointsindex]["@editedXY"].split(",");
                let x =
                  (parseFloat(childRoofPoints[0]) - this.minX) * this.ratio;
                let y = parseFloat(childRoofPoints[1] - this.minY) * this.ratio;
                const diff = Math.sqrt(
                  Math.pow(x - basex, 2) + Math.pow(y - basey, 2)
                );
                const updatedX =
                  (basex - diff * Math.cos(rad)) / this.ratio + this.minX;
                const updatedY =
                  (basey - diff * Math.sin(rad)) / this.ratio + this.minY;
                roofPoints[roofPointsindex]["@autoSnappedXY"] =
                  updatedX + "," + updatedY;
                roofPoints[roofPointsindex]["@editedXY"] =
                  updatedX + "," + updatedY;
              }
            }
          }
        }
      });
    }
    if (angleDegl2 % 45 != 0) {
      let rad = 0;
      angleDegl2 = this.getAcurateAngle(angleDegl2);
      if (!(line1.x1 == basex && line1.y1 == basey)) {
        rad = fabric.util.degreesToRadians(angleDegl2);
        const diff = Math.sqrt(
          Math.pow(line2.x2 - line2.x1, 2) + Math.pow(line2.y2 - line2.y1, 2)
        );
        const updatedX = line2.x1 - diff * Math.cos(rad);
        const updatedY = line2.y1 - diff * Math.sin(rad);
        nbasex = updatedX;
        nbasey = updatedY;
        e.target.line2.set({ x2: updatedX, y2: updatedY });
        e.target.line2.setCoords();
      } else {
        rad = fabric.util.degreesToRadians(angleDegl2);
        const diff = Math.sqrt(
          Math.pow(line2.x1 - line2.x2, 2) + Math.pow(line2.y1 - line2.y2, 2)
        );
        const updatedX = line2.x2 - diff * Math.cos(rad);
        const updatedY = line2.y2 - diff * Math.sin(rad);
        nbasex = updatedX;
        nbasey = updatedY;
        e.target.line2.set({ x1: updatedX, y1: updatedY });
        e.target.line2.setCoords();
      }

      for (
        let roomArrayIndex = 0;
        roomArrayIndex < roomArray.length;
        roomArrayIndex++
      ) {
        let roomObjectArray =
          designatorWiseObjectArray[roomArray[roomArrayIndex]];
        for (
          let roomObjectArrayIndex = 0;
          roomObjectArrayIndex < roomObjectArray.length;
          roomObjectArrayIndex++
        ) {
          let wallObject = roomObjectArray[roomObjectArrayIndex];
          if (wallObject["@type"] != "ROOM") {
            var linePointObjectArray = wallObject.LINE.linePointObjectArray;
            for (
              let linePointObjectArrayInedex = 0;
              linePointObjectArrayInedex < linePointObjectArray.length;
              linePointObjectArrayInedex++
            ) {
              if (
                line2.linePointObjectArray[0]["@id"] ==
                linePointObjectArray[linePointObjectArrayInedex]["@id"]
              ) {
                let x = line2.x1 / this.ratio + this.minX;
                let y = line2.y1 / this.ratio + this.minY;
                linePointObjectArray[linePointObjectArrayInedex][
                  "@autoSnappedXY"
                ] = x + "," + y;
                linePointObjectArray[linePointObjectArrayInedex]["@editedXY"] =
                  x + "," + y;
                if (
                  wallObject["@id"] != line1.id &&
                  wallObject["@id"] != line2.id
                ) {
                  connecteddata.push({
                    wallID: wallObject["@id"],
                    id: line2.id,
                    data: linePointObjectArray,
                    basex: nbasex,
                    basey: nbasey,
                  });
                }
              } else if (
                line2.linePointObjectArray[1]["@id"] ==
                linePointObjectArray[linePointObjectArrayInedex]["@id"]
              ) {
                let x = line2.x2 / this.ratio + this.minX;
                let y = line2.y2 / this.ratio + this.minY;
                linePointObjectArray[linePointObjectArrayInedex][
                  "@autoSnappedXY"
                ] = x + "," + y;
                linePointObjectArray[linePointObjectArrayInedex]["@editedXY"] =
                  x + "," + y;
                if (
                  wallObject["@id"] != line1.id &&
                  wallObject["@id"] != line2.id
                ) {
                  connecteddata.push({
                    wallID: wallObject["@id"],
                    id: line2.id,
                    data: linePointObjectArray,
                    basex: nbasex,
                    basey: nbasey,
                  });
                }
              }
            }
            wallObject.LINE.linePointObjectArray = linePointObjectArray;
          }
          roomObjectArray[roomObjectArrayIndex] = wallObject;
        }
        designatorWiseObjectArray[roomArray[roomArrayIndex]] = roomObjectArray;
      }

      const parantwall = facesArray.filter((el) => el["@id"] == line2.id);
      const childIdsline = facesArray.filter((el) =>
        parantwall[0]["@children"].split(",").includes(el["@id"])
      );
      childIdsline.forEach((childObj) => {
        for (let lineindex = 0; lineindex < rooflines.length; lineindex++) {
          if (rooflines[lineindex]["@id"] == childObj.POLYGON["@path"]) {
            for (
              let roofPointsindex = 0;
              roofPointsindex < roofPoints.length;
              roofPointsindex++
            ) {
              if (
                rooflines[lineindex]["@path"]
                  .split(",")
                  .includes(roofPoints[roofPointsindex]["@id"])
              ) {
                const childRoofPoints =
                  roofPoints[roofPointsindex]["@editedXY"].split(",");
                let x =
                  (parseFloat(childRoofPoints[0]) - this.minX) * this.ratio;
                let y = parseFloat(childRoofPoints[1] - this.minY) * this.ratio;
                const diff = Math.sqrt(
                  Math.pow(x - basex, 2) + Math.pow(y - basey, 2)
                );
                const updatedX =
                  (basex - diff * Math.cos(rad)) / this.ratio + this.minX;
                const updatedY =
                  (basey - diff * Math.sin(rad)) / this.ratio + this.minY;
                roofPoints[roofPointsindex]["@autoSnappedXY"] =
                  updatedX + "," + updatedY;
                roofPoints[roofPointsindex]["@editedXY"] =
                  updatedX + "," + updatedY;
              }
            }
          }
        }
      });
    }
    connecteddata.forEach((element) => {
      const parantwall = facesArray.filter((el) => el["@id"] == element.wallID);
      const childIdsline = facesArray.filter((el) =>
        parantwall[0]["@children"].split(",").includes(el["@id"])
      );
      const x1 =
        (parseFloat(element.data[0]["@editedXY"].split(",")[0]) - this.minX) *
        this.ratio;
      const y1 =
        (parseFloat(element.data[0]["@editedXY"].split(",")[1]) - this.minY) *
        this.ratio;
      const x2 =
        (parseFloat(element.data[1]["@editedXY"].split(",")[0]) - this.minX) *
        this.ratio;
      const y2 =
        (parseFloat(element.data[1]["@editedXY"].split(",")[1]) - this.minY) *
        this.ratio;
      let angleDegl = 0,
        rad = 0;
      if (
        x1.toFixed(2) == element.basex.toFixed(2) &&
        y1.toFixed(2) == element.basey.toFixed(2)
      ) {
        basex = x2;
        basey = y2;
        angleDegl = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
        rad = fabric.util.degreesToRadians(angleDegl);
      } else {
        basex = x1;
        basey = y1;
        angleDegl = (Math.atan2(y1 - y2, x1 - x2) * 180) / Math.PI;
        rad = fabric.util.degreesToRadians(angleDegl);
      }
      childIdsline.forEach((childObj) => {
        for (let lineindex = 0; lineindex < rooflines.length; lineindex++) {
          if (rooflines[lineindex]["@id"] == childObj.POLYGON["@path"]) {
            for (
              let roofPointsindex = 0;
              roofPointsindex < roofPoints.length;
              roofPointsindex++
            ) {
              if (
                rooflines[lineindex]["@path"]
                  .split(",")
                  .includes(roofPoints[roofPointsindex]["@id"])
              ) {
                const childRoofPoints =
                  roofPoints[roofPointsindex]["@editedXY"].split(",");
                let x =
                  (parseFloat(childRoofPoints[0]) - this.minX) * this.ratio;
                let y = parseFloat(childRoofPoints[1] - this.minY) * this.ratio;
                const diff = Math.sqrt(
                  Math.pow(x - basex, 2) + Math.pow(y - basey, 2)
                );
                const diffmain = Math.sqrt(
                  Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)
                );
                if (diff > diffmain) {
                  isfallinline = false;
                }
                const updatedX =
                  (basex - diff * Math.cos(rad)) / this.ratio + this.minX;
                const updatedY =
                  (basey - diff * Math.sin(rad)) / this.ratio + this.minY;
                roofPoints[roofPointsindex]["@autoSnappedXY"] =
                  updatedX + "," + updatedY;
                roofPoints[roofPointsindex]["@editedXY"] =
                  updatedX + "," + updatedY;
              }
            }
          }
        }
      });
    });
    if (!isfallinline) {
      designatorWiseObjectArray = copydesignatorWiseObjectArray;
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
        copyRoofPoints;
      originalFloorPlan = _.cloneDeep(copyOriginal);
      customToast.error(t("COMMON_MESSAGES.AUTOSNAP_INSIDE_DOOR"));
    } else {
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
      originalFloorPlan = _.cloneDeep(copyOriginal);
      if (
        !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
          originalFloorPlan,
          designatorWiseObjectArray,
          floorId: this.state.selectedFloor,
        })
      ) {
        EditModeChanges.push({
          originalFloorPlan: _.cloneDeep(originalFloorPlan),
          designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
          floorId: this.state.selectedFloor,
        });
        this.setState({
          undocount: EditModeChanges.length,
        });
      }
      //this.calculateAreaByRoom(editedRoomID);
    }
    this.canvas.clear();
    this.setState({ doundo: true });
    this.drawFloorPlan();
    setTimeout(() => {
      this.canvas.remove(
        this.canvas.getItemByAttr("id", "GROUP-" + editedRoomID)
      );
      this.canvas.requestRenderAll();
      this.createEditableRoom(editedRoomID);
      let refeditedRoomID = editedRoomID;
      this.getEditedArea();
      this.editArea(true);
      this.canvas.clear();
      this.drawFloorPlan();
      setTimeout(() => {
        this.canvas.remove(
          this.canvas.getItemByAttr("id", "GROUP-" + refeditedRoomID)
        );
        this.canvas.requestRenderAll();
        this.createEditableRoom(refeditedRoomID);
      }, 50);
      currentCircleEvent = null;
      this.setState({ doundo: false });
    }, 50);
  }
  getEditedArea() {
    let object = null;
    let objects = this.canvas.getObjects();

    for (let i = 0, len = this.canvas.size(); i < len; i++) {
      object = objects[i];
      if (object.type == "CENTRE-BOX-TEXT") {
        const cordinateArray = [];
        for (let j = 0, len = this.canvas.size(); j < len; j++) {
          if (objects[j].type == "WALL-LINE") {
            cordinateArray.push(objects[j].x1);
            cordinateArray.push(objects[j].y1);
            cordinateArray.push(objects[j].x2);
            cordinateArray.push(objects[j].y2);
          }
        }

        let areaSum = 0;
        for (
          let i = 0, cordinateArrayIndex = cordinateArray.length - 2;
          i < cordinateArrayIndex;
          i += 2
        ) {
          areaSum +=
            cordinateArray[i] * cordinateArray[i + 3] -
            cordinateArray[i + 2] * cordinateArray[i + 1];
        }
        let calculatedArea =
          (Math.abs(areaSum / 2) *
            PIXEL_TO_FOOT_CONSTANT *
            PIXEL_TO_FOOT_CONSTANT) /
          (this.ratio * this.ratio);
        let tempCalculatedAreaInFoot = parseInt(calculatedArea);
        let tempCalculatedAreaPoints =
          calculatedArea - tempCalculatedAreaInFoot;
        let calculatedAreaInch = (tempCalculatedAreaPoints * 12) / 100;
        calculatedAreaInch = parseInt(calculatedAreaInch * 100);
        calculatedArea = calculatedArea.toFixed(2);
        object.area = calculatedArea.toString();
      } else if (object.type == "WALL-LINE") {
        let width1 =
          Math.sqrt(
            object.width * object.width + object.height * object.height
          ) * PIXEL_TO_FOOT_CONSTANT;

        width1 /= this.ratio;

        let tempFoot = parseInt(width1);
        let tempPoints = width1 - tempFoot;
        let inch = (tempPoints * 100 * 12) / 100;
        inch = parseInt(inch);
        let unroundedSize = tempFoot + "." + inch;
        object.unroundedsize = unroundedSize.toString();
        object.size = Math.ceil(parseFloat(unroundedSize)).toString();
      }
    }
  }
  addingMissingLinePointObjectArray(pointObj, roofPoints) {
    let linePointObjectArray = [];
    if (pointObj[0]["@path"].split(",").length == 2) {
      let pathstart = pointObj[0]["@path"].split(",")[0];
      let pathend = pointObj[0]["@path"].split(",")[1];
      let roofpointObjstart = roofPoints.filter((el) => el["@id"] == pathstart);

      linePointObjectArray.push(roofpointObjstart[0]);

      let roofpointObjend = roofPoints.filter((el) => el["@id"] == pathend);
      linePointObjectArray.push(roofpointObjend[0]);
    }
    return linePointObjectArray;
  }
  creatingLineObjectArray(facesArray, rooflines, roofPoints) {
    let designatorPartitionObject = {};
    let partinWiseObjArray = [];
    for (
      let faceArrayIndex = 0;
      faceArrayIndex < facesArray.length;
      faceArrayIndex++
    ) {
      let face = facesArray[faceArrayIndex];
      if (face["@type"] == "ROOM") {
        if (face["@childrenLine"] != "") {
          let childrenlineids = face["@childrenLine"].split(",");
          for (let i = 0; i < childrenlineids.length; i++) {
            let lineobj = facesArray.filter(
              (el) => el["@id"] == childrenlineids[i]
            );
            let polygon = lineobj[0]["POLYGON"];
            let pointObj = rooflines.filter(
              (el) => el["@id"] == polygon["@path"]
            );
            if (pointObj[0].linePointObjectArray == undefined) {
              pointObj[0].linePointObjectArray =
                this.addingMissingLinePointObjectArray(pointObj, roofPoints);
            }
            designatorPartitionObject = lineobj[0];
            designatorPartitionObject.LINE = pointObj[0];
            designatorPartitionObject.roomID = face["@id"];
            partinWiseObjArray.push(designatorPartitionObject);
          }
        }
        if (
          face["@partitionDoor"] != undefined &&
          face["@partitionDoor"] != ""
        ) {
          let childrenlineids = face["@partitionDoor"].split(",");
          for (let i = 0; i < childrenlineids.length; i++) {
            let lineobj = facesArray.filter(
              (el) => el["@id"] == childrenlineids[i]
            );
            let polygon = lineobj[0]["POLYGON"];
            let pointObj = rooflines.filter(
              (el) => el["@id"] == polygon["@path"]
            );
            if (pointObj[0].linePointObjectArray == undefined) {
              pointObj[0].linePointObjectArray =
                this.addingMissingLinePointObjectArray(pointObj, roofPoints);
            }
            designatorPartitionObject = lineobj[0];
            designatorPartitionObject.LINE = pointObj[0];
            designatorPartitionObject.roomID = face["@id"];
            partinWiseObjArray.push(designatorPartitionObject);
          }
        }
        if (
          face["@partitionWindow"] != undefined &&
          face["@partitionWindow"] != ""
        ) {
          let childrenlineids = face["@partitionWindow"].split(",");
          for (let i = 0; i < childrenlineids.length; i++) {
            let lineobj = facesArray.filter(
              (el) => el["@id"] == childrenlineids[i]
            );
            let polygon = lineobj[0]["POLYGON"];
            let pointObj = rooflines.filter(
              (el) => el["@id"] == polygon["@path"]
            );
            let parentLinePoints = partinWiseObjArray.filter(
              (el) => el["@id"] == lineobj[0]["@parentPartition"]
            )[0].LINE.linePointObjectArray;

            let linePointXYstart = parentLinePoints[0]["@editedXY"].split(",");
            let linePointXYend = parentLinePoints[1]["@editedXY"].split(",");

            if (pointObj[0].linePointObjectArray == undefined) {
              pointObj[0].linePointObjectArray =
                this.addingMissingLinePointObjectArray(pointObj, roofPoints);
            }
            pointObj[0][
              "@beforeautosnappedstartXY"
            ] = `${linePointXYstart[0]},${linePointXYstart[1]}`;
            pointObj[0][
              "@beforeautosnappedendXY"
            ] = `${linePointXYend[0]},${linePointXYend[1]}`;

            designatorPartitionObject = lineobj[0];
            designatorPartitionObject.LINE = pointObj[0];
            designatorPartitionObject.roomID = face["@id"];
            partinWiseObjArray.push(designatorPartitionObject);
          }
        }
      }
    }
    return partinWiseObjArray;
  }
  insertLineObjectIntoDesignatorArray(partinWiseObjArray) {
    let partinWiseArray = partinWiseObjArray;
    for (let j = 0; j < partinWiseArray.length; j++) {
      let res = designatorWiseObjectArray[partinWiseArray[j].roomID];
      res.push(partinWiseArray[j]);
    }
  }
  disbaleBuildMenu = () => {
    this.setState({
      isAddLabel: false,
      isAddPolylineFromBuildMenu: false,
      isAddLineFromBuildMenu: false,
      isAddDoorFromBuildMenu: false,
      isAddWindowFromBuildMenu: false,
    });
  };
  /**
   * Purpose : This function will apply apply autosnap to all the rooms on the floor
   */
  async acceptAutoDegreeAll() {
    let editedID = editedRoomID;
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let partinWiseObjArray = [];

    partinWiseObjArray = this.creatingLineObjectArray(
      facesArray,
      rooflines,
      roofPoints
    );
    this.insertLineObjectIntoDesignatorArray(partinWiseObjArray);

    roomArray = Object.keys(designatorWiseObjectArray);
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      let selectedFloorRoom = roomObjectArray.filter(
        (el) =>
          el["@type"] == "ROOM" && el["@floorindex"] == this.state.selectedFloor
      );
      if (selectedFloorRoom.length == 0) {
        continue;
      }
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        const roomObjectArrayClone = JSON.parse(
          JSON.stringify(roomObjectArray)
        );
        const roofPointsClone = JSON.parse(JSON.stringify(roofPoints));
        let isfallinline = true;
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        if (wallObject["@type"] != "ROOM" && wallObject["@type"] != "LABEL") {
          let linePointObjectArray = wallObject.LINE.linePointObjectArray;
          let point0x =
            (parseFloat(
              linePointObjectArray[0]["@autoSnappedXY"].split(",")[0]
            ) -
              this.minX) *
            this.ratio;
          let point0y =
            (parseFloat(
              linePointObjectArray[0]["@autoSnappedXY"].split(",")[1]
            ) -
              this.minY) *
            this.ratio;
          let point1x =
            (parseFloat(
              linePointObjectArray[1]["@autoSnappedXY"].split(",")[0]
            ) -
              this.minX) *
            this.ratio;
          let point1y =
            (parseFloat(
              linePointObjectArray[1]["@autoSnappedXY"].split(",")[1]
            ) -
              this.minY) *
            this.ratio;
          let angleDegl =
            (Math.atan2(point0y - point1y, point0x - point1x) * 180) / Math.PI;
          let connecteddata = [];
          if (angleDegl % 45 != 0) {
            let rad = 0;
            angleDegl = this.getAcurateAngle(angleDegl);
            rad = fabric.util.degreesToRadians(angleDegl);
            const diff = Math.sqrt(
              Math.pow(point1x - point0x, 2) + Math.pow(point1y - point0y, 2)
            );
            const updatedX = point0x - diff * Math.cos(rad);
            const updatedY = point0y - diff * Math.sin(rad);
            let x = updatedX / this.ratio + this.minX;
            let y = updatedY / this.ratio + this.minY;
            if (wallObject["@type"] == "LINE") {
              linePointObjectArray[1]["@autoSnappedXY"] = x + "," + y;
              linePointObjectArray[1]["@editedXY"] = x + "," + y;
            } else if (wallObject["@type"] == "PARTITION_WINDOW") {
              //window start and end points
              let windowstartXY =
                linePointObjectArray[0]["@editedXY"].split(",");
              let windowendXY = linePointObjectArray[1]["@editedXY"].split(",");

              let currentPointStartXYArray =
                wallObject.LINE["@beforeautosnappedstartXY"].split(","); //basepoint

              let currentPointEndXYArray =
                wallObject.LINE["@beforeautosnappedendXY"].split(",");

              let parentLineID = wallObject["@parentPartition"];
              let newLineAutoSnapPoints = partinWiseObjArray.filter(
                (el) => el["@id"] == parentLineID
              )[0].LINE.linePointObjectArray;

              let newlineEndPointXY =
                newLineAutoSnapPoints[1]["@autoSnappedXY"].split(",");

              let NewLineEndXY = [newlineEndPointXY[0], newlineEndPointXY[1]];

              let newWindowStartXY = FindNewCoordinates(
                [
                  parseFloat(currentPointStartXYArray[0]),
                  parseFloat(currentPointStartXYArray[1]),
                ],
                {
                  x: parseFloat(NewLineEndXY[0]),
                  y: parseFloat(NewLineEndXY[1]),
                },
                [
                  parseFloat(currentPointEndXYArray[0]),
                  parseFloat(currentPointEndXYArray[1]),
                ],
                [parseFloat(windowstartXY[0]), parseFloat(windowstartXY[1])]
              );
              let newWindowEndXY = FindNewCoordinates(
                [
                  parseFloat(currentPointStartXYArray[0]),
                  parseFloat(currentPointStartXYArray[1]),
                ],
                {
                  x: parseFloat(NewLineEndXY[0]),
                  y: parseFloat(NewLineEndXY[1]),
                },
                [
                  parseFloat(currentPointEndXYArray[0]),
                  parseFloat(currentPointEndXYArray[1]),
                ],
                [parseFloat(windowendXY[0]), parseFloat(windowendXY[1])]
              );

              linePointObjectArray[0][
                "@autoSnappedXY"
              ] = `${newWindowStartXY.x},${newWindowStartXY.y}`;
              linePointObjectArray[0][
                "@editedXY"
              ] = `${newWindowStartXY.x},${newWindowStartXY.y}`;
              linePointObjectArray[1][
                "@autoSnappedXY"
              ] = `${newWindowEndXY.x},${newWindowEndXY.y}`;
              linePointObjectArray[1][
                "@editedXY"
              ] = `${newWindowEndXY.x},${newWindowEndXY.y}`;
            } else if (wallObject["@type"] == "PARTITION_DOOR") {
              let parentPartition = wallObject["@parentPartition"];
              //connect line coordinates
              let connectDoorLine1Coordinate =
                parentPartition[0]["partitionCoord"];
              let connectDoorLine2Coordinate =
                parentPartition[1]["partitionCoord"];

              let line1ID = parentPartition[0]["line"]; //Line1
              let line2ID = parentPartition[1]["line"]; //Line2
              //door coordinate
              let partitionDoorStartCoordinate =
                parentPartition[0]["partitionDoorCoord"];
              let partitionDoorEndCoordinate =
                parentPartition[1]["partitionDoorCoord"];

              let line1PointObjectArray =
                designatorWiseObjectArray[roomArray[roomArrayIndex]].filter(
                  (el) => el["@id"] == line1ID
                )[0]?.LINE?.linePointObjectArray ?? undefined;

              let connectDoorCoordinateLine1 = line1PointObjectArray.filter(
                (el) => el["@id"] == connectDoorLine1Coordinate
              );

              let xcordinateautosnaped =
                connectDoorCoordinateLine1[0]["@autoSnappedXY"].split(",")[0];
              let ycordinateautosnaped =
                connectDoorCoordinateLine1[0]["@autoSnappedXY"].split(",")[1];

              let xcordinateeditedxy =
                connectDoorCoordinateLine1[0]["@editedXY"].split(",")[0];
              let ycordinateeditedxy =
                connectDoorCoordinateLine1[0]["@editedXY"].split(",")[1];

              linePointObjectArray[0][
                "@autoSnappedXY"
              ] = `${xcordinateautosnaped},${ycordinateautosnaped}`;
              linePointObjectArray[0][
                "@editedXY"
              ] = `${xcordinateeditedxy},${ycordinateeditedxy}`;

              let line2PointObjectArray = designatorWiseObjectArray[
                roomArray[roomArrayIndex]
              ].filter((el) => el["@id"] == line2ID)[0].LINE
                .linePointObjectArray;

              let connectDoorCoordinateLine2 = line2PointObjectArray.filter(
                (el) => el["@id"] == connectDoorLine2Coordinate
              );

              let xcordinateautosnaped1 =
                connectDoorCoordinateLine2[0]["@autoSnappedXY"].split(",")[0];
              let ycordinateautosnaped1 =
                connectDoorCoordinateLine2[0]["@autoSnappedXY"].split(",")[1];

              let xcordinateeditedxy1 =
                connectDoorCoordinateLine2[0]["@editedXY"].split(",")[0];
              let ycordinateeditedxy1 =
                connectDoorCoordinateLine2[0]["@editedXY"].split(",")[1];

              linePointObjectArray[1][
                "@autoSnappedXY"
              ] = `${xcordinateautosnaped1},${ycordinateautosnaped1}`;
              linePointObjectArray[1][
                "@editedXY"
              ] = `${xcordinateeditedxy1},${ycordinateeditedxy1}`;
            } else {
              linePointObjectArray[1]["@autoSnappedXY"] = x + "," + y;
            }
            wallObject.LINE.linePointObjectArray = linePointObjectArray;
            const parantwall = facesArray.filter(
              (el) => el["@id"] == wallObject["@id"]
            );
            const childIdsline = facesArray.filter((el) =>
              parantwall[0]["@children"].split(",").includes(el["@id"])
            );
            for (
              let roomObjectArrayIndexcon = 0;
              roomObjectArrayIndexcon < roomObjectArray.length;
              roomObjectArrayIndexcon++
            ) {
              let wallObjectconnected =
                roomObjectArray[roomObjectArrayIndexcon];
              if (wallObjectconnected["@type"] != "ROOM") {
                let linePointObjectArrayconnected =
                  wallObjectconnected.LINE.linePointObjectArray;
                for (
                  let linePointObjectArrayInedex = 0;
                  linePointObjectArrayInedex <
                  linePointObjectArrayconnected.length;
                  linePointObjectArrayInedex++
                ) {
                  if (wallObjectconnected["@id"] != wallObject["@id"]) {
                    if (
                      wallObject.LINE["@path"].split(",")[1] ==
                      linePointObjectArrayconnected[linePointObjectArrayInedex][
                        "@id"
                      ]
                    ) {
                      linePointObjectArrayconnected[linePointObjectArrayInedex][
                        "@autoSnappedXY"
                      ] = x + "," + y;
                      wallObjectconnected.LINE.linePointObjectArray =
                        linePointObjectArrayconnected;
                      connecteddata.push({
                        wallID: wallObjectconnected["@id"],
                        data: linePointObjectArrayconnected,
                        basex: updatedX,
                        basey: updatedY,
                      });
                      connecteddata.forEach((element) => {
                        let basex, basey, nbasex, nbasey;
                        const parantwall = facesArray.filter(
                          (el) => el["@id"] == element.wallID
                        );
                        const childIdsline = facesArray.filter((el) =>
                          parantwall[0]["@children"]
                            .split(",")
                            .includes(el["@id"])
                        );
                        const x1 =
                          (parseFloat(
                            element.data[0]["@autoSnappedXY"].split(",")[0]
                          ) -
                            this.minX) *
                          this.ratio;
                        const y1 =
                          (parseFloat(
                            element.data[0]["@autoSnappedXY"].split(",")[1]
                          ) -
                            this.minY) *
                          this.ratio;
                        const x2 =
                          (parseFloat(
                            element.data[1]["@autoSnappedXY"].split(",")[0]
                          ) -
                            this.minX) *
                          this.ratio;
                        const y2 =
                          (parseFloat(
                            element.data[1]["@autoSnappedXY"].split(",")[1]
                          ) -
                            this.minY) *
                          this.ratio;
                        let angleDegl = 0,
                          rad = 0;
                        if (
                          x1.toFixed(2) == element.basex.toFixed(2) &&
                          y1.toFixed(2) == element.basey.toFixed(2)
                        ) {
                          basex = x2;
                          basey = y2;
                          nbasex = x1;
                          nbasey = y1;
                          angleDegl =
                            (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI;
                          rad = fabric.util.degreesToRadians(angleDegl);
                        } else {
                          basex = x1;
                          basey = y1;
                          nbasex = x2;
                          nbasey = y2;
                          angleDegl =
                            (Math.atan2(y1 - y2, x1 - x2) * 180) / Math.PI;
                          rad = fabric.util.degreesToRadians(angleDegl);
                        }
                        childIdsline.forEach((childObj) => {
                          for (
                            let lineindex = 0;
                            lineindex < rooflines.length;
                            lineindex++
                          ) {
                            if (
                              rooflines[lineindex]["@id"] ==
                              childObj.POLYGON["@path"]
                            ) {
                              for (
                                let roofPointsindex = 0;
                                roofPointsindex < roofPoints.length;
                                roofPointsindex++
                              ) {
                                if (
                                  rooflines[lineindex]["@path"]
                                    .split(",")
                                    .includes(
                                      roofPoints[roofPointsindex]["@id"]
                                    )
                                ) {
                                  const childRoofPoints =
                                    roofPoints[roofPointsindex][
                                      "@autoSnappedXY"
                                    ].split(",");
                                  let x =
                                    (parseFloat(childRoofPoints[0]) -
                                      this.minX) *
                                    this.ratio;
                                  let y =
                                    parseFloat(childRoofPoints[1] - this.minY) *
                                    this.ratio;
                                  const diff = Math.sqrt(
                                    Math.pow(x - basex, 2) +
                                      Math.pow(y - basey, 2)
                                  );
                                  const ndiff = Math.sqrt(
                                    Math.pow(x - nbasex, 2) +
                                      Math.pow(y - nbasey, 2)
                                  );
                                  const diffmain = Math.sqrt(
                                    Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)
                                  );
                                  if (diff > diffmain || ndiff > diffmain) {
                                    isfallinline = false;
                                  }
                                  const updatedX =
                                    (basex - diff * Math.cos(rad)) /
                                      this.ratio +
                                    this.minX;
                                  const updatedY =
                                    (basey - diff * Math.sin(rad)) /
                                      this.ratio +
                                    this.minY;
                                  roofPoints[roofPointsindex][
                                    "@autoSnappedXY"
                                  ] = updatedX + "," + updatedY;
                                }
                              }
                            }
                          }
                        });
                      });

                      if (isfallinline) {
                        roomObjectArray[roomObjectArrayIndexcon] =
                          _.cloneDeep(wallObjectconnected);
                      } else {
                        roomObjectArray[roomObjectArrayIndexcon] = _.cloneDeep(
                          roomObjectArrayClone[roomObjectArrayIndexcon]
                        );
                        roofPoints = roofPointsClone;
                      }
                    }
                  }
                }
              }
              //roomObjectArray[roomObjectArrayIndex] = wallObjectconnected;
            }
            if (isfallinline) {
              childIdsline.forEach((childObj) => {
                for (
                  let lineindex = 0;
                  lineindex < rooflines.length;
                  lineindex++
                ) {
                  if (
                    rooflines[lineindex]["@id"] == childObj.POLYGON["@path"]
                  ) {
                    for (
                      let roofPointsindex = 0;
                      roofPointsindex < roofPoints.length;
                      roofPointsindex++
                    ) {
                      if (
                        rooflines[lineindex]["@path"]
                          .split(",")
                          .includes(roofPoints[roofPointsindex]["@id"])
                      ) {
                        const childRoofPoints =
                          roofPoints[roofPointsindex]["@autoSnappedXY"].split(
                            ","
                          );
                        let x =
                          (parseFloat(childRoofPoints[0]) - this.minX) *
                          this.ratio;
                        let y =
                          parseFloat(childRoofPoints[1] - this.minY) *
                          this.ratio;
                        const diff = Math.sqrt(
                          Math.pow(x - point0x, 2) + Math.pow(y - point0y, 2)
                        );
                        const updatedX =
                          (point0x - diff * Math.cos(rad)) / this.ratio +
                          this.minX;
                        const updatedY =
                          (point0y - diff * Math.sin(rad)) / this.ratio +
                          this.minY;
                        roofPoints[roofPointsindex]["@autoSnappedXY"] =
                          updatedX + "," + updatedY;
                      }
                    }
                  }
                }
              });
            }
            if (isfallinline) {
              roomObjectArray[roomObjectArrayIndex] = _.cloneDeep(wallObject);
            } else {
              roomObjectArray[roomObjectArrayIndex] = _.cloneDeep(
                roomObjectArrayClone[roomObjectArrayIndex]
              );
            }
          }
        }
      }
      designatorWiseObjectArray[roomArray[roomArrayIndex]] = roomObjectArray;
      //this.calculateAreaByRoom(roomArray[roomArrayIndex]);
      editedRoomID = roomArray[roomArrayIndex];
      this.createEditableRoom(roomArray[roomArrayIndex]);
    }
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
    originalFloorPlan = _.cloneDeep(copyOriginal);
    if (
      !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
        originalFloorPlan,
        designatorWiseObjectArray,
        floorId: this.state.selectedFloor,
      })
    ) {
      EditModeChanges.push({
        originalFloorPlan: _.cloneDeep(originalFloorPlan),
        designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
        floorId: this.state.selectedFloor,
      });
      this.setState({
        undocount: EditModeChanges.length,
      });
    }

    this.editArea(false);
    this.canvas.clear();
    this.drawFloorPlan();
    editedRoomID = editedID;
    setTimeout(() => {
      this.canvas.remove(
        this.canvas.getItemByAttr("id", "GROUP-" + editedRoomID)
      );
      this.canvas.requestRenderAll();
      this.createEditableRoom(editedRoomID);
      this.editArea(false);
      currentCircleEvent = null;
      this.setState({ doundo: false });
    }, 50);
  }

  /**
   * Purpose : This function will calculate area of given roomID
   * @param {String} editedRoomID selected roomID
   */
  calculateAreaByRoom(editedRoomID) {
    let roomArray = Object.keys(designatorWiseObjectArray);
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      if (roomArray[roomArrayIndex] != editedRoomID) {
        continue;
      }
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        if (
          wallObject["@type"] != "ROOM" &&
          ![
            "LINE",
            "LABEL",
            "PARTITION_DOOR",
            "PARTITION_WINDOW",
            "STAIR_CASE",
          ].includes(wallObject["@type"])
        ) {
          var linePointObjectArray = wallObject.LINE.linePointObjectArray;
          let x1 =
            (parseFloat(linePointObjectArray[0]["@editedXY"].split(",")[0]) -
              this.minX) *
            this.ratio;
          let y1 =
            (parseFloat(linePointObjectArray[0]["@editedXY"].split(",")[1]) -
              this.minY) *
            this.ratio;
          let x2 =
            (parseFloat(linePointObjectArray[1]["@editedXY"].split(",")[0]) -
              this.minX) *
            this.ratio;
          let y2 =
            (parseFloat(linePointObjectArray[1]["@editedXY"].split(",")[1]) -
              this.minY) *
            this.ratio;
          const line = new fabric.Line([x1, y1, x2, y2], {});
          let width1 =
            Math.sqrt(line.width * line.width + line.height * line.height) *
            PIXEL_TO_FOOT_CONSTANT;

          width1 /= this.ratio;

          let tempFoot = parseInt(width1);
          let tempPoints = width1 - tempFoot;
          let inch = (tempPoints * 100 * 12) / 100;
          inch = parseInt(inch);
          let unroundedSize = tempFoot + "." + inch;
          wallObject.POLYGON["@editedUnroundedsize"] = unroundedSize.toString();
          wallObject.POLYGON["@editedSize"] = Math.ceil(
            parseFloat(unroundedSize)
          ).toString();
        }
        if (wallObject["@type"] == "ROOM") {
          let cordinateArray = [];
          for (
            let roomArrayIndex = 0;
            roomArrayIndex < roomArray.length;
            roomArrayIndex++
          ) {
            if (roomArray[roomArrayIndex] != editedRoomID) {
              continue;
            }
            let roomObjectArray =
              designatorWiseObjectArray[roomArray[roomArrayIndex]];
            for (
              let roomObjectArrayIndex = 0;
              roomObjectArrayIndex < roomObjectArray.length;
              roomObjectArrayIndex++
            ) {
              let wallObject = roomObjectArray[roomObjectArrayIndex];
              if (
                wallObject["@type"] != "ROOM" &&
                ![
                  "LINE",
                  "LABEL",
                  "PARTITION_DOOR",
                  "PARTITION_WINDOW",
                  "STAIR_CASE",
                ].includes(wallObject["@type"])
              ) {
                var linePointObjectArray = wallObject.LINE.linePointObjectArray;
                let x1 =
                  (parseFloat(
                    linePointObjectArray[0]["@editedXY"].split(",")[0]
                  ) -
                    this.minX) *
                  this.ratio;
                let y1 =
                  (parseFloat(
                    linePointObjectArray[0]["@editedXY"].split(",")[1]
                  ) -
                    this.minY) *
                  this.ratio;
                let x2 =
                  (parseFloat(
                    linePointObjectArray[1]["@editedXY"].split(",")[0]
                  ) -
                    this.minX) *
                  this.ratio;
                let y2 =
                  (parseFloat(
                    linePointObjectArray[1]["@editedXY"].split(",")[1]
                  ) -
                    this.minY) *
                  this.ratio;
                cordinateArray.push(x1);
                cordinateArray.push(y1);
                cordinateArray.push(x2);
                cordinateArray.push(y2);
              }
            }
          }
          let areaSum = 0;
          for (
            let i = 0, cordinateArrayIndex = cordinateArray.length - 2;
            i < cordinateArrayIndex;
            i += 2
          ) {
            areaSum +=
              cordinateArray[i] * cordinateArray[i + 3] -
              cordinateArray[i + 2] * cordinateArray[i + 1];
          }
          let calculatedArea =
            (Math.abs(areaSum / 2) *
              PIXEL_TO_FOOT_CONSTANT *
              PIXEL_TO_FOOT_CONSTANT) /
            (this.ratio * this.ratio);
          let tempCalculatedAreaInFoot = parseInt(calculatedArea);
          let tempCalculatedAreaPoints =
            calculatedArea - tempCalculatedAreaInFoot;
          let calculatedAreaInch = (tempCalculatedAreaPoints * 12) / 100;
          calculatedAreaInch = parseInt(calculatedAreaInch * 100);
          calculatedArea = calculatedArea.toFixed(2);
          wallObject["@editedArea"] = calculatedArea.toString();
        }
        roomObjectArray[roomObjectArrayIndex] = wallObject;
      }
      designatorWiseObjectArray[roomArray[roomArrayIndex]] = roomObjectArray;
    }
  }

  /**
   * Purpose : This function will discard all changes applied to the floors plan and reset it
   * to the original floor plan as it was scaned
   */
  resetJSONToOriginal() {
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let linePoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    for (
      let roofPointsIndex = 0;
      roofPointsIndex < roofPoints.length;
      roofPointsIndex++
    ) {
      roofPoints[roofPointsIndex]["@editedXY"] =
        roofPoints[roofPointsIndex]["@dataXY"];
      roofPoints[roofPointsIndex]["@autoSnappedXY"] =
        roofPoints[roofPointsIndex]["@dataXY"];
      if (!_.isNil(roofPoints[roofPointsIndex]["@scaleX"])) {
        roofPoints[roofPointsIndex]["@scaleX"] = 1 / this.ratio;
        roofPoints[roofPointsIndex]["@scaleY"] = 1 / this.ratio;
      }
    }
    for (let faceIndex = 0; faceIndex < faceArray.length; faceIndex++) {
      delete faceArray[faceIndex]["@angle"];
      if (faceArray[faceIndex]["@type"] === "ROOM") {
        faceArray[faceIndex]["@labelAngle"] = 0;
        faceArray[faceIndex]["@areaLabelLeft"] = 0;
        faceArray[faceIndex]["@areaLabelTop"] = 0;
      }
      if (
        faceArray[faceIndex]["@type"] === "ROOM" &&
        faceArray[faceIndex]["@isFrom3D"]
      ) {
        [
          "@childrenLine",
          "@partitionDoor",
          "@childrenLabel",
          "@partitionWindow",
          "@childrenStairCase",
        ].forEach((_elems) => {
          faceArray[faceIndex][_elems] = faceArray
            .filter((_faceArray) => {
              return (
                _faceArray["@type"] !== "ROOM" &&
                _faceArray["@type"] !== "WALLPENETRATION" &&
                _faceArray["@isFrom3D"] &&
                faceArray[faceIndex][_elems]?.includes(_faceArray["@id"])
              );
            })
            ?.map((_faceArray) => _faceArray["@id"])
            ?.join(",");
        });
      } else {
        faceArray[faceIndex]["@childrenLabel"] = "";
        faceArray[faceIndex]["@childrenLine"] = "";
        faceArray[faceIndex]["@partitionDoor"] = "";
        faceArray[faceIndex]["@partitionWindow"] = "";
        faceArray[faceIndex]["@childrenStairCase"] = "";
      }
    }
    let newFacesArray = [];
    let newLinePoints = [];
    let newRoofPoints = [];
    let newLinePointIds = [];
    let newRoofPointIds = [];
    let childrenArray = {
      childrenLabel: [],
      childrenLine: [],
      partitionDoor: [],
      partitionWindow: [],
      children: [],
      childrenStairCase: [],
    };
    for (let faceIndex = 0; faceIndex < faceArray.length; faceIndex++) {
      if (
        (faceArray[faceIndex]["@type"] != "LABEL" &&
          faceArray[faceIndex]["@type"] != "LINE" &&
          faceArray[faceIndex]["@type"] != "PARTITION_DOOR" &&
          faceArray[faceIndex]["@type"] != "PARTITION_WINDOW" &&
          faceArray[faceIndex]["@type"] != "STAIR_CASE" &&
          faceArray[faceIndex]["@type"] != "WALLPENETRATION") ||
        faceArray[faceIndex]["@isFrom3D"]
      ) {
        newFacesArray.push(faceArray[faceIndex]);
        for (
          let linePointsIndex = 0;
          linePointsIndex < linePoints.length;
          linePointsIndex++
        ) {
          if (
            faceArray[faceIndex].POLYGON["@path"] ==
            linePoints[linePointsIndex]["@id"]
          ) {
            newLinePointIds.push(linePoints[linePointsIndex]["@id"]);
            for (
              let roofPointsIndex = 0;
              roofPointsIndex < roofPoints.length;
              roofPointsIndex++
            ) {
              if (
                linePoints[linePointsIndex]["@path"]
                  .split(",")
                  .includes(roofPoints[roofPointsIndex]["@id"])
              ) {
                newRoofPointIds.push(roofPoints[roofPointsIndex]["@id"]);
              }
            }
          }
        }
      } else {
        if (faceArray[faceIndex]["@type"] == "WALLPENETRATION") {
          childrenArray.children.push(faceArray[faceIndex]["@id"]);
        } else if (faceArray[faceIndex]["@type"] == "LABEL") {
          childrenArray.childrenLabel.push(faceArray[faceIndex]["@id"]);
        } else if (faceArray[faceIndex]["@type"] == "LINE") {
          childrenArray.childrenLine.push(faceArray[faceIndex]["@id"]);
        } else if (faceArray[faceIndex]["@type"] == "PARTITION_DOOR") {
          childrenArray.partitionDoor.push(faceArray[faceIndex]["@id"]);
        } else if (faceArray[faceIndex]["@type"] == "PARTITION_WINDOW") {
          childrenArray.partitionWindow.push(faceArray[faceIndex]["@id"]);
        } else if (faceArray[faceIndex]["@type"] == "STAIR_CASE") {
          childrenArray.childrenStairCase.push(faceArray[faceIndex]["@id"]);
        }
      }
    }
    newLinePointIds = _.uniq(newLinePointIds);
    newRoofPointIds = _.uniq(newRoofPointIds);

    for (
      let linePointsIndex = 0;
      linePointsIndex < linePoints.length;
      linePointsIndex++
    ) {
      if (newLinePointIds.includes(linePoints[linePointsIndex]["@id"])) {
        newLinePoints.push(linePoints[linePointsIndex]);
      }
    }

    for (
      let roofPointsIndex = 0;
      roofPointsIndex < roofPoints.length;
      roofPointsIndex++
    ) {
      if (newRoofPointIds.includes(roofPoints[roofPointsIndex]["@id"])) {
        newRoofPoints.push(roofPoints[roofPointsIndex]);
      }
    }
    newFacesArray = this.removeAllChildrens(newFacesArray, childrenArray);
    newLinePoints = this.resetLinePointObjectArray(newLinePoints);
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = newRoofPoints;
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE = newLinePoints;
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE = newFacesArray;
    originalFloorPlan = _.cloneDeep(copyOriginal);

    let roomArray = Object.keys(designatorWiseObjectArray);
    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        if (
          wallObject["@type"] != "ROOM" &&
          wallObject["@type"] != "LABEL" &&
          wallObject["@type"] != "STAIR_CASE"
        ) {
          let linePointObjectArray = wallObject.LINE.linePointObjectArray;
          linePointObjectArray[0]["@editedXY"] =
            linePointObjectArray[0]["@dataXY"];
          linePointObjectArray[0]["@autoSnappedXY"] =
            linePointObjectArray[0]["@dataXY"];
          linePointObjectArray[1]["@editedXY"] =
            linePointObjectArray[1]["@dataXY"];
          linePointObjectArray[1]["@autoSnappedXY"] =
            linePointObjectArray[1]["@dataXY"];
          wallObject.LINE.linePointObjectArray = linePointObjectArray;
        }
        roomObjectArray[roomObjectArrayIndex] = wallObject;
      }
      designatorWiseObjectArray[roomArray[roomArrayIndex]] = roomObjectArray;
      this.calculateAreaByRoom(roomArray[roomArrayIndex]);
      editedRoomID = roomArray[roomArrayIndex];
    }
    this.editArea(false);
    this.canvas.clear();
    this.drawFloorPlan();
    EditModeChanges = [];
    EditModeChanges.push({
      originalFloorPlan: _.cloneDeep(originalFloorPlan),
      designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
      floorId: this.state.selectedFloor,
    });
    this.setState({ undocount: EditModeChanges.length });
    editedRoomID = 0;
    //this.saveArea();
    isEditMode = false;
  }
  removeAllChildrens = (faceArray, childrenArray) => {
    for (let faceIndex = 0; faceIndex < faceArray.length; faceIndex++) {
      if (faceArray[faceIndex]["@children"]) {
        faceArray[faceIndex]["@children"] = faceArray[faceIndex]["@children"]
          .split(",")
          .filter((val) => !childrenArray.children.includes(val))
          .join(",");
      }
      if (faceArray[faceIndex]["@childrenLabel"]) {
        faceArray[faceIndex]["@childrenLabel"] = faceArray[faceIndex][
          "@childrenLabel"
        ]
          .split(",")
          .filter((val) => !childrenArray.childrenLabel.includes(val))
          .join(",");
      }
      if (faceArray[faceIndex]["@childrenLine"]) {
        faceArray[faceIndex]["@childrenLine"] = faceArray[faceIndex][
          "@childrenLine"
        ]
          .split(",")
          .filter((val) => !childrenArray.childrenLine.includes(val))
          .join(",");
      }
      if (faceArray[faceIndex]["@partitionDoor"]) {
        faceArray[faceIndex]["@partitionDoor"] = faceArray[faceIndex][
          "@partitionDoor"
        ]
          .split(",")
          .filter((val) => !childrenArray.partitionDoor.includes(val))
          .join(",");
      }
      if (faceArray[faceIndex]["@partitionWindow"]) {
        faceArray[faceIndex]["@partitionWindow"] = faceArray[faceIndex][
          "@partitionWindow"
        ]
          .split(",")
          .filter((val) => !childrenArray.partitionWindow.includes(val))
          .join(",");
      }
      if (faceArray[faceIndex]["@childrenStairCase"]) {
        faceArray[faceIndex]["@childrenStairCase"] = faceArray[faceIndex][
          "@childrenStairCase"
        ]
          .split(",")
          .filter((val) => !childrenArray.childrenStairCase.includes(val))
          .join(",");
      }
    }
    return faceArray;
  };

  resetLinePointObjectArray = (linePoints) => {
    for (let lineIndex = 0; lineIndex < linePoints.length; lineIndex++) {
      if (
        ["LINE", "PARTITION_DOOR", "PARTITION_WINDOW"].includes(
          linePoints[lineIndex]["@type"]
        ) &&
        !_.isEmpty(linePoints[lineIndex]?.linePointObjectArray)
      ) {
        let linePointObjectArray = linePoints[lineIndex].linePointObjectArray;
        linePointObjectArray[0]["@editedXY"] =
          linePointObjectArray[0]["@dataXY"];
        linePointObjectArray[0]["@autoSnappedXY"] =
          linePointObjectArray[0]["@dataXY"];
        linePointObjectArray[1]["@editedXY"] =
          linePointObjectArray[1]["@dataXY"];
        linePointObjectArray[1]["@autoSnappedXY"] =
          linePointObjectArray[1]["@dataXY"];
        linePoints[lineIndex].linePointObjectArray = linePointObjectArray;
      }
    }
    return linePoints;
  };
  /**
   * Purpose : This function will give nearest possible angle to the 45 degree fot the given angle
   * @param {int} angle the angle to make it rounded to 45
   */
  getAcurateAngle(angle) {
    if (angle >= -23 && angle <= 22.99) {
      return 0;
    } else if (angle >= 23 && angle <= 67.99) {
      return 45;
    } else if (angle >= 68 && angle <= 112.99) {
      return 90;
    } else if (angle >= 113 && angle <= 157.99) {
      return 135;
    } else if (angle >= 158) {
      return 180;
    } else if (angle <= -158) {
      return 180;
    } else if (angle >= -157.99 && angle <= -113) {
      return -135;
    } else if (angle >= -112.99 && angle <= -68) {
      return -90;
    } else if (angle <= -22.99 && angle >= -67.99) {
      return -45;
    }
  }

  inside(p, vs) {
    let inside = false;
    for (let i = 0, j = vs.length - 1; i < vs.length; j = i++) {
      let xi = vs[i].x,
        yi = vs[i].y;
      let xj = vs[j].x,
        yj = vs[j].y;
      let intersect =
        yi > p.y !== yj > p.y &&
        p.x < ((xj - xi) * (p.y - yi)) / (yj - yi) + xi;
      if (intersect) {
        inside = !inside;
      }
    }
    return inside;
  }

  // TODO: just returnig false, to remove restrictions on stairs and lables, keeping code here in case if needed in future
  restrictObject = (e) => {
    return false;
    let p = e.target;
    const roomdata = designatorWiseObjectArray[p.roomID].filter(
      (el) => el["@type"] == "WALL"
    );
    const cCoords = [],
      uncoods = [];
    roomdata.forEach((element) => {
      const point1 =
        element.LINE.linePointObjectArray[0]["@editedXY"].split(",");
      const point2 =
        element.LINE.linePointObjectArray[1]["@editedXY"].split(",");

      let datax = (parseFloat(point1[0]) - this.minX) * this.ratio;
      let datay = (parseFloat(point1[1]) - this.minY) * this.ratio;

      let datax1 = (parseFloat(point2[0]) - this.minX) * this.ratio;
      let datay1 = (parseFloat(point2[1]) - this.minY) * this.ratio;
      if (!uncoods.includes(datax + "," + datay)) {
        cCoords.push({ x: datax, y: datay });
        uncoods.push(datax + "," + datay);
      }
      if (!uncoods.includes(datax1 + "," + datay1)) {
        cCoords.push({ x: datax1, y: datay1 });
        uncoods.push(datax1 + "," + datay1);
      }
    });
    let inBounds = true;
    e.target.setCoords();
    e.target.saveState();
    if (inBounds) {
      inBounds = this.inside(
        { x: e.target.lineCoords.bl.x, y: e.target.lineCoords.bl.y },
        cCoords
      );
    }
    if (inBounds) {
      inBounds = this.inside(
        { x: e.target.lineCoords.br.x, y: e.target.lineCoords.br.y },
        cCoords
      );
    }
    if (inBounds) {
      inBounds = this.inside(
        { x: e.target.lineCoords.tl.x, y: e.target.lineCoords.tl.y },
        cCoords
      );
    }
    if (inBounds) {
      inBounds = this.inside(
        { x: e.target.lineCoords.tr.x, y: e.target.lineCoords.tr.y },
        cCoords
      );
    }

    if (!inBounds) {
      let copyOriginal = _.cloneDeep(originalFloorPlan);
      let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
      let roofPoints =
        copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
      let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
      for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
        if (facesArray[faceIndex]["@id"] != p.id) {
          continue;
        }
        for (
          let rooflineIndex = 0;
          rooflineIndex < rooflines.length;
          rooflineIndex++
        ) {
          if (
            facesArray[faceIndex].POLYGON["@path"] ==
            rooflines[rooflineIndex]["@id"]
          ) {
            for (
              let roofPointIndex = 0;
              roofPointIndex < roofPoints.length;
              roofPointIndex++
            ) {
              if (
                rooflines[rooflineIndex]["@path"] ==
                roofPoints[roofPointIndex]["@id"]
              ) {
                const point1 =
                  roofPoints[roofPointIndex]["@editedXY"].split(",");
                let datax = (parseFloat(point1[0]) - this.minX) * this.ratio;
                let datay = (parseFloat(point1[1]) - this.minY) * this.ratio;
                e.target.set({ left: datax, top: datay });
              }
            }
          }
        }
      }
      e.target.setCoords();
      e.target.saveState();
      return true;
    }
    return false;
  };

  /**
   * Purpose : This function will call whenever object will move or scale
   * @param {Event} options it'll be an object of event contain scalling information
   */
  onObjectChange = (options) => {
    let object = options.target;
    if (object.type == "GROUP") {
      this.canvas._objects = this.canvas._objects.filter(
        (val) => !(val.type == "CENTRE-BOX-TEXT" && val.id == object.roomID)
      );
    }
    if (
      object.type == "textLabel" ||
      object.type === "stair-case" ||
      object.type === "CENTRE-BOX-TEXT"
    ) {
      return;
    }
    //remove line for door while rotating room #start
    if (
      designatorWiseObjectArray[object.roomID] &&
      designatorWiseObjectArray[object.roomID].length > 0
    ) {
      let childdata = designatorWiseObjectArray[object.roomID]
        .filter((el) => el["@id"] != object.roomID)
        .map((el) => {
          return el["@children"].length > 0 ? el["@children"].split(",") : [];
        });
      let childdataLabel = designatorWiseObjectArray[object.roomID]
        .filter((el) => el["@id"] == object.roomID)
        .map((el) => {
          return el["@childrenLabel"] && el["@childrenLabel"].length > 0
            ? el["@childrenLabel"].split(",")
            : [];
        });
      childdata = childdata.concat(childdataLabel);
      let childdataLine = designatorWiseObjectArray[object.roomID]
        .filter((el) => el["@id"] == object.roomID)
        .map((el) => {
          return el["@childrenLine"] && el["@childrenLine"].length > 0
            ? el["@childrenLine"].split(",")
            : [];
        });
      childdata = childdata.concat(childdataLine);
      let childDataPartitionDoor = designatorWiseObjectArray[object.roomID]
        .filter((el) => el["@id"] == object.roomID)
        .map((el) => {
          return el["@partitionDoor"] && el["@partitionDoor"].length > 0
            ? el["@partitionDoor"].split(",")
            : [];
        });
      childdata = childdata.concat(childDataPartitionDoor);
      let childDataPartitionWindow = designatorWiseObjectArray[object.roomID]
        .filter((el) => el["@id"] == object.roomID)
        .map((el) => {
          return el["@partitionWindow"] && el["@partitionWindow"].length > 0
            ? el["@partitionWindow"].split(",")
            : [];
        });
      childdata = childdata.concat(childDataPartitionWindow);
      let childdataStairCase = designatorWiseObjectArray[object.roomID]
        .filter((el) => el["@id"] == object.roomID)
        .map((el) => {
          return el["@childrenStairCase"] && el["@childrenStairCase"].length > 0
            ? el["@childrenStairCase"].split(",")
            : [];
        });
      childdata = childdata.concat(childdataStairCase);
      let childIds = Object.keys(childdata).reduce(function (arr, key) {
        return arr.concat(childdata[key]);
      }, []);
      childIds.forEach((element) => {
        this.canvas.remove(this.canvas.getItemByAttr("id", element));
      });
    }
    //remove line for door while rotating room #end

    let angle = object.angle;
    let groupObjects = object?.getObjects();

    for (
      let groupSubObjectIndex = 0;
      groupSubObjectIndex < groupObjects.length;
      groupSubObjectIndex++
    ) {
      let subObject = groupObjects[groupSubObjectIndex];

      //object.calcTransformMatrix()

      if (subObject.type == "CENTRE-BOX-TEXT") {
        // subObject.angle = angle;
        // subObject.set("angle", -angle);
        subObject.visible = false;
      }
    }

    options.target.setCoords();
    this.canvas.forEachObject(function (obj) {
      if (obj === options.target) {
        return;
      }
      //obj.set('opacity', options.target.intersectsWithObject(obj) ? 0.5 : 1);
    });
  };

  /**
   * Purpose : This function will create and return circle object
   * @param {float} left left position of circle
   * @param {float} top top position of circle
   * @param {Line} line1 line object connect to the circle
   * @param {Line} line2 line object connect to the circle
   * @param {String} color color of the circle
   * @param {float} editedRoomAngle degree of angle to the circle to be rotated
   * @return {Circle} with new position
   */
  makeCircle(left, top, line1, line2, color = "red", editedRoomAngle = 0) {
    let c = new fabric.Circle({
      left: left,
      top: top,
      strokeWidth: 7,
      radius: 4,
      fill: "#fff",
      stroke: color,
      type: "connector",
      angle: editedRoomAngle,
      originX: "center",
      originY: "center",
    });
    c.hasControls = c.hasBorders = false;

    c.line1 = line1;
    c.line2 = line2;

    return c;
  }

  // x0 = x coordinate of first point
  // y0 = y coordinate of first point
  // x1 = x coordinate of Second point
  // y1 = y coordinate of Second point

  /**
   * Purpose : This function will give new position to the provided degree angle
   * @param {float} a x coordinate
   * @param {float} b y coordinate
   * @param {float} angle degree of angle to be rotated
   * @return {Point} with new position
   */
  rotate(a, b, angle) {
    // a and b are arrays of length 2 with the x, y coordinate of
    // your segments extreme points with the form [x, y]

    let midpoint = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];

    // Make the midpoint the origin
    let a_mid = [a[0] - midpoint[0], a[1] - midpoint[1]];
    let b_mid = [b[0] - midpoint[0], b[1] - midpoint[1]];

    // Use the rotation matrix from the paper you mentioned
    let a_rotated = [
      Math.cos(angle) * a_mid[0] - Math.sin(angle) * a_mid[1],
      Math.sin(angle) * a_mid[0] + Math.cos(angle) * a_mid[1],
    ];
    let b_rotated = [
      Math.cos(angle) * b_mid[0] - Math.sin(angle) * b_mid[1],
      Math.sin(angle) * b_mid[0] + Math.cos(angle) * b_mid[1],
    ];

    // Then add the midpoint coordinates to return to previous origin
    a_rotated[0] = a_rotated[0] + midpoint[0];
    a_rotated[1] = a_rotated[1] + midpoint[1];
    b_rotated[0] = b_rotated[0] + midpoint[0];
    b_rotated[1] = b_rotated[1] + midpoint[1];

    // And the rotation is now done
    return [a_rotated, b_rotated];
  }

  /**
   * Purpose : This function will rotate whole canvas to the provided degree angle
   * @param {float} angle degree of angle to be rotated
   */
  rotateCanvas = (degrees) => {
    FloorRotation = degrees;
    // this.updateFloorPlanOnMove("roomID", []);
    this.RotateFloor();
    this.canvas.clear();
    this.drawFloorPlan();
  };

  /**
   * Purpose : This function will calculate and return center point from provided cooedinates
   * @param {float} x0 x coordinate
   * @param {float} x1 x coordinate
   * @param {float} x2 x coordinate
   * @param {float} x3 x coordinate
   * @param {float} y0 y coordinate
   * @param {float} y1 y coordinate
   * @param {float} y2 y coordinate
   * @param {float} y3 y coordinate
   * @return {Point} center point
   */
  calculateCentrePoint(x0, x1, x2, x3, y0, y1, y2, y3) {
    let midPointX = (x0 + x1 + x2 + x3) / 4;
    let midPointY = (y0 + y1 + y2 + y3) / 4;

    return {
      x: midPointX,
      y: midPointY,
    };
  }

  /**
   * Purpose : This function will update JSON data base on line move distance, rotate angle
   * @param {String} roomID is of room to make changes
   * @param {Array} linesArray array of lines of the room
   */
  updateFloorPlanOnMove = (roomID, linesArray) => {
    let processedPionts = [];
    let copyOriginal = _.cloneDeep(originalFloorPlan);

    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let roofPointsArray =
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

    // designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
      if (
        roomFaceObject["@type"] == "ROOM" &&
        roomFaceObject["@id"] == roomID
      ) {
        const { MaxX, MinX, MaxY, MinY, cx, cy, RectX, RectY } =
          this.getCenterPointofObject(roomID);
        if (
          faceArray[faceArrayIndex]["@areaLabelLeft"] &&
          faceArray[faceArrayIndex]["@areaLabelTop"]
        ) {
          if (rotatedAngle != 0) {
            let updatedX =
              (parseFloat(faceArray[faceArrayIndex]["@areaLabelLeft"]) -
                this.minX) *
              this.ratio;

            let updatedY =
              (parseFloat(faceArray[faceArrayIndex]["@areaLabelTop"]) -
                this.minY) *
              this.ratio;
            let centerOrigin = new fabric.Point(RectX, RectY);
            let radians = fabric.util.degreesToRadians(rotatedAngle);
            let objectOrigin = new fabric.Point(updatedX, updatedY);
            let new_loc = fabric.util.rotatePoint(
              objectOrigin,
              centerOrigin,
              radians
            );
            updatedX = new_loc.x / this.ratio + this.minX;
            updatedY = new_loc.y / this.ratio + this.minY;
            faceArray[faceArrayIndex]["@areaLabelLeft"] = updatedX;
            faceArray[faceArrayIndex]["@areaLabelTop"] = updatedY;
            roomFaceObject["@areaLabelLeft"] = updatedX;
            roomFaceObject["@areaLabelTop"] = updatedY;
          } else if (
            editedRoomFinalLeftDist != 0 ||
            editedRoomFinalTopDist != 0
          ) {
            faceArray[faceArrayIndex]["@areaLabelLeft"] =
              parseFloat(faceArray[faceArrayIndex]["@areaLabelLeft"]) +
              editedRoomFinalLeftDist / this.ratio;
            faceArray[faceArrayIndex]["@areaLabelTop"] =
              parseFloat(faceArray[faceArrayIndex]["@areaLabelTop"]) +
              editedRoomFinalTopDist / this.ratio;
            roomFaceObject["@areaLabelLeft"] =
              faceArray[faceArrayIndex]["@areaLabelLeft"];
            roomFaceObject["@areaLabelTop"] =
              faceArray[faceArrayIndex]["@areaLabelTop"];
          }
        }
        //Update area of room

        //Get walls of room
        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");
        //if (rotatedAngle == 0) {
        let childrenLabel = roomFaceObject["@childrenLabel"];
        roomChildrenArray = childrenLabel
          ? roomChildrenArray.concat(childrenLabel.split(","))
          : roomChildrenArray;
        let childrenLine = roomFaceObject["@childrenLine"];
        roomChildrenArray = childrenLine
          ? roomChildrenArray.concat(childrenLine.split(","))
          : roomChildrenArray;
        let childrenPartitionDoor = roomFaceObject["@partitionDoor"];
        roomChildrenArray = childrenPartitionDoor
          ? roomChildrenArray.concat(childrenPartitionDoor.split(","))
          : roomChildrenArray;
        let childrenPartitionWindow = roomFaceObject["@partitionWindow"];
        roomChildrenArray = childrenPartitionWindow
          ? roomChildrenArray.concat(childrenPartitionWindow.split(","))
          : roomChildrenArray;
        let childrenStairCase = roomFaceObject["@childrenStairCase"];
        roomChildrenArray = childrenStairCase
          ? roomChildrenArray.concat(childrenStairCase.split(","))
          : roomChildrenArray;
        //}

        //Not iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];

            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              //dwnew
              var childlines = [];
              if (faceObject["@type"] == "WALL") {
                let dw = faceArray.filter((el) =>
                  faceObject["@children"].split(",").includes(el["@id"])
                );
                dw.forEach((elementdw) => {
                  childlines.push(elementdw.POLYGON["@path"]);
                });
              }
              //dwnew
              let lineId = faceObject["POLYGON"]["@path"];
              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                //dwnew
                if (
                  lineObject["@id"] == lineId ||
                  childlines.includes(lineObject["@id"])
                ) {
                  //dwnew
                  let linePointObjectArray = [];
                  let linePoints = lineObject["@path"].split(",");

                  for (
                    let linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];

                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        if (
                          processedPionts.includes(linePoints[linePointsIndex])
                        ) {
                          roofPointObject["@dataXY"] =
                            roofPointObject["@dataXY"];
                          roofPointObject["@editedXY"] =
                            roofPointObject["@editedXY"];
                          roofPointObject["@autoSnappedXY"] =
                            roofPointObject["@autoSnappedXY"];
                        } else {
                          const editModeDataXYKeyCLone = editModeDataXYKey;
                          editModeDataXYKeyCLone.forEach((element) => {
                            let dataXY = roofPointObject[element].split(",");
                            let updatedX =
                              (parseFloat(dataXY[0]) - this.minX) * this.ratio;

                            let updatedY =
                              (parseFloat(dataXY[1]) - this.minY) * this.ratio;
                            if (rotatedAngle != 0) {
                              let centerOrigin = new fabric.Point(RectX, RectY);
                              let radians =
                                fabric.util.degreesToRadians(rotatedAngle);
                              const x =
                                (parseFloat(dataXY[0]) - this.minX) *
                                this.ratio;
                              const y =
                                (parseFloat(dataXY[1]) - this.minY) *
                                this.ratio;
                              let objectOrigin = new fabric.Point(x, y);
                              let new_loc = fabric.util.rotatePoint(
                                objectOrigin,
                                centerOrigin,
                                radians
                              );
                              updatedX = new_loc.x / this.ratio + this.minX;
                              updatedY = new_loc.y / this.ratio + this.minY;
                            } else if (
                              editedRoomFinalLeftDist != 0 ||
                              editedRoomFinalTopDist != 0
                            ) {
                              updatedX =
                                parseFloat(dataXY[0]) +
                                editedRoomFinalLeftDist / this.ratio;
                              updatedY =
                                parseFloat(dataXY[1]) +
                                editedRoomFinalTopDist / this.ratio;
                            }
                            dataXY = updatedX + "," + updatedY;
                            roofPointObject[element] = dataXY;
                          });
                          processedPionts.push(linePoints[linePointsIndex]);
                        }
                        linePointObjectArray.push(roofPointObject);
                      }
                    }
                  }
                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;
                  if (
                    !childlines.includes(lineObject["@id"]) &&
                    faceObject["@type"] != "LABEL" &&
                    faceObject["@type"] != "STAIR_CASE" &&
                    faceObject["@type"] != "LINE" &&
                    faceObject["@type"] != "PARTITION_DOOR" &&
                    faceObject["@type"] != "PARTITION_WINDOW"
                  ) {
                    faceObject["LINE"] = lineObject;
                    faceArray[wallFaceObjectIndex] = faceObject;
                  } else {
                    faceArray.map((el) => {
                      return el.POLYGON["@path"] == lineObject["@id"]
                        ? (el["LINE"] = lineObject)
                        : el;
                    });
                  }
                }
              }
              if (
                faceObject["@type"] != "LABEL" &&
                faceObject["@type"] != "STAIR_CASE" &&
                faceObject["@type"] != "LINE" &&
                faceObject["@type"] != "PARTITION_DOOR" &&
                faceObject["@type"] != "PARTITION_WINDOW"
              ) {
                designatorWiseObjectArray[roomFaceObject["@id"]].push(
                  faceObject
                );
              }
            } else {
              //TBD:Not in use.
            }
          }
        }
      }
    }
    originalFloorPlan = _.cloneDeep(copyOriginal);
    rotatedAngle = editedRoomAngle = 0;
    if (
      !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
        originalFloorPlan,
        designatorWiseObjectArray,
        floorId: this.state.selectedFloor,
      })
    ) {
      EditModeChanges.push({
        originalFloorPlan: _.cloneDeep(originalFloorPlan),
        designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
        floorId: this.state.selectedFloor,
      });
      this.setState({
        undocount: EditModeChanges.length,
      });
    }
  };

  /**
   * Purpose : This function will update JSON data base on line move distance, rotate angle
   * @param {int} selectedFloor is of Floor to make changes
   * @param {Array} linesArray array of lines of the room
   */
  updateFloorPlanOnRotate = (selectedFloor, linesArray) => {
    let processedPionts = [];
    const { cx, cy } = this.getCenterPointofFloor(selectedFloor);
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    let faceArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let roofPointsArray =
      copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

    // designatorWiseObjectArray = {};

    let roomChildrenArray = [];

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let roomFaceObject = _.cloneDeep(faceArray[faceArrayIndex]);
      if (
        roomFaceObject["@type"] == "ROOM" &&
        roomFaceObject["@floorindex"] == selectedFloor
      ) {
        //Update area of room

        //Get walls of room
        roomChildrenArray = [];
        designatorWiseObjectArray[roomFaceObject["@id"]] = [];

        designatorWiseObjectArray[roomFaceObject["@id"]].push(roomFaceObject);

        let children = roomFaceObject["@children"];
        roomChildrenArray = children.split(",");
        let childrenLabel = roomFaceObject["@childrenLabel"];
        roomChildrenArray = childrenLabel
          ? roomChildrenArray.concat(childrenLabel.split(","))
          : roomChildrenArray;
        let childrenLine = roomFaceObject["@childrenLine"];
        roomChildrenArray = childrenLine
          ? roomChildrenArray.concat(childrenLine.split(","))
          : roomChildrenArray;
        let childrenPartitionDoor = roomFaceObject["@partitionDoor"];
        roomChildrenArray = childrenPartitionDoor
          ? roomChildrenArray.concat(childrenPartitionDoor.split(","))
          : roomChildrenArray;
        let childrenPartitionWindow = roomFaceObject["@partitionWindow"];
        roomChildrenArray = childrenPartitionWindow
          ? roomChildrenArray.concat(childrenPartitionWindow.split(","))
          : roomChildrenArray;
        let childrenStairCase = roomFaceObject["@childrenStairCase"];
        roomChildrenArray = childrenStairCase
          ? roomChildrenArray.concat(childrenStairCase.split(","))
          : roomChildrenArray;

        //Not iterate room child...

        for (
          let roomChildrenIndex = 0;
          roomChildrenIndex < roomChildrenArray.length;
          roomChildrenIndex++
        ) {
          let roomId = roomChildrenArray[roomChildrenIndex];
          //Loop to iterate face object again. Later we'll manage processed ids

          for (
            let wallFaceObjectIndex = 0;
            wallFaceObjectIndex < faceArray.length;
            wallFaceObjectIndex++
          ) {
            let faceObject = faceArray[wallFaceObjectIndex];

            if (
              faceObject["POLYGON"]["@path"].trim().length > 0 &&
              roomId == faceObject["@id"]
            ) {
              //dwnew
              let childlines = [];
              if (faceObject["@type"] == "WALL") {
                let dw = faceArray.filter((el) =>
                  faceObject["@children"].split(",").includes(el["@id"])
                );
                dw.forEach((elementdw) => {
                  childlines.push(elementdw.POLYGON["@path"]);
                });
              }
              //dwnew
              let lineId = faceObject["POLYGON"]["@path"];
              if (faceObject["@type"] === "STAIR_CASE") {
                faceObject["@angle"] = !_.isNil(faceObject["@angle"])
                  ? parseFloat(faceObject["@angle"]) + FloorRotation
                  : FloorRotation;
              }
              //Find Line For child
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (childlines.includes(lineObject["@id"])) {
                  let linePointObjectArray = [];
                  let linePoints = lineObject["@path"].split(",");

                  for (
                    let linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];

                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        const editModeDataXYKeyCLone = editModeDataXYKey;
                        editModeDataXYKeyCLone.forEach((element) => {
                          let dataXY = roofPointObject[element].split(",");
                          let updatedX =
                            (parseFloat(dataXY[0]) - this.minX) * this.ratio;
                          let updatedY =
                            (parseFloat(dataXY[1]) - this.minY) * this.ratio;
                          if (FloorRotation != 0) {
                            let centerOrigin = new fabric.Point(cx, cy);
                            let radians =
                              fabric.util.degreesToRadians(FloorRotation);
                            const x =
                              (parseFloat(dataXY[0]) - this.minX) * this.ratio;
                            const y =
                              (parseFloat(dataXY[1]) - this.minY) * this.ratio;
                            let objectOrigin = new fabric.Point(x, y);
                            let new_loc = fabric.util.rotatePoint(
                              objectOrigin,
                              centerOrigin,
                              radians
                            );
                            updatedX = new_loc.x / this.ratio + this.minX;
                            updatedY = new_loc.y / this.ratio + this.minY;
                          }
                          dataXY = updatedX + "," + updatedY;
                          roofPointObject[element] = dataXY;
                        });
                        linePointObjectArray.push(roofPointObject);
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;
                }
              }
              //Find Line
              for (
                let lineArrayIndex = 0;
                lineArrayIndex < linesArray.length;
                lineArrayIndex++
              ) {
                let lineObject = linesArray[lineArrayIndex];
                if (lineObject["@id"] == lineId) {
                  let linePointObjectArray = [];
                  let linePoints = lineObject["@path"].split(",");

                  for (
                    let linePointsIndex = 0;
                    linePointsIndex < linePoints.length;
                    linePointsIndex++
                  ) {
                    for (
                      let roofPointsArrayIndex = 0;
                      roofPointsArrayIndex < roofPointsArray.length;
                      roofPointsArrayIndex++
                    ) {
                      let roofPointObject =
                        roofPointsArray[roofPointsArrayIndex];

                      if (
                        roofPointObject["@id"] == linePoints[linePointsIndex]
                      ) {
                        if (
                          processedPionts.includes(linePoints[linePointsIndex])
                        ) {
                          roofPointObject["@dataXY"] =
                            roofPointObject["@dataXY"];
                          roofPointObject["@editedXY"] =
                            roofPointObject["@editedXY"];
                          roofPointObject["@autoSnappedXY"] =
                            roofPointObject["@autoSnappedXY"];
                        } else {
                          const editModeDataXYKeyCLone = editModeDataXYKey;
                          editModeDataXYKeyCLone.forEach((element) => {
                            let dataXY = roofPointObject[element].split(",");
                            let updatedX =
                              (parseFloat(dataXY[0]) - this.minX) * this.ratio;
                            let updatedY =
                              (parseFloat(dataXY[1]) - this.minY) * this.ratio;
                            if (FloorRotation != 0) {
                              let centerOrigin = new fabric.Point(cx, cy);
                              let radians =
                                fabric.util.degreesToRadians(FloorRotation);
                              const x =
                                (parseFloat(dataXY[0]) - this.minX) *
                                this.ratio;
                              const y =
                                (parseFloat(dataXY[1]) - this.minY) *
                                this.ratio;
                              let objectOrigin = new fabric.Point(x, y);
                              let new_loc = fabric.util.rotatePoint(
                                objectOrigin,
                                centerOrigin,
                                radians
                              );
                              updatedX = new_loc.x / this.ratio + this.minX;
                              updatedY = new_loc.y / this.ratio + this.minY;
                            }
                            dataXY = updatedX + "," + updatedY;
                            roofPointObject[element] = dataXY;
                          });
                          processedPionts.push(linePoints[linePointsIndex]);
                        }
                        linePointObjectArray.push(roofPointObject);
                      }
                    }
                  }

                  lineObject["linePointObjectArray"] = linePointObjectArray;
                  linesArray[lineArrayIndex] = lineObject;

                  faceObject["LINE"] = lineObject;
                  faceArray[wallFaceObjectIndex] = faceObject;
                }
              }
              if (
                faceObject["@type"] != "LABEL" &&
                faceObject["@type"] != "LINE" &&
                faceObject["@type"] != "PARTITION_DOOR" &&
                faceObject["@type"] != "PARTITION_WINDOW" &&
                faceObject["@type"] != "STAIR_CASE"
              ) {
                designatorWiseObjectArray[roomFaceObject["@id"]].push(
                  faceObject
                );
              }
            } else {
              //TBD:Not in use.
            }
          }
        }
      }
    }
    originalFloorPlan = _.cloneDeep(copyOriginal);
    rotatedAngle = editedRoomAngle = 0;
    FloorRotation = 0;
    if (
      !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
        originalFloorPlan,
        designatorWiseObjectArray,
        floorId: this.state.selectedFloor,
      })
    ) {
      EditModeChanges.push({
        originalFloorPlan: _.cloneDeep(originalFloorPlan),
        designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
        floorId: this.state.selectedFloor,
      });
      this.setState({
        undocount: EditModeChanges.length,
      });
    }
  };

  /**
   * Purpose : This function will zoom object based on type
   * @param {String} type zoomin/zoomout
   */
  doZoom = (type) => {
    let obj = this.canvas.getObjects();
    obj.forEach((element) => {
      if (element.isEditing) {
        element.exitEditing();
      }
    });
    const currentZoom = this.canvas.getZoom();
    let fontScale = 1;
    let nextZoom = currentZoom;
    if (type == "in") {
      nextZoom = currentZoom * 1.1;
      fontScale = fontScale * 1.1;
      if (nextZoom > 20) {
        nextZoom = 20;
      }
    } else if (type == "out") {
      nextZoom = currentZoom / 1.1;
      fontScale = fontScale / 1.1;
      if (nextZoom < 0.01) {
        nextZoom = 0.01;
      }
    }
    const zoompoint = new fabric.Point(
      this.canvas.width / 2,
      this.canvas.height / 2
    );

    this.canvas.setZoom(nextZoom);

    let object = null;
    let objects = this.canvas.getObjects();

    for (
      let canvasObjectIndex = 0;
      canvasObjectIndex < objects.length;
      canvasObjectIndex++
    ) {
      let roomID = objects[canvasObjectIndex].roomID;
      let groupWidth = objects[canvasObjectIndex].width;
      let groupHeight = objects[canvasObjectIndex].height;
      if (objects[canvasObjectIndex].getObjects == null) {
        return;
      }

      let groupObject = objects[canvasObjectIndex].getObjects();

      for (
        let groupSubObjectIndex = 0;
        groupSubObjectIndex < groupObject.length;
        groupSubObjectIndex++
      ) {
        let object = groupObject[groupSubObjectIndex];

        //object.calcTransformMatrix()

        if (object.type == "CENTRE-BOX-TEXT") {
          let fontSize = parseFloat(object["fontSize"]);

          let width = object.width;

          if (
            type == "in" &&
            width + 60 <= groupWidth &&
            fontSize * fontScale < MAX_FONT_SIZE &&
            fontSize * fontScale > MIN_FONT_SIZE
          ) {
            fontSize *= fontScale;
            object.set("fontSize", fontSize);
            roomWiseFontSize[roomID] = fontSize;
          } else if (
            width + 60 <= groupWidth &&
            fontSize * fontScale < MAX_FONT_SIZE &&
            fontSize * fontScale > MIN_FONT_SIZE
          ) {
            fontSize *= fontScale;
            object.set("fontSize", fontSize);
            roomWiseFontSize[roomID] = fontSize;
          }
        } else if (object.type == "LABEL") {
          let fontSize = parseFloat(object["fontSize"]);
          fontSize *= fontScale;
          object.set("fontSize", fontSize);
        } else if (object.type == "MEASUREMENT-BOX-TEXT-GROUP") {
          let subgroupObjects = object.getObjects();
          for (let obj = 0; obj < subgroupObjects.length; obj++) {
            let subObject = subgroupObjects[obj];
            if (subObject.type == "MEASUREMENT-BOX-TEXT") {
              let fontSize = parseFloat(subObject["fontSize"]);
              let width = subObject.width;
              if (
                type == "in" &&
                width + 60 <= groupWidth &&
                fontSize * fontScale < MAX_FONT_SIZE &&
                fontSize * fontScale > MIN_FONT_SIZE
              ) {
                fontSize *= fontScale;
                subObject.set("fontSize", fontSize);
                roomWiseFontSize[roomID] = fontSize;
              } else if (
                width + 60 <= groupWidth &&
                fontSize * fontScale < MAX_FONT_SIZE &&
                fontSize * fontScale > MIN_FONT_SIZE
              ) {
                fontSize *= fontScale;
                subObject.set("fontSize", fontSize);
                roomWiseFontSize[roomID] = fontSize;
              }
            }
          }
        }
      }
    }

    this.canvas.renderAll();
  };

  /**
   * Purpose : This function will move object based on side
   * @param {String} side left/right/up/down
   */
  doNavigate = (side) => {
    const units = 10;
    let delta = null;
    if (side == "left") {
      delta = new fabric.Point(-units, 0);
    } else if (side == "right") {
      delta = new fabric.Point(units, 0);
    } else if (side == "up") {
      delta = new fabric.Point(0, -units);
    } else if (side == "down") {
      delta = new fabric.Point(0, units);
    }
    if (delta != null) {
      this.canvas.relativePan(delta);
    }
  };

  /**
   * Purpose : This function will show hide area details
   */
  toggleAreaDetails = () => {
    this.setState({
      showAreaDetails: !this.state.showAreaDetails,
      areaDetails: designatorWiseObjectArray,
    });
  };

  /**
   * Purpose : This function will show hide area name in room
   */
  toggleAreaName = () => {
    this.setState({ isShowAreaName: !this.state.isShowAreaName }, () => {
      this.canvas.clear();
      this.drawFloorPlan();
    });
  };

  /**
   * Purpose : This function will toogle edit mode of selecte room
   */
  toggleEditMode = () => {
    if (this.state.isEditModeEnabled) {
      removePartitionCircle(this);
    }
    this.canvas.clear();
    this.drawFloorPlan();
    this.setState({
      isAddLabel: false,
      isAddPolylineFromBuildMenu: false,
      isAddLineFromBuildMenu: false,
      isAddDoorFromBuildMenu: false,
      isAddWindowFromBuildMenu: false,
    });
    this.setState({ isEditModeEnabled: !this.state.isEditModeEnabled }, () => {
      if (this.state.isEditModeEnabled) {
        this.canvas._objects = this.canvas._objects.filter(
          (val) => val.type != "doorobject"
        );
        this.canvas.renderAll();
      } else {
        editedRoomID = 0;
        isEditMode = false;
      }
    });
  };

  toggleAddLabel = () => {
    const { t } = this.props;
    if (
      this.state.isEditModeEnabled &&
      (this.state.selectedFloor == "4" ||
        this.state.selectedMeasurementType == "2" ||
        this.state.selectedMeasurementType == "3" ||
        this.state.selectedMeasurementType == "4")
    ) {
      // make a copy of the object which has fabric wall-line objects.
      const ___roomWiseLineAndTextObjectsCopy = {
        ...roomWiseLineAndTextObjects,
      };
      const ___roomWiseLineAndTextObjects = {};

      this.canvas
        .getObjects()
        .filter((x) => x.type === "GROUP")
        .forEach((x) => {
          ___roomWiseLineAndTextObjects[x.roomID] =
            ___roomWiseLineAndTextObjectsCopy[x.roomID];
        });
      this.removeAllWallLines(___roomWiseLineAndTextObjects);
      removePartitionCircle(this, true);

      this.setState({
        isAddLabel: !this.state.isAddLabel,
        isAddPolylineFromBuildMenu: false,
        isAddLineFromBuildMenu: false,
        isAddDoorFromBuildMenu: false,
        isAddWindowFromBuildMenu: false,
      });
    } else if (!this.state.isEditModeEnabled) {
      customToast.error(t("COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Label"));
    } else if (this.state.selectedFloor != "4") {
      customToast.error(t("COMMON_MESSAGES.REQUIRED_ROOM_SELECTION"));
    }
  };

  toggleAddStairCase = () => {
    const { t } = this.props;
    if (
      this.state.isEditModeEnabled &&
      (this.state.selectedFloor == "4" ||
        this.state.selectedMeasurementType == "2" ||
        this.state.selectedMeasurementType == "3" ||
        this.state.selectedMeasurementType == "4")
    ) {
      // make a copy of the object which has fabric wall-line objects.
      const ___roomWiseLineAndTextObjectsCopy = {
        ...roomWiseLineAndTextObjects,
      };
      const ___roomWiseLineAndTextObjects = {};

      this.canvas
        .getObjects()
        .filter((x) => x.type === "GROUP")
        .forEach((x) => {
          ___roomWiseLineAndTextObjects[x.roomID] =
            ___roomWiseLineAndTextObjectsCopy[x.roomID];
        });
      this.removeAllWallLines(___roomWiseLineAndTextObjects);
      removePartitionCircle(this, true);

      this.setState({
        isAddLabel: false,
        isAddPolylineFromBuildMenu: false,
        isAddLineFromBuildMenu: false,
        isAddDoorFromBuildMenu: false,
        isAddWindowFromBuildMenu: false,
        isAddStairCase: !this.state.isAddStairCase,
      });
    } else if (!this.state.isEditModeEnabled) {
      customToast.error(
        t("COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Staircase")
      );
    } else if (this.state.selectedFloor != "4") {
      customToast.error(t("COMMON_MESSAGES.REQUIRED_ROOM_SELECTION"));
    }
  };

  /**
   * Purpose : This function will change font size
   * @param {String} op plus/minus
   */
  updateFontSize = (op) => {
    //let currentZoomFontSize = this.canvas.getZoom();
    let currentZoomFontSize = 1;
    let fontScale = 1;
    let copyOriginal = _.cloneDeep(originalFloorPlan);

    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    if (op == "plus") {
      fontScale = currentZoomFontSize * 1.1;
    } else if (op == "minus") {
      fontScale = currentZoomFontSize / 1.1;
    }

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomID = roomArray[roomArrayIndex];
      let roomFontSize = roomWiseFontSize[roomID];

      if (
        roomFontSize * fontScale < MAX_FONT_SIZE &&
        roomFontSize * fontScale > MIN_FONT_SIZE
      ) {
        let groupID = "GROUP-" + roomID;

        let groupObject = this.canvas.getItemByAttr("id", groupID);

        if (groupObject != null) {
          let groupWidth = groupObject.width;

          let groupObjects = groupObject.getObjects();

          for (
            let groupSubObjectIndex = 0;
            groupSubObjectIndex < groupObjects.length;
            groupSubObjectIndex++
          ) {
            let object = groupObjects[groupSubObjectIndex];

            //object.calcTransformMatrix()
            if (object.type == "MEASUREMENT-BOX-TEXT-GROUP") {
              let subgroupObjects = object.getObjects();
              for (let obj = 0; obj < subgroupObjects.length; obj++) {
                let subObject = subgroupObjects[obj];
                if (subObject.type == "MEASUREMENT-BOX-TEXT") {
                  this.updateLabelFontSize(
                    subObject,
                    roomID,
                    groupWidth,
                    op,
                    fontScale
                  );
                }
              }
            }
            if (object.type == "CENTRE-BOX-TEXT" || object.type == "LABEL") {
              let fontSize = parseFloat(object["fontSize"]);

              let width = object.width;
              let height = object.height;
              if (object.type == "CENTRE-BOX-TEXT") {
                object.set("left", (width / 2) * -1);
                object.set("top", (height / 2) * -1);
              }
              if (op == "plus" && width + 60 <= groupWidth) {
                fontSize = fontSize * fontScale;
                object.set("fontSize", fontSize);
                roomWiseFontSize[roomID] = fontSize;
              } else if (op == "minus") {
                fontSize = fontSize * fontScale;
                object.set("fontSize", fontSize);
                roomWiseFontSize[roomID] = fontSize;
              }
            }
          }

          const roomelm = facesArray.filter(
            (el) => el["@type"] == "ROOM" && el["@id"] == roomID
          );
          if (roomelm[0] && roomelm[0]["@childrenLabel"]) {
            const labelid = roomelm[0]["@childrenLabel"].split(",");
            for (let i = 0; i < labelid.length; i++) {
              let labelObject = this.canvas.getItemByAttr("id", labelid[i]);
              if (labelObject) {
                let fontSize = parseFloat(labelObject["fontSize"]);

                let width = labelObject.width;
                let height = labelObject.height;

                if (op == "plus" && width + 60 <= groupWidth) {
                  fontSize = fontSize * fontScale;
                  labelObject.set("fontSize", fontSize);
                } else if (op == "minus") {
                  fontSize = fontSize * fontScale;
                  labelObject.set("fontSize", fontSize);
                }
              }
            }
          }
        }
      }
    }

    this.canvas.renderAll();
  };
  updateLabelFontSize = (subObject, roomID, groupWidth, op, fontScale) => {
    let fontSize = parseFloat(subObject["fontSize"]);
    let width = subObject.width;
    if (op == "plus" && width + 60 <= groupWidth) {
      fontSize = fontSize * fontScale;
      subObject.set("fontSize", fontSize);
      roomWiseFontSize[roomID] = fontSize;
    } else if (op == "minus") {
      fontSize = fontSize * fontScale;
      subObject.set("fontSize", fontSize);
      roomWiseFontSize[roomID] = fontSize;
    }
  };
  /**
   * Purpose : This function will delete selecte room
   */
  deleteRoom = () => {
    const { t } = this.props;
    let activeRoom = this.canvas.getActiveObject();
    if (
      activeRoom ||
      (this.state.enableLabelDelete && this.state.selectedLabel) ||
      (this.state.enableLineDelete && this.state.selectedLine) ||
      (this.state.enablePartitionDoorDelete &&
        this.state.selectedPartitionDoor) ||
      (this.state.enablePartitionWindowDelete &&
        this.state.selectedPartitionWindow) ||
      (this.state.enableDoorDelete && this.state.selectedDoor) ||
      (this.state.enableStairCaseDelete && this.state.selectedStairCase)
    ) {
      let roomId =
        this.state.enableLabelDelete && this.state.selectedLabel
          ? this.state.selectedLabel
          : this.state.enableLineDelete && this.state.selectedLine
          ? this.state.selectedLine
          : this.state.enablePartitionDoorDelete &&
            this.state.selectedPartitionDoor
          ? this.state.selectedPartitionDoor
          : this.state.enablePartitionWindowDelete &&
            this.state.selectedPartitionWindow
          ? this.state.selectedPartitionWindow
          : this.state.enableDoorDelete && this.state.selectedDoor
          ? this.state.selectedDoor
          : this.state.enableStairCaseDelete && this.state.selectedStairCase
          ? this.state.selectedStairCase
          : activeRoom.roomID;
      this.canvas.remove(this.canvas.getActiveObject());
      this.canvas.renderAll();
      this.handleConfirmationModal();

      let copyOriginal = _.cloneDeep(originalFloorPlan);
      let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
      let linesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
      let pointsArray =
        copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;

      let roomObj = _.find(facesArray, function (face) {
        return face["@id"] == roomId;
      });

      // Remove partition door and door shape from fabric
      facesArray
        .filter((el) => el["@type"] === "PARTITION_DOOR")
        .forEach((el) => {
          if (
            el["@parentPartition"]?.[0]?.line === roomObj["@id"] ||
            el["@parentPartition"]?.[1]?.line === roomObj["@id"]
          ) {
            this.canvas.remove(this.canvas.getItemByAttr("id", el["@id"]));
            this.canvas.remove(
              this.canvas.getItemByAttr("id", `doorobject_${el["@id"]}`)
            );
          }
        });
      // Remove partition window from fabric
      facesArray
        .filter((el) => el["@type"] === "PARTITION_WINDOW")
        .forEach((el) => {
          if (
            el["@parentPartition"] === roomObj["@id"] ||
            el["@parentPartition"] === roomObj["@id"]
          ) {
            this.canvas.remove(this.canvas.getItemByAttr("id", el["@id"]));
          }
        });
      let walls = [];
      let childrenLabel = [];
      let childrenLine = [],
        childrenPartitionDoor = [],
        childrenPartitionWindow = [],
        childrenStairCase = [];
      let lines = [];
      let points = [];
      if (roomObj) {
        if (roomObj["@children"]) {
          walls = roomObj["@children"].split(",");
        }
        if (roomObj["@type"] == "LABEL") {
          walls.push(roomObj["@id"]);
          facesArray.map(
            (face) =>
              (face["@childrenLabel"] = face["@childrenLabel"]
                ? face["@childrenLabel"]
                    .split(",")
                    .filter((el) => el != roomObj["@id"])
                    .join(",")
                : "")
          );
        } else if (roomObj["@type"] == "LINE") {
          walls.push(roomObj["@id"]);
          facesArray.map(
            (face) =>
              (face["@childrenLine"] = face["@childrenLine"]
                ? face["@childrenLine"]
                    .split(",")
                    .filter((el) => el != roomObj["@id"])
                    .join(",")
                : "")
          );

          // Connected partition door/window array
          let connectedParttiionDoor = [],
            connectedParttiionWindow = [];
          facesArray.forEach((el) => {
            if (el["@parentPartition"] === roomObj["@id"]) {
              connectedParttiionWindow.push(el["@id"]);
            } else if (el["@parentPartition"] === roomObj["@id"]) {
              connectedParttiionDoor.push(el["@id"]);
            }
          });

          // Remove partition door from face array
          connectedParttiionDoor.forEach((element) => {
            facesArray.map((face) => {
              return (face["@partitionDoor"] = face["@partitionDoor"]
                ? face["@partitionDoor"]
                    .split(",")
                    .filter((el) => {
                      return el != element;
                    })
                    .join(",")
                : "");
            });
          });

          // Remove partition window from face array
          connectedParttiionWindow.forEach((element) => {
            facesArray.map((face) => {
              return (face["@partitionWindow"] = face["@partitionWindow"]
                ? face["@partitionWindow"]
                    .split(",")
                    .filter((el) => {
                      return el != element;
                    })
                    .join(",")
                : "");
            });
          });
        } else if (roomObj["@type"] == "PARTITION_DOOR") {
          walls.push(roomObj["@id"]);
          facesArray.map(
            (face) =>
              (face["@partitionDoor"] = face["@partitionDoor"]
                ? face["@partitionDoor"]
                    .split(",")
                    .filter((el) => el != roomObj["@id"])
                    .join(",")
                : "")
          );
        } else if (roomObj["@type"] == "PARTITION_WINDOW") {
          walls.push(roomObj["@id"]);
          facesArray.map(
            (face) =>
              (face["@partitionWindow"] = face["@partitionWindow"]
                ? face["@partitionWindow"]
                    .split(",")
                    .filter((el) => el != roomObj["@id"])
                    .join(",")
                : "")
          );
        } else if (roomObj["@type"] == "STAIR_CASE") {
          walls.push(roomObj["@id"]);
          facesArray.map(
            (face) =>
              (face["@childrenStairCase"] = face["@childrenStairCase"]
                ? face["@childrenStairCase"]
                    .split(",")
                    .filter((el) => el != roomObj["@id"])
                    .join(",")
                : "")
          );
        }
        if (roomObj["@childrenLabel"] && roomObj["@childrenLabel"].length > 0) {
          childrenLabel = walls.concat(roomObj["@childrenLabel"].split(","));
        }
        if (roomObj["@childrenLine"] && roomObj["@childrenLine"].length > 0) {
          childrenLine = walls.concat(roomObj["@childrenLine"].split(","));
        }
        if (roomObj["@partitionDoor"] && roomObj["@partitionDoor"].length > 0) {
          childrenPartitionDoor = walls.concat(
            roomObj["@partitionDoor"].split(",")
          );
        }
        if (
          roomObj["@partitionWindow"] &&
          roomObj["@partitionWindow"].length > 0
        ) {
          childrenPartitionWindow = walls.concat(
            roomObj["@partitionWindow"].split(",")
          );
        }
        if (
          roomObj["@childrenStairCase"] &&
          roomObj["@childrenStairCase"].length > 0
        ) {
          childrenStairCase = walls.concat(
            roomObj["@childrenStairCase"].split(",")
          );
        }
        let childdoorswalls = facesArray.filter((face) =>
          walls.find(
            (wall) =>
              wall === face["@id"] ||
              ((face["@type"] === "PARTITION_DOOR" ||
                face["@type"] === "PARTITION_WINDOW") &&
                (face["@parentPartition"]?.[0]?.line === wall ||
                  face["@parentPartition"]?.[1]?.line === wall))
          )
        );
        let childdoors = facesArray
          .filter((face) =>
            childdoorswalls.find((wall) =>
              wall["@children"].split(",").includes(face["@id"])
            )
          )
          .map((el) => {
            return el["@id"];
          });
        childdoors.forEach((element) => {
          this.canvas
            .getObjects()
            .filter((x) => x.id === "doorobject_" + element || x.id === element)
            .forEach((x) => {
              this.canvas.remove(x);
            });
        });
        childrenLabel.forEach((element) => {
          this.canvas.remove(this.canvas.getItemByAttr("id", element));
        });
        childrenLine.forEach((element) => {
          this.canvas.remove(this.canvas.getItemByAttr("id", element));
        });
        childrenPartitionDoor.forEach((element) => {
          this.canvas
            .getObjects()
            .filter((x) => x.id === "doorobject_" + element || x.id === element)
            .forEach((x) => {
              this.canvas.remove(x);
            });
        });
        childrenPartitionWindow.forEach((element) => {
          this.canvas.remove(this.canvas.getItemByAttr("id", element));
        });
        childrenStairCase.forEach((element) => {
          this.canvas.remove(this.canvas.getItemByAttr("id", element));
        });
        walls = [
          ...walls,
          ...childdoors,
          ...childrenLabel,
          ...childrenLine,
          ...childrenPartitionDoor,
          ...childrenPartitionWindow,
          ...childrenStairCase,
        ];
        let wallsArray = facesArray.filter((face) =>
          walls.find(
            (wall) =>
              wall === face["@id"] ||
              ((face["@type"] === "PARTITION_DOOR" ||
                face["@type"] === "PARTITION_WINDOW") &&
                (face["@parentPartition"]?.[0]?.line === wall ||
                  face["@parentPartition"]?.[1]?.line === wall))
          )
        );

        let lineObjOfDoorToBeDeleted, pointsObjOfDoorToBeDeleted;
        if (this.state.selectedDoor && this.state.enableDoorDelete) {
          this.canvas
            .getObjects()
            .filter((x) => x.id === "doorobject_" + this.state.selectedDoor)
            .forEach((x) => {
              this.canvas.remove(x);
            });
          lineObjOfDoorToBeDeleted = facesArray
            .filter((fa) => fa["@id"] === this.state.selectedDoor)
            .map((fa) => fa.POLYGON["@path"])[0];
          pointsObjOfDoorToBeDeleted = linesArray
            .filter((la) => la["@id"] === lineObjOfDoorToBeDeleted)
            .map((la) => la["@path"])[0];
        }

        let newFacesArray = facesArray.filter(
          (face) =>
            !walls.find(
              (wall) =>
                wall === face["@id"] ||
                ((face["@type"] === "PARTITION_DOOR" ||
                  face["@type"] === "PARTITION_WINDOW") &&
                  (face["@parentPartition"]?.[0]?.line === wall ||
                    face["@parentPartition"]?.[1]?.line === wall))
            ) &&
            (face["@id"] != roomId ||
              ((face["@type"] === "PARTITION_DOOR" ||
                face["@type"] === "PARTITION_WINDOW") &&
                (face["@parentPartition"]?.[0]?.line != roomId ||
                  face["@parentPartition"]?.[1]?.line != roomId)))
        );
        lines = wallsArray.map((wall) => wall.POLYGON["@path"]);
        let removedLinesArray = linesArray.filter((l) =>
          lines.find((line) => line === l["@id"])
        );
        let newLinesArray = linesArray.filter(
          (l) => !lines.find((line) => line === l["@id"])
        );
        points = removedLinesArray.map((line) => line["@path"].split(","));
        points = points.flat(1);
        let newPointsArray = pointsArray.filter(
          (p) => !points.find((point) => point === p["@id"])
        );

        if (this.state.selectedDoor && this.state.enableDoorDelete) {
          // removes the deleted door from a particular wall's children
          newFacesArray.forEach((myFaceObj) => {
            let wallChildren = myFaceObj["@children"];
            if (
              !_.isEmpty(wallChildren) &&
              wallChildren.includes(this.state.selectedDoor)
            ) {
              const wallChildrenDoors = wallChildren
                .split(",")
                .filter((doorId) => doorId !== this.state.selectedDoor);
              myFaceObj["@children"] = wallChildrenDoors.join(",");
              return;
            }
          });

          // removes the LINE associated with deleted door
          newLinesArray = newLinesArray.filter(
            (myLineObj) => myLineObj["@id"] !== lineObjOfDoorToBeDeleted
          );

          // removes the POINTs associated with deleted door
          newPointsArray = newPointsArray.filter(
            (myPointObj) =>
              myPointObj["@id"] !== pointsObjOfDoorToBeDeleted[0] &&
              myPointObj["@id"] !== pointsObjOfDoorToBeDeleted[1]
          );
        }

        copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE =
          newFacesArray;
        copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE =
          newLinesArray;
        copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
          newPointsArray;

        originalFloorPlan = _.cloneDeep(copyOriginal);
        this.setState({ enableDelete: false });
        this.setState({
          enableLabelDelete: false,
          enableLineDelete: false,
          enableDoorDelete: false,
          enablePartitionDoorDelete: false,
          enablePartitionWindowDelete: false,
          enableStairCaseDelete: false,
        });
        delete designatorWiseObjectArray[roomId];
        customToast.success(t("COMMON_MESSAGES.DELETE_ROOM_MESSAGE"));
        if (
          !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
            originalFloorPlan,
            designatorWiseObjectArray,
            floorId: this.state.selectedFloor,
          })
        ) {
          EditModeChanges.push({
            originalFloorPlan: _.cloneDeep(originalFloorPlan),
            designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
            floorId: this.state.selectedFloor,
          });
          this.setState({
            undocount: EditModeChanges.length,
          });
        }
      } else {
      }
    } else {
    }
  };

  /**
   * Purpose : This function will retunn center point selecte room
   * @param {String} roomID roomId for what we need center point
   * @returns {Object} object with coordinates of center points
   */
  getCenterPointofObject = (roomID) => {
    const selectedFloor = this.state.selectedFloor;

    const faces = _.get(
      originalFloorPlan,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "FACES", "FACE"],
      []
    );
    // const findAllRooms = _.filter(faces, (face) => {
    //   return face["@floorindex"] == selectedFloor;
    // });

    let walllist = [];
    _.map(faces, (room) => {
      if (room["@id"] == roomID) {
        const childrens = room["@children"];
        const array = childrens.split(",");
        walllist = walllist.concat(array);
      }
    });

    let linelist = [];
    _.map(faces, (face) => {
      if (face["@type"] == "WALL" && walllist.includes(face["@id"])) {
        linelist.push(_.get(face, ["POLYGON", "@path"]));
      }
    });

    const lines = _.get(
      originalFloorPlan,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "LINES", "LINE"],
      []
    );
    let pointlinelist = [];
    let pointlist = [];
    _.map(lines, (line) => {
      if (linelist.includes(line["@id"])) {
        const path = line["@path"];
        const array = line["@path"].split(",");
        pointlinelist = pointlinelist.concat(path);
        pointlist = pointlist.concat(array);
      }
    });

    pointlist = _.uniqBy(pointlist);
    let minx, miny, maxx, maxy;

    const points = _.get(
      originalFloorPlan,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "POINTS", "POINT"],
      []
    );

    let i = 0;
    let totalX = 0;
    let totalY = 0;
    _.map(points, (point) => {
      if (pointlist.includes(point["@id"])) {
        const dataxy = point["@editedXY"];
        const xy = dataxy.split(",");
        const x = (parseFloat(xy[0]) - this.minX) * this.ratio;
        const y = (parseFloat(xy[1]) - this.minY) * this.ratio;
        // const x = parseFloat(xy[0]);
        // const y = parseFloat(xy[1]);

        totalX += x;
        totalY += y;

        if (i == 0) {
          minx = x;
          maxx = x;
          miny = y;
          maxy = y;
        }
        if (x <= minx) {
          minx = x;
        }
        if (maxx <= x) {
          maxx = x;
        }

        if (y <= miny) {
          miny = y;
        }
        if (maxy <= y) {
          maxy = y;
        }
        i++;
      }
    });

    const centerX = totalX / pointlist.length;
    const centerY = totalY / pointlist.length;
    const RectX = (maxx + minx) / 2;
    const RectY = (maxy + miny) / 2;
    return {
      MaxX: maxx,
      MinX: minx,
      MaxY: maxy,
      MinY: miny,
      cx: centerX,
      cy: centerY,
      RectX: RectX,
      RectY: RectY,
    };
  };

  /**
   * Purpose : This function will retunn center point selecte Floor
   * @param {int} floorId floorId for what we need center point
   * @returns {Object} object with coordinates of center points
   */
  getCenterPointofFloor = (floorId) => {
    const selectedFloor = floorId;
    const faces = _.get(
      originalFloorPlan,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "FACES", "FACE"],
      []
    );

    const rooms = [];
    _.map(faces, (face) => {
      if (face["@floorindex"] == selectedFloor) {
        rooms.push(face["@id"]);
      }
    });

    let walllist = [];
    _.map(faces, (room) => {
      if (rooms.includes(room["@id"])) {
        const childrens = room["@children"];
        const array = childrens.split(",");
        walllist = walllist.concat(array);
      }
    });

    let linelist = [];
    _.map(faces, (face) => {
      if (face["@type"] == "WALL" && walllist.includes(face["@id"])) {
        linelist.push(_.get(face, ["POLYGON", "@path"]));
      }
    });

    const lines = _.get(
      originalFloorPlan,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "LINES", "LINE"],
      []
    );
    let pointlinelist = [];
    let pointlist = [];
    _.map(lines, (line) => {
      if (linelist.includes(line["@id"])) {
        const path = line["@path"];
        const array = line["@path"].split(",");
        pointlinelist = pointlinelist.concat(path);
        pointlist = pointlist.concat(array);
      }
    });

    pointlist = _.uniqBy(pointlist);
    let minx, miny, maxx, maxy;

    const points = _.get(
      originalFloorPlan,
      ["EAGLEVIEW_EXPORT", "STRUCTURES", "ROOF", "POINTS", "POINT"],
      []
    );

    let i = 0;
    let totalX = 0;
    let totalY = 0;
    _.map(points, (point) => {
      if (pointlist.includes(point["@id"])) {
        const dataxy = point["@editedXY"];
        const xy = dataxy.split(",");
        const x = (parseFloat(xy[0]) - this.minX) * this.ratio;
        const y = (parseFloat(xy[1]) - this.minY) * this.ratio;
        // const x = parseFloat(xy[0]);
        // const y = parseFloat(xy[1]);

        totalX += x;
        totalY += y;

        if (i == 0) {
          minx = x;
          maxx = x;
          miny = y;
          maxy = y;
        }
        if (x <= minx) {
          minx = x;
        }
        if (maxx <= x) {
          maxx = x;
        }

        if (y <= miny) {
          miny = y;
        }
        if (maxy <= y) {
          maxy = y;
        }
        i++;
      }
    });

    const centerX = totalX / pointlist.length;
    const centerY = totalY / pointlist.length;

    const cx = (maxx + minx) / 2;
    const cy = (maxy + miny) / 2;

    return { cx, cy };
  };

  /**
   * Purpose : This function will show confirmation modal
   */
  handleConfirmationModal = () => {
    this.setState({ confirmationModal: !this.state.confirmationModal });
  };

  /**
   * Purpose : This function will hanlde wall input
   */
  handleWallInput = (e) => {
    if (!isNaN(parseFloat(e.target.value)) && parseFloat(e.target.value) >= 0) {
      this.setState({
        wallThickness: e.target.value,
        wallThicknessError: false,
      });
    } else {
      this.setState({
        wallThickness: e.target.value,
        wallThicknessError: "Please enter valid number",
      });
    }
  };

  /**
   * Purpose : This function will undo last changes before save
   */
  handleUndo() {
    this.setState({ doundo: true });
    let deduction = 2;
    let floorId = (designatorWiseObjectArray = _.cloneDeep(
      EditModeChanges[EditModeChanges.length - 1].floorId
    ));
    if (floorId != this.state.selectedFloor) {
      this.setState({
        selectedFloor: floorId,
      });
      deduction = 1;
    }
    originalFloorPlan = _.cloneDeep(
      EditModeChanges[EditModeChanges.length - deduction].originalFloorPlan
    );
    designatorWiseObjectArray = _.cloneDeep(
      EditModeChanges[EditModeChanges.length - deduction]
        .designatorWiseObjectArray
    );
    if (floorId == this.state.selectedFloor) {
      EditModeChanges.pop();
    }
    this.setState({
      undocount: EditModeChanges.length,
    });
    this.canvas.clear();
    this.drawFloorPlan();
    this.setState({ doundo: false });
  }

  /**
   * Purpose : This function will return maxID to create texObject for exterior floor
   */
  getMaxId(array, prefix) {
    let MatchArray = array
      .filter((el) => el["@id"].startsWith(prefix))
      .map((el) => {
        return parseInt(el["@id"].replace(prefix, ""));
      });
    return MatchArray.length > 0 ? Math.max(...MatchArray) : 0;
  }

  handleMeasurementTypeChange = (e) => {
    store.dispatch(StartCenterLoading());
    this.setState({
      selectedMeasurementType: e.target.value,
    });
    let type = measurementTypes.find((el) => el.id == e.target.value);
    this.props
      .loadFloorScanIndex({
        jobOrderId: this.props.jobOrderId,
      })
      .then((floorScanIndexData) => {
        this.props.setFloorListForVideo(floorScanIndexData);
        let floorData = {};
        if (floorScanIndexData?.length > 0) {
          floorData = floorScanIndexData?.find(
            (item) => item.floorTagNameList?.length
          );
          this.props.setSelectedFloorScanId(floorData.floorScanId);
        }
        this.props
          .loadMeasurementJson({
            jobOrderId: this.props.jobOrderId,
            type: type.name,
            format: measurementResponseFormat.converted,
            floorScanId: floorData.floorScanId,
            floorTagName: floorData.floorTagNameList[0],
          })
          .then((data) => {
            store.dispatch(StopCenterLoading());
          })
          .catch((err) => {
            store.dispatch(StopCenterLoading());
          });
      })
      .catch((err) => {
        store.dispatch(StopCenterLoading());
      });
  };

  addDoorOnStrokeDetection = (
    extractedWallLine,
    extractedWallLineMDEvent,
    isWindow = false,
    isPartitionWindow = false
  ) => {
    removePartitionCircle(this, true);
    if (
      this.state.extractedWallLineID &&
      this.state.extractedWallLineID != extractedWallLine.id
    ) {
      const { t } = this.props;
      if (isWindow) {
        customToast.error(t("COMMON_MESSAGES.Add_Window_On_Same_Wall"));
      } else {
        customToast.error(t("COMMON_MESSAGES.Add_Door_On_Same_Wall"));
      }
      return;
    }

    const ___roomWiseLineAndTextObjectsCopy = {
      ...roomWiseLineAndTextObjects,
    };
    const ___roomWiseLineAndTextObjects = {};
    this.canvas
      .getObjects()
      .filter((x) => x.type === "GROUP")
      .forEach((x) => {
        ___roomWiseLineAndTextObjects[x.roomID] =
          ___roomWiseLineAndTextObjectsCopy[x.roomID];
      });
    const __pointer = {
      x: extractedWallLineMDEvent.pointer.x / this.canvas.getZoom(),
      y: extractedWallLineMDEvent.pointer.y / this.canvas.getZoom(),
    };
    const __dx = extractedWallLine.x2 - __pointer.x;
    const __dy = extractedWallLine.y2 - __pointer.y;
    const __theta = Math.atan2(__dy, __dx);
    let __xp = 27 * Math.cos(__theta);
    let __yp = 27 * Math.sin(__theta);
    let pointerArr = [...this.state.wallLinePointerArray];
    pointerArr.push(__pointer);
    this.setState({
      wallLinePointerArray: pointerArr,
      extractedWallLineID: extractedWallLine.id,
    });
    if (pointerArr.length < 2) {
      const circle = new fabric.Circle({
        radius: 5,
        fill: isWindow
          ? PARTITION_WINDOW_COLOR
          : this.state.doorDirection == doorDirectionEnum.inside
          ? PARTITION_INSIDE_DOOR_COLOR
          : PARTITION_DOOR_COLOR,
        left: pointerArr[0].x - 5,
        top: pointerArr[0].y - 5,
        hasControls: false,
        hasBorders: false,
        type: "wallLinePoints",
        name: "wallLinePoints",
        id: `id${pointerArr[0].x}${pointerArr[0].y}`,
        customLineCoords: { x1: pointerArr[0].x, y1: pointerArr[0].y },
      });
      this.canvas.add(circle);
      this.canvas.renderAll();
      return;
    }
    __xp = pointerArr[0].x - pointerArr[1].x;
    __yp = pointerArr[0].y - pointerArr[1].y;

    // prepare JSON for door added via "Add Door" from Build Menu.
    let copyOriginal = _.cloneDeep(originalFloorPlan);
    let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
    let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
    let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
    const doorId =
      this.getMaxId(
        facesArray,
        isPartitionWindow ? "PARTITION_WINDOW" : isWindow ? "WINDOW" : "DOOR"
      ) + 1;
    const cid = this.getMaxId(roofPoints, "C") + 1;
    const lid = this.getMaxId(rooflines, "L") + 1;
    let datax1 = pointerArr[0].x / this.ratio + this.minX;
    let datay1 = pointerArr[0].y / this.ratio + this.minY;
    let datax2 = pointerArr[1].x / this.ratio + this.minX;
    let datay2 = pointerArr[1].y / this.ratio + this.minY;

    let NewLineStartXY = null;
    let NewLineEndXY = null;
    let editedLineStartXY = null;
    let editedLineEndXY = null;
    let newDoorStartEditedXY = { x: datax1, y: datay1 };
    let newDoorEndEditedXY = { x: datax2, y: datay2 };
    let lineObj = isPartitionWindow
      ? facesArray.filter(
          (el) => el["@type"] === "LINE" && el["id"] === extractedWallLine.id
        )?.[0]
      : extractedWallLine;
    if (lineObj?.linePointObjectArray?.length) {
      NewLineStartXY =
        lineObj.linePointObjectArray[0]["@autoSnappedXY"].split(",");
      NewLineStartXY = [
        parseFloat(NewLineStartXY[0]),
        parseFloat(NewLineStartXY[1]),
      ];
      NewLineEndXY =
        lineObj.linePointObjectArray[1]["@autoSnappedXY"].split(",");
      NewLineEndXY = [parseFloat(NewLineEndXY[0]), parseFloat(NewLineEndXY[1])];

      editedLineStartXY =
        lineObj.linePointObjectArray[0]["@editedXY"].split(",");
      editedLineStartXY = [
        parseFloat(editedLineStartXY[0]),
        parseFloat(editedLineStartXY[1]),
      ];
      editedLineEndXY = lineObj.linePointObjectArray[1]["@editedXY"].split(",");
      editedLineEndXY = [
        parseFloat(editedLineEndXY[0]),
        parseFloat(editedLineEndXY[1]),
      ];

      newDoorStartEditedXY = FindNewCoordinates(
        editedLineEndXY,
        { x: editedLineStartXY[0], y: editedLineStartXY[1] },
        NewLineStartXY,
        [datax1, datay1]
      );
      newDoorEndEditedXY = FindNewCoordinates(
        editedLineStartXY,
        { x: editedLineEndXY[0], y: editedLineEndXY[1] },
        NewLineEndXY,
        [datax2, datay2]
      );
    }

    // prepare face data
    let facedata = {
      "@floorindex": "",
      "@floor": "",
      "@areaname": "",
      "@measuretype": "",
      "@type": isPartitionWindow ? "PARTITION_WINDOW" : "WALLPENETRATION",
      "@text": "",
      "@area": "",
      "@editedArea": "",
      "@designator": "",
      POLYGON: {
        "@orientation": "",
        "@pitch": "",
        "@unroundedsize": "",
        "@path": "L" + lid,
        "@editedUnroundedsize": "",
        "@size": "",
        "@editedSize": "",
        "@id": "",
      },
      "@children": "",
      "@id": isPartitionWindow
        ? `PARTITION_WINDOW${doorId}`
        : `${isWindow ? "WINDOW" : "DOOR"}${doorId}`,
      "@mode": isPartitionWindow
        ? `PARTITION_WINDOW`
        : `${isWindow ? "WINDOW" : "DOOR"}`,
      "@doorDirection": isPartitionWindow ? "" : this.state.doorDirection,
      "@parentPartition": isPartitionWindow ? extractedWallLine.id : null,
    };
    facesArray.push(_.cloneDeep(facedata));

    // prepare points data
    let cdata1 = {
      "@id": "C" + cid,
      "@data": "0,0",
      "@dataXY": datax1 + "," + datay1,
      "@autoSnappedXY": datax1 + "," + datay1,
      "@editedXY": newDoorStartEditedXY.x + "," + newDoorStartEditedXY.y,
    };
    roofPoints.push(_.cloneDeep(cdata1));
    let cdata2 = {
      "@id": "C" + (cid + 1),
      "@data": "0,0",
      "@dataXY": datax2 + "," + datay2,
      "@autoSnappedXY": datax2 + "," + datay2,
      "@editedXY": newDoorEndEditedXY.x + "," + newDoorEndEditedXY.y,
    };
    roofPoints.push(_.cloneDeep(cdata2));

    // prepare line data
    let ldata = {
      "@angle": "",
      "@distance": "",
      "@id": "L" + lid,
      "@path": "C" + cid + ",C" + (cid + 1),
      "@type": isPartitionWindow ? "PARTITION_WINDOW" : "TOPWALL",
      linePointObjectArray: [cdata1, cdata2],
    };
    rooflines.push(_.cloneDeep(ldata));

    for (let i = 0; i < facesArray.length; i++) {
      if (!isPartitionWindow && facesArray[i]["@id"] == extractedWallLine.id) {
        if (!facesArray[i]["@children"]) {
          facesArray[i]["@children"] = "";
        }
        let child = facesArray[i]["@children"].split(",");
        if (facesArray[i]["@children"].length == 0) {
          child = [];
        }
        child.push(
          isPartitionWindow
            ? `PARTITION_WINDOW${doorId}`
            : `${isWindow ? "WINDOW" : "DOOR"}${doorId}`
        );
        facesArray[i]["@children"] = child.join(",");
        break;
      } else if (
        isPartitionWindow &&
        facesArray[i]["@id"] == extractedWallLine.roomID
      ) {
        if (!facesArray[i]["@partitionWindow"]) {
          facesArray[i]["@partitionWindow"] = "";
        }
        let child = facesArray[i]["@partitionWindow"].split(",");
        if (facesArray[i]["@partitionWindow"].length == 0) {
          child = [];
        }
        child.push(
          isPartitionWindow
            ? `PARTITION_WINDOW${doorId}`
            : `${isWindow ? "WINDOW" : "DOOR"}${doorId}`
        );
        facesArray[i]["@partitionWindow"] = child.join(",");
        break;
      }
    }
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE =
      _.cloneDeep(facesArray);
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
      _.cloneDeep(roofPoints);
    copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE =
      _.cloneDeep(rooflines);
    originalFloorPlan = _.cloneDeep(copyOriginal);
    if (
      !_.isEqual(EditModeChanges[EditModeChanges.length - 1], {
        originalFloorPlan,
        designatorWiseObjectArray,
        floorId: this.state.selectedFloor,
      })
    ) {
      EditModeChanges.push({
        originalFloorPlan: _.cloneDeep(originalFloorPlan),
        designatorWiseObjectArray: _.cloneDeep(designatorWiseObjectArray),
        floorId: this.state.selectedFloor,
      });
      this.setState({
        undocount: EditModeChanges.length,
      });
    }

    let line = new fabric.Line(
      [__pointer.x, __pointer.y, __xp + __pointer.x, __yp + __pointer.y],
      {
        stroke: isWindow
          ? PARTITION_WINDOW_COLOR
          : this.state.doorDirection == doorDirectionEnum.inside
          ? PARTITION_INSIDE_DOOR_COLOR
          : PARTITION_DOOR_COLOR,
        strokeWidth: lineStokeWidth,
        hasControls: false,
        hasBorders: true,
        selectable: false,
        lockScalingX: isPartitionWindow ? true : false,
        lockScalingY: isPartitionWindow ? true : false,
        lockMovementX: false,
        lockMovementY: false,
        type: isPartitionWindow ? "PARTITION_WINDOW" : "DW",
        isDoor: !isWindow,
        wallID: extractedWallLine.id,
        originX: "center",
        originY: "center",
        roomID: selectedRoom,
        id: isPartitionWindow
          ? `PARTITION_WINDOW${doorId}`
          : `${isWindow ? "WINDOW" : "DOOR"}${doorId}`,
        linePointObjectArray: "C" + cid + ",C" + (cid + 1),
        doorDirection: !isWindow ? this.state.doorDirection : "",
        parentPartitionId: isPartitionWindow ? extractedWallLine.id : null,
      }
    );

    this.canvas.add(line);
    this.canvas.discardActiveObject();
    if (isPartitionWindow) {
      // make a copy of the object which has fabric wall-line objects.
      const ___roomWiseLineAndTextObjectsCopy = {
        ...roomWiseLineAndTextObjects,
      };
      const ___roomWiseLineAndTextObjects = {};
      this.canvas
        .getObjects()
        .filter((x) => x.type === "GROUP")
        .forEach((x) => {
          ___roomWiseLineAndTextObjects[x.roomID] =
            ___roomWiseLineAndTextObjectsCopy[x.roomID];
        });
      // remove all wall-lines from the canvas.
      Object.keys(___roomWiseLineAndTextObjects).forEach((rwl) => {
        ___roomWiseLineAndTextObjects[rwl].roomLinesGroup.forEach((exw) =>
          this.canvas.remove(exw)
        );
      });

      // reset perPixelTargetFind to original value after door placement.
      this.canvas.set({
        perPixelTargetFind: false,
        targetFindTolerance: 0,
      });

      // bring back GROUP objects back on screen.
      this.canvas
        .getObjects()
        .filter((x) => x.type === "GROUP")
        .forEach((x) => {
          x.set({ visible: true });
        });
    }
    this.setState({
      isAddDoorFromBuildMenu: false,
      isAddWindowFromBuildMenu: false,
    });
    isDoorEdited = !isWindow;
    isWindowEdited = isWindow;
    this.state.doorDirection = doorDirectionEnum.inside;
    this.removeAllWallLines(___roomWiseLineAndTextObjects);
  };

  removeAllWallLines(___roomWiseLineAndTextObjects) {
    this.setState({ wallLinePointerArray: [], extractedWallLineID: null });
    this.canvas.remove(this.addLineVariables.line);
    this.canvas.remove(this.addPartitionDoorVariables.line);
    this.addLineVariables = {
      mouseDown: null,
      point1: null,
      line: null,
    };
    this.addPartitionDoorVariables = {
      mouseDown: null,
      point1: null,
      line: null,
    };
    // remove all wall-lines from the canvas.
    Object.keys(___roomWiseLineAndTextObjects).forEach((rwl) => {
      ___roomWiseLineAndTextObjects[rwl].roomLinesGroup.forEach((exw) =>
        this.canvas.remove(exw)
      );
    });

    // reset perPixelTargetFind to original value after door placement.
    this.canvas.set({
      perPixelTargetFind: false,
      targetFindTolerance: 0,
    });

    // bring back GROUP objects back on screen.
    this.canvas
      .getObjects()
      .filter((x) => x.type === "GROUP" || x.type === "partitionLine")
      .forEach((x) => {
        x.set({ visible: true });
        x?.type === "partitionLine" && this.canvas.remove(x);
      });

    this.canvas
      .getObjects()
      .filter((x) => x.type === "wallLinePoints")
      .forEach((x) => {
        this.canvas.remove(x);
      });
    // render fabric stuff.
    this.canvas.renderAll();
  }

  render() {
    const { t } = this.props;
    return (
      <>
        <div
          className={`measurement-container ${
            this.props.isTechnician?.create || this.props.isTechnician?.edit
              ? "technician-container"
              : ""
          }`}
        >
          <div
            className="measurement-head"
            style={{
              visibility:
                this.state.showErrorPage && this.props.isTechnician?.edit
                  ? "hidden"
                  : "visible",
            }}
          >
            {!this.state.isModifiableRoom && (
              <div className="menu-list">
                <div
                  style={{
                    visibility:
                      this.state.showErrorPage && !this.props.measurementLoading
                        ? "hidden"
                        : "visible",
                  }}
                  className="menu-items"
                >
                  <ul>
                    {/* <li>
                    <button className="">
                      <i className="icon-back"></i>Back
                    </button>
                  </li> */}
                    {/* <li>
                    <button className="">
                      <i className="icon-bookmark-edit"></i>Edit
                    </button>
                  </li> */}
                    {!this.props.isTechnician?.create && (
                      <li className="tooltip-icon">
                        <Tooltip title={t("BUTTONS.Save")} arrow>
                          <button
                            className="active"
                            onClick={() => {
                              this.saveArea();
                              customToast.success(
                                t("COMMON_MESSAGES.MEASUREMENT_SAVE_MESSAGE")
                              );
                            }}
                          >
                            <i className="icon-save-file"></i>
                          </button>
                        </Tooltip>
                      </li>
                    )}

                    <li className="tooltip-icon">
                      <Tooltip title={t("BUTTONS.Rotate_Left")} arrow>
                        <button
                          className=""
                          onClick={() => {
                            degree -= 45;
                            this.rotateCanvas(-45);
                            this.disbaleBuildMenu();
                          }}
                        >
                          <i className="icon-rotate-left"></i>
                        </button>
                      </Tooltip>
                    </li>
                    <li className="tooltip-icon">
                      <Tooltip title={t("BUTTONS.Rotate_Right")} arrow>
                        <button
                          className=""
                          onClick={() => {
                            degree += 45;
                            this.rotateCanvas(45);
                            this.disbaleBuildMenu();
                          }}
                        >
                          <i className="icon-rotate-right"></i>
                        </button>
                      </Tooltip>
                    </li>
                    <li className="tooltip-icon">
                      <button
                        onClick={() => {
                          this.acceptAutoDegreeAll();
                          this.disbaleBuildMenu();
                        }}
                      >
                        <Tooltip title={t("BUTTONS.Auto_Snap_all_Rooms")} arrow>
                          <i className="icon-auto-snaps-90"></i>
                        </Tooltip>
                      </button>
                    </li>
                    {/* <li className="tooltip-icon">
                    <button>
                      <Tooltip title="Auto Stitch" arrow>
                        <i className="icon-auto-stiche"></i>
                      </Tooltip>
                    </button>
                  </li> */}

                    <li className="tooltip-icon">
                      <Tooltip
                        title={t("BUTTONS.Reset_to_Original_View")}
                        arrow
                      >
                        <button
                          onClick={() => {
                            this.resetJSONToOriginal();
                            this.disbaleBuildMenu();
                          }}
                        >
                          <i className="icon-reset"></i>
                        </button>
                      </Tooltip>
                    </li>
                    {this.state.undocount > 1 && (
                      <li className="tooltip-icon">
                        <Tooltip title={t("BUTTONS.Undo")} arrow>
                          <button
                            className=""
                            onClick={() => {
                              this.handleUndo();
                              this.disbaleBuildMenu();
                              this.addPartitionDoorVariables.line = null;
                            }}
                          >
                            <i className="icon-undo"></i>
                          </button>
                        </Tooltip>
                      </li>
                    )}
                    <li>
                      <div className="switch-group">
                        <CustomSwitch
                          checked={this.state.isEditModeEnabled}
                          onChange={() => this.toggleEditMode()}
                        />{" "}
                        <label>{t("BUTTONS.Edit_Mode")}</label>
                      </div>
                    </li>
                    {
                      <li>
                        <button
                          disabled={
                            !this?.canvas?.getActiveObject() ||
                            (!this.state.enableDelete &&
                              !this.state.enableLabelDelete &&
                              !this.state.enableLineDelete &&
                              !this.state.enablePartitionDoorDelete &&
                              !this.state.enablePartitionWindowDelete &&
                              !this.state.enableDoorDelete &&
                              !this.state.enableStairCaseDelete)
                          }
                          className={classnames({
                            disable:
                              !this?.canvas?.getActiveObject() ||
                              (!this.state.enableDelete &&
                                !this.state.enableLabelDelete &&
                                !this.state.enableLineDelete &&
                                !this.state.enablePartitionDoorDelete &&
                                !this.state.enablePartitionWindowDelete &&
                                !this.state.enableDoorDelete &&
                                !this.state.enableStairCaseDelete),
                          })}
                          onClick={() => this.handleConfirmationModal()}
                        >
                          <i className="icon-delete"></i>
                          {t("BUTTONS.Delete")}
                          {/* <i className="icon-information"></i> */}
                        </button>
                      </li>
                    }
                    <li class="menu-more">
                      <button
                        class=""
                        className={
                          this.state.isAddLabel ||
                          this.state.isAddLineFromBuildMenu ||
                          this.state.isAddDoorFromBuildMenu ||
                          this.state.isAddWindowFromBuildMenu ||
                          this.state.isAddStairCase
                            ? "selected"
                            : ""
                        }
                      >
                        {t("BUTTONS.Build")}
                      </button>
                      <ul class="buid-menu">
                        <li>
                          <button
                            className={this.state.isAddLabel ? "selected" : ""}
                            style={{
                              justifyContent: "left",
                              width: "100%",
                            }}
                            onClick={() => {
                              this.toggleAddLabel();
                            }}
                          >
                            <i className="icon-build_add_label"></i>
                            &emsp;
                            <div>{t("BUTTONS.Add_Label")}</div>
                          </button>
                        </li>
                        {/* <li>
                        <button
                          style={{
                            justifyContent: "left",
                            width: "100%",
                          }}
                          onClick={() => {
                            const { t } = this.props;
                            if (
                              // selectedRoom &&
                              this.state.isEditModeEnabled &&
                              this.state.selectedFloor == "4"
                            ) {
                              this.setState({
                                isAddLabel: false,
                                isAddPolylineFromBuildMenu: true,
                                isAddLineFromBuildMenu: false,
                              });
                            } else if (!this.state.isEditModeEnabled) {
                              customToast.error(
                                t(
                                  "COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Polyline"
                                )
                              );
                            } else if (this.state.selectedFloor != "4") {
                              customToast.error(
                                t(
                                  "COMMON_MESSAGES.REQUIRED_ROOM_SELECTION_for_Add_Polyline"
                                )
                              );
                            }
                          }}
                        >
                          <img
                            src="/images/build_add_line.svg"
                            alt="Add Polyline"
                          />
                          &emsp;
                          <div>{t("BUTTONS.Add_Polyline")}</div>
                        </button>
                      </li> */}
                        <li>
                          <button
                            className={
                              this.state.isAddLineFromBuildMenu
                                ? "selected"
                                : ""
                            }
                            style={{
                              justifyContent: "left",
                              width: "100%",
                            }}
                            onClick={() => {
                              const { t } = this.props;
                              if (
                                this.state.isEditModeEnabled &&
                                (this.state.selectedFloor == "4" ||
                                  this.state.selectedMeasurementType == "2" ||
                                  this.state.selectedMeasurementType == "3" ||
                                  this.state.selectedMeasurementType == "4")
                              ) {
                                if (isEditMode == true && editedRoomID != 0) {
                                  customToast.error(
                                    t(
                                      "COMMON_MESSAGES.Please_close_the_room_edit_mode"
                                    )
                                  );
                                  this.setState({
                                    isAddDoorFromBuildMenu: false,
                                  });
                                  return;
                                }
                                // make a copy of the object which has fabric wall-line objects.
                                const ___roomWiseLineAndTextObjectsCopy = {
                                  ...roomWiseLineAndTextObjects,
                                };
                                const ___roomWiseLineAndTextObjects = {};

                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => {
                                    ___roomWiseLineAndTextObjects[x.roomID] =
                                      ___roomWiseLineAndTextObjectsCopy[
                                        x.roomID
                                      ];
                                  });
                                this.removeAllWallLines(
                                  ___roomWiseLineAndTextObjects
                                );
                                removePartitionCircle(this, true);
                                deselectPartition(this);
                                this.setState({
                                  isAddLabel: false,
                                  isAddPolylineFromBuildMenu: false,
                                  isAddLineFromBuildMenu:
                                    !this.state.isAddLineFromBuildMenu,
                                  isAddDoorFromBuildMenu: false,
                                  isAddWindowFromBuildMenu: false,
                                });
                              } else if (!this.state.isEditModeEnabled) {
                                customToast.error(
                                  t(
                                    "COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Line"
                                  )
                                );
                              } else if (this.state.selectedFloor != "4") {
                                customToast.error(
                                  t(
                                    "COMMON_MESSAGES.REQUIRED_ROOM_SELECTION_for_Add_Line"
                                  )
                                );
                              }
                            }}
                          >
                            <i className="icon-build_add_line"></i>
                            &emsp;
                            <div>{t("BUTTONS.Add_Line")}</div>
                          </button>
                        </li>
                        {/* {this.state.selectedFloor == "4" && (
                          <li>
                            <button
                              style={{
                                justifyContent: "left",
                                width: "100%",
                              }}
                              onClick={() => {
                                this.createModifiableRoom();
                              }}
                            >
                              <i className="icon-node-modify"></i>
                              &emsp;
                              <div>{t("BUTTONS.Modify_Room")}</div>
                            </button>
                          </li>
                        )} */}
                        <li>
                          <button
                            className={
                              this.state.isAddDoorFromBuildMenu &&
                              this.state.doorDirection == 0
                                ? "selected"
                                : ""
                            }
                            style={{
                              justifyContent: "left",
                              width: "100%",
                            }}
                            onClick={() => {
                              const { t } = this.props;
                              if (
                                // selectedRoom &&
                                this.state.isEditModeEnabled
                              ) {
                                if (isEditMode == true && editedRoomID != 0) {
                                  customToast.error(
                                    t(
                                      "COMMON_MESSAGES.Please_close_the_room_edit_mode"
                                    )
                                  );
                                  this.setState({
                                    isAddDoorFromBuildMenu: false,
                                  });
                                  return;
                                }
                                // make a copy of the object which has fabric wall-line objects.
                                const ___roomWiseLineAndTextObjectsCopy = {
                                  ...roomWiseLineAndTextObjects,
                                };
                                const ___roomWiseLineAndTextObjects = {};

                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => {
                                    ___roomWiseLineAndTextObjects[x.roomID] =
                                      ___roomWiseLineAndTextObjectsCopy[
                                        x.roomID
                                      ];
                                  });
                                removePartitionCircle(this, true);
                                this.removeAllWallLines(
                                  ___roomWiseLineAndTextObjects
                                );
                                if (
                                  this.state.isAddDoorFromBuildMenu &&
                                  this.state.doorDirection == 0
                                ) {
                                  this.setState({
                                    isAddLabel: false,
                                    isAddPolylineFromBuildMenu: false,
                                    isAddLineFromBuildMenu: false,
                                    isAddDoorFromBuildMenu: false,
                                    isAddWindowFromBuildMenu: false,
                                    doorDirection: doorDirectionEnum.inside,
                                  });
                                  return;
                                }

                                addPartitionCircle(this);
                                this.setState({
                                  isAddLabel: false,
                                  isAddPolylineFromBuildMenu: false,
                                  isAddLineFromBuildMenu: false,
                                  isAddDoorFromBuildMenu: true,
                                  isAddWindowFromBuildMenu: false,
                                  doorDirection: doorDirectionEnum.inside,
                                });

                                // perPixelTargetFind is required for stroke detection without bounding box.
                                this.canvas.set({
                                  perPixelTargetFind: true,
                                  targetFindTolerance: 0,
                                });

                                // temporarily hide all GROUP objects.
                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => x.set({ visible: false }));

                                // add add-door related logic on individual wall-line objects.
                                Object.keys(
                                  ___roomWiseLineAndTextObjects
                                ).forEach((rwl) => {
                                  ___roomWiseLineAndTextObjects[
                                    rwl
                                  ].roomLinesGroup.forEach(
                                    (extractedWallLine) => {
                                      // evented is set to true for adding mousedown event-listener on individual wall-lines.
                                      extractedWallLine.set({
                                        evented: true,
                                      });

                                      // render individual wall-lines on the canvas.
                                      this.canvas.add(extractedWallLine);

                                      // remove all event-listeners for individual wall-lines which are part of copied object named ___roomWiseLineAndTextObjects.
                                      extractedWallLine.__eventListeners = {};

                                      // render fabric stuff.
                                      this.canvas.renderAll();

                                      // mousedown listener on individual wall-line objects.
                                      setTimeout(
                                        function () {
                                          extractedWallLine.on(
                                            "mousedown",
                                            function (
                                              extractedWallLineMDEvent
                                            ) {
                                              this.setState({
                                                doorDirection:
                                                  doorDirectionEnum.inside,
                                              });
                                              // door is detected hence we add the door at the mousedown location.
                                              this.addDoorOnStrokeDetection(
                                                extractedWallLine,
                                                extractedWallLineMDEvent
                                              );
                                            }.bind(this)
                                          );
                                        }.bind(this),
                                        500
                                      );
                                    }
                                  );
                                });
                              } else if (!this.state.isEditModeEnabled) {
                                customToast.error(
                                  t(
                                    "COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Door"
                                  )
                                );
                              }
                            }}
                          >
                            <i className="app-icon-inside-door"></i>
                            &emsp;
                            <div>{t("BUTTONS.Inside_Door")}</div>
                          </button>
                        </li>
                        <li>
                          <button
                            className={
                              this.state.isAddDoorFromBuildMenu &&
                              this.state.doorDirection == 1
                                ? "selected"
                                : ""
                            }
                            style={{
                              justifyContent: "left",
                              width: "100%",
                            }}
                            onClick={() => {
                              const { t } = this.props;
                              if (
                                // selectedRoom &&
                                this.state.isEditModeEnabled
                              ) {
                                if (isEditMode == true && editedRoomID != 0) {
                                  customToast.error(
                                    t(
                                      "COMMON_MESSAGES.Please_close_the_room_edit_mode"
                                    )
                                  );
                                  this.setState({
                                    isAddDoorFromBuildMenu: false,
                                  });
                                  return;
                                }
                                // make a copy of the object which has fabric wall-line objects.
                                const ___roomWiseLineAndTextObjectsCopy = {
                                  ...roomWiseLineAndTextObjects,
                                };
                                const ___roomWiseLineAndTextObjects = {};

                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => {
                                    ___roomWiseLineAndTextObjects[x.roomID] =
                                      ___roomWiseLineAndTextObjectsCopy[
                                        x.roomID
                                      ];
                                  });
                                removePartitionCircle(this, true);
                                this.removeAllWallLines(
                                  ___roomWiseLineAndTextObjects
                                );
                                if (
                                  this.state.isAddDoorFromBuildMenu &&
                                  this.state.doorDirection == 1
                                ) {
                                  this.setState({
                                    isAddLabel: false,
                                    isAddPolylineFromBuildMenu: false,
                                    isAddLineFromBuildMenu: false,
                                    isAddDoorFromBuildMenu: false,
                                    isAddWindowFromBuildMenu: false,
                                    doorDirection: doorDirectionEnum.inside,
                                  });
                                  return;
                                }

                                addPartitionCircle(this);
                                this.setState({
                                  isAddLabel: false,
                                  isAddPolylineFromBuildMenu: false,
                                  isAddLineFromBuildMenu: false,
                                  isAddDoorFromBuildMenu: true,
                                  isAddWindowFromBuildMenu: false,
                                  doorDirection: doorDirectionEnum.outside,
                                });

                                // perPixelTargetFind is required for stroke detection without bounding box.
                                this.canvas.set({
                                  perPixelTargetFind: true,
                                  targetFindTolerance: 0,
                                });

                                // temporarily hide all GROUP objects.
                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => x.set({ visible: false }));

                                // add add-door related logic on individual wall-line objects.
                                Object.keys(
                                  ___roomWiseLineAndTextObjects
                                ).forEach((rwl) => {
                                  ___roomWiseLineAndTextObjects[
                                    rwl
                                  ].roomLinesGroup.forEach(
                                    (extractedWallLine) => {
                                      // evented is set to true for adding mousedown event-listener on individual wall-lines.
                                      extractedWallLine.set({
                                        evented: true,
                                      });

                                      // render individual wall-lines on the canvas.
                                      this.canvas.add(extractedWallLine);

                                      // remove all event-listeners for individual wall-lines which are part of copied object named ___roomWiseLineAndTextObjects.
                                      extractedWallLine.__eventListeners = {};

                                      // render fabric stuff.
                                      this.canvas.renderAll();

                                      // mousedown listener on individual wall-line objects.
                                      setTimeout(
                                        function () {
                                          extractedWallLine.on(
                                            "mousedown",
                                            function (
                                              extractedWallLineMDEvent
                                            ) {
                                              this.setState({
                                                doorDirection:
                                                  doorDirectionEnum.outside,
                                              });
                                              // door is detected hence we add the door at the mousedown location.
                                              this.addDoorOnStrokeDetection(
                                                extractedWallLine,
                                                extractedWallLineMDEvent
                                              );
                                            }.bind(this)
                                          );
                                        }.bind(this),
                                        500
                                      );
                                    }
                                  );
                                });
                              } else if (!this.state.isEditModeEnabled) {
                                customToast.error(
                                  t(
                                    "COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Door"
                                  )
                                );
                              }
                            }}
                          >
                            <i className="app-icon-outside-door"></i>
                            &emsp;
                            <div>{t("BUTTONS.Outside_Door")}</div>
                          </button>
                        </li>
                        <li>
                          <button
                            className={
                              this.state.isAddWindowFromBuildMenu
                                ? "selected"
                                : ""
                            }
                            style={{
                              justifyContent: "left",
                              width: "100%",
                            }}
                            onClick={() => {
                              const { t } = this.props;
                              if (
                                // selectedRoom &&
                                this.state.isEditModeEnabled
                              ) {
                                if (isEditMode == true && editedRoomID != 0) {
                                  customToast.error(
                                    t(
                                      "COMMON_MESSAGES.Please_close_the_room_edit_mode"
                                    )
                                  );
                                  this.setState({
                                    isAddDoorFromBuildMenu: false,
                                  });
                                  return;
                                }
                                // make a copy of the object which has fabric wall-line objects.
                                const ___roomWiseLineAndTextObjectsCopy = {
                                  ...roomWiseLineAndTextObjects,
                                };
                                const ___roomWiseLineAndTextObjects = {};
                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => {
                                    ___roomWiseLineAndTextObjects[x.roomID] =
                                      ___roomWiseLineAndTextObjectsCopy[
                                        x.roomID
                                      ];
                                  });
                                removePartitionCircle(this, true);
                                this.removeAllWallLines(
                                  ___roomWiseLineAndTextObjects
                                );
                                if (this.state.isAddWindowFromBuildMenu) {
                                  this.setState({
                                    isAddLabel: false,
                                    isAddPolylineFromBuildMenu: false,
                                    isAddLineFromBuildMenu: false,
                                    isAddDoorFromBuildMenu: false,
                                    isAddWindowFromBuildMenu: false,
                                  });
                                  return;
                                }
                                this.setState({
                                  isAddLabel: false,
                                  isAddPolylineFromBuildMenu: false,
                                  isAddLineFromBuildMenu: false,
                                  isAddDoorFromBuildMenu: false,
                                  isAddWindowFromBuildMenu: true,
                                });

                                // perPixelTargetFind is required for stroke detection without bounding box.
                                this.canvas.set({
                                  perPixelTargetFind: true,
                                  targetFindTolerance: 0,
                                });

                                // temporarily hide all GROUP objects.
                                this.canvas
                                  .getObjects()
                                  .filter((x) => x.type === "GROUP")
                                  .forEach((x) => x.set({ visible: false }));

                                // add add-door related logic on individual wall-line objects.
                                Object.keys(
                                  ___roomWiseLineAndTextObjects
                                ).forEach((rwl) => {
                                  ___roomWiseLineAndTextObjects[
                                    rwl
                                  ].roomLinesGroup.forEach(
                                    (extractedWallLine) => {
                                      // evented is set to true for adding mousedown event-listener on individual wall-lines.
                                      extractedWallLine.set({
                                        evented: true,
                                      });

                                      // render individual wall-lines on the canvas.
                                      this.canvas.add(extractedWallLine);

                                      // remove all event-listeners for individual wall-lines which are part of copied object named ___roomWiseLineAndTextObjects.
                                      extractedWallLine.__eventListeners = {};

                                      // render fabric stuff.
                                      this.canvas.renderAll();

                                      // mousedown listener on individual wall-line objects.
                                      setTimeout(
                                        function () {
                                          extractedWallLine.on(
                                            "mousedown",
                                            function (
                                              extractedWallLineMDEvent
                                            ) {
                                              this.setState({
                                                doorDirection:
                                                  doorDirectionEnum.outside,
                                              });
                                              // door is detected hence we add the door at the mousedown location.
                                              this.addDoorOnStrokeDetection(
                                                extractedWallLine,
                                                extractedWallLineMDEvent,
                                                true
                                              );
                                            }.bind(this)
                                          );
                                        }.bind(this),
                                        500
                                      );
                                    }
                                  );
                                });
                              } else if (!this.state.isEditModeEnabled) {
                                customToast.error(
                                  t(
                                    "COMMON_MESSAGES.REQUIRED_EDIT_MODE_for_Add_Window"
                                  )
                                );
                              }
                            }}
                          >
                            <i className="icon-add-window"></i>
                            &emsp;
                            <div>{t("BUTTONS.Window")}</div>
                          </button>
                        </li>
                        <li>
                          <button
                            className={
                              this.state.isAddStairCase ? "selected" : ""
                            }
                            style={{
                              justifyContent: "left",
                              width: "100%",
                            }}
                            onClick={() => {
                              this.toggleAddStairCase();
                            }}
                          >
                            <i className="app-icon-staircase"></i>
                            &emsp;
                            <div>{t("BUTTONS.add_stair_case")}</div>
                          </button>
                        </li>
                      </ul>
                    </li>
                    <li class="menu-more">
                      <button class="">{t("BUTTONS.More")}</button>
                      <ul class="">
                        {this.state.selectedFloor != "4" && (
                          <li>
                            <div className="switch-group">
                              <CustomSwitch
                                checked={this.state.isShowAreaName}
                                onChange={() => this.toggleAreaName()}
                              />{" "}
                              <label>{t("BUTTONS.Area_Label")}</label>
                            </div>
                          </li>
                        )}
                        <li className="label-size">
                          <button
                            className=""
                            onClick={() => this.updateFontSize("plus")}
                          >
                            <i className="icon-plus"></i>
                          </button>
                          <div> {t("BUTTONS.Label_Size")}</div>{" "}
                          <button className="">
                            <i
                              className="icon-minus"
                              onClick={() => this.updateFontSize("minus")}
                            ></i>
                          </button>
                        </li>
                        <li>
                          <label>Font size:</label>
                          <input
                            type="number"
                            value={this.state.textSize}
                            onChange={(e) =>
                              this.setState({ textSize: e.target.value })
                            }
                          />
                        </li>
                        <li className="wall-thinkness">
                          <div className="thinkness-field">
                            <input
                              className="form-control"
                              type="number"
                              onChange={(e) => this.handleWallInput(e)}
                              value={this.state.wallThickness}
                            />
                            <span className="wall-label">
                              {t("BUTTONS.Wall_Thickness_Inches")}
                            </span>
                          </div>
                          {this.state.wallThicknessError && (
                            <div className="form-error">
                              {this.state.wallThicknessError}
                            </div>
                          )}
                        </li>
                      </ul>
                    </li>
                  </ul>
                  {this.props.isTechnician?.create && (
                    <button
                      id={"saveArea"}
                      onClick={() => {
                        this.saveArea();
                      }}
                    />
                  )}
                </div>
                <div className="select-floor">
                  {!this.props.isTechnician?.create &&
                    !this.props.isTechnician?.edit &&
                    (this.props.newMeasurementTypes?.remoteVal ||
                      this.props.newMeasurementTypes?.remoteValVideo) && (
                      <select
                        className="form-control sm-hight"
                        name="floortype"
                        value={this.state.selectedMeasurementType}
                        onChange={(e) => {
                          this.handleMeasurementTypeChange(e);
                        }}
                      >
                        {this.props.newMeasurementTypes?.remoteVal && (
                          <option
                            key={measurementTypes[0].id}
                            value={measurementTypes[0].id}
                          >
                            {measurementTypes[0].name}
                          </option>
                        )}
                        {this.props.newMeasurementTypes?.remoteValVideo && (
                          <option
                            key={measurementTypes[3].id}
                            value={measurementTypes[3].id}
                          >
                            RemoteVal Video
                          </option>
                        )}
                      </select>
                    )}
                  {!this.props.isTechnician?.create &&
                  this.state.selectedMeasurementType === "4" ? (
                    this.props.floorListForVideo.length &&
                    (this.props.floorListForVideo.length > 1 ||
                      this.props.floorListForVideo.some(
                        (item) => item.floorTagNameList?.length > 1
                      )) ? (
                      <select
                        className="form-control sm-hight"
                        name="floornumber"
                        value={this.state.selectedCustomFloorName}
                        onChange={(e) => {
                          this.handleOnchangeForRemoteValVideo(e);
                        }}
                      >
                        {this.props.floorListForVideo.map((floor) =>
                          floor.floorTagNameList?.map((floorname) => (
                            <option
                              key={floorname}
                              value={floorname}
                              selectedfloorindex={floor.floorIndexList}
                              id={floor.floorScanId}
                            >
                              {floorname}
                            </option>
                          ))
                        )}
                      </select>
                    ) : this.props.floorListForVideo.length == 1 &&
                      this.props.floorListForVideo[0]?.floorTagNameList
                        ?.length == 1 ? (
                      <span>
                        {this.props.floorListForVideo[0]?.floorTagNameList[0]}
                      </span>
                    ) : (
                      this.props.floorListForVideo.map((floor) =>
                        floorName.map(
                          (floorname) =>
                            floorname.id === floor.floorIndexList && (
                              <span>{floorname.value}</span>
                            )
                        )
                      )
                    )
                  ) : !this.props.isTechnician?.create &&
                    !this.props.isTechnician?.edit &&
                    this.state.floorList.length > 1 ? (
                    <select
                      className="form-control sm-hight"
                      name="floornumber"
                      value={this.state.selectedFloor}
                      onChange={(e) => {
                        this.handleOnchange(e);
                      }}
                    >
                      {this.state.floorList.map((floor) => (
                        <option key={floor.floorId} value={floor.floorId}>
                          {floor.floorName}
                        </option>
                      ))}
                    </select>
                  ) : (
                    !this.props.isTechnician?.create &&
                    !this.props.isTechnician?.edit &&
                    this.state.floorList.length == 1 && (
                      <span>{this.state.floorList[0].floorName}</span>
                    )
                  )}
                  {!this.props.isTechnician?.create &&
                    this.state.selectedMeasurementType !== "4" &&
                    !this.state.showErrorPage &&
                    this.state.enableDelete && (
                      <select
                        className="form-control sm-hight"
                        name="floortype"
                        value={this.state.selectedRoomType}
                        onChange={(e) => {
                          this.handleOnchangeRoomType(e);
                        }}
                      >
                        <option>GLA</option>
                        <option>Non-GLA</option>
                      </select>
                    )}

                  <div
                    style={{
                      visibility: this.state.showErrorPage
                        ? "hidden"
                        : "visible",
                    }}
                    className="floorname-wrap"
                  >
                    {!this.state.wallThicknessError && (
                      <button
                        onClick={() => this.toggleAreaDetails()}
                        className="view-detail"
                      >
                        <Tooltip title={t("BUTTONS.Property_Details")} arrow>
                          <i className="icon-information"></i>
                        </Tooltip>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
            {this.state.isModifiableRoom && (
              <div className="menu-list">
                <div className="menu-items">
                  <ul>
                    <li className="tooltip-icon">
                      <Tooltip title={t("BUTTONS.Save")} arrow>
                        <button
                          className="active"
                          onClick={() => {
                            this.saveModifiableRoom();
                          }}
                        >
                          <i className="icon-save-file"></i>
                        </button>
                      </Tooltip>
                    </li>
                  </ul>
                </div>
              </div>
            )}
          </div>
          {!this.state.isMajourmentData ||
            (this.state.showErrorPage && (
              <div className="no-data-found-container">
                <div className="no-data-found">
                  <div className="box">
                    {!this.props.measurementLoading && (
                      <>
                        <i className={MEASUREMENTS_ICON}></i>
                        <p>
                          {t("ERROR_MESSAGES.Floor_sketch_is_not_available")}
                        </p>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          {this.state.isMajourmentData && !this.state.showErrorPage && (
            <div className="measurement-view">
              {!this.state.isEditModeEnabled && (
                <div
                  className={`induction-measurment ${
                    this.props.isTechnician?.create ? "technician-view" : ""
                  }`}
                >
                  <ul>
                    <li className="gla">
                      <span></span>GLA
                    </li>
                    <li className="non-gla">
                      <span></span>NON-GLA
                    </li>
                    <li className="partition">
                      <span></span>Partition
                    </li>
                    {this.state.selectedMeasurementType ===
                      measurementTypes[3].id && (
                      <li className="non-additional">
                        <span></span>NON-ADDITIONAL
                      </li>
                    )}
                  </ul>
                </div>
              )}
              {this.state.isEditMode && (
                <div className="snap-instruction">
                  <p>
                    {t("WEB_LABELS.Double_click_on_any_corner_to_auto_snap")}
                  </p>
                </div>
              )}
              {this.state.isDoorAvailable && (
                <div className="snap-instruction-rep">
                  <p>
                    {t(
                      "WEB_LABELS.Click_on_door_window_and_drag_to_reposition"
                    )}
                  </p>
                </div>
              )}

              <div
                className={`direction-view ${
                  this.props.isTechnician?.create ? "technician-view" : ""
                }`}
              >
                <div className="arrow">
                  <div className="row-one">
                    <button onClick={() => this.doNavigate("left")}>
                      <i className="icon-arrow-left"></i>
                    </button>
                  </div>
                  <div className="row-one">
                    <button onClick={() => this.doNavigate("up")}>
                      <i className="icon-arow-top"></i>
                    </button>
                    <button onClick={() => this.doNavigate("down")}>
                      <i className="icon-arrow-bottom"></i>
                    </button>
                  </div>
                  <div className="row-one">
                    <button onClick={() => this.doNavigate("right")}>
                      <i className="icon-arrow-right"></i>
                    </button>
                  </div>
                </div>
                <div className="zoom-level">
                  <div className="level">
                    <button onClick={() => this.doZoom("in")}>
                      <i className="icon-measurement-plus"></i>
                    </button>
                    <button onClick={() => this.doZoom("out")}>
                      <i className="icon-measurement-minus"></i>
                    </button>
                  </div>
                </div>
              </div>
              <div className="inner-measurement inner-measurement-hidden">
                <canvas id="measurementcanvas" />
              </div>
            </div>
          )}
        </div>
        {this.state.showAreaDetails && (
          <AreaDetails
            toggleAreaDetails={this.toggleAreaDetails}
            areaDetails={this.state.areaDetails}
            showAreaDetails={this.state.showAreaDetails}
            wallThickness={this.state.wallThickness}
            selectedFloor={this.state.selectedFloor}
            floorList={this.state.floorList}
            floorListForVideo={this.props.floorListForVideo}
            selectedMeasurementType={this.state.selectedMeasurementType}
            originalFloorPlan={originalFloorPlan}
          ></AreaDetails>
        )}
        {this.state.confirmationModal && (
          <ConfirmationModal
            cancelEvent={() => {
              this.handleConfirmationModal();
            }}
            title={t("COMMON_MESSAGES.DELETEROOM_CONFIRMATION_MESSAGE")}
            cancelText={t("COMMON_MESSAGES.No")}
            confirmText={t("COMMON_MESSAGES.Yes")}
            confirmEvent={() => {
              this.deleteRoom();
            }}
          ></ConfirmationModal>
        )}
        {!this.state.is90Degree && (
          <div style={this.state.style}>
            <ul className="auto-snap-button">
              <li>
                <Tooltip title="Auto Snap Correct" arrow>
                  <button
                    className="snap-true"
                    onClick={() => {
                      this.acceptAutoDegree(currentCircleEvent);
                    }}
                  >
                    <i className="icon-true"></i>
                  </button>
                </Tooltip>
              </li>
              <li>
                <Tooltip title="Auto Snap Discard" arrow>
                  <button
                    className="snap-false"
                    onClick={() => {
                      this.discardAutoDegree();
                    }}
                  >
                    <i className="icon-false"></i>
                  </button>
                </Tooltip>
              </li>
            </ul>
          </div>
        )}

        {this.state.lineselected && (
          <div style={this.state.linestyle}>
            <ul className="auto-snap-button">
              <li>
                <Tooltip title="Add Line" arrow>
                  <button
                    className="snap-true"
                    onClick={() => {
                      this.addLine();
                    }}
                  >
                    <img src="/images/build_add_line.svg" alt="Add Line" />
                  </button>
                </Tooltip>
              </li>
              <li>
                <Tooltip title="Delete Line" arrow>
                  <button
                    className="snap-false"
                    onClick={() => {
                      this.deleteLine();
                    }}
                  >
                    <i className="icon-delete"></i>
                  </button>
                </Tooltip>
              </li>
              <li>
                <Tooltip title="Close" arrow>
                  <button
                    className="snap-false"
                    onClick={() => {
                      this.CloseOptions();
                    }}
                  >
                    <i className="icon-false"></i>
                  </button>
                </Tooltip>
              </li>
            </ul>
          </div>
        )}
      </>
    );
  }
}

export default connect(null, {
  saveMeasurementJson,
  StartLoading,
  StopLoading,
})(withTranslation()(MeasurementTab));
