import api from "./api";

export default class VideoCallAPI {
  geneateQuickCall(requestData) {
    return api.post(`call/generatelink`, requestData);
  }
}
