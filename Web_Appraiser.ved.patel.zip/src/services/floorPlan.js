import api from "./apis/api";
import { hydrateFloors } from "./transformers/viewFloorPlanTransformer";

class FloorService {
  getFloor(data) {
    return api.floors.getFloor(data).then(hydrateFloors);
  }
  getFloorContent(data) {
    return api.floors.getFloorContent(data);
  }
  publishJson(data) {
    return api.floors.publishJsonData(data);
  }
  fetchZipFile(payload) {
    return api.downloadGet(
      `/floorscan/file-view/${payload.floorScanId}/${payload.fileName}`,
      {}
    );
  }
  autoSaveThreeDJson(data) {
    return api.floors.autoSaveThreeDJson(data);
  }
}

export default new FloorService();
