import React, { useEffect, useRef, useState } from "react";
import _ from "lodash";
import Button from "./../../common/Button";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Tooltip from "@mui/material/Tooltip";
import { useTranslation } from "react-i18next";
import { useParams, useHistory } from "react-router-dom";
import {
  measurementResponseFormat,
  measurementTypes,
  VSI_JO_TYPE,
} from "../../../constants/appConstant";
import { connect, useDispatch, useSelector } from "react-redux";
import {
  getFloorScanList,
  plyRetry,
  PlyRetryAfterSuccess,
  fetchFloorScanReportList,
} from "../../../actions/technicianJobAction";
import "./index.scss";
import {
  floorScanStatusEnum,
  floorName,
  floorScanType,
} from "../../../constants/enums";
import CompleteTechnicianJobOrder from "./CompleteTechnicianJobOrder";
import { customToast } from "../../../helpers/customToast";
import MeasurementTab from "../../JobOrders/JobOrderDetails/measurementTab";
import {
  loadAvailableMeasurementData,
  loadDownloadReportMeasurementJson,
  loadFloorScanIndex,
  loadMeasurementJson,
  loadFloorScanJsons,
  downloadPDFFromHTML,
  sendReportTOHomeOwner,
} from "../../../actions/measurementAction";
import { fetchProfileDetails } from "../../../actions/profileAction";
import { MEASUREMENTS_ICON } from "../../JobOrders/JobOrderDetails/Common/commonText";
import DownloadReportModal from "../../JobOrders/JobOrderDetails/measurementTab/downloadReportModal";
import {
  captureMapViewImage,
  downloadReport,
} from "../View3DFloorPlan/UtilityThreejs";
import { fetchDetails } from "../../../actions/detailsActions";
import store from "../../../store";
import { StoreActions } from "../../../actions/jobAction";
import { scrollIntoView } from "../../../helpers";

const FloorScanList = (props) => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const { id } = useParams();
  const history = useHistory();
  const [sortBy, setSortBy] = useState("assignee");
  const [direction, setDirection] = useState("DESC");
  const floorScanStore = useSelector(
    (state) => state?.technicianJob?.floorScan
  );
  const floosScansLoading = useSelector(
    (state) => state?.technicianJob?.floosScansLoading
  );
  const [floorScan, setfloorScan] = useState({});
  const [openCompleteInspectionModal, setOpenCompleteInspectionModal] =
    useState(false);
  const [
    selectedJobOrderIdForCompleteInspection,
    setSelectedJobOrderIdForCompleteInspection,
  ] = useState(null);
  const [refresh, setRefresh] = useState(false);
  const [floorScanList, setFloorScanList] = useState(true);
  const [newMeasurementTypes, setNewMeasurementTypes] = useState({
    remoteValVideo: true,
  });
  const [selectedFloorScanId, setSelectedFloorScanId] = useState([]);
  const [selectedFloorScanName, setSelectedFloorScanName] = useState("");
  const [floorListForVideo, setFloorListForVideo] = useState([]);
  const [loadMeasurementTab, setLoadMeasurementTab] = useState(false);
  const [showDownloadReportModal, setShowDownloadReportModal] = useState(false);
  const [isDownloadReport, setIsDownloadReport] = useState(false);
  const [isSendReport, setIsSendReport] = useState(false);
  const [tenantLogoUrl, setTenantLogoUrl] = useState("");
  const [addressMapUrl, setAddressMapUrl] = useState("");
  const tenantLogo = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess?.tenantLogo;
  });
  let tenantDetails = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess;
  });
  const fetchDetailsStart = useSelector(
    (state) => state?.details?.fetchDetailsStart
  );
  const scrollableListRef = useRef();

  let totalCount = _.get(floorScan, ["floorList"], []);
  totalCount = totalCount.length;
  const [measurementTabDataLoading, setMeasurementTabDataLoading] =
    useState(false);

  useEffect(() => {
    if (!_.isNil(floorScanStore.floorList?.length)) {
      setfloorScan(floorScanStore);
    }
  }, [floorScanStore]);

  useEffect(() => {
    if (id) {
      setLoadMeasurementTab(false);
      props.fetchDetails(id).then((data) => {
        captureMapViewImage(
          setAddressMapUrl,
          !_.isEmpty(data?.address) ? data.address : ""
        );
      });
      dispatch(
        getFloorScanList({
          id,
          direction,
        })
      );
    }
  }, [id, dispatch, direction, refresh, floorScanList]);
  useEffect(() => {
    if (!floorScanList) {
      setMeasurementTabDataLoading(true);
      props
        .loadAvailableMeasurementData({
          jobOrderId: id,
        })
        .then((data) => {
          setNewMeasurementTypes(data);
          setMeasurementTabDataLoading(true);
          props
            .loadFloorScanIndex({
              jobOrderId: id,
            })
            .then((floorScanIndexData) => {
              setFloorListForVideo(floorScanIndexData);
              setSelectedFloorScanId(floorScanIndexData?.[0]?.floorScanId);
              setSelectedFloorScanName(
                floorScanIndexData?.[0]?.floorTagNameList?.[0]
              );
              let type = measurementTypes[3].name;
              let format = measurementResponseFormat.converted;
              let floorData = floorScanIndexData?.find(
                (item) => item.floorTagNameList?.length
              );
              setMeasurementTabDataLoading(true);
              type && format
                ? props
                    .loadMeasurementJson({
                      jobOrderId: id,
                      type: type,
                      format: format,
                      floorScanId: floorData?.floorScanId,
                      floorTagName: floorData?.floorTagNameList[0],
                    })
                    .then((data) => {
                      setLoadMeasurementTab(true);
                      setMeasurementTabDataLoading(false);
                    })
                    .catch(() => {
                      setMeasurementTabDataLoading(false);
                    })
                : (() => {
                    setLoadMeasurementTab(true);
                    setMeasurementTabDataLoading(false);
                  })();
            })
            .catch(() => {
              setMeasurementTabDataLoading(false);
            });
        })
        .catch(() => {
          setMeasurementTabDataLoading(false);
        });
    }
  }, [id, floorScanList]);

  useEffect(() => {
    if (!floosScansLoading && totalCount !== 0) {
      setTimeout(() => {
        scrollIntoView(scrollableListRef);
      }, 10);
    }
  }, [floosScansLoading, totalCount]);

  const tableHead = [
    { key: "orderId", label: "Floor Scan", disableSorting: true },
    { key: "name", label: "Floor Name", disableSorting: true },
    {
      key: "wallThickness",
      label: "Wall Thickness (inch)",
      disableSorting: true,
    },
    { key: "floorScanType", label: "Floor Scan Type", disableSorting: true },
    { key: "assignee", label: "Created On", disableSorting: false },
    { key: "propertyType", label: "Floor Scan Status", disableSorting: true },
    { key: "action", label: "Action", disableSorting: true },
  ];

  const handleSorting = (cellId) => {
    resetActionsData();
    const isAsc = sortBy === cellId && direction === "DESC";
    setDirection(isAsc ? "ASC" : "DESC");
    setSortBy(cellId);
  };
  const handleJobOrder = () => {
    history.push("/");
  };

  const PlyRetry = (floorScanID) => {
    resetActionsData();
    dispatch(plyRetry({ floorScanID })).then(() =>
      dispatch(
        getFloorScanList({
          id,
          direction,
        })
      )
    );
  };

  const PlyRetryAfterSuccessClick = (floorScanID) => {
    resetActionsData();
    dispatch(PlyRetryAfterSuccess({ floorScanID })).then(() =>
      dispatch(
        getFloorScanList({
          id,
          direction,
        })
      )
    );
  };

  const loadDownloadReportData = () => {
    resetActionsData();
    props.loadDownloadReportMeasurementJson(id).then((_) => {
      setShowDownloadReportModal(true);
    });
  };

  const resetActionsData = () => {
    store.dispatch(
      StoreActions({
        jobOrders: _.get(props, ["job", "storeActionsData", "jobOrders"], {}),
        floorScans: {},
      })
    );
  };

  return (
    <section className="content-wapper">
      <div className="breadcrumb breadcrumb-end">
        <ul>
          <li>
            <button onClick={() => handleJobOrder()}>
              {t("WEB_LABELS.My_Job_Orders")}
            </button>
          </li>
          <li>
            {_.get(props, ["details", "fetchDetailsSuccess", "orderNo"], "--")}
          </li>
        </ul>
        <div className="right-side">
          {(VSI_JO_TYPE.includes(
            floorScan?.jobOrderSource?.trim()?.toLowerCase()
          ) ||
            floorScan?.jobOrderSource?.trim()?.toLowerCase() == "sdk") &&
            !floosScansLoading && (
              <Button
                disabled={
                  floorScan?.jobOrderStatus === "Completed" ? true : null
                }
                onClick={() => {
                  dispatch(
                    fetchFloorScanReportList(floorScan?.jobOrderId)
                  ).then((__response) => {
                    if (__response?.data?.data?.length > 0) {
                      setOpenCompleteInspectionModal(true);
                      setSelectedJobOrderIdForCompleteInspection(
                        floorScan?.jobOrderId
                      );
                    } else {
                      customToast.error("There are no Floor Scan Reports");
                    }
                  });
                }}
                className="blue-btn"
              >
                Complete Inspection
              </Button>
            )}
          <Button
            disabled={fetchDetailsStart}
            className="blue-btn"
            onClick={() => loadDownloadReportData()}
          >
            <span>
              <i className="icon-download-report"></i>
            </span>
            Download Report
          </Button>
        </div>
      </div>
      <div className="common-panel">
        <CompleteTechnicianJobOrder
          refresh={refresh}
          setRefresh={setRefresh}
          openCompleteInspectionModal={openCompleteInspectionModal}
          setOpenCompleteInspectionModal={setOpenCompleteInspectionModal}
          selectedJobOrderIdForCompleteInspection={
            selectedJobOrderIdForCompleteInspection
          }
        />
        <div>
          <div className="custom-tab">
            <ul className="tab-list custom_tab-list">
              <li className={floorScanList ? "active" : ""}>
                <button
                  onClick={() => {
                    setFloorScanList(true);
                  }}
                >
                  Floor Scans
                </button>
              </li>
              <li className={floorScanList ? "" : "active"}>
                <button
                  onClick={() => {
                    resetActionsData();
                    setFloorScanList(false);
                  }}
                >
                  Measurements
                </button>
              </li>
            </ul>
          </div>
        </div>
        {floorScanList ? (
          <div className="panel-body profile-appraiser scroll-bar-style floor-plan-height">
            {!floosScansLoading && totalCount !== 0 ? (
              <TableContainer>
                <Table aria-label="simple table">
                  <TableHead>
                    <TableRow>
                      {tableHead.map((head) => (
                        <TableCell
                          key={head.key}
                          sortDirection={
                            sortBy === head.key ? direction : false
                          }
                        >
                          {head.disableSorting ? (
                            head.label
                          ) : (
                            <TableSortLabel
                              active={sortBy === head.key}
                              direction={direction.toLowerCase()}
                              onClick={() => {
                                handleSorting(head.key);
                              }}
                            >
                              {head.label}
                            </TableSortLabel>
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {_.get(floorScan, ["floorList"], []).map((d, id) => {
                      const actionData = _.get(
                        props,
                        ["job", "storeActionsData"],
                        ""
                      );
                      return (
                        <TableRow
                          ref={
                            d.id === actionData?.floorScans?.floorScanId
                              ? scrollableListRef
                              : null
                          }
                          className={`${
                            d.id === actionData?.floorScans?.floorScanId
                              ? "selected-item"
                              : ""
                          }`}
                          key={d.id}
                        >
                          <TableCell style={{ width: "15%" }}>
                            <div className="lander-logo">{d.FloorScan}</div>
                          </TableCell>
                          <TableCell style={{ width: "17%" }}>
                            {!_.isNull(d.FloorNumber) ? (
                              floorName?.map(
                                ({ id, value }, index) =>
                                  d.FloorNumber === id && <>{value}</>
                              )
                            ) : (
                              <>-</>
                            )}
                          </TableCell>
                          <TableCell style={{ width: "10%" }}>
                            {d.wallThickness}
                          </TableCell>
                          <TableCell style={{ width: "15%" }}>
                            {d.FloorScanType
                              ? d.FloorScanType === floorScanType[0].value
                                ? floorScanType[0].type
                                : floorScanType[1].type
                              : "-"}
                          </TableCell>
                          <TableCell style={{ width: "17%" }}>
                            {d.CreatedOn}
                          </TableCell>
                          <TableCell style={{ width: "16%" }}>
                            {d.Status ? (
                              floorScanStatusEnum?.map(
                                ({ id, valTechnician, color }) =>
                                  d.Status === id && (
                                    <div className={`card-chips ${color}`}>
                                      {valTechnician}
                                    </div>
                                  )
                              )
                            ) : (
                              <>-</>
                            )}
                          </TableCell>
                          <TableCell style={{ width: "12%" }}>
                            <ul className="btn-list">
                              <li>
                                {d.Status !== floorScanStatusEnum[1].id &&
                                (d.retryAvaliable || d.retryLimitReach) ? (
                                  <Tooltip title="Re-Try" arrow>
                                    <button
                                      className={`action ${
                                        d.retryLimitReach ? "disable" : ""
                                      }`}
                                      disabled={d.retryLimitReach}
                                      onClick={() => PlyRetry(d.id)}
                                    >
                                      <i className="icon-re-try" />
                                    </button>
                                  </Tooltip>
                                ) : (
                                  <Tooltip title="Edit Floor Plan" arrow>
                                    <button
                                      className="action"
                                      onClick={() => {
                                        store.dispatch(
                                          StoreActions({
                                            jobOrders: actionData?.jobOrders,
                                            floorScans: {
                                              floorScanId: d.id,
                                            },
                                          })
                                        );
                                        history.push(`/view-floorscan/${d.id}`);
                                      }}
                                    >
                                      <i className="icon-created-by" />
                                    </button>
                                  </Tooltip>
                                )}
                              </li>
                              {!d.retryAvaliable && (
                                <li>
                                  <Tooltip title="Re-Try" arrow>
                                    <button
                                      className="action"
                                      onClick={() =>
                                        PlyRetryAfterSuccessClick(d.id)
                                      }
                                    >
                                      <i className="icon-re-try" />
                                    </button>
                                  </Tooltip>
                                </li>
                              )}
                            </ul>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <div className="no-data-found">
                <div className="box">
                  {floosScansLoading ? (
                    <div className="loader-spin"></div>
                  ) : (
                    <>
                      <i className="icon-no-bookmark"></i>
                      <p>{t("WEB_LABELS.There_Are_No_Floor_Plan_Available")}</p>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : loadMeasurementTab && !floorScanList ? (
          <MeasurementTab
            mesurementData={_.get(props, ["details", "mesurementData"], {})}
            measurementLoading={_.get(
              props,
              ["details", "measurementLoading"],
              false
            )}
            measurementLoaded={_.get(
              props,
              ["details", "measurementLoaded"],
              false
            )}
            measurementError={_.get(
              props,
              ["details", "measurementError"],
              false
            )}
            isTechnician={{
              create: false,
              edit: true,
            }}
            jobOrderId={id}
            details={_.get(props, ["details", "fetchDetailsSuccess"], false)}
            fetchProfileDetails={props.fetchProfileDetails}
            loadMeasurementJson={props.loadMeasurementJson}
            newMeasurementTypes={newMeasurementTypes}
            selectedFloorScanId={selectedFloorScanId}
            setSelectedFloorScanId={setSelectedFloorScanId}
            selectedFloorScanName={selectedFloorScanName}
            setSelectedFloorScanName={setSelectedFloorScanName}
            loadFloorScanIndex={props.loadFloorScanIndex}
            floorListForVideo={floorListForVideo}
            setFloorListForVideo={setFloorListForVideo}
          ></MeasurementTab>
        ) : (
          <div className="panel-body profile-appraiser scroll-bar-style floor-plan-height">
            <div className="no-data-found-container">
              <div className="no-data-found">
                <div className="box">
                  {measurementTabDataLoading ||
                  !_.get(props, ["details", "measurementLoaded"], false) ||
                  _.get(props, ["details", "measurementLoading"], false) ? (
                    <div className="loader-spin"></div>
                  ) : (
                    <>
                      <i className={MEASUREMENTS_ICON}></i>
                      <p>{t("ERROR_MESSAGES.Floor_sketch_is_not_available")}</p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
        {showDownloadReportModal && (
          <DownloadReportModal
            loadDownloadReportData={_.get(
              props,
              ["details", "downloadReportDataSuccess"],
              []
            )}
            setShowDownloadReportModal={setShowDownloadReportModal}
            downloadReport={(selectedFloors2D, selectedFloors3D, action) =>
              downloadReport(
                props.loadFloorScanJsons,
                selectedFloors2D,
                selectedFloors3D,
                setIsDownloadReport,
                setIsSendReport,
                id,
                tenantLogoUrl,
                addressMapUrl,
                tenantDetails,
                setShowDownloadReportModal,
                setTenantLogoUrl,
                tenantLogo,
                props.downloadPDFFromHTML,
                _.get(props, ["details", "fetchDetailsSuccess"], {}),
                action,
                props.sendReportTOHomeOwner
              )
            }
            isDownloadReport={isDownloadReport}
            isSendReport={isSendReport}
            isTechnician={true}
            jobOrderSource={_.get(
              props,
              ["details", "fetchDetailsSuccess", "jobOrderSource"],
              null
            )}
          />
        )}
      </div>
    </section>
  );
};

const mapStateToProps = (state) => {
  return {
    details: state.details,
    job: state.job,
  };
};

export default connect(mapStateToProps, {
  loadMeasurementJson,
  loadAvailableMeasurementData,
  loadFloorScanIndex,
  fetchProfileDetails,
  fetchDetails,
  loadDownloadReportMeasurementJson,
  loadFloorScanJsons,
  downloadPDFFromHTML,
  sendReportTOHomeOwner,
})(FloorScanList);
