import _ from "lodash";

export const deHydrateAttachments = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    direction: data.direction.toUpperCase(),
    sortBy: data.sortBy,
  };
};

export function hydrateAttachment(data) {
  return _.omitBy(
    {
      attachmentId: data.id,
      fileName: data.fileName,
      location: data.location,
      updatedBy: data.updatedBy,
      updatedAt: data.updatedAt,
      fileSize: data.size,
    },
    _.isUndefined
  );
}

export const hydrateAttachments = (data) =>
  data.map((d) => hydrateAttachment(d));
