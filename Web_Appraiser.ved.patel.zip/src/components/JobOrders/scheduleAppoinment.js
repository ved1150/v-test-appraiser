import React, { useEffect, useState } from "react";
import { Formik } from "formik";
import * as Yup from "yup";
import Tooltip from "@mui/material/Tooltip";
import { scheduleAppoinmentMessages } from "./../../constants/validationerrorMessages";
import DatePicker from "react-datepicker";
import CustomSwitch from "../common/CustomSwitch";
import PhoneInput from "../common/PhoneInput";
import jobService from "./../../services/jobService";
import appointmentSlotsService from "./../../services/appointmentSlotsService";
import moment from "moment";
import _ from "lodash";
import { customToast } from "./../../helpers/customToast";
import {
  APPOINMENT_SCHEDULE_SUCCESS_MESSSAGE,
  APPOINMENT_RESCHEDULE_MESSSAGE,
} from "./../../constants/commonMessages";
import {
  APPOINTMENT_STATUS,
  SLOT_STATUSES,
} from "./../../constants/appConstant";
import { isNotEmpty } from "./../../helpers/commonJSFunction";
import classnames from "classnames";
import {
  validatePhoneWithRequired,
  validateInvitationTypeTab,
} from "./../../helpers/validation";
import ConfirmationMsgModal from "./../common/confirmationMsgModal";
import Button from "../common/Button";
import authenticationService from "../../services/authenticationService";
import { useTranslation } from "react-i18next";
import { logEvent } from "firebase/analytics";
import getAnalyticsInstance from "../../services/analytics";

const ScheduleNewAppoinmentStatus = [
  APPOINTMENT_STATUS.CANCELLED.key,
  APPOINTMENT_STATUS.CALL_COMPLETED.key,
];
const POConfirmedAppointmentStatus = [
  APPOINTMENT_STATUS.CONFIRMED_BY_PO.key,
  APPOINTMENT_STATUS.RESCHEDULED.key,
];

const ScheduleAppoinment = (props) => {
  const { t } = useTranslation();
  const [inviteBySMS, setInviteBySMS] = useState(true);
  const [inviteByEmail, setInviteByEmail] = useState(false);
  const [availableAppoinmentSlots, setAvailableAppoinmentSlots] = useState([]);
  const [disableAllFields, setDisableAllFields] = useState(false);
  const [enableFieldsForReschedule, setEnableFieldsForReschedule] =
    useState(false);
  const [showRescheduleBtn, setShowRescheduleBtn] = useState(false);
  const [selectedJobOrder, setSelectedJobOrder] = useState({
    ...props.selectedJobOrder,
  });
  const [submitLoading, setSubmitLoading] = useState(false);
  const [phoneNo, setPhoneNo] = useState(
    _.get(props.selectedJobOrder, ["jobOrderAppointment", "phoneNumber"], "")
  );
  const [stateErrors, seterrors] = useState({});

  const [cancelAppointmentModal, setCancelAppointmentModal] = useState(false);
  const [reason, setReason] = useState("");
  const [tempRescheduleObj, setTempRescheduleObj] = useState({});
  const [resheduleAppointmentModal, setResheduleAppointmentModal] =
    useState(false);
  useEffect(() => {
    let aStatus = _.get(
      props,
      ["selectedJobOrder", "jobOrderAppointment", "status"],
      ""
    );
    setSubmitLoading(props.job.scheduleAppoinmentStart);

    if (aStatus == APPOINTMENT_STATUS.NEW_APPOINTMENT.key) {
      setDisableAllFields(!disableAllFields);
      dateChangeHandle(
        _.get(
          props,
          ["selectedJobOrder", "jobOrderAppointment", "slotDate"],
          ""
        )
      );
    } else if (
      aStatus == APPOINTMENT_STATUS.CONFIRMED_BY_PO.key ||
      aStatus == APPOINTMENT_STATUS.RESCHEDULED.key
    ) {
      setDisableAllFields(!disableAllFields);
      setShowRescheduleBtn(!showRescheduleBtn);
      dateChangeHandle(
        _.get(
          props,
          ["selectedJobOrder", "jobOrderAppointment", "slotDate"],
          ""
        )
      );
    } else if (
      aStatus == APPOINTMENT_STATUS.CANCELLED.key ||
      aStatus == APPOINTMENT_STATUS.CALL_COMPLETED.key
    ) {
      setSelectedJobOrder({});
    } else {
    }
  }, []);

  const dateChangeHandle = (value) => {
    if (value && moment(value).isValid()) {
      const date = moment(value).startOf("day");
      const obj = {
        startDate: `${moment(date)
          .add(-1, "day")
          .format("YYYY-MM-DD")} 00:00:00`,
        endDate: `${moment(date).add(1, "day").format("YYYY-MM-DD")} 23:59:59`,
      };
      appointmentSlotsService.get(obj).then((res) => {
        if (res.length > 0) {
          const data = [];
          res.forEach((event) => {
            event.slotDetail.forEach((slot) => {
              const isSelectedObj =
                date.isSame(moment(slot.slotStartDate).startOf("day")) &&
                date.isSame(moment(slot.slotEndDate).startOf("day")) &&
                slot.isPast != true;
              if (
                isSelectedObj &&
                (slot.status == SLOT_STATUSES.AVAILABLE ||
                  slot.status == SLOT_STATUSES.CANCELLED ||
                  slot.status == SLOT_STATUSES.RESCHEDULED)
              ) {
                data.push({
                  ...slot,
                  slotDate: event.slotDate,
                  appraisersSlotId: slot.slotId,
                  startTime: slot.formatedStartTime,
                  endTime: slot.formatedEndTime,
                });
              }
              if (
                isSelectedObj &&
                slot.status == SLOT_STATUSES.BOOKED &&
                slot.slotId ==
                  _.get(
                    props,
                    ["selectedJobOrder", "jobOrderAppointment", "slotId"],
                    ""
                  )
              ) {
                data.push({
                  ...slot,
                  slotDate: event.slotDate,
                  appraisersSlotId: slot.slotId,
                  startTime: slot.formatedStartTime,
                  endTime: slot.formatedEndTime,
                });
              }
            });
          });
          setAvailableAppoinmentSlots(data);
        } else {
          if (
            window.confirm(
              t("COMMON_MESSAGES.Configure_your_availability_from_calendar_tab")
            )
          ) {
            props.history.push("/calendar");
          }
        }
      });
    }
  };

  const handlePhoneChange = (value) => {
    const errors = stateErrors;
    setPhoneNo(value);
    errors["phoneNo"] = validatePhoneWithRequired(value);
    seterrors(errors);
  };

  const toggleInvite = (e) => {
    const errors = stateErrors;
    let obj = {
      sms: inviteBySMS,
      email: inviteByEmail,
    };
    if (e.target.name == "sms") {
      setInviteBySMS(e.target.checked);
      obj["sms"] = e.target.checked;
    } else if (e.target.name == "email") {
      setInviteByEmail(e.target.checked);
      obj["email"] = e.target.checked;
    }

    errors["invitationType"] = validateInvitationTypeTab(obj);
    seterrors(errors);
  };
  const isBtnDisabled = () => {
    if (
      stateErrors.phoneNo ||
      (inviteBySMS && validatePhoneWithRequired(phoneNo))
    ) {
      return true;
    }
    if (stateErrors.invitationType) {
      return true;
    }
    return false;
  };

  const handleFormSubmit = (data) => {
    let aStatus = _.get(
      props,
      ["selectedJobOrder", "jobOrderAppointment", "status"],
      ""
    );
    let appraiserAvailability = _.find(availableAppoinmentSlots, {
      appraisersSlotId: data.slots,
    });
    const requestData = {
      address: data.address,
      emailId: data.email,
      jobOrderId: props.selectedJobOrder.id,
      message: "",
      phoneNumber: phoneNo,
      propertyOwnerName: data.ownerName,
      isRecording: data.isRecording,
    };
    if (appraiserAvailability) {
      requestData["appraiserAvailability"] = {
        appraisersSlotId: appraiserAvailability.slotId,
        slotDate: appraiserAvailability.slotDate,
        slotDateEndTime: appraiserAvailability.slotDateEndTime,
        slotDateStartTime: appraiserAvailability.slotDateStartTime,
        slotStatus: appraiserAvailability.status,
      };
    }
    if (data.submitType == 1) {
      if (
        aStatus == APPOINTMENT_STATUS.NEW_APPOINTMENT.key &&
        !enableFieldsForReschedule
      ) {
        resendAppointment({
          appointmentId: _.get(props, [
            "selectedJobOrder",
            "jobOrderAppointment",
            "appointmentId",
          ]),
          emailId: inviteByEmail ? data.email : null,
          phoneNumber: inviteBySMS ? phoneNo : null,
        });
      } else {
        scheduleAppointment(requestData);
      }
    } else if (data.submitType == 3) {
      handleResheduleAppointment({
        ...requestData,
        appointmentStatus: APPOINTMENT_STATUS.NEW_APPOINTMENT.key,
      });
    } else {
    }
  };

  const resendAppointment = (requestData) => {
    setSubmitLoading(true);
    props.resendAppointment(requestData).then((res) => {
      if (res) {
        setSubmitLoading(false);
        props.toggleScheduleAppoinment();
        props.handleJobOrder();
      } else {
      }
    });
  };
  const scheduleAppointment = (requestData) => {
    setSubmitLoading(true);
    props.scheduleAppoinment(requestData).then((res) => {
      if (res) {
        setSubmitLoading(false);
        props.toggleScheduleAppoinment();
        customToast.success(
          t("COMMON_MESSAGES.APPOINMENT_SCHEDULE_SUCCESS_MESSSAGE")
        );
        props.handleJobOrder();
        if (process.env.REACT_APP_SENTRY_ENV == "Production") {
          getAnalyticsInstance().then((analytics) => {
            logEvent(analytics, "Schedule Session", { name: "" + " " + "" });
          });
        } else {
        }
      } else {
      }
    });
  };

  const rescheduleAppointment = () => {
    const requestData = { ...tempRescheduleObj, reason: reason };
    const id = props.selectedJobOrder.jobOrderAppointment.appointmentId;
    props.rescheduleAppoinment(requestData, id).then((res) => {
      if (res) {
        setReason("");
        handleResheduleAppointment();
        props.toggleScheduleAppoinment();
        customToast.success(
          t("COMMON_MESSAGES.APPOINMENT_RESCHEDULE_MESSSAGE")
        );
        props.handleJobOrder();
      } else {
      }
    });
  };

  const cancelAppointment = () => {
    const data = {
      appointmentId: _.get(
        selectedJobOrder,
        ["jobOrderAppointment", "appointmentId"],
        ""
      ),
      status: "CANCELLED",
      reason: reason,
    };
    props.cancelAppointment(data).then((res) => {
      setReason("");
      handleCancelAppointment();
      props.toggleScheduleAppoinment();
    });
  };

  const handleCancelAppointment = () => {
    setCancelAppointmentModal(!cancelAppointmentModal);
  };

  const handleResheduleAppointment = (obj = {}) => {
    setTempRescheduleObj(obj);
    setResheduleAppointmentModal(!resheduleAppointmentModal);
  };

  return (
    <>
      <div className="comman-modal right-side open">
        <div className="comman-modal-main">
          <div className="side-head">
            {t("WEB_LABELS.Schedule_Appointment")}
            <button
              className="close-modal"
              onClick={props.toggleScheduleAppoinment}
            >
              <i className="icon-close-image"></i>
            </button>
          </div>

          <div className="comman-modal-body schedule-appointment scroll-bar-style">
            <Formik
              enableReinitialize
              initialValues={{
                jobOrderId: _.get(props, ["selectedJobOrder", "orderNo"], ""),
                address:
                  _.isNil(props.selectedJobOrder.jobOrderAppointment) ||
                  _.includes(
                    ScheduleNewAppoinmentStatus,
                    _.get(
                      props,
                      ["selectedJobOrder", "jobOrderAppointment", "status"],
                      ""
                    )
                  )
                    ? _.get(props, ["selectedJobOrder", "address"], "")
                    : _.get(
                        selectedJobOrder,
                        ["jobOrderAppointment", "address"],
                        ""
                      ),
                ownerName:
                  _.isNil(props.selectedJobOrder.jobOrderAppointment) ||
                  _.includes(
                    ScheduleNewAppoinmentStatus,
                    _.get(
                      props,
                      ["selectedJobOrder", "jobOrderAppointment", "status"],
                      ""
                    )
                  )
                    ? _.get(props, ["selectedJobOrder", "name"], "")
                    : _.get(
                        selectedJobOrder,
                        ["jobOrderAppointment", "propertyOwnerName"],
                        ""
                      ),
                email: _.get(
                  selectedJobOrder,
                  ["jobOrderAppointment", "emailId"],
                  ""
                ),

                date: moment(
                  _.get(
                    selectedJobOrder,
                    ["jobOrderAppointment", "slotDate"],
                    ""
                  )
                ).isValid()
                  ? moment(
                      _.get(
                        selectedJobOrder,
                        ["jobOrderAppointment", "slotDate"],
                        ""
                      )
                    ).toDate()
                  : null,
                slots: _.get(
                  selectedJobOrder,
                  ["jobOrderAppointment", "slotId"],
                  ""
                ),
                message: _.get(
                  selectedJobOrder,
                  ["jobOrderAppointment", "message"],
                  ""
                ),
                isRecording:
                  isNotEmpty(selectedJobOrder) &&
                  isNotEmpty(selectedJobOrder.jobOrderAppointment)
                    ? _.get(
                        selectedJobOrder,
                        ["jobOrderAppointment", "callRecording"],
                        ""
                      )
                    : _.get(props, ["configurationDetail", "isCallRecording"]),
                submitType: 1,
              }}
              onSubmit={(values, { setSubmitting }) => {
                handleFormSubmit(values);
                setSubmitting(false);
              }}
              validationSchema={Yup.object().shape({
                address: Yup.string().required(
                  t("ERROR_MESSAGES.scheduleAppoinmentMessages.addressRequired")
                ),
                ownerName: Yup.string().required(
                  t(
                    "ERROR_MESSAGES.scheduleAppoinmentMessages.ownernameRequired"
                  )
                ),
                date: Yup.string()
                  .required(t("WEB_LABELS.Appointment_Date_is_Required"))
                  .nullable(),
                slots:
                  (_.get(
                    props,
                    ["selectedJobOrder", "jobOrderAppointment", "status"],
                    ""
                  ) != APPOINTMENT_STATUS.NEW_APPOINTMENT.key ||
                    enableFieldsForReschedule) &&
                  Yup.string().required(
                    t("ERROR_MESSAGES.scheduleAppoinmentMessages.slotRequired")
                  ),
                email: inviteByEmail
                  ? Yup.string()
                      .required(
                        t(
                          "ERROR_MESSAGES.scheduleAppoinmentMessages.emailRequired"
                        )
                      )
                      .nullable()
                      .email(
                        t(
                          "ERROR_MESSAGES.scheduleAppoinmentMessages.emailValid"
                        )
                      )
                  : Yup.string()
                      .email(
                        t(
                          "ERROR_MESSAGES.scheduleAppoinmentMessages.emailValid"
                        )
                      )
                      .nullable(),
              })}
            >
              {(props) => {
                const {
                  values,
                  isValid,
                  touched,
                  errors,
                  isSubmitting,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  setFieldValue,
                  dirty,
                  setTouched,
                } = props;
                return (
                  <form className="" onSubmit={handleSubmit}>
                    <div className="form-group">
                      <label>{t("WEB_LABELS.Job_Order_ID")}</label>
                      <input
                        disabled="disabled"
                        type="text"
                        className="form-control"
                        name="jobOrderId"
                        placeholder=""
                        onChange={handleChange}
                        value={values.jobOrderId}
                      />
                    </div>

                    <div className="form-group">
                      <label>{t("WEB_LABELS.Property_Owner_Name")}</label>
                      <input
                        disabled="disabled"
                        type="text"
                        className="form-control"
                        name="ownerName"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        placeholder={t("WEB_LABELS.Property_Owner_Name")}
                        value={values.ownerName}
                      />
                      {errors.ownerName && touched.ownerName && (
                        <div className="form-error">{errors.ownerName}</div>
                      )}
                    </div>

                    <div className="form-group">
                      <label>{t("WEB_LABELS.Address")}</label>
                      <input
                        disabled="disabled"
                        type="text"
                        className="form-control"
                        name="address"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        placeholder={t("WEB_LABELS.Address")}
                        value={values.address}
                      />
                      {errors.address && touched.address && (
                        <div className="form-error">{errors.address}</div>
                      )}
                    </div>

                    <div className="check-group">
                      <div className="check-group-inner">
                        <div className="check-btn">
                          <label>
                            <input
                              type="checkbox"
                              id="sms"
                              name="sms"
                              onClick={toggleInvite}
                              checked={inviteBySMS}
                            />
                            <span>{t("WEB_LABELS.Cell_Phone")}</span>
                          </label>
                        </div>
                        <div className="check-btn">
                          <label>
                            <input
                              type="checkbox"
                              id="email"
                              name="email"
                              onClick={toggleInvite}
                              checked={inviteByEmail}
                            />
                            <span>{t("WEB_LABELS.Email")}</span>
                          </label>
                        </div>
                      </div>
                      {stateErrors.invitationType && (
                        <div className="form-error">
                          {stateErrors.invitationType}
                        </div>
                      )}
                    </div>
                    {inviteBySMS && (
                      <div className="form-group">
                        <PhoneInput
                          country={"us"}
                          name={"phoneNo"}
                          value={phoneNo}
                          onChange={handlePhoneChange}
                          countryCodeEditable={false}
                          onlyCountries={["us"]}
                          enableSearch={false}
                          placeholder={t("WEB_LABELS.enter_phone_number")}
                        />
                        {stateErrors.phoneNo && (
                          <div className="form-error">
                            {stateErrors.phoneNo}
                          </div>
                        )}
                      </div>
                    )}
                    {inviteByEmail && (
                      <div className="form-group">
                        <input
                          type="text"
                          className="form-control"
                          name="email"
                          onBlur={handleBlur}
                          onChange={handleChange}
                          placeholder="abc@abc.com"
                          value={values.email}
                        />
                        {errors.email && touched.email && (
                          <div className="form-error">{errors.email}</div>
                        )}
                      </div>
                    )}
                    {disableAllFields && !enableFieldsForReschedule && (
                      <div className="schedule-link">
                        {" "}
                        <button
                          onClick={() => {
                            setEnableFieldsForReschedule(
                              !enableFieldsForReschedule
                            );
                          }}
                          className="link-btn"
                        >
                          {t("WEB_LABELS.Reschedule_Appointment")}
                        </button>
                      </div>
                    )}
                    {enableFieldsForReschedule && (
                      <div className="schedule-link">
                        {" "}
                        <button
                          className="link-btn"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            props.setFieldValue(
                              "slots",
                              _.get(
                                selectedJobOrder,
                                ["jobOrderAppointment", "slotId"],
                                ""
                              )
                            );
                            props.setFieldValue(
                              "date",
                              moment(
                                _.get(
                                  selectedJobOrder,
                                  ["jobOrderAppointment", "slotDate"],
                                  ""
                                )
                              ).toDate()
                            );
                            dateChangeHandle(
                              _.get(
                                selectedJobOrder,
                                ["jobOrderAppointment", "slotDate"],
                                ""
                              )
                            );
                            setEnableFieldsForReschedule(
                              !enableFieldsForReschedule
                            );
                          }}
                        >
                          {t("WEB_LABELS.Reset_date_and_time")}
                        </button>
                      </div>
                    )}

                    <div className="form-group">
                      <label>
                        {t("WEB_LABELS.Appointment_Date")}{" "}
                        <Tooltip
                          title={t(
                            "WEB_LABELS.Appointment_Date_needs_to_be_completed_within_30_days"
                          )}
                          arrow
                        >
                          <i className="icon-information"></i>
                        </Tooltip>
                      </label>
                      <div className="date-formate">
                        <span className="icon-date-picker"></span>
                        <DatePicker
                          disabled={
                            disableAllFields && !enableFieldsForReschedule
                          }
                          id="patient-dateofbirth"
                          name="date"
                          className="form-control"
                          dateFormat="MM/dd/yyyy"
                          placeholderText={t("WEB_LABELS.Select_Date")}
                          minDate={moment().toDate()}
                          autoComplete="off"
                          onChange={(val, e) => {
                            handleChange(e);
                            dateChangeHandle(val);
                            setFieldValue("date", val);
                            setFieldValue("slots", "");
                            setTouched({
                              ...touched,
                              slots: false,
                              date: false,
                            });
                          }}
                          onBlur={handleBlur}
                          selected={values.date}
                        />
                        {touched.date && errors.date && (
                          <div className="form-error">{errors.date}</div>
                        )}
                      </div>
                    </div>
                    <div className="form-group">
                      <label>
                        {t("WEB_LABELS.Available_Appointment_Time_Slot")}
                      </label>
                      <select
                        name="slots"
                        disabled={
                          disableAllFields && !enableFieldsForReschedule
                        }
                        className="form-control"
                        onChange={handleChange}
                        onBlur={handleBlur}
                        placeholder={t(
                          "WEB_LABELS.Available_Appointment_Time_Slot"
                        )}
                        value={values.slots}
                      >
                        <option value="" disabled selected>
                          {t("WEB_LABELS.Available_Appointment_Time_Slot")}
                        </option>
                        {availableAppoinmentSlots.map((item) => (
                          <option
                            key={item.appraisersSlotId}
                            value={item.appraisersSlotId}
                          >
                            {item.startTime} - {item.endTime}
                          </option>
                        ))}
                      </select>
                      {errors.slots && touched.slots && (
                        <div className="form-error">{errors.slots}</div>
                      )}
                    </div>
                    {/* <div className="form-group">
                      <label>Message</label>
                      <textarea
                        disabled="disabled"
                        name="message"
                        onChange={handleChange}
                        className="form-control"
                        rows="5"
                        placeholder=""
                      >
                        Hello Participant, This is Appriser Name - please join
                        me for a secure video call. Click on the following link:
                        https://name.com/alexpike
                      </textarea>
                    </div> */}
                    <div className="switch-group">
                      <CustomSwitch
                        checked={values.isRecording}
                        onChange={() => {
                          setFieldValue("isRecording", !values.isRecording);
                        }}
                        name="isRecording"
                      />
                      <label>{t("WEB_LABELS.Record_Virtual_Call")}</label>
                    </div>
                    <div className="button-group text-center">
                      {disableAllFields && (
                        <Button
                          onClick={(e) => {
                            handleCancelAppointment();
                          }}
                          type="button"
                          className="blue-btn"
                        >
                          {t("BUTTONS.Cancel_Appointment")}
                        </Button>
                      )}
                      {!enableFieldsForReschedule &&
                        !_.includes(
                          POConfirmedAppointmentStatus,
                          _.get(
                            selectedJobOrder,
                            ["jobOrderAppointment", "status"],
                            ""
                          )
                        ) && (
                          <Button
                            disabled={
                              !isValid ||
                              (props.job &&
                                props.job.scheduleAppoinmentStart) ||
                              isBtnDisabled()
                            }
                            type="submit"
                            className={classnames("blue-btn", {
                              disable:
                                !isValid || submitLoading || isBtnDisabled(),
                            })}
                          >
                            {_.get(
                              selectedJobOrder,
                              ["jobOrderAppointment", "status"],
                              ""
                            ) === APPOINTMENT_STATUS.NEW_APPOINTMENT.key
                              ? t("BUTTONS.Resend_Invitation")
                              : t("BUTTONS.Send")}{" "}
                            {submitLoading && (
                              <div className="loader-spin"></div>
                            )}
                          </Button>
                        )}
                      {enableFieldsForReschedule && (
                        <Button
                          type="submit"
                          disabled={
                            !isValid ||
                            !dirty ||
                            (props.job && props.job.scheduleAppoinmentStart) ||
                            isBtnDisabled()
                          }
                          onClick={() => setFieldValue("submitType", 3)}
                          className={classnames("blue-btn", {
                            disable:
                              !isValid ||
                              !dirty ||
                              submitLoading ||
                              isBtnDisabled(),
                          })}
                        >
                          {t("BUTTONS.Reschedule_Appointment")}{" "}
                          {submitLoading && <div className="loader-spin"></div>}
                        </Button>
                      )}
                    </div>
                  </form>
                );
              }}
            </Formik>
          </div>
        </div>
      </div>
      {cancelAppointmentModal && (
        <ConfirmationMsgModal
          from="JobOrder"
          eventAction="Cancel"
          selectedJobOrder={selectedJobOrder}
          handleCancelAppointment={handleCancelAppointment}
          handleConfirmationModal={cancelAppointment}
          setReason={setReason}
          callType=""
        ></ConfirmationMsgModal>
      )}
      {resheduleAppointmentModal && (
        <ConfirmationMsgModal
          from="JobOrder"
          eventAction="Reschedule"
          selectedJobOrder={{}}
          handleCancelAppointment={handleResheduleAppointment}
          handleConfirmationModal={rescheduleAppointment}
          setReason={setReason}
          callType=""
        ></ConfirmationMsgModal>
      )}
    </>
  );
};

export default ScheduleAppoinment;
