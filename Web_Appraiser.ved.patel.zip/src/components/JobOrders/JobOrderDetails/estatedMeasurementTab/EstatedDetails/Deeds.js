import { useState } from "react";

const Deeds = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Deeds{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {props.estatedData.data.deeds.map((value) =>
          Object.keys(value).map((key) => (
            <li key={`deeds_${key}`}>
              {key === "document_type" ? (
                <b>{value[key]}</b>
              ) : (
                <>
                  <div style={{ textTransform: "capitalize" }}>
                    {key.split("_").join(" ")}
                  </div>
                  <div>{value[key]?.toString() ?? "N/A"}</div>
                </>
              )}
            </li>
          ))
        )}
      </ul>
    </>
  );
};

export default Deeds;
