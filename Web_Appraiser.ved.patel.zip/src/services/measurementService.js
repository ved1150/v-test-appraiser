import api from "./apis/api";

class MeasurementService {
  get(payload) {
    return api.mesurement.get(payload);
  }

  getAvailableMeasurementData(payload) {
    return api.mesurement.getAvailableMeasurementData(payload);
  }

  getFloorScanIndex(payload) {
    return api.mesurement.getFloorScanIndex(payload);
  }
  getFloorScanJsons(payload) {
    return api.mesurement.getFloorScanJsons(payload);
  }
  save(data) {
    return api.mesurement.save(data);
  }

  create(data) {
    return api.mesurement.create(data);
  }

  getDownloadReportMeasurementJson(payload) {
    return api.mesurement.getDownloadReportMeasurementJson(payload);
  }
  downloadPDFFromHTML(body) {
    return api.mesurement.downloadPDFFromHTML(body);
  }
  requestEstatedData(data) {
    return api.mesurement.fetchEstatedData(data);
  }
  sendReportTOHomeOwner(jobOrderId, htmlContent) {
    return api.mesurement.sendReportTOHomeOwner(jobOrderId, htmlContent);
  }
}

export default new MeasurementService();
