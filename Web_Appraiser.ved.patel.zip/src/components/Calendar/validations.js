import moment from "moment";
import {
  TIME_IS_REQUIRED,
  DATE_IS_REQUIRED,
  TIME_IS_INVALID,
  FROM_TIME_CANNOT_BE_GREATER_THAN_TO_TIME,
} from "../../constants/validationerrorMessages";

export const validateTime = (time) => {
  const regex = /^(0?[1-9]|1[012])(:[0-5]\d) [APap][mM]$/;
  if (time.length === 0) return { msg: TIME_IS_REQUIRED, error: true };
  if (!regex.test(time)) return { msg: TIME_IS_INVALID, error: true };
  return { msg: "", error: false };
};

export const validateDate = (date) => {
  if (date.length === 0) return { msg: DATE_IS_REQUIRED, error: true };
  return { msg: "", error: false };
};

const convertTime12to24 = (time12h) => {
  const [time, modifier] = time12h.split(" ");
  let [hours, minutes] = time.split(":");
  if (hours === "12") {
    hours = "00";
  }
  if (modifier === "PM") {
    hours = parseInt(hours, 10) + 12;
  }
  return `${hours}:${minutes}`;
};

export const compareTime = (start, end) => {
  const startTime = convertTime12to24(start);
  const endTime = convertTime12to24(end);
  if (startTime > endTime)
    return { msg: FROM_TIME_CANNOT_BE_GREATER_THAN_TO_TIME, error: true };
  return { msg: "", error: false };
};

export const compareDateWithTime = (start, end) => {
  const mStart = moment(start);
  const mEnd = moment(end);
  const diff = mEnd.diff(mStart, "minutes");
  if (diff <= 29) {
    return { msg: FROM_TIME_CANNOT_BE_GREATER_THAN_TO_TIME, error: true };
  }
  return { msg: "", error: false };
};
