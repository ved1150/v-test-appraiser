export function dehydrateQuestionnaire(data) {
  return {
    jobOrderId: data.data && data.data.data && data.data.data.jobOrderId,
    questionnaireAnswer:
      data.data && data.data.data && data.data.data.questionnaireAnswer
        ? JSON.parse(data.data.data.questionnaireAnswer)
        : null,
    questionnaireQuestion:
      data.data && data.data.data && data.data.data.questionnaireQuestion
        ? JSON.parse(data.data.data.questionnaireQuestion)
        : null,
  };
}
