import api from "./api";

export default class WhiteLabelApi {
  getTheme() {
    return api.get("/tenant/theme", {
      callWithStaticToken: true,
    });
  }
}
