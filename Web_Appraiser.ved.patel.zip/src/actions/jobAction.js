import * as actionTypes from "./actionTypes";
import jobService from "../services/jobService";
import { customToast } from "../helpers/customToast";
import { StartLoading, StopLoading } from "./UIAction";
import authenticationService from "../services/authenticationService";

const startJobOrder = () => {
  return {
    type: actionTypes.JOB_ORDER_START,
  };
};

const successJobOrder = (data) => {
  return {
    type: actionTypes.JOB_ORDER_SUCCESS,
    payload: data,
  };
};
const errorJobOrder = (error) => {
  return {
    type: actionTypes.JOB_ORDER_ERROR,
    payload: error,
  };
};

const startScheduleAppoinment = () => {
  return {
    type: actionTypes.SCHEDULE_APPOINMENT_START,
  };
};

const successScheduleAppoinment = (data) => {
  return {
    type: actionTypes.SCHEDULE_APPOINMENT_SUCCESS,
    payload: data,
  };
};
const errorScheduleAppoinment = (error) => {
  return {
    type: actionTypes.SCHEDULE_APPOINMENT_ERROR,
    payload: error,
  };
};

export function getJobOrders(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startJobOrder());
    return jobService
      .getJobOrders(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successJobOrder(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorJobOrder(err));
      });
  };
}

export function scheduleAppoinment(data) {
  return (dispatch) => {
    dispatch(startScheduleAppoinment());
    return jobService
      .scheduleAppoinment(data)
      .then((data) => {
        dispatch(successScheduleAppoinment(data));
        return data;
      })
      .catch((err) => {
        dispatch(errorScheduleAppoinment(err));
      });
  };
}

export function rescheduleAppoinment(data, id) {
  return (dispatch) => {
    dispatch(startScheduleAppoinment());
    return jobService
      .rescheduleAppoinment(data, id)
      .then((data) => {
        dispatch(successScheduleAppoinment(data));
        return data;
      })
      .catch((err) => {
        dispatch(errorScheduleAppoinment(err));
      });
  };
}

export function resendAppointment(data) {
  return (dispatch) => {
    return jobService
      .resendAppointment(data)
      .then((data) => {
        customToast.success("Resend appointment details successfully");
        return data;
      })
      .catch((err) => {
        throw err;
      });
  };
}

const startAutoSnap = () => {
  return {
    type: actionTypes.AUTO_SNAP_START,
  };
};

const successAutoSnap = (data) => {
  return {
    type: actionTypes.AUTO_SNAP_SUCCESS,
    payload: data,
  };
};
const errorAutoSnap = (error) => {
  return {
    type: actionTypes.AUTO_SNAP_ERROR,
    payload: error,
  };
};

export function autoSnap(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startAutoSnap());
    return jobService
      .autoSnap(data)
      .then((data) => {
        dispatch(StopLoading());
        if (data.data) {
          dispatch(successAutoSnap(data.data));
          customToast.success(data.data.message);
          return data;
        }
      })
      .catch((err) => {
        dispatch(StopLoading());
        if (err.response) {
          dispatch(errorAutoSnap(err.response.data));
        }
      });
  };
}

const payForJobOrderStart = () => {
  return {
    type: actionTypes.PAY_FOR_JOB_ORDER_START,
  };
};

const payForJobOrderSuccess = (data) => {
  return {
    type: actionTypes.PAY_FOR_JOB_ORDER_SUCCESS,
    payload: data,
  };
};

const payForJobOrderError = (error) => {
  return {
    type: actionTypes.PAY_FOR_JOB_ORDER_ERROR,
    payload: error,
  };
};

export const payForJobOrder = (data) => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(payForJobOrderStart());
  return jobService
    .payForJobOrder(data)
    .then((response) => {
      dispatch(StopLoading());
      return dispatch(payForJobOrderSuccess(response));
    })
    .catch((error) => {
      dispatch(StopLoading());
      dispatch(payForJobOrderError(error));
      throw error;
    });
};

export const StoreActions = (data) => {
  return {
    type: actionTypes.STORE_ACTIONS,
    payload: data,
  };
};
