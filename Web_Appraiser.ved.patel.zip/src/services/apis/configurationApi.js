import api from "./api";

export default class ConfigrationAPI {
  get(event) {
    return api.get(`configuration/${event}`);
  }
}
