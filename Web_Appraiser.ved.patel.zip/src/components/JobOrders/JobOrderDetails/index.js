import React, { useRef, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import ImageTab from "./ImageTab";
import {
  fetchImages,
  downloadImages,
  deleteImages,
} from "./../../../actions/imageAction";
import { fetchRecordings } from "./../../../actions/recordingsAction";
import {
  fetchRelar,
  filterRelar,
  requestRelar,
} from "../../../actions/relarAction";
import { connect, useSelector } from "react-redux";
import {
  fetchFloorPlans,
  downloadZip,
  downloadImage,
} from "./../../../actions/floorPlansAction";
import _ from "lodash";
import DetailsTab from "./DetailsTab";
import ViewImage from "./../JobOrderDetails/Models/viewImage";
import ViewImageForFloorPlan from "./../JobOrderDetails/Models/viewImageForFloorPlan";
import RecordingsTab from "./recordingTab";
import FloorPlanTab from "./FloorPlansTab";
import NotesTab from "./NotesTab";
import MeasurementTab from "./measurementTab/mesurementContainer";
import EagleViewMeasurementTab from "./eagleViewMeasurementTab";
import EstatedMeasurementTab from "./estatedMeasurementTab";
import { fetchNotes } from "./../../../actions/notesAction";
import {
  fetchDetails,
  fetchCallDetails,
} from "../../../actions/detailsActions";
import { fetchProfileDetails } from "./../../../actions/profileAction";
import CompleteJobOrder from "./Models/completeJobOrder";
import { completeJobOrder } from "./../../../actions/jobOrderDetailsAction";
import {
  loadMeasurementJson,
  loadAvailableMeasurementData,
  loadFloorScanIndex,
  loadFloorScanJsons,
  loadDownloadReportMeasurementJson,
  downloadPDFFromHTML,
  fetchEstatedData,
} from "./../../../actions/measurementAction";
import { createOrder } from "./../../../actions/eagleViewAction";
import Button from "../../common/Button";
import AttachmentTab from "./AttachmentTab";
import RelarTab from "./Relar/relarTab";
import {
  loadAttachments,
  downloadAttachments,
  downloadAttachment,
} from "./../../../actions/attachmentsAction";
import { downloadRecording } from "../../../actions/recordingsAction";

import { AttachmentDocumentModal } from "./AttachmentTab/AttachmentDocumentModal";
import { generateImage } from "./measurementTab/pdfGeneration";
import { useTranslation } from "react-i18next";
import storage from "../../../services/storage";
import {
  measurementTypes,
  measurementResponseFormat,
  TempX_TenantKey,
} from "./../../../constants/appConstant";
import { fetchPDRDetails } from "./../../../actions/PDRReportsAction";
import PDRReports from "./PDRReports";
import axios from "axios";
import { getImageViaAxios, getSubDomainFromURL } from "../../../helpers";
import DownloadReportModal from "./measurementTab/downloadReportModal";
import { generateReport } from "./measurementTab/generateReport";
import authenticationService from "../../../services/authenticationService";

const JobOrderDetails = (props) => {
  const { t } = useTranslation();
  const TABS = {
    DETAILS: "DETAILS",
    NOTES: "NOTES",
    CAPTURED_IMAGES: "CAPTURED_IMAGES",
    RECORDINGS: "RECORDINGS",
    ATTACHMENT: "ATTACHMENT",
    CALL_HISTORY: "CALL_HISTORY",
    MEASUREMENT: "MEASUREMENT",
    FLOOR_PLAN: "FLOOR_PLAN",
    // PDR_REPORTS: "PDR_REPORTS",
    EAGLEVIEWMEASUREMENT: "EAGLEVIEWMEASUREMENT",
    ESTATEDMEASUREMENT: "ESTATEDMEASUREMENT",
    RELAR: "RELAR",
  };

  const [activeTab, setActiveTab] = useState(TABS.DETAILS);
  const jobId = useParams();
  const [jobOrderId, setJobOrderId] = useState(jobId.id);
  const [selectedImageIndexForView, setSelectedImageIndexForView] =
    useState("");
  const [enableImageView, setEnableImageView] = useState(false);
  const [completeJobOrder, setCompleteJobOrder] = useState(false);
  const [refreshMeasurementJson, setRefreshMeasurementJson] = useState(false);
  const [
    isAttachmentDocumentModalVisible,
    setIsAttachmentDocumentModalVisible,
  ] = useState(false);
  const [isDownloadReport, setIsDownloadReport] = useState(false);
  const [isCreateReport, setIsCreateReport] = useState(false);
  const [completeData, setCompleteData] = useState({});
  const [isRefreshAttachments, setIsRefreshAttachments] = useState(false);
  const [loadMeasurementTab, setLoadMeasurementTab] = useState(false);
  const [enableImageViewForFloorPlan, setEnableImageViewForFloorPlan] =
    useState(false);
  const [imageFloorScanObj, setImageFloorScanObj] = useState({
    floorPlanPath: null,
    floorPlanViewPath: null,
  });

  const [newMeasurementTypes, setNewMeasurementTypes] = useState({});
  const [selectedFloorScanId, setSelectedFloorScanId] = useState([]);
  const [selectedFloorScanName, setSelectedFloorScanName] = useState("");
  const [floorListForVideo, setFloorListForVideo] = useState([]);
  const [tenantLogoUrl, setTenantLogoUrl] = useState("");
  const [showDownloadReportModal, setShowDownloadReportModal] = useState(false);
  const [addressMapUrl, setAddressMapUrl] = useState("");
  const [isSwitchAndLoadingTab, setIsSwitchAndLoadingTab] = useState(false);
  const [estatedStatus, setEstatedStatus] = useState({
    isAPICalled: false,
    estatedData: null,
  });
  const primaryPictures = useSelector(
    (state) => state?.details?.fetchDetailsSuccess?.primaryPictures
  );
  useEffect(() => {
    const currentActiveTab = storage.get("activeTab");
    if (currentActiveTab) {
      setActiveTab(currentActiveTab);
    }
    getTenantLogo();
  }, []);
  useEffect(() => {
    let _jobOrderDetails = _.get(props, ["details", "fetchDetailsSuccess"], {});
    let address = _.get(_jobOrderDetails, ["address"], "");
    if (
      primaryPictures?.length > 0 &&
      !_.isEmpty(primaryPictures[0]?.original)
    ) {
      getPrimaryPicture(primaryPictures[0].original);
    } else if (address != "") {
      captureMapViewImage();
    }
  }, [_.get(props, ["details", "fetchDetailsSuccess"], {})]);
  useEffect(() => {
    setIsSwitchAndLoadingTab(true);
    props
      .loadAvailableMeasurementData({
        jobOrderId: jobOrderId,
      })
      .then((data) => {
        setNewMeasurementTypes(data);
        props
          .loadFloorScanIndex({
            jobOrderId: jobOrderId,
          })
          .then((floorScanIndexData) => {
            setFloorListForVideo(floorScanIndexData);
            setSelectedFloorScanId(floorScanIndexData?.[0]?.floorScanId);
            setSelectedFloorScanName(
              floorScanIndexData?.[0]?.floorTagNameList?.[0]
            );
            if (
              activeTab === TABS.MEASUREMENT ||
              activeTab === TABS.EAGLEVIEWMEASUREMENT ||
              activeTab === TABS.ESTATEDMEASUREMENT
            ) {
              let type;
              let format;
              if (activeTab === TABS.MEASUREMENT) {
                if (data?.remoteVal) {
                  type = measurementTypes[0].name;
                  format = measurementResponseFormat.converted;
                } else if (data?.remoteValVideo) {
                  type = measurementTypes[3].name;
                  format = measurementResponseFormat.converted;
                } else {
                  type = measurementTypes[0].name;
                  format = measurementResponseFormat.converted;
                }
              } else if (activeTab === TABS.EAGLEVIEWMEASUREMENT) {
                type = measurementTypes[1].name;
                format = measurementResponseFormat.original;
              } else if (activeTab === TABS.ESTATEDMEASUREMENT) {
                type = measurementTypes[2].name;
                format = measurementResponseFormat.original;
              } else {
              }
              let floorData = floorScanIndexData?.find(
                (item) => item.floorTagNameList?.length
              );
              type && format
                ? props
                    .loadMeasurementJson({
                      jobOrderId: jobOrderId,
                      type: type,
                      format: format,
                      floorScanId: floorData?.floorScanId,
                      floorTagName: floorData?.floorTagNameList[0],
                    })
                    .then((data) => {
                      setLoadMeasurementTab(true);
                      setIsSwitchAndLoadingTab(false);
                      if (type == measurementTypes[2].name) {
                        setEstatedStatus({
                          isAPICalled: true,
                          estatedData: data?.estatedJsonData,
                        });
                      }
                    })
                : setLoadMeasurementTab(true);
            } else {
              setLoadMeasurementTab(false);
            }
          });
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps

    // For Download Report API Data
  }, [jobOrderId, refreshMeasurementJson, activeTab]);

  const toggleRefreshMeasurementJson = () => {
    setRefreshMeasurementJson(!refreshMeasurementJson);
    return !refreshMeasurementJson;
  };

  const clickTabHandler = (tab) => {
    if (tab != TABS.ESTATEDMEASUREMENT) {
      setEstatedStatus({
        isAPICalled: false,
        estatedData: null,
      });
    }
    setActiveTab(tab);
    storage.set("activeTab", tab);
  };

  const viewImage = (imgIndex) => {
    toggleViewImage();
    setSelectedImageIndexForView(imgIndex);
  };

  const toggleViewImage = () => {
    setEnableImageView(!enableImageView);
  };

  const viewImageForFloorPlan = (floorPlanPath, floorPlanViewPath) => {
    setEnableImageViewForFloorPlan(!enableImageViewForFloorPlan);
    setImageFloorScanObj({
      floorPlanPath: floorPlanPath,
      floorPlanViewPath: floorPlanViewPath,
    });
  };

  const loadDownloadReportData = () => {
    props.loadDownloadReportMeasurementJson(jobOrderId).then((_) => {
      setShowDownloadReportModal(true);
    });
  };

  const tenantLogo = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess?.tenantLogo;
  });
  const captureMapViewImage = async (mapType = "roadmap", zoomLevel = "17") => {
    return new Promise(
      function (resolve, reject) {
        /*stuff using username, password*/
        let _jobOrderDetails = _.get(
          props,
          ["details", "fetchDetailsSuccess"],
          false
        );
        let address = _.get(_jobOrderDetails, ["address"], "");
        let canvasHeight = 640;
        let canvasWidth = 640;
        let imgurl =
          "https://maps.googleapis.com/maps/api/streetview?size=" +
          canvasWidth +
          "x" +
          canvasHeight +
          "&location=" +
          encodeURIComponent(address) +
          "&key=" +
          process.env.REACT_APP_GOOGLE_MAP_API_KEY;
        let xhr = new XMLHttpRequest();
        xhr.open("GET", imgurl, true);
        xhr.responseType = "blob";
        xhr.send(null);
        xhr.onload = function (response) {
          let blob = xhr.response;
          let reader = new FileReader();
          reader.readAsDataURL(blob);
          reader.onload = function () {
            var base64data = reader.result;
            setAddressMapUrl(base64data);
            resolve(true);
          }.bind(this);
        }.bind(this);
      }.bind(this)
    );
  };
  const handleJobOrder = () => {
    props.history.push("/");
    storage.remove("activeTab");
  };

  const toggleCompleteJobOrder = async () => {
    setIsCreateReport(true);
    props
      .loadMeasurementJson({
        jobOrderId: jobOrderId,
        type: measurementTypes[0].name,
        format: measurementResponseFormat.converted,
      })
      .then(async (res) => {
        let data = await generateImage(
          _.get(res, ["jsonData"], {}),
          _.get(props, ["details", "fetchDetailsSuccess"], false),
          tenantLogo,
          jobOrderId,
          true
        );
        setCompleteData(data);
        setIsCreateReport(false);
        setCompleteJobOrder(!completeJobOrder);
      });
    // }
  };
  const getTenantLogo = () => {
    const X_TenantKey = getSubDomainFromURL();
    const xTenant = X_TenantKey != "" ? X_TenantKey : TempX_TenantKey;
    // getImageViaAxios params - url, tokenType, tenant.
    getImageViaAxios(tenantLogo, true, xTenant).then((data) => {
      const reader = new window.FileReader();
      reader.readAsDataURL(data.data);
      reader.onload = () => {
        setTenantLogoUrl(reader.result);
        return reader.result;
      };
    });
  };
  let tenantDetails = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess;
  });
  const downloadReport = async (selectedFloors2D, selectedFloors3D) => {
    setIsDownloadReport(true);
    const data = {
      floorScanJsonRequest: selectedFloors3D,
      jobOrderId: jobOrderId,
      types: [measurementTypes[3].name, measurementTypes[0].name],
      format: 0,
    };
    props.loadFloorScanJsons(data).then(async (res) => {
      let jobDetails = _.get(props, ["details", "fetchDetailsSuccess"], {});
      let payload = await generateReport(
        _.get(res, ["data", "floorScanJsonData"], {}),
        jobDetails,
        tenantLogoUrl,
        jobOrderId,
        addressMapUrl,
        _.get(res, ["data", "jsonData"], {}),
        selectedFloors2D,
        tenantDetails,
        _.get(props, ["profile", "fetchProfileDetailsSuccess"], "")
      );
      let parser = new DOMParser();
      let doc = parser.parseFromString(payload, "text/html");
      let temp = new XMLSerializer().serializeToString(doc);
      props
        .downloadPDFFromHTML({ htmlContent: temp })
        .then((pdfData) => {
          const downloadurl = window.URL.createObjectURL(
            new Blob([pdfData.data])
          );
          const link = document.createElement("a");
          link.href = downloadurl;
          // TODO for naming the response can have wins in headers
          link.setAttribute(
            "download",
            _.get(jobDetails, ["address"], "Inspection") + "_Report.pdf"
          ); //or any other extension
          document.body.appendChild(link);
          link.click();
          setIsDownloadReport(false);
          setShowDownloadReportModal(false);
        })
        .catch((err) => {
          setIsDownloadReport(false);
        });
    });
  };

  const jobOrderSource = props?.details?.fetchDetailsSuccess?.jobOrderSource
    ?.trim()
    ?.toLowerCase();

  const getPrimaryPicture = (primaryPicture) => {
    const currentTenantSubDomain = authenticationService.getTenantDetails()
      ? JSON.parse(authenticationService.getTenantDetails()).tenantSubDomain
      : null;
    const X_TenantKey = currentTenantSubDomain || getSubDomainFromURL();
    const xTenant = X_TenantKey != "" ? X_TenantKey : TempX_TenantKey;
    // getImageViaAxios params - url, tokenType, tenant.
    getImageViaAxios(primaryPicture, false, xTenant).then((data) => {
      const reader = new window.FileReader();
      reader.readAsDataURL(data.data);
      reader.onload = () => {
        setAddressMapUrl(reader.result);
        return reader.result;
      };
    });
  };

  const fetchDetailsStart = useSelector(
    (state) => state?.details?.fetchDetailsStart
  );

  return (
    <div>
      <section className="content-wapper">
        <div className="breadcrumb">
          <ul>
            <li>
              <button onClick={() => handleJobOrder()}>
                {t("WEB_LABELS.My_Job_Orders")}
              </button>
            </li>
            <li>
              {_.get(
                props,
                ["details", "fetchDetailsSuccess", "orderNo"],
                "--"
              )}
            </li>
          </ul>
        </div>
        <div className="common-panel">
          <div className="panel-body job-details-wapper">
            <div className="custom-tab">
              <div className="right-side">
                <Button
                  className="blue-btn"
                  disabled={fetchDetailsStart}
                  onClick={() => loadDownloadReportData()}
                >
                  <span>
                    <i className="icon-download-report"></i>
                  </span>
                  {t("BUTTONS.Download_Report")}
                </Button>
                &nbsp;
                {jobOrderSource !== "vsi" && (
                  <Button
                    className="blue-btn"
                    onClick={() => toggleCompleteJobOrder()}
                    disabled={
                      isCreateReport ||
                      _.get(
                        props,
                        ["details", "fetchDetailsSuccess", "jobOrderStatus"],
                        ""
                      ) == "Completed"
                    }
                  >
                    <span>
                      <i className="icon-complete-job-order"></i>
                    </span>
                    {t("BUTTONS.Inspection_Completed")}
                    {isCreateReport && <div className="loader-spin"></div>}
                  </Button>
                )}
              </div>
              <ul className="tab-list">
                <li className={`${activeTab == TABS.DETAILS ? "active" : ""}`}>
                  <button onClick={() => clickTabHandler(TABS.DETAILS)}>
                    {t("WEB_LABELS.Details")}
                  </button>
                </li>
                <li className={`${activeTab == TABS.NOTES ? "active" : ""}`}>
                  <button onClick={() => clickTabHandler(TABS.NOTES)}>
                    {t("WEB_LABELS.Notes")}
                  </button>
                </li>
                <li
                  className={`${
                    activeTab == TABS.CAPTURED_IMAGES ? "active" : ""
                  }`}
                >
                  <button onClick={() => clickTabHandler(TABS.CAPTURED_IMAGES)}>
                    {t("WEB_LABELS.Captured_Images")}{" "}
                  </button>
                </li>
                <li
                  className={`${activeTab == TABS.RECORDINGS ? "active" : ""}`}
                >
                  <button onClick={() => clickTabHandler(TABS.RECORDINGS)}>
                    {t("WEB_LABELS.Recordings")}{" "}
                  </button>
                </li>

                <li
                  className={`${activeTab == TABS.ATTACHMENT ? "active" : ""}`}
                >
                  <button onClick={() => clickTabHandler(TABS.ATTACHMENT)}>
                    {t("WEB_LABELS.Attachments")}{" "}
                  </button>
                </li>
                <li
                  className={`${activeTab == TABS.MEASUREMENT ? "active" : ""}`}
                >
                  <button onClick={() => clickTabHandler(TABS.MEASUREMENT)}>
                    {t("WEB_LABELS.Measurements")}{" "}
                  </button>
                </li>
                <li
                  className={`${activeTab == TABS.FLOOR_PLAN ? "active" : ""}`}
                >
                  <button onClick={() => clickTabHandler(TABS.FLOOR_PLAN)}>
                    {t("WEB_LABELS.Floor_Plan")}{" "}
                  </button>
                </li>

                {/* <li
                  className={`${activeTab == TABS.PDR_REPORTS ? "active" : ""}`}
                >
                  <button onClick={() => clickTabHandler(TABS.PDR_REPORTS)}>
                    PDR Report{" "}
                  </button>
                </li> */}

                <li
                  className={`${
                    activeTab == TABS.EAGLEVIEWMEASUREMENT ? "active" : ""
                  }`}
                >
                  <button
                    onClick={() => clickTabHandler(TABS.EAGLEVIEWMEASUREMENT)}
                  >
                    {t("WEB_LABELS.EagleView_Measurement")}{" "}
                  </button>
                </li>

                <li
                  className={`${
                    activeTab == TABS.ESTATEDMEASUREMENT ? "active" : ""
                  }`}
                >
                  <button
                    onClick={() => clickTabHandler(TABS.ESTATEDMEASUREMENT)}
                  >
                    {t("WEB_LABELS.Public_Records_Data")}{" "}
                  </button>
                </li>
                <li className={`${activeTab == TABS.RELAR ? "active" : ""}`}>
                  <button onClick={() => clickTabHandler(TABS.RELAR)}>
                    {t("WEB_LABELS.MLS_Sales")}{" "}
                  </button>
                </li>
              </ul>

              <div className="tab-content open" style={{ display: "block" }}>
                {activeTab == TABS.DETAILS && (
                  <DetailsTab
                    fetchDetails={props.fetchDetails}
                    jobOrderId={jobOrderId}
                    fetchCallDetails={props.fetchCallDetails}
                    details={props.details}
                    jobOrders={props.job.jobOrders.data}
                  ></DetailsTab>
                )}

                {activeTab == TABS.NOTES && (
                  <NotesTab
                    fetchNotes={props.fetchNotes}
                    notes={props.notes}
                    jobOrderId={jobOrderId}
                  ></NotesTab>
                )}

                {activeTab == TABS.CAPTURED_IMAGES && (
                  <ImageTab
                    fetchImages={props.fetchImages}
                    jobOrderId={jobOrderId}
                    fetchDetails={props.fetchDetails}
                    imageList={props.images}
                    viewImage={viewImage}
                    toggleViewImage={toggleViewImage}
                    downloadImages={props.downloadImages}
                    deleteImages={props.deleteImages}
                  ></ImageTab>
                )}
                {activeTab == TABS.RECORDINGS && (
                  <RecordingsTab
                    fetchRecordings={props.fetchRecordings}
                    jobOrderId={jobOrderId}
                    recordings={props.recordings}
                    downloadRecording={props.downloadRecording}
                  ></RecordingsTab>
                )}
                {activeTab == TABS.ATTACHMENT && (
                  <AttachmentTab
                    loadAttachments={props.loadAttachments}
                    jobOrderId={jobOrderId}
                    attachments={props.attachments}
                    details={props.details}
                    downloadAttachment={props.downloadAttachment}
                    downloadAttachments={props.downloadAttachments}
                    setAttachmentDocumentModalVisible={(value) =>
                      setIsAttachmentDocumentModalVisible(value)
                    }
                    isRefreshAttachments={isRefreshAttachments}
                  ></AttachmentTab>
                )}
                {activeTab == TABS.MEASUREMENT && loadMeasurementTab && (
                  <MeasurementTab
                    mesurementData={_.get(
                      props,
                      ["details", "mesurementData"],
                      {}
                    )}
                    measurementLoading={_.get(
                      props,
                      ["details", "measurementLoading"],
                      false
                    )}
                    measurementLoaded={_.get(
                      props,
                      ["details", "measurementLoaded"],
                      false
                    )}
                    measurementError={_.get(
                      props,
                      ["details", "measurementError"],
                      false
                    )}
                    toggleRefreshMeasurementJson={toggleRefreshMeasurementJson}
                    jobOrderId={jobOrderId}
                    details={_.get(
                      props,
                      ["details", "fetchDetailsSuccess"],
                      false
                    )}
                    fetchProfileDetails={props.fetchProfileDetails}
                    loadMeasurementJson={props.loadMeasurementJson}
                    newMeasurementTypes={newMeasurementTypes}
                    selectedFloorScanId={selectedFloorScanId}
                    setSelectedFloorScanId={setSelectedFloorScanId}
                    selectedFloorScanName={selectedFloorScanName}
                    setSelectedFloorScanName={setSelectedFloorScanName}
                    loadFloorScanIndex={props.loadFloorScanIndex}
                    floorListForVideo={floorListForVideo}
                    setFloorListForVideo={setFloorListForVideo}
                  ></MeasurementTab>
                )}
                {activeTab == TABS.FLOOR_PLAN && (
                  <FloorPlanTab
                    fetchFloorPlans={props.fetchFloorPlans}
                    downloadZip={props.downloadZip}
                    jobOrderId={jobOrderId}
                    floorPlans={props.floorPlans}
                    viewImageForFloorPlan={viewImageForFloorPlan}
                  ></FloorPlanTab>
                )}

                {/* {activeTab == TABS.PDR_REPORTS && (
                  <PDRReports
                    fetchPDRDetails={props.fetchPDRDetails}
                    jobOrderId={jobOrderId}
                  ></PDRReports>
                )} */}

                {activeTab == TABS.EAGLEVIEWMEASUREMENT && (
                  <EagleViewMeasurementTab
                    t={t}
                    mesurementData={_.get(
                      props,
                      ["details", "mesurementData"],
                      {}
                    )}
                    measurementLoading={_.get(
                      props,
                      ["details", "measurementLoading"],
                      false
                    )}
                    measurementLoaded={_.get(
                      props,
                      ["details", "measurementLoaded"],
                      false
                    )}
                    measurementError={_.get(
                      props,
                      ["details", "measurementError"],
                      false
                    )}
                    createOrder={props.createOrder}
                    jobOrderId={jobOrderId}
                    eagleView={props.eagleView}
                    toggleRefreshMeasurementJson={toggleRefreshMeasurementJson}
                    isSwitchAndLoadingTab={isSwitchAndLoadingTab}
                  ></EagleViewMeasurementTab>
                )}

                {activeTab == TABS.ESTATEDMEASUREMENT && (
                  <EstatedMeasurementTab
                    t={t}
                    mesurementData={_.get(
                      props,
                      ["details", "mesurementData"],
                      {}
                    )}
                    measurementLoading={_.get(
                      props,
                      ["details", "measurementLoading"],
                      false
                    )}
                    measurementLoaded={_.get(
                      props,
                      ["details", "measurementLoaded"],
                      false
                    )}
                    measurementError={_.get(
                      props,
                      ["details", "measurementError"],
                      false
                    )}
                    jobOrderId={jobOrderId}
                    fetchEstatedData={props.fetchEstatedData}
                    toggleRefreshMeasurementJson={toggleRefreshMeasurementJson}
                    isSwitchAndLoadingTab={isSwitchAndLoadingTab}
                    estatedStatus={estatedStatus}
                  ></EstatedMeasurementTab>
                )}

                {/* {activeTab == TABS.CALL_HISTORY && (
                  <CallHistoryTab></CallHistoryTab>
                )} */}
                {activeTab == TABS.RELAR && (
                  <RelarTab
                    // fetchRelar={props.fetchRelar}
                    // relar={props.relar}
                    // jobOrderId={jobOrderId}
                    fetchRelar={props.fetchRelar}
                    filterRelar={props.filterRelar}
                    jobOrderId={jobOrderId}
                    details={props.details}
                    requestRelar={props.requestRelar}
                    toggleRefreshMeasurementJson={toggleRefreshMeasurementJson}
                    // recordings={props.recordings}
                    // downloadRecording={props.downloadRecording}
                  ></RelarTab>
                )}
                {showDownloadReportModal && (
                  <DownloadReportModal
                    loadDownloadReportData={_.get(
                      props,
                      ["details", "downloadReportDataSuccess"],
                      []
                    )}
                    setShowDownloadReportModal={setShowDownloadReportModal}
                    downloadReport={(selectedFloors2D, selectedFloors3D) =>
                      downloadReport(selectedFloors2D, selectedFloors3D)
                    }
                    isDownloadReport={isDownloadReport}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
      {enableImageView && (
        <ViewImage
          selectedImageIndexForView={selectedImageIndexForView}
          imageList={props.images.fetchImageSuccess}
          toggleViewImage={toggleViewImage}
        ></ViewImage>
      )}

      {enableImageViewForFloorPlan && (
        <ViewImageForFloorPlan
          imageFloorScanObj={imageFloorScanObj}
          downloadImage={props.downloadImage}
          viewImageForFloorPlan={viewImageForFloorPlan}
        />
      )}

      {completeJobOrder && (
        <CompleteJobOrder
          toggleCompleteJobOrder={toggleCompleteJobOrder}
          completeJobOrder={props.completeJobOrder}
          jobOrderDetails={props.jobOrderDetails}
          jobOrderId={jobOrderId}
          completeData={completeData}
          history={props.history}
          setCompleteJobOrder={setCompleteJobOrder}
        ></CompleteJobOrder>
      )}

      {isAttachmentDocumentModalVisible && (
        <AttachmentDocumentModal
          jobOrderId={jobOrderId}
          hideAttachmentDocumentModal={() =>
            setIsAttachmentDocumentModalVisible(false)
          }
          setIsRefreshAttachments={setIsRefreshAttachments}
          isRefreshAttachments={isRefreshAttachments}
        />
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    images: state.image,
    recordings: state.recordings,
    floorPlans: state.floorPlans,
    notes: state.notes,
    details: state.details,
    jobOrderDetails: state.jobOrderDetails,
    eagleView: state.eagleView,
    attachments: state.attachments,
    profile: state.profile,
    job: state.job,
  };
};

export default connect(mapStateToProps, {
  fetchImages,
  fetchRecordings,
  fetchFloorPlans,
  downloadImage,
  downloadZip,
  fetchRelar,
  filterRelar,
  fetchNotes,
  downloadImages,
  fetchDetails,
  fetchCallDetails,
  completeJobOrder,
  loadMeasurementJson,
  loadAvailableMeasurementData,
  loadFloorScanIndex,
  createOrder,
  fetchEstatedData,
  requestRelar,
  loadAttachments,
  downloadAttachments,
  downloadAttachment,
  downloadRecording,
  fetchProfileDetails,
  deleteImages,
  fetchPDRDetails,
  loadFloorScanJsons,
  loadDownloadReportMeasurementJson,
  downloadPDFFromHTML,
})(JobOrderDetails);
