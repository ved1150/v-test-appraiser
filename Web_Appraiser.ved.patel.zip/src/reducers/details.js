import * as actionTypes from "../actions/actionTypes";

const detailsState = {
  fetchDetailsStart: false,
  fetchDetailsSuccess: [],
  fetchDetailsError: null,
};

const callDetailsState = {
  fetchCallDetailsStart: false,
  fetchCallDetailsSuccess: [],
  fetchCallDetailsError: null,
};

const defaultMesurementStates = {
  mesurementData: {},
  measurementLoading: false,
  measurementLoaded: false,
  measurementError: null,
};

const createMeasurementStates = {
  createMeasurementStart: false,
  createMeasurementSuccess: {},
  createMeasurementError: null,
};
const defaultFloorScans = {
  floorScansDataStart: false,
  floorScansDataSuccess: [],
  floorScansDataError: null,
};
const defaultDownloadReportData = {
  downloadReportDataStart: false,
  downloadReportDataSuccess: [],
  downloadReportDataError: null,
};

const defaultStates = {
  ...detailsState,
  ...callDetailsState,
  ...defaultMesurementStates,
  ...createMeasurementStates,
  ...defaultFloorScans,
  ...defaultDownloadReportData,
  reportData: {},
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_DETAILS_START:
      return {
        ...state,
        fetchDetailsStart: true,
        fetchDetailsSuccess: [],
        fetchDetailsError: null,
      };
    case actionTypes.FETCH_DETAILS_SUCCESS:
      return {
        ...state,
        fetchDetailsStart: false,
        fetchDetailsSuccess: action.payload,
        fetchDetailsError: null,
      };
    case actionTypes.FETCH_DETAILS_ERROR:
      return {
        ...state,
        fetchDetailsStart: false,
        fetchDetailsSuccess: [],
        fetchDetailsError: action.payload,
      };
    case actionTypes.FETCH_CALL_DETAILS_START:
      return {
        ...state,
        fetchCallDetailsStart: true,
        fetchCallDetailsSuccess: [],
        fetchCallDetailsError: null,
      };
    case actionTypes.FETCH_CALL_DETAILS_SUCCESS:
      return {
        ...state,
        fetchCallDetailsStart: false,
        fetchCallDetailsSuccess: action.payload,
        fetchCallDetailsError: null,
      };
    case actionTypes.FETCH_CALL_DETAILS_ERROR:
      return {
        ...state,
        fetchCallDetailsStart: false,
        fetchCallDetailsSuccess: [],
        fetchCallDetailsError: action.payload,
      };

    case actionTypes.MEASUREMENT_JSON_START:
      return {
        ...state,
        mesurementData: {},
        measurementLoading: true,
        measurementLoaded: false,
        measurementError: null,
      };
    case actionTypes.MESUREMENT_JSON_SUCCESS:
      return {
        ...state,
        mesurementData: action.payload,
        measurementLoading: false,
        measurementLoaded: true,
        measurementError: null,
      };
    case actionTypes.MESUREMENT_JSON_ERROR:
      return {
        ...state,
        mesurementData: {},
        measurementLoading: false,
        measurementLoaded: false,
        measurementError: action.payload,
      };
    case actionTypes.CREATE_MEASUREMENT_START:
      return {
        ...state,
        createMeasurementStart: true,
        createMeasurementSuccess: {},
        createMeasurementError: null,
      };
    case actionTypes.CREATE_MEASUREMENT_SUCCESS:
      return {
        ...state,
        createMeasurementStart: false,
        createMeasurementSuccess: action.payload,
        createMeasurementError: null,
      };
    case actionTypes.CREATE_MEASUREMENT_ERROR:
      return {
        ...state,
        createMeasurementStart: false,
        createMeasurementSuccess: {},
        createMeasurementError: action.payload,
      };
    case actionTypes.FLOORSCAN_JSONS_SUCCESS:
      return {
        ...state,
        reportData: action.payload,
      };
    case actionTypes.FLOOR_SCAN_INDEX_START:
      return {
        ...state,
        floorScansDataStart: true,
        floorScansDataSuccess: [],
        floorScansDataError: null,
      };
    case actionTypes.FLOOR_SCAN_INDEX_SUCCESS:
      return {
        ...state,
        floorScansDataStart: false,
        floorScansDataSuccess: action.payload,
        floorScansDataError: null,
      };
    case actionTypes.FLOOR_SCAN_INDEX_ERROR:
      return {
        ...state,
        floorScansDataStart: false,
        floorScansDataSuccess: [],
        floorScansDataError: action.payload,
      };
    case actionTypes.DOWNLOAD_REPORT_START:
      return {
        ...state,
        downloadReportDataStart: true,
        downloadReportDataSuccess: [],
        downloadReportDataError: null,
      };
    case actionTypes.DOWNLOAD_REPORT_SUCCESS:
      return {
        ...state,
        downloadReportDataStart: false,
        downloadReportDataSuccess: action.payload,
        downloadReportDataError: null,
      };
    case actionTypes.DOWNLOAD_REPORT_ERROR:
      return {
        ...state,
        downloadReportDataStart: false,
        downloadReportDataSuccess: [],
        downloadReportDataError: action.payload,
      };
    default:
      return state;
  }
};
