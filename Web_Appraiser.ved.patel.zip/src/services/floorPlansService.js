import api from "./apis/api";
import {
  hydrateFloorPlans,
  deHydrateFloorPlans,
  hydrateDownloadZip,
  hydrateDownloadFloorPlanImages,
} from "./transformers/jobOrderDetailsTransformer";

class FloorPlansService {
  getFloorPlans(data) {
    return api.floorplans
      .getFloorPlans(deHydrateFloorPlans(data))
      .then(hydrateFloorPlans);
  }

  downloadImage(data) {
    return api.floorplans
      .downloadImage(data)
      .then(hydrateDownloadFloorPlanImages);
  }

  downloadZip(data) {
    return api.floorplans.downloadZip(data).then(hydrateDownloadZip);
  }
}

export default new FloorPlansService();
