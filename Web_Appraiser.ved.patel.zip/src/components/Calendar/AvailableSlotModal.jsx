import React, { useState } from "react";
import "@hassanmojab/react-modern-calendar-datepicker/lib/DatePicker.css";
import DatePicker from "@hassanmojab/react-modern-calendar-datepicker";
import { utils } from "react-modern-calendar-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { validateDate, validateTime, compareDateWithTime } from "./validations";
import appointmentSlotsService from "../../services/appointmentSlotsService";
import moment from "moment";
import {
  getDateString,
  TimePickerOptions,
} from "../../helpers/commonJSFunction";
import { customToast } from "./../../helpers/customToast";
import { DATE_IS_INVALID } from "./../../constants/validationerrorMessages";
import Button from "../common/Button";
import { useTranslation } from "react-i18next";
function AvailableSlotModal({ open, onClose, selectedDate }) {
  const { t } = useTranslation();
  const dateObj = { from: selectedDate, to: selectedDate };
  const dateString = getDateString(dateObj);
  const [selectedDay, setSelectedDay] = useState({
    from: selectedDate,
    to: selectedDate,
  });
  const [selectedDayString, setSelectedDayString] = useState(dateString);
  const [dateError, setDateError] = useState("");
  const [startTimeError, setStartTimeError] = useState("");
  const [endTimeError, setEndTimeError] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleOnDateChange = (date) => {
    setSelectedDay(date);
    if (date.from !== null && date.to !== null) {
      const fromDay =
        date.from.day < 10 ? `0${date.from.day}` : `${date.from.day}`;
      const toDay = date.to.day < 10 ? `0${date.to.day}` : `${date.to.day}`;
      const fromMonth =
        date.from.month < 10 ? `0${date.from.month}` : `${date.from.month}`;
      const toMonth =
        date.to.month < 10 ? `0${date.to.month}` : `${date.to.month}`;
      const dateStr = `${fromMonth}/${fromDay}/${date.from.year} - ${toMonth}/${toDay}/${date.to.year}`;
      setSelectedDayString(dateStr);
    }
  };

  const validation = () => {
    const { from, to } = selectedDay;
    const tempStartTime = moment(startTime, "h:mm A");
    const tempEndTime = moment(endTime, "h:mm A");
    const dateValidation = validateDate(selectedDayString);
    const currentTime = moment(new Date(), "h:mm A");
    let tempDate = { ...from };
    tempDate.month = tempDate.month - 1;
    tempDate = moment(tempDate).format("MM-DD-YYYY");
    let pastTimeVal = { msg: "", error: false };
    let pastDateVal = { msg: "", error: false };
    const dateDiff = moment(tempDate).diff(moment().toDate(), "days");
    if (dateDiff == 0 && moment(tempDate).isSame(moment().toDate(), "day")) {
      pastTimeVal.error = moment(startTime, "h:mm A").isBefore(currentTime);
    } else if (dateDiff < 0) {
      pastDateVal.error = true;
    } else {
    }
    const sTimeValidation = validateTime(startTime);
    const eTimeValidation = validateTime(endTime);
    let compareDateVal = { msg: "", error: false };
    if (from != null && to != null) {
      const startDate = moment([
        from.year,
        from.month,
        from.day,
        tempStartTime.format("HH"),
        tempStartTime.format("mm"),
      ]);
      const endDate = moment([
        to.year,
        to.month,
        to.day,
        tempEndTime.format("HH"),
        tempEndTime.format("mm"),
      ]);
      compareDateVal = compareDateWithTime(startDate, endDate);
    }
    if (
      dateValidation.error ||
      sTimeValidation.error ||
      eTimeValidation.error ||
      compareDateVal.error ||
      pastTimeVal.error ||
      pastDateVal.error
    ) {
      return {
        dateValidation,
        sTimeValidation,
        eTimeValidation,
        compareDateVal,
        pastTimeVal,
        pastDateVal,
      };
    }
    return false;
  };

  const isBtnDisabled = () => {
    const validationObj = validation();
    if (typeof validationObj == "object") {
      return true;
    }
    return false;
  };

  const saveForm = async () => {
    const validationObj = validation();
    if (typeof validationObj != "object") {
      setSubmitting(true);
      let newendDate = selectedDayString.split(" ")[2];
      let newendDate2 = newendDate.split("/");
      const endDate = `${newendDate2[2]}-${newendDate2[0]}-${newendDate2[1]}`;

      let newtoDate = selectedDayString.split(" ")[0];
      let newtoDate2 = newtoDate.split("/");
      const toDate = `${newtoDate2[2]}-${newtoDate2[0]}-${newtoDate2[1]}`;
      const startUTCDate = `${moment(toDate + " " + startTime)
        .utc()
        .format("YYYY-MM-DD")} 00:00:00`;
      const fromUTCTime = moment(toDate + " " + startTime)
        .utc()
        .format("hh:mm A");
      const endUTCDate = `${moment(endDate + " " + endTime)
        .utc()
        .format("YYYY-MM-DD")} 00:00:00`;
      const toUTCTime = moment(endDate + " " + endTime)
        .utc()
        .format("hh:mm A");

      const data = {
        availabilityEndDate: endUTCDate,
        availabilityFromTime: fromUTCTime,
        availabilityStartDate: startUTCDate,
        availabilityToTime: toUTCTime,
      };
      appointmentSlotsService
        .post(data)
        .then((res) => {
          if (res.data.status === "STATUS_SLOTS_ADD_SUCCESS") {
            customToast.success(res.data.message);
            onClose();
          } else if (res.data.code == 400) {
            customToast.error(res.data.message);
          }
          setSubmitting(false);
        })
        .catch((err) => {
          setSubmitting(false);
        });
    } else {
      setDateError(validationObj.dateValidation.msg);
      setStartTimeError(validationObj.sTimeValidation.msg);
      setEndTimeError(validationObj.eTimeValidation.msg);
      if (
        !validationObj.sTimeValidation.error &&
        !validationObj.eTimeValidation.error
      ) {
        setStartTimeError(validationObj.compareDateVal.msg);
      }
    }
  };

  const renderCustomInput = ({ ref }) => (
    <div className="form-group">
      <label>{t("WEB_LABELS.Date")} </label>
      <div className="date-formate">
        <span className="icon-date-picker"></span>
        <input
          readOnly
          ref={ref}
          placeholder="08/03/2021 - 10/03/2021"
          value={selectedDayString}
          className="form-control"
        />
        {dateError && <div className="form-error">{dateError}</div>}
      </div>
    </div>
  );

  return (
    <div className={`comman-modal right-side ${open ? "open" : ""}`}>
      <div className="comman-modal-main">
        <div className="side-head">
          {t("WEB_LABELS.Add_Appointment_Time_Slot")}
          <button className="close-modal" onClick={onClose}>
            <i className="icon-close-image"></i>
          </button>
        </div>
        <div className="comman-modal-body schedule-appointment scroll-bar-style">
          <DatePicker
            value={selectedDay}
            colorPrimary="#334aa6"
            colorPrimaryLight="rgba(51,74,166,0.4)"
            onChange={handleOnDateChange}
            renderInput={renderCustomInput}
            minimumDate={utils().getToday()}
            shouldHighlightWeekends
            style={{ width: "100%" }}
            calendarClassName="custom-calendar"
          />
          <div className="form-group">
            <label>{t("WEB_LABELS.From")} </label>
            <div className="date-formate">
              <span className="icon-Time"></span>
              <select
                className="form-control"
                onChange={(e) => setStartTime(e.target.value)}
                name="start time "
                placeholder="01:00 PM"
                value={startTime}
              >
                <option value="" disabled selected>
                  {t("WEB_LABELS.Select_Start_Time")}
                </option>
                {TimePickerOptions.map((item) => (
                  <option key={item.key} value={item.value}>
                    {item.value}
                  </option>
                ))}
              </select>
              {startTimeError && (
                <div className="form-error">{startTimeError}</div>
              )}
            </div>
          </div>
          <div className="form-group">
            <label>{t("WEB_LABELS.To")} </label>
            <div className="date-formate">
              <span className="icon-Time"></span>
              <select
                className="form-control"
                onChange={(e) => setEndTime(e.target.value)}
                name="end time "
                placeholder="05:00 PM"
                value={endTime}
              >
                <option value="" disabled selected>
                  {t("WEB_LABELS.Select_End_Time")}
                </option>
                {TimePickerOptions.map((item) => (
                  <option key={item.key} value={item.value}>
                    {item.value}
                  </option>
                ))}
              </select>
              {endTimeError && <div className="form-error">{endTimeError}</div>}
            </div>
          </div>
          <div className="button-group text-center">
            <Button
              disabled={isBtnDisabled() || submitting}
              className="blue-btn"
              type="button"
              onClick={saveForm}
            >
              {t("BUTTONS.Add")}{" "}
              {submitting && <div className="loader-spin"></div>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AvailableSlotModal;
