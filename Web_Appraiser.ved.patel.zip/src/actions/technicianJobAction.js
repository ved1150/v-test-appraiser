import * as actionTypes from "./actionTypes";
import technicianJobService from "../services/technicianJobService";
import { StartLoading, StopLoading } from "./UIAction";
import { customToast } from "../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "../constants/commonMessages";
import { STATUS } from "../constants/appConstant";
import i18n from "../translations/i18n";

const startTechnicianJobOrder = () => {
  return {
    type: actionTypes.TECHNICIAN_JOB_ORDER_START,
  };
};
const successTechnicianJobOrder = (data) => {
  return {
    type: actionTypes.TECHNICIAN_JOB_ORDER_SUCCESS,
    payload: data,
  };
};
const errorTechnicianJobOrder = (error) => {
  return {
    type: actionTypes.TECHNICIAN_JOB_ORDER_ERROR,
    payload: error,
  };
};

export function getTechnicianJobOrders(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startTechnicianJobOrder());
    return technicianJobService
      .getTechnicianJobOrders(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successTechnicianJobOrder(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorTechnicianJobOrder(err));
      });
  };
}

const startFloorScanList = () => {
  return {
    type: actionTypes.FLOOR_SCAN_START,
  };
};
const successFloorScanList = (data) => {
  return {
    type: actionTypes.FLOOR_SCAN_SUCCESS,
    payload: data,
  };
};
const errorFloorScanList = (error) => {
  return {
    type: actionTypes.FLOOR_SCAN_ERROR,
    payload: error,
  };
};

export function getFloorScanList(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFloorScanList());
    return technicianJobService
      .getFloorscanList(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFloorScanList(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFloorScanList(err));
      });
  };
}

const startUpdateFloorscanImage = () => {
  return {
    type: actionTypes.UPDATE_FLOOR_SCAN_IMAGE_START,
  };
};
const successUpdateFloorscanImage = (data) => {
  return {
    type: actionTypes.UPDATE_FLOOR_SCAN_IMAGE_SUCCESS,
    payload: data,
  };
};
const errorUpdateFloorscanImage = (error) => {
  return {
    type: actionTypes.UPDATE_FLOOR_SCAN_IMAGE_ERROR,
    payload: error,
  };
};
export function updateFloorScan(floorscanData) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startUpdateFloorscanImage());
    return technicianJobService
      .updateFloorScanImage(floorscanData)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successUpdateFloorscanImage(data));
        customToast.success(data.message);
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorUpdateFloorscanImage(err));
      });
  };
}

const startFloorScanDetail = () => {
  return {
    type: actionTypes.FLOOR_SCAN_DETAIL_START,
  };
};
const successFloorScanDetail = (data) => {
  return {
    type: actionTypes.FLOOR_SCAN_DETAIL_SUCCESS,
    payload: data,
  };
};
const errorFloorScanDetail = (error) => {
  return {
    type: actionTypes.FLOOR_SCAN_DETAIL_ERROR,
    payload: error,
  };
};

export const unmountFloorScanDetail = () => {
  return {
    type: actionTypes.FLOOR_SCAN_DETAIL_UNMOUNT,
  };
};
export function getFloorScanDetail(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFloorScanDetail());
    return technicianJobService
      .getFloorscanDetail(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFloorScanDetail(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFloorScanDetail(err));
      });
  };
}

const startUpdateFloorScanStatus = () => {
  return {
    type: actionTypes.FLOOR_SCAN_UPDATE_STATUS_START,
  };
};
const successUpdateFloorScanStatus = (data) => {
  return {
    type: actionTypes.FLOOR_SCAN_UPDATE_STATUS_SUCCESS,
    payload: data,
  };
};
const errorUpdateFloorScanStatus = (error) => {
  return {
    type: actionTypes.FLOOR_SCAN_UPDATE_STATUS_ERROR,
    payload: error,
  };
};
export function updateFloorScanStatus(floorscanData) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startUpdateFloorScanStatus());
    return technicianJobService
      .updateFloorScanStatus(floorscanData)
      .then((data) => {
        if (floorscanData?.status === STATUS.COMPLETED) {
          customToast.success(i18n.t("COMMON_MESSAGES.FLOOR_PLAN_COMPLETED"));
        } else if (floorscanData?.status === STATUS.FLOORPLAN_FAILED) {
          customToast.success(i18n.t("COMMON_MESSAGES.RESCAN_REQUESTED"));
        }
        dispatch(StopLoading());
        dispatch(successUpdateFloorScanStatus(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorUpdateFloorScanStatus(err));
        throw err;
      });
  };
}

const startPlyRetry = () => {
  return {
    type: actionTypes.PLY_RETRY_START,
  };
};

const successPlyRetry = (data) => {
  return {
    type: actionTypes.PLY_RETRY_SUCCESS,
    payload: data,
  };
};
const errorPlyRetry = (error) => {
  return {
    type: actionTypes.PLY_RETRY_ERROR,
    payload: error,
  };
};

export function plyRetry(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startPlyRetry());
    return technicianJobService
      .plyRetry(data)
      .then((data) => {
        dispatch(StopLoading());
        if (data.data) {
          dispatch(successPlyRetry(data.data));
          customToast.success(data.data.message);
          return data;
        }
      })
      .catch((err) => {
        dispatch(StopLoading());
        if (err.response) {
          dispatch(errorPlyRetry(err.response.data));
        }
      });
  };
}

export function PlyRetryAfterSuccess(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startPlyRetry());
    return technicianJobService
      .PlyRetryAfterSuccess(data)
      .then((data) => {
        dispatch(StopLoading());
        if (data.data) {
          dispatch(successPlyRetry(data.data));
          customToast.success(data.data.message);
          return data;
        }
      })
      .catch((err) => {
        dispatch(StopLoading());
        if (err.response) {
          dispatch(errorPlyRetry(err.response.data));
        }
      });
  };
}

const fetchFloorScanReportListStart = () => {
  return {
    type: actionTypes.FETCH_FLOOR_SCAN_REPORT_LIST_START,
  };
};
const fetchFloorScanReportListSuccess = (data) => {
  return {
    type: actionTypes.FETCH_FLOOR_SCAN_REPORT_LIST_SUCCESS,
    payload: data,
  };
};
const fetchFloorScanReportListError = (error) => {
  return {
    type: actionTypes.FETCH_FLOOR_SCAN_REPORT_LIST_ERROR,
    payload: error,
  };
};

export function fetchFloorScanReportList(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(fetchFloorScanReportListStart());
    return technicianJobService
      .fetchFloorScanReportList(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(fetchFloorScanReportListSuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(fetchFloorScanReportListError(err));
        throw err;
      });
  };
}

const scanIsOkayStart = () => {
  return {
    type: actionTypes.SCAN_IS_OKAY_START,
  };
};
const scanIsOkaySuccess = (data) => {
  return {
    type: actionTypes.SCAN_IS_OKAY_SUCCESS,
    payload: data,
  };
};
const scanIsOkayError = (error) => {
  return {
    type: actionTypes.SCAN_IS_OKAY_ERROR,
    payload: error,
  };
};

export function markScanIsOkay(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(scanIsOkayStart());
    return technicianJobService
      .scanIsOkay(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(scanIsOkaySuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(scanIsOkayError(err));
        throw err;
      });
  };
}

const getRequestRescanHistoryStart = () => {
  return {
    type: actionTypes.GET_REQUEST_RESCAN_HISTORY_START,
  };
};
const getRequestRescanHistorySuccess = (data) => {
  return {
    type: actionTypes.GET_REQUEST_RESCAN_HISTORY_SUCCESS,
    payload: data,
  };
};
const getRequestRescanHistoryError = (error) => {
  return {
    type: actionTypes.GET_REQUEST_RESCAN_HISTORY_ERROR,
    payload: error,
  };
};

export function getRequestRescanHistory(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(getRequestRescanHistoryStart());
    return technicianJobService
      .getRequestRescanHistory(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(getRequestRescanHistorySuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(getRequestRescanHistoryError(err));
        throw err;
      });
  };
}
