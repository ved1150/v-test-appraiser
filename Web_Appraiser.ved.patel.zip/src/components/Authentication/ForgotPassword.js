import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Formik } from "formik";
import { connect, useSelector } from "react-redux";
import * as Yup from "yup";
import TextInput from "../common/TextInput";
import Button from "./../common/Button";
import { forgotPassword } from "../../actions/authenticationAction";
import { forgotPasswordMessages } from "../../constants/validationerrorMessages";
import Logo from "../../images/blue-logo.svg";
import "./index.scss";
import { useTranslation } from "react-i18next";
import DisplayErrorModal from "./../../components/common/DisplayErrorModal/DisplayErrorModal";
import { get, isEmpty } from "lodash";
import AsyncImage from "../common/AsyncImage";
const ForgotPassword = (props) => {
  const { t } = useTranslation();
  const [submitloading, setSubmitLoading] = useState(false);

  React.useEffect(() => {}, []);

  const tenantLogo = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess?.tenantLogo;
  });

  return (
    <>
      {props.errorModalloading && <DisplayErrorModal />}
      <section className="main-authaticatoin-wraper">
        <div className="auth-center-segment">
          <div className="auth-logo-top">
            {!isEmpty(tenantLogo) ? (
              <AsyncImage useStaticToken={true} imageUrl={tenantLogo} />
            ) : (
              <img src={Logo} alt="logo" />
            )}
          </div>
          <div className="auth-form-field-section">
            <Formik
              initialValues={{ email: "" }}
              onSubmit={(values, { setSubmitting }) => {
                setSubmitLoading(true);
                props
                  .forgotPassword(values)
                  .then((res) => {
                    setSubmitLoading(false);
                  })
                  .catch((e) => setSubmitLoading(false));
                setSubmitting(false);
              }}
              validationSchema={Yup.object().shape({
                email: Yup.string()
                  .email(t("ERROR_MESSAGES.forgotPasswordMessages.emailValid"))
                  .required(
                    t("ERROR_MESSAGES.forgotPasswordMessages.emailRequired")
                  ),
              })}
            >
              {(props) => {
                const {
                  values,
                  touched,
                  errors,
                  isSubmitting,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                } = props;
                return (
                  <form className="authatication-form" onSubmit={handleSubmit}>
                    <div className="inner-authaticatio-form">
                      <div className="form-group">
                        <p className="text-center">
                          {t("WEB_LABELS.Enter_your_registered_email_address")}
                        </p>
                      </div>
                      <TextInput
                        type="text"
                        name="email"
                        placeholder={t("WEB_LABELS.Email")}
                        value={values.email}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={errors.email}
                        touched={touched.email}
                        icon={
                          <div className="auth-icons font-email-set">
                            <i className="icon-email"></i>
                          </div>
                        }
                      />
                      <div className="form-group text-center">
                        <Button
                          disabled={submitloading}
                          type="submit"
                          className="blue-btn"
                        >
                          {t("BUTTONS.Submit")}{" "}
                          {submitloading && <div className="loader-spin"></div>}
                        </Button>
                      </div>
                      <div className="form-group-btn text-center">
                        <Link to="/sign-in" className="sign-in">
                          {t("BUTTONS.Sign_In")}
                        </Link>
                      </div>
                    </div>
                  </form>
                );
              }}
            </Formik>
          </div>
        </div>
      </section>
    </>
  );
};
const mapStateToProps = (state) => {
  return {
    errorModalloading: get(state, ["errorReducer", "errorModalloading"]),
  };
};
export default connect(mapStateToProps, {
  forgotPassword,
})(ForgotPassword);
