import * as actionTypes from "../actions/actionTypes";

export const defaultState = {
  listCardsLoading: false,
  listCardsData: {},
  listCardsError: null,

  deleteCardLoading: false,
  deleteCardData: {},
  deleteCardError: null,

  defaultCardLoading: false,
  defaultCardData: {},
  defaultCardError: null,

  getHostedProfileTokenLoading: false,
  getHostedProfileTokenData: {},
  getHostedProfileTokenError: null,
};

const states = {
  ...defaultState,
};

const manageCardsReducer = (state = states, action = {}) => {
  switch (action.type) {
    case actionTypes.MANAGE_CARDS_LIST_START:
      return {
        ...state,
        listCardsLoading: true,
        listCardsData: {},
        listCardsError: null,
      };
    case actionTypes.MANAGE_CARDS_LIST_SUCCESS:
      return {
        ...state,
        listCardsLoading: false,
        listCardsData: action.payload,
        listCardsError: null,
      };
    case actionTypes.MANAGE_CARDS_LIST_ERROR:
      return {
        ...state,
        listCardsLoading: false,
        listCardsData: {},
        listCardsError: action.payload,
      };

    case actionTypes.MANAGE_CARDS_GET_TOKEN_START:
      return {
        ...state,
        getHostedProfileTokenLoading: true,
        getHostedProfileTokenData: {},
        getHostedProfileTokenError: null,
      };
    case actionTypes.MANAGE_CARDS_GET_TOKEN_SUCCESS:
      return {
        ...state,
        getHostedProfileTokenLoading: false,
        getHostedProfileTokenData: action.payload,
        getHostedProfileTokenError: null,
      };
    case actionTypes.MANAGE_CARDS_GET_TOKEN_ERROR:
      return {
        ...state,
        getHostedProfileTokenLoading: false,
        getHostedProfileTokenData: {},
        getHostedProfileTokenError: action.payload,
      };

    case actionTypes.DELETE_CARDS_START:
      return {
        ...state,
        deleteCardLoading: true,
        deleteCardData: {},
        deleteCardError: null,
      };
    case actionTypes.DELETE_CARDS_SUCCESS:
      return {
        ...state,
        deleteCardLoading: false,
        deleteCardData: action.payload,
        deleteCardError: null,
      };
    case actionTypes.DELETE_CARDS_ERROR:
      return {
        ...state,
        deleteCardLoading: false,
        deleteCardData: {},
        deleteCardError: action.payload,
      };

    case actionTypes.SET_DEFAULT_CARDS_START:
      return {
        ...state,
        defaultCardLoading: true,
        defaultCardData: {},
        defaultCardError: null,
      };
    case actionTypes.SET_DEFAULT_CARDS_SUCCESS:
      return {
        ...state,
        defaultCardLoading: false,
        defaultCardData: action.payload,
        defaultCardError: null,
      };
    case actionTypes.SET_DEFAULT_CARDS_ERROR:
      return {
        ...state,
        defaultCardLoading: false,
        defaultCardData: {},
        defaultCardError: action.payload,
      };

    default:
      return state;
  }
};

export default manageCardsReducer;
