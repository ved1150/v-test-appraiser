import api from "./apis/api";

class TransactionHistoryService {
  fetchTransactionHistory(data) {
    return api.transactionHistory.fetch(data);
  }

  fetchTransactionStatus(data) {
    return api.transactionHistory.fetchStatus(data);
  }

  exportTransactionHistory(data) {
    return api.transactionHistory.exportTransactionHistory(data);
  }
}

export default new TransactionHistoryService();
