import React, { useState } from "react";
import i18n from "./../../translations/i18n";

import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import englishLanguage from "../../images/all-flag/English.svg";
import spanishLanguage from "../../images/all-flag/Spanish.svg";
import ArabicLanguage from "../../images/all-flag/Arabic.svg";
import FrenchLanguage from "../../images/all-flag/French.svg";
import IndiaLanguage from "../../images/all-flag/India.svg";
import PhilippinesLanguage from "../../images/all-flag/Philippines.svg";
import VietnameseLanguage from "../../images/all-flag/Vietnamese.svg";
import ChineseLanguage from "../../images/all-flag/Chinese.svg";
import KoreanLanguage from "../../images/all-flag/Korean.svg";
import RussianLanguage from "../../images/all-flag/Russian.svg";
import TurkishLanguage from "../../images/all-flag/Turkish.svg";
import "./index.scss";

export default function LanguageSwitcher() {
  const [anchorEl, setAnchorEl] = useState(null);
  const [language, setLanguage] = useState(
    sessionStorage.getItem("selectedLanguage")
      ? sessionStorage.getItem("selectedLanguage")
      : "english"
  );

  const handleLanguageClick = (event) => {
    setTimeout(() => {
      document
        .querySelector("div#contolled-language")
        .getElementsByClassName("MuiPaper-root")[0]
        .classList.add("MuiPaper-root-signin");
    }, 100);
    setAnchorEl(event.currentTarget);
  };

  const handleLanguageClose = (item, e) => {
    switch (item) {
      case "english": {
        i18n.changeLanguage("en");
        break;
      }
      case "arabic": {
        i18n.changeLanguage("ar");
        break;
      }
      case "cantonese": {
        i18n.changeLanguage("yue");
        break;
      }
      case "french": {
        i18n.changeLanguage("fr");
        break;
      }
      case "hindi": {
        i18n.changeLanguage("hi");
        break;
      }
      case "japanese": {
        i18n.changeLanguage("ja");
        break;
      }
      case "korean": {
        i18n.changeLanguage("ko");
        break;
      }
      case "mandarin": {
        i18n.changeLanguage("cmn");
        break;
      }
      case "tagalog": {
        i18n.changeLanguage("tl");
        break;
      }
      case "vietnamese": {
        i18n.changeLanguage("vi");
        break;
      }
      case "spanish": {
        i18n.changeLanguage("es");
        break;
      }
      case "russian": {
        i18n.changeLanguage("ru");
        break;
      }
      case "turkish": {
        i18n.changeLanguage("tr");
        break;
      }
    }
    if (typeof item == "string") {
      setLanguage(item);
      sessionStorage.setItem("selectedLanguage", item);
    }
    setAnchorEl(null);
  };
  return (
    <div className="language-signin">
      <button
        className={
          anchorEl ? "language-signin-button active" : "language-signin-button"
        }
        type="button"
        id="contolled-language"
        onClick={handleLanguageClick}
      >
        {language === "english" && (
          <>
            <div class="img language-signin-image">
              <img src={englishLanguage} alt="english" />
            </div>
            <div class="text">
              English <span>English</span>
            </div>
          </>
        )}
        {language === "hindi" && (
          <>
            <div class="img language-signin-image">
              <img src={IndiaLanguage} alt="hindi" />
            </div>
            <div class="text">
              Hindi <span>हिन्दी</span>
            </div>
          </>
        )}
        {language === "arabic" && (
          <>
            <div class="img language-signin-image">
              <img src={ArabicLanguage} alt="Arabic" />
            </div>
            <div class="text">
              Arabic <span>عربى</span>
            </div>
          </>
        )}
        {language === "french" && (
          <>
            <div className="img language-signin-image">
              <img src={FrenchLanguage} alt="french" />
            </div>
            <div className="text">
              French <span>Français</span>
            </div>
          </>
        )}
        {language === "japanese" && (
          <>
            <div className="img language-signin-image">
              <img src={ChineseLanguage} alt="japanese" />
            </div>
            <div className="text">
              Japanese <span>日本</span>
            </div>
          </>
        )}
        {language === "korean" && (
          <>
            <div className="img language-signin-image">
              <img src={KoreanLanguage} alt="korean" />
            </div>
            <div className="text">
              Korean <span>한국인</span>
            </div>
          </>
        )}
        {language === "spanish" && (
          <>
            <div className="img language-signin-image">
              <img src={spanishLanguage} alt="spanish" />
            </div>
            <div className="text">
              Spanish <span>Español</span>
            </div>
          </>
        )}
        {language === "vietnamese" && (
          <>
            <div className="img language-signin-image">
              <img src={VietnameseLanguage} alt="vietnamese" />
            </div>
            <div className="text">
              Vietnamese <span>Tiếng Việt</span>
            </div>
          </>
        )}
        {language === "tagalog" && (
          <>
            <div className="img language-signin-image">
              <img src={PhilippinesLanguage} alt="tagalog" />
            </div>
            <div className="text">
              Tagalog <span>Tagalog</span>
            </div>
          </>
        )}
        {language === "mandarin" && (
          <>
            <div className="img language-signin-image">
              <img src={ChineseLanguage} alt="mandarin" />
            </div>
            <div className="text">
              Mandarin <span>普通话</span>
            </div>
          </>
        )}
        {language === "cantonese" && (
          <>
            <div className="img language-signin-image">
              <img src={ChineseLanguage} alt="cantonese" />
            </div>
            <div className="text">
              Cantonese <span>粵語</span>
            </div>
          </>
        )}
        {language === "russian" && (
          <>
            <div className="img language-signin-image">
              <img src={RussianLanguage} alt="russian" />
            </div>
            <div className="text">
              Russian <span>русский</span>
            </div>
          </>
        )}
        {language === "turkish" && (
          <>
            <div className="img language-signin-image">
              <img src={TurkishLanguage} alt="turkish" />
            </div>
            <div className="text">
              Turkish <span>Türk</span>
            </div>
          </>
        )}
      </button>
      <Menu
        id="contolled-language"
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left",
        }}
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleLanguageClose}
        TransitionProps={{
          appear: false,
        }}
      >
        <MenuItem
          className={`${language === "arabic" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("arabic", e)}
        >
          <button>
            <div className="img">
              <img src={ArabicLanguage} alt="arabic" />
            </div>
            <div className="text">
              Arabic <span>عربى</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "cantonese" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("cantonese", e)}
        >
          <button>
            <div className="img">
              <img src={ChineseLanguage} alt="cantonese" />
            </div>
            <div className="text">
              Cantonese <span>粵語</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "english" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("english", e)}
        >
          <button>
            <div className="img">
              <img src={englishLanguage} alt="english" />
            </div>
            <div className="text">
              English <span>English</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "french" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("french", e)}
        >
          <button>
            <div className="img">
              <img src={FrenchLanguage} alt="french" />
            </div>
            <div className="text">
              French <span>Français</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "hindi" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("hindi", e)}
        >
          <button>
            <div className="img">
              <img src={IndiaLanguage} alt="hindi" />
            </div>
            <div className="text">
              Hindi <span>हिन्दी</span>
            </div>
          </button>
        </MenuItem>

        <MenuItem
          className={`${language === "japanese" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("japanese", e)}
        >
          <button>
            <div className="img">
              <img src={ChineseLanguage} alt="japanese" />
            </div>
            <div className="text">
              Japanese <span>日本</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "korean" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("korean", e)}
        >
          <button>
            <div className="img">
              <img src={KoreanLanguage} alt="korean" />
            </div>
            <div className="text">
              Korean <span>한국인</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "mandarin" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("mandarin", e)}
        >
          <button>
            <div className="img">
              <img src={ChineseLanguage} alt="mandarin" />
            </div>
            <div className="text">
              Mandarin <span>普通话</span>
            </div>
          </button>
        </MenuItem>
        <MenuItem
          className={`${language === "spanish" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("spanish", e)}
        >
          <button>
            <div className="img">
              <img src={spanishLanguage} alt="spanish" />
            </div>
            <div className="text">
              Spanish <span>Español</span>
            </div>
          </button>
        </MenuItem>

        <MenuItem
          className={`${language === "tagalog" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("tagalog", e)}
        >
          <button>
            <div className="img">
              <img src={PhilippinesLanguage} alt="tagalog" />
            </div>
            <div className="text">
              Tagalog <span>Tagalog</span>
            </div>
          </button>
        </MenuItem>

        <MenuItem
          className={`${language === "vietnamese" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("vietnamese", e)}
        >
          <button>
            <div className="img">
              <img src={VietnameseLanguage} alt="vietnamese" />
            </div>
            <div className="text">
              Vietnamese <span>Tiếng Việt</span>
            </div>
          </button>
        </MenuItem>

        <MenuItem
          className={`${language === "russian" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("russian", e)}
        >
          <button>
            <div className="img">
              <img src={RussianLanguage} alt="russian" />
            </div>
            <div className="text">
              Russian <span>русский</span>
            </div>
          </button>
        </MenuItem>

        <MenuItem
          className={`${language === "turkish" ? "active" : ""}`}
          onClick={(e) => handleLanguageClose("turkish", e)}
        >
          <button>
            <div className="img">
              <img src={TurkishLanguage} alt="turkish" />
            </div>
            <div className="text">
              Turkish <span>Türk</span>
            </div>
          </button>
        </MenuItem>
      </Menu>
    </div>
  );
}
