import * as actionTypes from "../actions/actionTypes";

const whiteLabelState = {
  getTenantThemeStart: false,
  getTenantThemeSuccess: {},
  getTenantThemeError: null,
};

export const defaultState = {
  ...whiteLabelState,
};

const whiteLabelReducer = (state = defaultState, action = {}) => {
  switch (action.type) {
    case actionTypes.GET_TENANT_THEME_START:
      return {
        ...state,
        getTenantThemeStart: true,
        getTenantThemeSuccess: {},
        getTenantThemeError: null,
      };
    case actionTypes.GET_TENANT_THEME_SUCCESS:
      return {
        ...state,
        getTenantThemeStart: false,
        getTenantThemeSuccess: action.payload,
        getTenantThemeError: null,
      };
    case actionTypes.GET_TENANT_THEME_ERROR:
      return {
        ...state,
        getTenantThemeStart: false,
        getTenantThemeSuccess: {},
        getTenantThemeError: action.payload,
      };
    default:
      return state;
  }
};

export default whiteLabelReducer;
