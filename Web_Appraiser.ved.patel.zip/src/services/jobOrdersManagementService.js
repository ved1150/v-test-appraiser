import api from "./apis/api";
import {
  deHydrateJobOrdersManagement,
  hydrateJobOrdersManagement,
} from "./transformers/jobOrdersManagementTransformer";

class JobOrdersManagementService {
  createJobOrder(data) {
    return api.jobOrdersManagement
      .createJobOrder(deHydrateJobOrdersManagement(data))
      .then(hydrateJobOrdersManagement);
  }

  editJobOrder(jobOrderId, data) {
    return api.jobOrdersManagement
      .editJobOrder(jobOrderId, deHydrateJobOrdersManagement(data))
      .then(hydrateJobOrdersManagement);
  }
}

export default new JobOrdersManagementService();
