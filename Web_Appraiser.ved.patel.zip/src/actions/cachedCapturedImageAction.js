import * as actionTypes from "./actionTypes";

export const addCachedCapturedImage = (key, value) => {
  return {
    type: actionTypes.ADD_CACHED_CAPTURED_IMAGE,
    key: key,
    value: value,
  };
};

export const deleteCachedCapturedImage = (key) => {
  return {
    type: actionTypes.DELETE_CACHED_CAPTURED_IMAGE,
    key: key,
  };
};
