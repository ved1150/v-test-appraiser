import { useState } from "react";

const Parcel = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Parcel{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {Object.keys(props.estatedData.data.parcel).map((key) => (
          <li key={key}>
            <div style={{ textTransform: "capitalize" }}>
              {key.split("_").join(" ")}
            </div>
            {Array.isArray(props.estatedData.data.parcel[key]) && (
              <div>
                {props.estatedData.data.parcel[key] &&
                props.estatedData.data.parcel[key].isNotEmpty
                  ? props.estatedData.data.parcel[key].join(",")
                  : "N/A"}
              </div>
            )}
            {!Array.isArray(props.estatedData.data.parcel[key]) && (
              <div>{props.estatedData.data.parcel[key] ?? "N/A"}</div>
            )}
          </li>
        ))}
      </ul>
    </>
  );
};

export default Parcel;
