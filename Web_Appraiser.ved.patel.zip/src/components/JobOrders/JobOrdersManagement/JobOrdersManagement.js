import React, { useState, useEffect } from "react";
import { connect, useSelector } from "react-redux";
import { useParams, useHistory, Prompt } from "react-router-dom";
import { useTranslation } from "react-i18next";
import _ from "lodash";
import { Formik } from "formik";
import * as Yup from "yup";
import TextInput from "../../common/TextInput";
import Button from "../../common/Button";
import { countries, propertyTypes } from "../../../constants/enums";
import CustomFormikPhoneInput from "../../common/CustomFormikPhoneInput/";
import "./jobOrdersManagement.scss";
import { fetchDetails } from "../../../actions/detailsActions";
import {
  createJobOrder,
  editJobOrder,
} from "../../../actions/jobOrdersManagementAction";
import { logEvent } from "firebase/analytics";
import getAnalyticsInstance from "../../../services/analytics";
import { fetchStates } from "../../../actions/authenticationAction";
import { listJobOrderTypes } from "../../../actions/jobOrderTypesAction";
import ConfirmationModal from "../../common/confirmationModal";

const JobOrdersManagement = (props) => {
  const history = useHistory();
  const param = useParams();
  const [selectedJobOrder, setSelectedJobOrder] = useState(
    _.get(param, ["jobOrderId"], "")
  );
  const [isEditJobOrder, setIsEditJobOrder] = useState(false);
  const [isCreateJobOrder, setIsCreateJobOrder] = useState(false);
  const [jobOrderDetails, setJobOrderDetails] = useState({
    jobOrderAssignee: null,
    propertyType: "",
    ownerName: "",
    ownerPhone: "",
    ownerEmail: "",
    propertyAddress1: "",
    propertyAddress2: "",
    propertyCity: "",
    propertyState: "",
    propertyCountry: "USA",
    propertyZip: "",
    jobOrderType: "",
  });
  const [states, setStates] = useState([]);

  useEffect(() => {
    props
      .fetchStates()
      .then((data) => {
        if (!_.isNull(data.states)) {
          setStates(data.states);
        } else {
          setStates([]);
        }
      })
      .catch((err) => {
        setStates([]);
        throw err;
      });
    if (!selectedJobOrder) {
      props.listJobOrderTypes();
    }

    window.onbeforeunload = function (e) {
      return window.confirm(
        "The data will be lost. Are you sure you want to navigate?"
      );
    };
    return () => {
      window.onbeforeunload = null;
    };
  }, []);

  useEffect(() => {
    if (selectedJobOrder) {
      if (!props?.location?.state?.isSelfCreated) {
        history.replace("/");
        return;
      }
      props.fetchDetails(selectedJobOrder).then((res) => {
        setJobOrderDetails({
          jobOrderAssignee: res.assignee,
          propertyType: res.propertyType,
          ownerName: res.name,
          ownerPhone: res.phone,
          ownerEmail: res.email,
          propertyAddress1: res.address1,
          propertyAddress2: res.address2,
          propertyCity: res.city,
          propertyState: res.state,
          propertyCountry: "USA",
          propertyZip: res.propertyZip,
          jobOrderType: res.jobOrderType,
        });
      });
    }
  }, [selectedJobOrder]);

  const { t } = useTranslation();
  const _jobOrderAssignee = useSelector(
    (state) =>
      `${state?.profile?.fetchProfileDetailsSuccess?.firstName} ${state?.profile?.fetchProfileDetailsSuccess?.lastName}`
  );

  const _userId = useSelector(
    (state) => state?.profile?.fetchProfileDetailsSuccess?.userId
  );

  const [
    showCreateConfirmationPriceModal,
    setShowCreateConfirmationPriceModal,
  ] = useState(false);

  const [createConfirmModalPriceValue, setCreateConfirmModalPriceValue] =
    useState(null);

  return (
    <section className="content-wapper">
      <div className="breadcrumb">
        <ul>
          <li>
            <button
              onClick={() => {
                props.history.push("/");
              }}
            >
              {t("WEB_LABELS.My_Job_Orders")}
            </button>
          </li>
          <li>{t(selectedJobOrder ? "Edit_Job_Order" : "Create_Job_Order")}</li>
        </ul>
      </div>
      <div className="common-panel">
        <section>
          <Formik
            enableReinitialize
            initialValues={{
              jobOrderAssignee:
                jobOrderDetails.jobOrderAssignee ?? _jobOrderAssignee,
              propertyType: jobOrderDetails.propertyType,
              ownerName: jobOrderDetails.ownerName,
              ownerPhone: jobOrderDetails.ownerPhone,
              ownerEmail: jobOrderDetails.ownerEmail,
              propertyAddress1: jobOrderDetails.propertyAddress1,
              propertyAddress2: jobOrderDetails.propertyAddress2,
              propertyCity: jobOrderDetails.propertyCity,
              propertyState: jobOrderDetails.propertyState,
              propertyCountry: jobOrderDetails.propertyCountry,
              propertyZip: jobOrderDetails.propertyZip,
              jobOrderType: jobOrderDetails.jobOrderType,
            }}
            onSubmit={(values, { setSubmitting, resetForm }) => {
              setSubmitting(true);
              if (selectedJobOrder) {
                const __values = {
                  ...values,
                };
                delete __values.jobOrderType;
                return props
                  .editJobOrder(selectedJobOrder, {
                    ...__values,
                    userId: _userId,
                  })
                  .then(() => {
                    setSubmitting(false);
                    setIsEditJobOrder(false);
                    history.replace("/");
                    resetForm();
                  })
                  .catch(() => {
                    setIsEditJobOrder(true);
                    setSubmitting(false);
                  });
              } else {
                const __values = {
                  ...values,
                  jobOrderTypeId: values.jobOrderType,
                };
                delete __values.jobOrderType;
                setShowCreateConfirmationPriceModal(false);
                return props
                  .createJobOrder({
                    ...__values,
                    userId: _userId,
                  })
                  .then(() => {
                    if (process.env.REACT_APP_SENTRY_ENV == "Production") {
                      getAnalyticsInstance().then((analytics) => {
                        logEvent(analytics, "Create Job Order", {
                          name: "" + " " + "",
                        });
                      });
                    }
                    setSubmitting(false);
                    setIsCreateJobOrder(false);
                    history.replace("/");
                    resetForm();
                  })
                  .catch(() => {
                    setIsCreateJobOrder(true);
                    setSubmitting(false);
                  });
              }
            }}
            validationSchema={Yup.object().shape({
              jobOrderAssignee: Yup.string()
                .required("jobOrderAssigneeRequired")
                .nullable(),
              propertyType: Yup.string()
                .required("propertyTypeRequired")
                .nullable(),
              ownerName: Yup.string()
                .required("ownerNameRequired")
                .nullable()
                .matches(/^[a-zA-Z ]{2,30}$/, "ownerNameValid"),
              ownerPhone: Yup.string()
                .required("ownerPhoneRequired")
                .nullable()
                .matches(/^\+[1-9]{1}[0-9]{10}$/, "ownerPhoneMaxLength"),
              ownerEmail: Yup.string()
                .email("ownerEmailValid")
                .required("ownerEmailRequired")
                .nullable(),
              propertyAddress1: Yup.string()
                .required("propertyAddress1Required")
                .nullable(),
              propertyAddress2: Yup.string().nullable(),
              propertyCity: Yup.string()
                .required("propertyCityRequired")
                .nullable(),
              propertyState: Yup.string()
                .required("propertyStateRequired")
                .nullable(),
              propertyCountry: Yup.string()
                .required("propertyCountryRequired")
                .nullable(),
              propertyZip: Yup.string()
                .required("propertyZipRequired")
                .nullable()
                .matches(
                  /^(\d{5}(-\d{4})?|[A-Z]\d[A-Z] ?\d[A-Z]\d)$/,
                  "propertyZipMaxLength"
                ),
              jobOrderType: selectedJobOrder
                ? Yup.string().nullable()
                : Yup.string().required("jobOrderTypeRequired").nullable(),
            })}
          >
            {(formikProps) => {
              const {
                values,
                isValid,
                dirty,
                touched,
                errors,
                isSubmitting,
                handleChange,
                handleBlur,
                handleSubmit,
                setFieldValue,
                setTouched,
              } = formikProps;

              return (
                <>
                  <form onSubmit={handleSubmit}>
                    <div className="panel-body admin-profile">
                      <div className="vrow">
                        <div className="vcol-4">
                          <div className="form-group boot-dropdown">
                            <label>
                              {t("Appraiser")}
                              <span className="error-mark">*</span>
                            </label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="jobOrderAssignee"
                              placeholder={t("Appraiser")}
                              value={values.jobOrderAssignee}
                              onChange={handleChange}
                              error={errors.jobOrderAssignee}
                              touched={touched.jobOrderAssignee}
                              onBlur={handleBlur}
                              disabled
                            />
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("WEB_LABELS.Property_Type")}
                              <span className="error-mark">*</span>
                            </label>
                            <select
                              className="form-control"
                              name="propertyType"
                              placeholder={t("WEB_LABELS.Property_Type")}
                              value={values.propertyType}
                              onChange={handleChange}
                              error={errors.propertyType}
                              touched={touched.propertyType}
                              onBlur={handleBlur}
                            >
                              <option value="">
                                {t("Select_Property_Type")}
                              </option>
                              {propertyTypes?.map(({ id, type }, index) => (
                                <option value={id}>{t(type)}</option>
                              ))}
                            </select>
                            {touched.propertyType && errors.propertyType && (
                              <div className="form-error">
                                {t(errors.propertyType)}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Owner_Name")}
                              <span className="error-mark">*</span>
                            </label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="ownerName"
                              placeholder={t("Owner_Name")}
                              value={values.ownerName}
                              onChange={handleChange}
                              error={errors.ownerName}
                              touched={touched.ownerName}
                              onBlur={handleBlur}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="vrow">
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Job_Order_Type")}
                              <span className="error-mark">*</span>
                            </label>
                            <select
                              disabled={selectedJobOrder}
                              className="form-control"
                              name="jobOrderType"
                              placeholder={t("Job_Order_Type")}
                              value={values.jobOrderType}
                              onChange={handleChange}
                              error={errors.jobOrderType}
                              touched={touched.jobOrderType}
                              onBlur={handleBlur}
                            >
                              <option value="">
                                {selectedJobOrder
                                  ? _.isEmpty(values.jobOrderType)
                                    ? "-"
                                    : values.jobOrderType
                                  : t("Select_Job_Order_Type")}
                              </option>
                              {_.get(
                                props,
                                [
                                  "jobOrderTypes",
                                  "listJobOrderTypeSuccess",
                                  "data",
                                  "data",
                                  "list",
                                ],
                                []
                              )?.map(({ id, type }, index) => (
                                <option value={id}>{type}</option>
                              ))}
                            </select>
                            {touched.jobOrderType && errors.jobOrderType && (
                              <div className="form-error">
                                {t(errors.jobOrderType)}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("WEB_LABELS.Cell_Phone")}
                              <span className="error-mark">*</span>
                            </label>
                            <CustomFormikPhoneInput
                              as="TextInput"
                              country="us"
                              name="ownerPhone"
                              value={values.ownerPhone}
                              onChange={handleChange}
                              countryCodeEditable={false}
                              onlyCountries={["us"]}
                              enableSearch={false}
                              placeholder={t("WEB_LABELS.Cell_Phone")}
                              errors={errors}
                              touched={touched}
                              onBlur={handleBlur}
                              setFieldValue={setFieldValue}
                              setTouched={setTouched}
                            />
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("WEB_LABELS.Email")}
                              <span className="error-mark">*</span>
                            </label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="ownerEmail"
                              placeholder={t("WEB_LABELS.Email")}
                              value={values.ownerEmail}
                              onChange={handleChange}
                              error={errors.ownerEmail}
                              touched={touched.ownerEmail}
                              onBlur={handleBlur}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="vrow">
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Property_Address_1")}
                              <span className="error-mark">*</span>
                            </label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="propertyAddress1"
                              placeholder={t("Property_Address_1")}
                              value={values.propertyAddress1}
                              onChange={handleChange}
                              error={errors.propertyAddress1}
                              touched={touched.propertyAddress1}
                              onBlur={handleBlur}
                            />
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>{t("Property_Address_2")}</label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="propertyAddress2"
                              placeholder={t("Property_Address_2")}
                              value={values.propertyAddress2}
                              onChange={handleChange}
                              error={errors.propertyAddress2}
                              touched={touched.propertyAddress2}
                              onBlur={handleBlur}
                            />
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Property_City")}
                              <span className="error-mark">*</span>
                            </label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="propertyCity"
                              placeholder={t("Property_City")}
                              value={values.propertyCity}
                              onChange={handleChange}
                              error={errors.propertyCity}
                              touched={touched.propertyCity}
                              onBlur={handleBlur}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="vrow">
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Property_State")}
                              <span className="error-mark">*</span>
                            </label>
                            <select
                              className="form-control"
                              name="propertyState"
                              placeholder={t("Property_State")}
                              value={values.propertyState}
                              onChange={handleChange}
                              error={errors.propertyState}
                              touched={touched.propertyState}
                              onBlur={handleBlur}
                            >
                              <option value="">{t("Select_State")}</option>
                              {states?.map(({ stateId, state }, index) => (
                                <option key={stateId} value={state}>
                                  {state}
                                </option>
                              ))}
                            </select>
                            {touched.propertyState && errors.propertyState && (
                              <div className="form-error">
                                {t(errors.propertyState)}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Property_Country")}
                              <span className="error-mark">*</span>
                            </label>
                            <select
                              className="form-control"
                              name="propertyCountry"
                              placeholder={t("Property_Country")}
                              value={values.propertyCountry}
                              onChange={handleChange}
                              error={errors.propertyCountry}
                              touched={touched.propertyCountry}
                              onBlur={handleBlur}
                            >
                              <option value="">{t("Select_Country")}</option>
                              {countries.map(({ id, name }, index) => (
                                <option key={id} value={id}>
                                  {name}
                                </option>
                              ))}
                            </select>
                            {touched.propertyCountry &&
                              errors.propertyCountry && (
                                <div className="form-error">
                                  {t(errors.propertyCountry)}
                                </div>
                              )}
                          </div>
                        </div>
                        <div className="vcol-4">
                          <div className="form-group">
                            <label>
                              {t("Property_Zip_Code")}
                              <span className="error-mark">*</span>
                            </label>
                            <TextInput
                              className="form-control"
                              type="text"
                              name="propertyZip"
                              placeholder={t("Property_Zip_Code")}
                              value={values.propertyZip}
                              onChange={handleChange}
                              error={errors.propertyZip}
                              touched={touched.propertyZip}
                              onBlur={handleBlur}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="panel-footer">
                      <Button
                        onClick={(e) => {
                          if (!selectedJobOrder) {
                            setCreateConfirmModalPriceValue(
                              _.get(
                                props,
                                [
                                  "jobOrderTypes",
                                  "listJobOrderTypeSuccess",
                                  "data",
                                  "data",
                                  "list",
                                ],
                                []
                              )
                                .filter((e) => e.id === values.jobOrderType)
                                .map((e) => e.price)
                            );
                            setShowCreateConfirmationPriceModal(true);
                            e.preventDefault();
                          }
                        }}
                        type="submit"
                        className="blue-btn"
                        disabled={isSubmitting || !(isValid && dirty)}
                      >
                        {t(selectedJobOrder ? "Update" : "Create")}
                        {isSubmitting && <div className="loader-spin"></div>}
                      </Button>
                    </div>
                  </form>
                  <Prompt
                    when={dirty && (isEditJobOrder || isCreateJobOrder)}
                    message="The data will be lost. Are you sure you want to navigate?"
                  />
                  {showCreateConfirmationPriceModal && (
                    <ConfirmationModal
                      cancelEvent={() => {
                        setShowCreateConfirmationPriceModal(false);
                      }}
                      title={`${t(
                        "Are you sure you want to create the job order? This will charge you"
                      )} $${createConfirmModalPriceValue}`}
                      cancelText={t("COMMON_MESSAGES.No")}
                      confirmText={t("COMMON_MESSAGES.Yes")}
                      confirmEvent={handleSubmit}
                    ></ConfirmationModal>
                  )}
                </>
              );
            }}
          </Formik>
        </section>
      </div>
    </section>
  );
};

const mapStateToProps = (state) => {
  return {
    jobOrder: state.jobOrder,
    userManagement: state.userManagement,
    jobOrderTypes: state.jobOrderTypes,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchDetails: (data) => dispatch(fetchDetails(data)),
    createJobOrder: (data) => dispatch(createJobOrder(data)),
    editJobOrder: (jobOrderId, data) =>
      dispatch(editJobOrder(jobOrderId, data)),
    fetchStates: () => dispatch(fetchStates()),
    listJobOrderTypes: (data) => dispatch(listJobOrderTypes(data)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(JobOrdersManagement);
