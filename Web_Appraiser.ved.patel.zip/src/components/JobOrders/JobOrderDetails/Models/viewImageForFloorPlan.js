import React, { useState } from "react";
import AsyncImage from "../../../common/AsyncImage";
import "./zoomOption.scss";
import _ from "lodash";
import { customToast } from "../../../../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "../../../../constants/commonMessages";

const ViewImageForFloorPlan = (props) => {
  const [zoomLevel, setZoomLevel] = useState("1");

  const downloadImageFloorPlan = () => {
    props
      .downloadImage(props.imageFloorScanObj.floorPlanPath)
      .then((data) => {
        window.open(data.data, "_blank");
      })
      .catch((err) => {
        throw err;
      });
  };

  return (
    <div className="download_images_sec_floorScan">
      <div className="download_img_header">
        <div></div>
        <div className="download_img_btn">
          <div className="download_img_icon">
            <button type="button" onClick={() => downloadImageFloorPlan()}>
              <i className="icon-download-img"></i>
            </button>
            <button onClick={props.viewImageForFloorPlan} type="button">
              <i className="icon-close-image"></i>
            </button>
          </div>
        </div>
      </div>
      <div className="image_content zoom-level-image">
        <AsyncImage
          zoomLevel={zoomLevel}
          imageUrl={props.imageFloorScanObj.floorPlanViewPath}
        />
        <div className="zoom_outer" style={{ display: "block" }}>
          <span className="zoom-level">Zoom Level</span>
          <div className="zoom_main">
            <div className="level">
              <label>
                <input
                  type="radio"
                  name="zoomlevel"
                  value="3(3x)"
                  onClick={() => setZoomLevel("3")}
                />
                <span>3X</span>
              </label>
            </div>
            <div className="level">
              <label>
                <input
                  type="radio"
                  name="zoomlevel"
                  className=""
                  value="2(2x)"
                  onClick={() => setZoomLevel("2")}
                />
                <span>2X</span>
              </label>
            </div>
            <div className="level">
              <label>
                <input
                  type="radio"
                  name="zoomlevel"
                  className="checked"
                  value="1(1x)"
                  onClick={() => setZoomLevel("1")}
                  checked={zoomLevel === "1" ?? "checked"}
                />
                <span>1X</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewImageForFloorPlan;
