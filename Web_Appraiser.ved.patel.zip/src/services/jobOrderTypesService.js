import api from "./apis/api";

class JobOrderTypesService {
  listJobOrderTypes(data) {
    return api.jobOrderTypes.list(data);
  }
}

export default new JobOrderTypesService();
