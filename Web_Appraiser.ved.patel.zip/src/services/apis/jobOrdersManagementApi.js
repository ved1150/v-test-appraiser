import api from "./api";

export default class JobOrdersManagementAPI {
  createJobOrder(data) {
    return api.post("/create-joborders", data);
  }

  editJobOrder(jobOrderId, data) {
    return api.put(`/joborders/${jobOrderId}`, data);
  }
}
