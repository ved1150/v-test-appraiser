import React, { useEffect, useState } from "react";
import { floorName } from "../../../../constants/enums";
import "./downloadreport.scss";
import _ from "lodash";
import { useTranslation } from "react-i18next";
import authenticationService from "../../../../services/authenticationService";
import { ROLE } from "../../../../constants/appConstant";
const DownloadReportModal = (props) => {
  const [floorListForVideo, setFloorListForVideo] = useState([]);
  const [floorListForRemoteVal, setFloorListForRemoteVal] = useState([]);
  const [selectedFloorIdList3D, setSelectedFloorIdList3D] = useState([]);
  const [selectedFloorIdList2D, setSelectedFloorIdList2D] = useState([]);
  const [remotevalVideoCheckbox, setRemotevalVideoCheckbox] = useState(false);
  const [remotevalCheckbox, setRemotevalCheckbox] = useState(false);
  const { t } = useTranslation();
  useEffect(() => {
    let cornerDetectionFloors = props?.isTechnician
      ? []
      : _.cloneDeep(
          _.get(
            props.loadDownloadReportData,
            ["data", "data", "cornerDetectionFloors"],
            []
          )
        );
    let videoBasedFloors = _.cloneDeep(
      _.get(
        props.loadDownloadReportData,
        ["data", "data", "videoBasedFloors"],
        []
      )
    );
    if (videoBasedFloors != null) {
      videoBasedFloors.map((val) => {
        let floorTagNameList = val.floorTagNameList.map((str, index) => ({
          value: str,
          checked: false,
        }));
        val.floorTagNameList = floorTagNameList;
      });
      setFloorListForVideo(videoBasedFloors);
    }
    if (cornerDetectionFloors != null) {
      setFloorListForRemoteVal(
        cornerDetectionFloors.map((val) => {
          return {
            floorId: val.floorIndex,
            floorName: val.floorName,
            checked: false,
          };
        })
      );
    }
  }, []);
  const selectAllFloorTags = (floor, e) => {
    const { checked } = e.target;
    floorListForVideo.map((val) => {
      if (val.floorScanId == floor.floorScanId) {
        val.checked = checked;
        let floorTagNameList = val.floorTagNameList.map((str, index) => ({
          value: str.value,
          checked: checked,
        }));
        val.floorTagNameList = floorTagNameList;
      }
    });
    setFloorListForVideo([...floorListForVideo]);
    checkSelectedCheckbox();
  };
  const selectAllRemoteValVideo = (e) => {
    const { checked } = e.target;
    setRemotevalVideoCheckbox(checked);
    floorListForVideo.map((val) => {
      val.checked = checked;
      let floorTagNameList = val.floorTagNameList.map((str, index) => ({
        value: str.value,
        checked: checked,
      }));
      val.floorTagNameList = floorTagNameList;
    });
    setFloorListForVideo([...floorListForVideo]);
    checkSelectedCheckbox();
  };
  const selectAllRemoteVal = (e) => {
    const { checked } = e.target;
    setRemotevalCheckbox(checked);
    floorListForRemoteVal.map((val) => {
      val.checked = checked;
    });
    setFloorListForRemoteVal([...floorListForRemoteVal]);
    checkSelectedCheckbox();
  };
  const selectCurrentFloorTag = (floor, index, e) => {
    const { checked } = e.target;
    floorListForVideo.map((val) => {
      if (val.floorScanId == floor.floorScanId) {
        val.floorTagNameList[index].checked = checked;
        let parentChecked = Object.values(val.floorTagNameList).every(
          (v) => v.checked === true
        );
        if (parentChecked) {
          val.checked = true;
        } else {
          val.checked = false;
        }
      }
    });
    setFloorListForVideo([...floorListForVideo]);
    checkSelectedCheckbox();
  };
  const selectCurrentFloorRemoteVal = (floor, e) => {
    const { checked } = e.target;
    floorListForRemoteVal.map((val) => {
      if (val.floorId == floor.floorId) {
        val.checked = checked;
        let parentChecked = Object.values(floorListForRemoteVal).every(
          (v) => v.checked === true
        );
        if (parentChecked) {
          setRemotevalCheckbox(true);
        } else {
          setRemotevalCheckbox(false);
        }
      }
    });
    setFloorListForRemoteVal([...floorListForRemoteVal]);
    checkSelectedCheckbox();
  };
  const checkSelectedCheckbox = () => {
    setSelectedFloorIdList3D([]);
    let selectedFloorsFor3D = [];
    let selectedFloorsFor2D = [];
    floorListForVideo.forEach((floor) => {
      let currentfloor = {
        floorScanId: floor.floorScanId,
        floorTagNameList: [],
      };
      floor.floorTagNameList.forEach((tag) => {
        if (tag.checked) {
          currentfloor.floorTagNameList.push(tag.value);
        }
      });
      if (currentfloor.floorTagNameList.length > 0) {
        selectedFloorsFor3D.push(currentfloor);
      }
    });
    selectedFloorsFor2D = floorListForRemoteVal.filter(
      (val) => val.checked == true
    );
    setSelectedFloorIdList3D([...selectedFloorsFor3D]);
    setSelectedFloorIdList2D([...selectedFloorsFor2D]);
    return [selectedFloorsFor2D, selectedFloorsFor3D];
  };
  const deselectAllCheckbox = () => {
    setRemotevalVideoCheckbox(false);
    setRemotevalCheckbox(false);
    setSelectedFloorIdList3D([]);
    setSelectedFloorIdList2D([]);
    let floorList = floorListForVideo.map((floor, index) => ({
      ...floor,
      checked: false,
    }));
    floorList.forEach((floor) => {
      let floorTagNameList = floor.floorTagNameList.map((tag, index) => ({
        value: tag.value,
        checked: false,
      }));
      floor.floorTagNameList = floorTagNameList;
    });
    let remoteValFloors = floorListForRemoteVal.map((val) => {
      return { floorId: val.floorId, floorName: val.floorName, checked: false };
    });
    setFloorListForVideo([...floorList]);
    setFloorListForRemoteVal([...remoteValFloors]);
  };
  const downloadReport = (action) => {
    let selectedFloors = checkSelectedCheckbox();
    props.downloadReport(selectedFloors[0], selectedFloors[1], action);
  };
  return (
    <div className="comman-modal right-side open" style={{ display: "block" }}>
      <div className="comman-modal-main">
        <div className="side-head">
          {t("BUTTONS.Download_Reports")}
          {!props.isDownloadReport && (
            <button
              className="close-modal"
              type="button"
              onClick={() => {
                props.setShowDownloadReportModal(false);
              }}
            >
              <i className="icon-close-image"></i>
            </button>
          )}
        </div>
        <div className="comman-modal-body scroll-bar-style">
          {(floorListForVideo.length > 0 || floorListForRemoteVal.length) >
            0 && (
            <form className="">
              <div className="checkbox-listwrap">
                {floorListForRemoteVal && floorListForRemoteVal.length > 0 && (
                  <>
                    <div className="checklist-title">
                      <div className="">
                        RemoteVal ({t("WEB_LABELS.Corner_Detection_Technique")})
                      </div>
                      <div className="check-btn">
                        <label>
                          <input
                            type="checkbox"
                            name="remotevalCheckbox"
                            checked={remotevalCheckbox}
                            onClick={(e) => {
                              selectAllRemoteVal(e);
                            }}
                          />
                          <span></span>
                        </label>
                      </div>
                    </div>
                    {floorListForRemoteVal.map((floor, index) => (
                      <div key={index} className="checkbox-list">
                        <div className="checkbox-list-item">
                          <div className="form-group">
                            <div className="check-btn">
                              <label>
                                <input
                                  type="checkbox"
                                  id={floor.floorId}
                                  name={floor.floorId}
                                  checked={floor.checked || false}
                                  key={index}
                                  onClick={(e) => {
                                    selectCurrentFloorRemoteVal(floor, e);
                                  }}
                                />
                                <span>{floor.floorName}</span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
                {floorListForVideo.length > 0 && (
                  <div className="checklist-title">
                    <div className="">
                      RemoteVal {t("WEB_LABELS.Video")} (
                      {t("WEB_LABELS.Video_Based_Technique")})
                    </div>
                    <div className="check-btn">
                      <label>
                        <input
                          type="checkbox"
                          name="remotevalVideoCheckbox"
                          checked={remotevalVideoCheckbox}
                          onClick={(e) => {
                            selectAllRemoteValVideo(e);
                          }}
                        />
                        <span></span>
                      </label>
                    </div>
                  </div>
                )}
                {floorListForVideo.length > 0 &&
                  floorListForVideo.map((floor, i) => (
                    <div key={i} className="checkbox-list">
                      <div className="checkbox-list-item">
                        <div className="form-group">
                          <div className="check-btn">
                            <label>
                              <input
                                key={i}
                                type="checkbox"
                                onClick={(e) => selectAllFloorTags(floor, e)}
                                id={floor.floorScanId}
                                name={floor.floorScanId}
                                checked={floor.checked || false}
                              />
                              <span>
                                <b>
                                  {
                                    floorName.filter(
                                      (val) => val.id === floor.floorIndexList
                                    )[0].value
                                  }
                                </b>
                              </span>
                            </label>
                          </div>
                        </div>
                      </div>
                      {floor.floorTagNameList &&
                        floor.floorTagNameList.length > 0 &&
                        floor.floorTagNameList.map((floorTag, index) => (
                          <div className="checkbox-list-item child-items">
                            <div className="form-group">
                              <div className="check-btn">
                                <label>
                                  <input
                                    key={index}
                                    type="checkbox"
                                    onClick={(e) => {
                                      selectCurrentFloorTag(floor, index, e);
                                    }}
                                    id={floorTag.value + " " + index}
                                    name={floorTag.value + " " + index}
                                    checked={floorTag.checked || false}
                                  />
                                  <span>{floorTag.value}</span>
                                </label>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ))}

                <div className="button-group text-center">
                  <button
                    disabled={
                      (selectedFloorIdList3D.length > 0 ||
                        selectedFloorIdList2D.length > 0) &&
                      !props.isDownloadReport
                        ? false
                        : true
                    }
                    className="blue-btn"
                    type="button"
                    onClick={() => {
                      downloadReport();
                    }}
                  >
                    {t("BUTTONS.Download_Report")}
                    {props.isDownloadReport && (
                      <div className="loader-spin"></div>
                    )}
                  </button>
                  {authenticationService.getUserRole() == ROLE.TECHNICIAN &&
                    props.jobOrderSource &&
                    props.jobOrderSource.trim().toLowerCase() == "sdk" && (
                      <button
                        disabled={
                          (selectedFloorIdList3D.length > 0 ||
                            selectedFloorIdList2D.length > 0) &&
                          !props.isSendReport
                            ? false
                            : true
                        }
                        className="blue-btn download-and-send-btn"
                        type="button"
                        onClick={() => {
                          downloadReport("SEND_EMAIL");
                        }}
                      >
                        Send Report to Home Owner
                        {props.isSendReport && (
                          <div className="loader-spin"></div>
                        )}
                      </button>
                    )}
                </div>
                {authenticationService.getUserRole() === "APPRAISER" && (
                  <div style={{ padding: "15px", color: "red" }}>
                    <span>
                      <b>{t("COMMON_MESSAGES.Note")}</b>{" "}
                      {t("Download_Reports_Cover_Photo_Note")}
                    </span>
                  </div>
                )}
              </div>
            </form>
          )}
          {floorListForVideo.length === 0 &&
            floorListForRemoteVal.length === 0 && (
              <div className="no-data-found">
                <div className="box">
                  <i className="icon-download-report"></i>
                  <p>No Reports Available</p>
                </div>
              </div>
            )}
        </div>
      </div>
    </div>
  );
};
export default DownloadReportModal;
