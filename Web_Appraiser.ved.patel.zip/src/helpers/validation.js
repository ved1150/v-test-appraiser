import { isValidPhoneNumber } from "libphonenumber-js";
import i18n from "i18next";
import sessionStorage from "../services/sessionStorage";
import localStorage from "./../services/storage";
import { storageTypes } from "../constants/appConstant";
import authenticationService from "../services/authenticationService";

export function isEmailValid(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function parseNullItem(data) {
  data = { ...data };
  Object.keys(data).map((key) => {
    if (data[key] === null || data[key] === "null") {
      delete data[key];
    }
    return null;
  });
  return data;
}

export function isPhoneValid(phone) {
  return /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{3,6}$/im.test(
    phone
  );
}

export function isURLValid(url) {
  return /[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/gi.test(
    url
  );
}

export function validateRequired(text) {
  if (!isNaN(text)) {
    text = text.toString();
  }
  if (text.trim() === "") {
    return i18n.t("ERROR_MESSAGES.This_field_is_required");
  }
  return false;
}

export function validatePhoneWithRequired(text) {
  if (text != undefined) {
    if (text.trim() === "") {
      return i18n.t("ERROR_MESSAGES.PHONE_NO_IS_REQUIRED");
    } else {
      if (!isValidPhoneNumber(text, "US")) {
        return i18n.t("ERROR_MESSAGES.PHONE_NO_IS_INVALID");
      }
    }
  } else {
    return i18n.t("ERROR_MESSAGES.PHONE_NO_IS_REQUIRED");
  }
  return false;
}

export function validateNameWithRequired(text) {
  if (text != undefined) {
    let pattern = /^[A-Za-z\s]+$/;
    if (text.trim() === "") {
      return i18n.t("ERROR_MESSAGES.Please_enter_your_name");
    } else if (!pattern.test(text)) {
      return i18n.t("ERROR_MESSAGES.Please_enter_valid_name");
    }
  } else {
    return i18n.t("ERROR_MESSAGES.Please_enter_your_name");
  }
  return false;
}

export function validateTextWithRequired(text) {
  if (text != undefined) {
    let pattern = /^[A-Za-z\s]+$/;
    if (text.trim() === "") {
      return i18n.t("ERROR_MESSAGES.This_field_is_required");
    } else if (!pattern.test(text)) {
      return i18n.t("ERROR_MESSAGES.Invalid_Text");
    }
  } else {
    return i18n.t("ERROR_MESSAGES.This_field_is_required");
  }
  return false;
}

export function validateEmailWithRequired(text) {
  if (text != undefined) {
    if (text.trim() === "") {
      return i18n.t("ERROR_MESSAGES.EMAIL_IS_REQUIRED");
    } else {
      if (!isEmailValid(text)) {
        return i18n.t("ERROR_MESSAGES.EMAIL_IS_INVALID");
      }
    }
  }
  return false;
}

export function validateInvitationTypeTab(obj) {
  if (!(obj.sms || obj.email)) {
    return i18n.t("ERROR_MESSAGES.Select_atleast_one_checkbox");
  }
  return false;
}

export function redirectToUnAuthPage(history, canRedirect = true) {
  if (authenticationService.getStorageType() == storageTypes.sessionStorage) {
    sessionStorage.clearAll();
  } else {
    localStorage.clearAll();
    sessionStorage.clearAll();
  }
  if (canRedirect) {
    if (history) {
      let path =
        history.location.pathname === "/"
          ? "/sign-in"
          : `/sign-in?redirect=${history.location.pathname}`;
      history.push(path);
    } else {
      window.location = "/sign-in";
    }
  }
}
function parseJwt(token) {
  let base64Url = token.split(".")[1];
  let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  let jsonPayload = decodeURIComponent(
    atob(base64)
      .split("")
      .map(function (c) {
        return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
      })
      .join("")
  );
  return JSON.parse(jsonPayload);
}

export function isTokenExpired() {
  try {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const type = urlParams.get("type");
    let token = null;
    if (
      sessionStorage.get("storageType") == storageTypes.sessionStorage ||
      type == storageTypes.sessionStorage
    ) {
      token = sessionStorage.get("token");
    } else {
      token = localStorage.get("token");
    }
    const { exp } = parseJwt(token);
    return Math.floor(new Date().getTime() / 1000) >= exp;
  } catch (error) {
    return false;
  }
}
