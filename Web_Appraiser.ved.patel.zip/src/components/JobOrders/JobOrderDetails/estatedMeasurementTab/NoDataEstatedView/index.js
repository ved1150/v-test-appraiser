import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
const NoDataEstatedView = (props) => {
  const { t } = useTranslation();
  const [message, setMessage] = useState();
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    if (props.estatedStatus.isAPICalled && !props.estatedStatus.estatedData) {
      setIsLoading(true);
      props
        .fetchEstatedData(props.jobOrderId)
        .then((res) => {
          setIsLoading(false);
          if (res?.data?.data?.status == "JOB_ORDER_ESTATED_PROCESS_SUCCESS") {
            setMessage("WEB_LABELS.Estated_Data_Is_Requested");
          }
        })
        .catch(() => {
          setIsLoading(false);
          setMessage("Job Order processing failed with Estated");
        });
    } else if (props.estatedStatus.isAPICalled) {
      setMessage("WEB_LABELS.Relar_Could_Not_Locate_This_Address");
    }
  }, [props.estatedStatus]);
  return (
    <div className="no-data-found">
      <div className="box">
        {isLoading ? (
          <div className="loader-spin"></div>
        ) : (
          <div>
            <i className="icon-Measurement-Details"></i>
            <p>{t(message)}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NoDataEstatedView;
