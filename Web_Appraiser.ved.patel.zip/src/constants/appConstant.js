export const APPOINTMENT_STATUS = {
  NEW_APPOINTMENT: { key: "NEW_APPOINTMENT", value: "Request Sent" },
  CONFIRMED_BY_PO: { key: "CONFIRMED_BY_PO", value: "Booked" },
  RESCHEDULED: { key: "RESCHEDULED", value: "Rescheduled and Confirmed" },
  CANCELLED: { key: "CANCELLED", value: "Cancelled" },
  CALL_COMPLETED: { key: "CALL_COMPLETED", value: "Call Completed" },
  SESSSION_STARTED: { key: "SESSSION_STARTED", value: "Session Started" },
};

export const CALL_RECORDING = "CALL_RECORDING";

export const scheduleAppointmentStatus = [
  APPOINTMENT_STATUS.CANCELLED.key,
  APPOINTMENT_STATUS.CALL_COMPLETED.key,
];
export const reScheduleAppointmentStatus = [
  APPOINTMENT_STATUS.NEW_APPOINTMENT.key,
  APPOINTMENT_STATUS.CONFIRMED_BY_PO.key,
  APPOINTMENT_STATUS.RESCHEDULED.key,
];

export const callTypes = {
  QUICK_CALL: "QUICK_CALL",
  SCHEDULE_CALL: "SCHEDULE_CALL",
};

export const TIME_SHORT_FORMAT = "hh:mm A";
export const DATE_TIME_API_FORMAT = "YYYY-MM-DDTHH:mm:ss.SSSS";

export const storageTypes = {
  sessionStorage: 1,
};

export const loginType = {
  valueConnect: 1,
  Appraiser: 2,
};

export const jobOrdersPerPage = [
  { displayName: "10", value: 10 },
  { displayName: "20", value: 20 },
  { displayName: "50", value: 50 },
  { displayName: "100", value: 100 },
];

export const relarPerPage = [
  { displayName: "10", value: 10 },
  { displayName: "20", value: 20 },
  { displayName: "50", value: 50 },
  { displayName: "100", value: 100 },
];

export const DATE_FORMAT = "MM/DD/YYYY hh:mm A";

export const SLOT_STATUSES = {
  BOOKED: "BOOKED",
  AVAILABLE: "AVAILABLE",
  CANCELLED: "CANCELLED",
  RESCHEDULED: "RESCHEDULED",
};

export const ROLE = {
  APPRAISER: "APPRAISER",
  TECHNICIAN: "TECHNICIAN",
  SWITCH_MULTITENANT_APPRAISER: "SWITCH_MULTITENANT_APPRAISER",
  SWITCH_MULTITENANT_TECHNICIAN: "SWITCH_MULTITENANT_TECHNICIAN",
};

export const measurementTypes = [
  { id: "1", name: "RemoteVal" },
  { id: "2", name: "Eagleview" },
  { id: "3", name: "Estated" },
  { id: "4", name: "REMOTEVAL_VIDEO" },
];

export const measurementResponseFormat = {
  original: 1,
  converted: 2,
};

export const STATUS = {
  COMPLETED: "COMPLETED",
  FLOORPLAN_FAILED: "FLOORPLAN_FAILED",
  STATUS_OVERRIDE_PREVENTED: "STATUS_OVERRIDE_PREVENTED",
  STATUS_TAG_ALREADY_EXIST: "STATUS_TAG_ALREADY_EXIST",
  STATUS_MEASUREMENT_JSON_ADDED: "STATUS_MEASUREMENT_JSON_ADDED",
};
export const screenModeTypes = {
  minimize: 0,
  maximize: 1,
};
export const SHAPE_TYPE = {
  PENCIL_DRAW: "1",
  RECTANGLE: "2",
  TEXTDRAW: "3",
  CIRCLE: "4",
  ARROW: "6",
  LINE: "5",
  TEXT: "7",
};
export const MARKUP_VIEW = {
  PENCIL_STROKE_WIDTH: 8,
  HIGHLIGHT_STROKE_WIDTH: 22,
};
export const SHAPE_STATUS = {
  DRAW: "1",
  MOVE: "2",
  UNDO: "3",
  REDO: "4",
};
export const ANNOTATION_ACK = {
  REQUEST_FOR_IMAGE_CAPTURE: "0",
  UPLOADING: "1",
  UPLOADED: "2",
  DOWNLOADING: "3",
  STARTED: "4",
  STOPPED: "5",
  CLEAR: "6",
  MANUALLY_CANCEL: "7",
  SERVERERROR: "8",
};
export const VSI_JO_TYPE = ["vsi", "virtual_appraisal", "virtual appraisal"];
export const AREA_TYPES = ["Exterior", "Interior"];
export const CHAR_LIMIT = 256;
export const SHORT_NAME_CHAR_LIMIT = 20;
export const threeDFloorScan = {
  msgForSameFloorPublish:
    "Floor plan with same name already exists. Are you sure you want to override the floor plan with this?",
  msgForFloorplanPrevented:
    "Floor plan with same name already exists in this job order.Please use diffrent name.",
  msgForBack: "Your changes will be lost. Are you sure want to go back?",
  msgForPreview:
    "Are you sure want to exit measurement and switch to Explore mode?",
  msgForPublish: "Are you sure you want to publish Floor scan?",
  Complete_Door_Selection: "Please complete door selection.",
  Please_Complete_Window_Selection: "Please complete window selection.",
  Finish_The_Ongoing_Process_Before_Undo:
    "Please finish the ongoing process before Undo!",
  Add_Door_Window_On_Same_Wall:
    "The door/window remains on the single wall only. Please finish the door/wall where it started.",
  Add_Partition_Door_In_Same_Room: "Door must be added in the same room.",
  Add_Partition_Door_In_Different_Partition:
    "Door cannot be added on the same partition.",
  Oops_Some_Error_Occured_Please_Try_Again:
    "Oops! Some error occured. Please try again.",
  Please_Connect_Room_And_Try_To_Add_Door:
    "Please connect room and try to add Door.",
  Please_Add_At_Least_One_Room: "Please add at least one room.",
  Please_Connect_Room_And_Try_To_Add_Window:
    "Please connect room and try to add Window.",
  Please_Wait: "Please Wait...",
  Please_complete_the_partition_first_before_moving_ahead:
    "Please complete the partition first before moving ahead!",
  Please_Connect_Room_And_Try_To_Add_Label:
    "Please connect room and try to add Label.",
  Please_Connect_Room_And_Try_To_Add_Partition:
    "Please connect room and try to add Partition.",
  partition_cannot_be_extended_outside_of_the_room:
    "Oops! The partition cannot be extended outside of the room",
  Please_try_to_edit_the_partition_inside_the_room_area_only:
    "Please try to edit the partition inside the room area only.",
  please_try_to_drag_label_inside_room_area:
    "Oops! please try to drag label inside room area.",
  Please_Connect_Room_And_Try_To_Hide_PLY:
    "Please connect room and try to hide PLY.",
  Please_Connect_Room_And_Try_To_Select_Item:
    "Please connect room and try to select item.",
  Please_Select_Area_Type: "Please Select Area Type.",
  door_override: "You can not add a door on an existing door/window.",
  window_override: "You can not add a window on an existing door/window.",
  add_staircase: "Oops! please try to add staircase inside room area.",
};
export const TempX_TenantKey = "catalog_master";
export const appname = "RemoteVal";
export const STATUS_TENANT_NOT_FOUND = "STATUS_TENANT_NOT_FOUND";
export const Area_Type_Tooltip =
  "Based on your selection of whether you have created a floor plan as Interior or Exterior, the platform will use this data for further steps. If the floor plan is Exterior, the detailed area calculation, measurements, and preview will look accordingly in the Inspection report.";
