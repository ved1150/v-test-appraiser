import {
  START_LOAD_ATTACHMENTS,
  LOAD_ATTACHMENTS_SUCCESS,
  LOAD_ATTACHMENTS_ERROR,
  START_UPLOAD_ATTACHMENT,
  UPLOAD_ATTACHMENT_SUCCESS,
  UPLOAD_ATTACHMENT_ERROR,
  START_DELETE_ATTACHMENT,
  DELETE_ATTACHMENT_SUCCESS,
  DELETE_ATTACHMENT_ERROR,
  START_DOWNLOAD_ATTACHMENTS,
  DOWNLOAD_ATTACHMENTS_SUCCESS,
  DOWNLOAD_ATTACHMENTS_ERROR,
  START_DOWNLOAD_ATTACHMENT,
  DOWNLOAD_ATTACHMENT_SUCCESS,
  DOWNLOAD_ATTACHMENT_ERROR,
} from "./actionTypes";
import attachmentService from "./../services/attachmentService";
import { StartLoading, StopLoading } from "./UIAction";
export const startLoadAttachments = () => {
  return {
    type: START_LOAD_ATTACHMENTS,
  };
};

export const loadAttachmentsSuccess = (payload) => {
  return {
    type: LOAD_ATTACHMENTS_SUCCESS,
    payload,
  };
};

export const loadAttachmentsError = (payload) => {
  return {
    type: LOAD_ATTACHMENTS_ERROR,
    payload,
  };
};

export function loadAttachments(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startLoadAttachments());
    return attachmentService
      .getAttachmentsByJobOrderId(data)
      .then(function (data) {
        dispatch(StopLoading());
        dispatch(loadAttachmentsSuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(loadAttachmentsError(err));
      });
  };
}

export const startUploadAttachment = () => {
  return {
    type: START_UPLOAD_ATTACHMENT,
  };
};

export const uploadAttachmentSuccess = (payload) => {
  return {
    type: UPLOAD_ATTACHMENT_SUCCESS,
    payload,
  };
};

export const uploadAttachmentError = (payload) => {
  return {
    type: UPLOAD_ATTACHMENT_ERROR,
    payload,
  };
};

export function uploadAttachment(file, fileName, extraPayload) {
  return (dispatch) => {
    dispatch(startUploadAttachment());
    return attachmentService
      .addAttachment(file, fileName, extraPayload)
      .then(function (data) {
        return dispatch(uploadAttachmentSuccess(data));
      })
      .catch((err) => {
        return dispatch(uploadAttachmentError(err));
      });
  };
}

export const startDeleteAttachment = () => {
  return {
    type: START_DELETE_ATTACHMENT,
  };
};

export const deleteAttachmentSuccess = (payload) => {
  return {
    type: DELETE_ATTACHMENT_SUCCESS,
    payload,
  };
};

export const deleteAttachmentError = (payload) => {
  return {
    type: DELETE_ATTACHMENT_ERROR,
    payload,
  };
};

export function deleteAttachment(attachmentId) {
  return (dispatch) => {
    dispatch(startDeleteAttachment());
    return attachmentService
      .deleteAttachment(attachmentId)
      .then(function (data) {
        return dispatch(deleteAttachmentSuccess(data));
      })
      .catch((err) => {
        return dispatch(deleteAttachmentError(err));
      });
  };
}

export const startDownloadAttachments = () => {
  return {
    type: START_DOWNLOAD_ATTACHMENTS,
  };
};

export const downloadAttachmentsSuccess = (payload) => {
  return {
    type: DOWNLOAD_ATTACHMENTS_SUCCESS,
    payload,
  };
};

export const downloadAttachmentsError = (payload) => {
  return {
    type: DOWNLOAD_ATTACHMENTS_ERROR,
    payload,
  };
};

export function downloadAttachments(payload) {
  return (dispatch) => {
    dispatch(startDownloadAttachments());
    return attachmentService
      .downloadAttachments(payload)
      .then((data) => {
        dispatch(downloadAttachmentsSuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(downloadAttachmentsError(err));
        return {};
      });
  };
}

export const startDownloadAttachment = () => {
  return {
    type: START_DOWNLOAD_ATTACHMENT,
  };
};

export const downloadAttachmentSuccess = (payload) => {
  return {
    type: DOWNLOAD_ATTACHMENT_SUCCESS,
    payload,
  };
};

export const downloadAttachmentError = (payload) => {
  return {
    type: DOWNLOAD_ATTACHMENT_ERROR,
    payload,
  };
};

export function downloadAttachment(attachmentId) {
  return (dispatch) => {
    dispatch(startDownloadAttachment());
    return attachmentService
      .downloadAttachment(attachmentId)
      .then((data) => {
        dispatch(downloadAttachmentSuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(downloadAttachmentError(err));
        return {};
      });
  };
}
