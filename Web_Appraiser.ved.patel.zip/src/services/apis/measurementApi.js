import { measurementTypes } from "../../constants/appConstant";
import api from "./api";

export default class MeasurementAPI {
  get(payload) {
    let floorScanId = "";
    if (payload.floorScanId) {
      floorScanId = payload.floorScanId;
    }
    const url =
      payload.type === measurementTypes[3].name
        ? `measurementjson/${payload.type}/${payload.format}/${payload.jobOrderId}?floorScan=${floorScanId}&floorTagName=${payload.floorTagName}`
        : `measurementjson/${payload.type}/${payload.format}/${payload.jobOrderId}`;

    return api.get(url).then((res) => {
      return res.data.data;
    });
  }

  getAvailableMeasurementData(payload) {
    return api
      .get(`available-measurement-data/${payload.jobOrderId}`)
      .then((res) => {
        return res.data.data;
      });
  }

  getFloorScanIndex(payload) {
    return api.get(`floorscan/index/${payload.jobOrderId}`).then((res) => {
      return res.data.data;
    });
  }
  getFloorScanJsons(data) {
    return api.post(`getReportData`, data);
  }
  save(data) {
    return api.post(`measurementjson`, data);
  }

  create(data) {
    return api.post("measurement/create", data);
  }
  getDownloadReportMeasurementJson(jobOrderId) {
    return api.get(`floorscan/floor-list/${jobOrderId}`);
  }
  downloadPDFFromHTML(body) {
    return api.downloadPdfPost(`convert-to-pdf`, body);
  }
  fetchEstatedData(data) {
    return api.get(`/joborders/${data}/process/estated`);
  }
  sendReportTOHomeOwner(jobOrderId, htmlContent) {
    return api.post(
      `joborder/send-property-inspection-report-po/${jobOrderId}`,
      htmlContent
    );
  }
}
