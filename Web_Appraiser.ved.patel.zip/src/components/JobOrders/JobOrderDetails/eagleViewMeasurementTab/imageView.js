import React, { useState, useEffect } from "react";
import "./index.scss";
import eagleViewService from "../../../../services/eagleViewService";
import _ from "lodash";

const ImageView = (props) => {
  const [eagleViewImages, setEagleViewImages] = useState(props.eagleViewImages);

  return (
    <div className="measurement-items">
      {_.size(eagleViewImages) &&
        eagleViewImages.map((img, id) => (
          <div key={id} className="measurement-image">
            <img src={img.filePath} alt="" />
          </div>
        ))}
    </div>
  );
};

export default ImageView;
