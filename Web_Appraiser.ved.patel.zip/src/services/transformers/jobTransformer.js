import _ from "lodash";
import moment from "moment";
import { DATE_FORMAT } from "../../constants/appConstant";
import { hydratePagination } from "./paginationTransformer";
export function dehydrateJobOrders(params) {
  return {
    user_id: params.userId,
  };
}

export function hydrateJobOrder(order) {
  const originalDate = order.inspectionDate;
  const targetFormat = "YYYY-MM-DD HH:mm:ss";
  const convertedDate = moment(originalDate, "MM/DD/YYYY hh:mmA z")
    .utc()
    .format(targetFormat);

  return {
    id: order.id,
    orderNo: order.orderNumber || "--",
    assignee: order.assignee,
    autoSnapshot: order.autoSnapshot,
    propertyType: order.propertyType,
    assignDate: moment(order.assignDate).isValid()
      ? moment.utc(order.assignDate).local().format(DATE_FORMAT)
      : "--",
    inspectionDate: moment(convertedDate).isValid()
      ? moment.utc(convertedDate).local().format(DATE_FORMAT)
      : "--",
    jobStatus: order.jobStatus,
    appointmentStatus: order.appointmentStatus,
    jobOrderAppointment: order.jobOrderAppointment,
    quickCallUrl: order.quickCallUrl,
    name: order.name,
    phone: order.phone,
    email: order.email,
    address1: order.address1,
    address2: order.address2,
    callStartDate: order.callStartDate,
    formatedCallStartDate: moment(order.callStartDate).isValid()
      ? moment.utc(order.callStartDate).local().format(DATE_FORMAT)
      : "--",
    city: order.city,
    state: order.state,
    country: order.country,
    address: `${order.address1}${
      !_.isEmpty(order.address2) ? `, ${order.address2}` : ""
    }, ${order.city}, ${order.state}, ${order.country}`,
    isSelfCreated: order.isSelfCreated,
    jobOrderSource: order.jobOrderSource,
    jobOrderType: order.jobOrderType,
    isPaymentDone: { Paid: true, "Not Paid": false, "Third Party Free": true }[
      order.paymentStatus
    ],
    isCardAdded: order.isCardAdded,
    isDemoJobOrder: order.isDemoJobOrder,
    jobOrderTypePriceValue: order.jobOrderTypePriceValue,
  };
}

export const hydrateJobOrders = (data) => {
  const list = _.get(data, "list", []);
  return {
    data: list.map((d) => hydrateJobOrder(d)),
    pagination: hydratePagination(_.get(data, ["page"], {})),
  };
};

export const dyHydrateJobOrders = (data) => {
  return {
    page: data.pageNo - 1,
    size: data.pageSize,
    searchText: data.searchText,
  };
};

export const deHydrateScheduleAppoinment = (data) => {
  return {
    address: data.address,
    appraiserAvailability: data.appraiserAvailability,
    appraiserId: data.appraiserId,
    emailId: data.emailId,
    jobOrderId: data.jobOrderId,
    message: data.message,
    phoneNumber: data.phoneNumber,
    propertyOwnerName: data.propertyOwnerName,
    isRecording: data.isRecording ? 1 : 0,
    appointmentStatus: data.appointmentStatus,
    reason: data.reason,
  };
};

const hydrateAppointmentSlot = (data) => {
  return {
    appraiserId: data.appraiserId,
    appraisersSlotId: data.appraisersSlotId,
    slotDate: data.slotDate,
    slotDateEndTime: data.slotDateEndTime,
    slotDateStartTime: data.slotDateStartTime,
    slotStatus: data.slotStatus,
    startTime: moment.utc(data.slotDateStartTime).local().format("hh:mm A"),
    endTime: moment.utc(data.slotDateEndTime).local().format("hh:mm A"),
  };
};

export const hydrateAppointmentSlots = (data) =>
  data.data.data.map((d) => hydrateAppointmentSlot(d));

export const deHydrateAutoSnapData = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    autoSnapshot: data.checked,
  };
};
