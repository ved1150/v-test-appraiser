//React & Redux
import React from "react";
import Measurement from "./index.js";
import _ from "lodash";
import { MEASUREMENTS_ICON } from "../Common/commonText.js";
import { withTranslation } from "react-i18next";
class MesurementContainer extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {}

  render() {
    const { t } = this.props;
    let isMajourmentData = true;
    if (
      this.props.mesurementData.jsonData &&
      this.props.mesurementData.jsonData.EAGLEVIEW_EXPORT.STRUCTURES != null
    ) {
      var roofPoints = [
        this.props.mesurementData.jsonData.EAGLEVIEW_EXPORT.STRUCTURES.ROOF
          .POINTS.POINT,
      ];
      if (!roofPoints[0][0] || !roofPoints[0][0]["@autoSnappedXY"]) {
        isMajourmentData = false;
      }
    }
    return (
      <>
        {/* {_.isEmpty(this.props.mesurementData.jsonData) || !isMajourmentData ? (
          <div className="no-data-found-container">
            <div className="no-data-found">
              <div className="box">
                <i className={MEASUREMENTS_ICON}></i>
                <p>{t("WEB_LABELS.There_Are_No_Measurements_Recorded")}</p>
              </div>
            </div>
          </div>
        ) : ( */}
        <Measurement {...this.props} />
        {/* )} */}
      </>
    );
  }
}

export default withTranslation()(MesurementContainer);
