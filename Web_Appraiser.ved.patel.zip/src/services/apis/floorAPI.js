import api from "./api";
export default class FloorAPI {
  getFloor(data) {
    return api.get(
      `/floorscan/details/${data.floorScanId}
      `
    );
  }
  getFloorContent(data) {
    return api.get(`${data.path}`);
  }

  publishJsonData(data) {
    const result = api.put("/floorscan/publish", data);
    return result;
  }
  autoSaveThreeDJson(data) {
    return api.put("/floorscan/auto-save", data);
  }
}
