import React, { Component } from "react";

import { fabric } from "fabric";
import "fabric-history";
import * as THREE from "three";
import _ from "lodash";

const STATE_IDLE = "idle";
const STATE_PANNING = "panning";

export default class MeasurementTab extends Component {
  canvas = null;
  maxX = 0;
  maxY = 0;
  minX = null;
  minY = null;
  canvasWidth = window.innerHeight - 400;
  canvasHeight = window.innerWidth - 400;

  constructor(props) {
    super();

    this.state = {};
  }
  async componentDidMount() {
    let canvas;

    this.canvasHeight = document.querySelector(
      "div.open.tab-content"
    ).clientHeight;

    this.canvasWidth = document.querySelector(
      "div.open.tab-content"
    ).clientWidth;

    canvas = new fabric.Canvas("measurementcanvas", {
      height: this.canvasHeight,
      width: this.canvasWidth,
      selection: false,
    });

    fabric.Canvas.prototype.toggleDragMode = function (dragMode) {
      // Remember the previous X and Y coordinates for delta calculations
      let lastClientX;
      let lastClientY;
      // Keep track of the state
      let state = STATE_IDLE;
      // We're entering dragmode
      if (dragMode) {
        // Discard any active object
        this.discardActiveObject();
        // Set the cursor to 'move'
        this.defaultCursor = "move";
        // Loop over all objects and disable events / selectable. We remember its value in a temp variable stored on each object
        this.forEachObject(function (object) {
          object.prevEvented = object.evented;
          object.prevSelectable = object.selectable;
          object.evented = false;
          object.selectable = false;
        });
        // Remove selection ability on the canvas
        this.selection = false;
        // When MouseUp fires, we set the state to idle
        this.on("mouse:up", function (e) {
          state = STATE_IDLE;
        });
        // When MouseDown fires, we set the state to panning
        this.on("mouse:down", (e) => {
          state = STATE_PANNING;
          lastClientX = e.e.clientX;
          lastClientY = e.e.clientY;
        });
        // When the mouse moves, and we're panning (mouse down), we continue
        this.on("mouse:move", (e) => {
          if (state === STATE_PANNING && e && e.e) {
            // let delta = new fabric.Point(e.e.movementX, e.e.movementY); // No Safari support for movementX and movementY
            // For cross-browser compatibility, I had to manually keep track of the delta

            // Calculate deltas
            let deltaX = 0;
            let deltaY = 0;
            if (lastClientX) {
              deltaX = e.e.clientX - lastClientX;
            }
            if (lastClientY) {
              deltaY = e.e.clientY - lastClientY;
            }
            // Update the last X and Y values
            lastClientX = e.e.clientX;
            lastClientY = e.e.clientY;

            let delta = new fabric.Point(deltaX, deltaY);
            this.relativePan(delta);
            //   this.trigger('moved');
          }
        });
      } else {
        // When we exit dragmode, we restore the previous values on all objects
        this.forEachObject(function (object) {
          object.evented =
            object.prevEvented !== undefined
              ? object.prevEvented
              : object.evented;
          object.selectable =
            object.prevSelectable !== undefined
              ? object.prevSelectable
              : object.selectable;
        });
        // Reset the cursor
        this.defaultCursor = "default";
        // Remove the event listeners
        this.off("mouse:up");
        this.off("mouse:down");
        this.off("mouse:move");
        // Restore selection ability on the canvas
        this.selection = true;
      }
    };

    this.canvas = canvas;

    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/eagleview_mobile_json.json", true);
    xhr.responseType = "json";
    xhr.send(null);
    xhr.onload = function (response) {
      console.log(response.target.response);

      console.log("response.target.response - ", response.target.response);

      this.showTheListFromJson(response.target.response);
    }.bind(this);

    // console.log("this.props.mesurementData.jsonData - ", this.props.mesurementData.jsonData);
    // console.log("this.props.mesurementData.jsonData - ",JSON.stringify(this.props.mesurementData.jsonData) );
    // if (_.isObject(this.props.mesurementData.jsonData)) {
    //   const newJson = _.cloneDeep(this.props.mesurementData.jsonData);
    //   this.showTheListFromJson(newJson);
    // }
  }

  async showTheListFromJson(json) {
    var pointarr = [];
    var pointarrThreeD = [];
    var paths = [];

    var jsonObject = json;

    var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    var roofPointsArray = roofPoints[0]["POINT"];

    var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    var linesArray = lines[0].LINE;

    var faceArray = roofObject[0]["FACES"]["FACE"];

    var designatorWiseObjectArray = {};

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let faceObject = faceArray[faceArrayIndex];

      if (designatorWiseObjectArray[faceObject["@designator"]] == null) {
        designatorWiseObjectArray[faceObject["@designator"]] = [];
      } else {
        //TBD
      }

      if (faceObject["POLYGON"]["@path"].trim().length > 0) {
        var lineId = faceObject["POLYGON"]["@path"];

        //Find Line
        for (
          let lineArrayIndex = 0;
          lineArrayIndex < linesArray.length;
          lineArrayIndex++
        ) {
          let lineObject = linesArray[lineArrayIndex];
          if (lineObject["@id"] == lineId) {
            var linePointObjectArray = [];
            var linePoints = lineObject["@path"].split(",");
            for (
              var linePointsIndex = 0;
              linePointsIndex < linePoints.length;
              linePointsIndex++
            ) {
              for (
                let roofPointsArrayIndex = 0;
                roofPointsArrayIndex < roofPointsArray.length;
                roofPointsArrayIndex++
              ) {
                let roofPointObject = roofPointsArray[roofPointsArrayIndex];
                if (roofPointObject["@id"] == linePoints[linePointsIndex]) {
                  if (roofPointObject["@dataXY"] == null) {
                    var data = roofPointObject["@data"].split(',');
                    roofPointObject["@dataXY"] = data[0] + ',' + data[1];
                  }
                  linePointObjectArray.push(roofPointObject);

                  break;
                }
              }
            }

            lineObject["linePointObjectArray"] = linePointObjectArray;
            linesArray[lineArrayIndex] = lineObject;

            faceObject["LINE"] = lineObject;
            faceArray[faceArrayIndex] = faceObject;
          }
        }
      }

      designatorWiseObjectArray[faceObject["@designator"]].push(faceObject);
    }

    // console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    this.canvas.viewportTransform[4] = 0;
    this.canvas.viewportTransform[5] = 0;

    this.canvas.isDrawingMode = false;
    this.canvas.freeDrawingBrush.width = 5;
    this.canvas.freeDrawingBrush.color = "red";

    var pointer = {
      x: 0,
      y: 0,
    };

    let options = { pointer, e: {} }; // required for Fabric 4.3.1

    this.canvas.freeDrawingBrush.onMouseDown(pointer, options);

    let roomArray = Object.keys(designatorWiseObjectArray);
    // console.log("roomArray 1 - ", roomArray);

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];
      // console.log("roomObject - ", roomObjectArray);

      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];
        // console.log("wallObject - ", wallObject);

        if (wallObject.LINE == null) {
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;

        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];
          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

          if (parseFloat(v1[0]) > this.maxX) {
            this.maxX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) > this.maxY) {
            this.maxY = parseFloat(v1[1]);
          }

          if (this.minX == null) {
            this.minX = this.maxX;
          }
          if (this.minY == null) {
            this.minY = this.maxY;
          }

          if (parseFloat(v1[0]) < this.minX) {
            this.minX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) < this.minY) {
            this.minY = parseFloat(v1[1]);
          }
        }
      }
    }

    this.canvasHeight = this.maxY - this.minY;
    this.canvasWidth = this.maxX - this.minX;

    this.canvas.setHeight(this.canvasHeight + 50);
    this.canvas.setWidth(this.canvasWidth + 50);

    let ratioX = 1;
    let ratioY = 1;

    let multiplierX = 1;
    if (this.maxX - this.minX > this.canvasWidth) {
      ratioX = (this.canvasWidth / (this.maxX - this.minX)) * multiplierX;
    } else {
      ratioX = ((this.maxX - this.minX) / this.canvasWidth) * multiplierX;
    }

    if (this.maxY - this.minY > this.canvasHeight) {
      ratioY =
        (this.canvasHeight / (this.maxY - this, this.minY)) * multiplierX;
    } else {
      ratioY = ((this.maxY - this.minY) / this.canvasHeight) * multiplierX;
    }

    //Now start drawing

    for (
      let roomArrayIndex = 0;
      roomArrayIndex < roomArray.length;
      roomArrayIndex++
    ) {
      var roomArea = "";
      let roomObjectArray =
        designatorWiseObjectArray[roomArray[roomArrayIndex]];

      var roomLinesGroup = [];
      var roomTextGroup = [];
      var wallNo = 0;
      for (
        let roomObjectArrayIndex = 0;
        roomObjectArrayIndex < roomObjectArray.length;
        roomObjectArrayIndex++
      ) {
        let wallObject = roomObjectArray[roomObjectArrayIndex];

        if (wallObject.LINE == null) {
          roomArea = wallObject["@area"];

          continue;
        }

        let isWallPenetration =
          wallObject["@type"] == "WALLPENETRATION" ? true : false;
        if (isWallPenetration == false) {
          wallNo++;
        } else {
          continue;
        }

        var linePointObjectArray = wallObject.LINE.linePointObjectArray;
        var poligonObject = wallObject.POLYGON;

        let points = [];
        for (
          let linePointObjectArrayInedex = 0;
          linePointObjectArrayInedex < linePointObjectArray.length;
          linePointObjectArrayInedex++
        ) {
          var value1 =
            linePointObjectArray[linePointObjectArrayInedex]["@dataXY"];
          if (value1 == null) {
            break;
          }
          var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
          var v1 = value1.split(",");
          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
          points.push(fval);
        }

        //Add line
        if (points.length < 2) {
          break;
        }

        var line = null;

        var color = isWallPenetration ? "#fe741f" : "black";

        line = new fabric.Line(
          [
            (points[0].x - this.minX) * ratioX,
            (points[0].y - this.minY) * ratioY,
            (points[1].x - this.minX) * ratioX,
            (points[1].y - this.minY) * ratioY,
          ],
          {
            stroke: color,
            strokeWidth: 2,
            selectable: false,
            evented: false,
          }
        );

        let textLeftPosition = line.get("x1");
        let textTopPosition = line.get("y1");
        let moveLeft = false;
        let moveTop = false;

        if (line.get("x1") == line.get("x2")) {
          textTopPosition = (line.get("y1") + line.get("y2")) / 2;

          moveTop = true;
          if (isWallPenetration) {
            textLeftPosition = line.get("x2") - 15;
          } else {
            if (wallNo == 2) {
              textLeftPosition = line.get("x2") - 5;
            } else {
              textLeftPosition = line.get("x2") + 15;
            }
          }
        } else if (line.get("y1") == line.get("y2")) {
          textLeftPosition = (line.get("x1") + line.get("x2")) / 2;

          moveLeft = true;

          if (isWallPenetration) {
            textTopPosition = line.get("y2") - 15;
          } else {
            if (wallNo == 3) {
              textTopPosition = line.get("y2") - 15;
            } else {
              textTopPosition = line.get("y2") + 5;
            }
          }
        }

        var unRoundedSize = parseFloat(poligonObject["@unroundedsize"]);
        var unRoundedSizeFeet =
          parseFloat(unRoundedSize * 3.28084).toFixed(2) + " ft";

        var text = new fabric.Text(unRoundedSizeFeet, {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: textLeftPosition,
          top: textTopPosition,
          angle: wallNo == 2 || wallNo == 4 ? 90 : 0,
          fill: color,
        });

        if (moveLeft) {
          text.set(
            "left",
            text.getBoundingRect().left - text.getBoundingRect().width / 2
          );
        } else if (moveTop) {
          text.set(
            "top",
            text.getBoundingRect().top - text.getBoundingRect().height / 2
          );
        }

        //this.canvas.add(line);
        roomTextGroup.push(text);
        roomLinesGroup.push(line);
      }

      var roomDrawingObjectArray = roomLinesGroup.concat(roomTextGroup);

      var group = new fabric.Group(roomDrawingObjectArray, {
        // left: 150,
        // top: 100,
        // angle: -10
      });

      var left = group.get("left") + group.get("width") / 2;
      var top = group.get("top") + group.get("height") / 2;

      var centreLabelTemp = new fabric.Text(roomArea, {
        fontFamily: "Delicious_500",
        fontSize: 10,
        left: left,
        top: top,
        fill: "blue",
      });

      left =
        centreLabelTemp.getBoundingRect().left -
        centreLabelTemp.getBoundingRect().width;

      var centreLabel = new fabric.Text(roomArea, {
        fontFamily: "Delicious_500",
        fontSize: 10,
        left: left,
        top: top,
        fill: "black",
      });

      group.addWithUpdate(centreLabel);

      this.canvas.add(group);
    }

    let canvasHeight = document.querySelector("div.open.tab-content")
      .clientHeight;

    let canvasWidth = document.querySelector("div.open.tab-content")
      .clientWidth;

    this.canvas.setHeight(canvasHeight);
    this.canvas.setWidth(canvasWidth);

    this.canvas.renderAll();

    // Ends drawing

    var printedAreaName = [];

    this.canvas.on(
      "object:moving",
      function (e) {
        var p = e.target;

        p.line1 && p.line1.set({ x2: p.left, y2: p.top });
        p.line2 && p.line2.set({ x1: p.left, y1: p.top });
        this.canvas.renderAll();
      }.bind(this)
    );

    this.canvas.on(
      "mouse:wheel",
      function (opt) {
        var delta = opt.e.deltaY;
        var zoom = this.canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        this.canvas.setZoom(zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }.bind(this)
    );

    // this.canvas.toggleDragMode(true);
  }

  async showTheListFromJsonLineWise(json) {
    var pointarr = [];
    var pointarrThreeD = [];
    var paths = [];

    var jsonObject = json;

    var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
    var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

    var roofPointsArray = roofPoints[0]["POINT"];

    var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
    var linesArray = lines[0].LINE;

    var faceArray = roofObject[0]["FACES"]["FACE"];

    var designatorWiseObjectArray = {};

    for (
      let faceArrayIndex = 0;
      faceArrayIndex < faceArray.length;
      faceArrayIndex++
    ) {
      let faceObject = faceArray[faceArrayIndex];

      if (designatorWiseObjectArray[faceObject["@designator"]] == null) {
        designatorWiseObjectArray[faceObject["@designator"]] = [];
      } else {
        //TBD
      }

      if (faceObject["POLYGON"]["@path"].trim().length > 0) {
        var lineId = faceObject["POLYGON"]["@path"];

        //Find Line
        for (
          let lineArrayIndex = 0;
          lineArrayIndex < linesArray.length;
          lineArrayIndex++
        ) {
          let lineObject = linesArray[lineArrayIndex];
          if (lineObject["@id"] == lineId) {
            var linePointObjectArray = [];
            var linePoints = lineObject["@path"].split(",");
            for (
              var linePointsIndex = 0;
              linePointsIndex < linePoints.length;
              linePointsIndex++
            ) {
              for (
                let roofPointsArrayIndex = 0;
                roofPointsArrayIndex < roofPointsArray.length;
                roofPointsArrayIndex++
              ) {
                let roofPointObject = roofPointsArray[roofPointsArrayIndex];
                if (roofPointObject["@id"] == linePoints[linePointsIndex]) {
                  if (roofPointObject["@dataXY"] == null) {
                    var data = roofPointObject["@data"].split(',');
                    roofPointObject["@dataXY"] = data[0] + ',' + data[1];
                  }
                  linePointObjectArray.push(roofPointObject);

                  break;
                }
              }
            }

            lineObject["linePointObjectArray"] = linePointObjectArray;
            linesArray[lineArrayIndex] = lineObject;

            faceObject["LINE"] = lineObject;
            faceArray[faceArrayIndex] = faceObject;
          }
        }
      }

      designatorWiseObjectArray[faceObject["@designator"]].push(faceObject);
    }

    console.log("designatorWiseObjectArray - ", designatorWiseObjectArray);

    var printedAreaName = [];

    for (var i = 0; i < 1; i++) {
      //for lines

      for (var j = 0; j < lines.length; j++) {
        var mline = lines[j].LINE;
        for (var k = 0; k < mline.length; k++) {
          /*
          
          TOPWALL
          BOTTOMWALL
          OUTSIDECORNER
          INSIDECORNER
          RIDGE
          OTHER
          */

          var ml1 = mline[k]["@path"];
          ml1 = ml1 + "," + mline[k]["@type"] + "," + mline[k]["@id"];
          paths.push(ml1);
        }
      }

      var lineArray = [];
      var labelArray = [];
      for (var j = 0; j < roofPoints.length; j++) {
        var line = roofPoints[j].POINT;

        for (var k = 0; k < line.length; k++) {
          //var value1 = line[k].getAttribute("data");
          //var id = line[k].getAttribute("id");

          if (line[k]["@dataXY"] == null) {
            line[k]["@dataXY"] = "0,0";
          }

          var value1 = line[k]["@dataXY"];
          var id = line[k]["@id"];
          var v1 = value1.split(",");

          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

          if (parseFloat(v1[0]) > this.maxX) {
            this.maxX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) > this.maxY) {
            this.maxY = parseFloat(v1[1]);
          }

          if (this.minX == null) {
            this.minX = this.maxX;
          }
          if (this.minY == null) {
            this.minY = this.maxY;
          }

          if (parseFloat(v1[0]) < this.minX) {
            this.minX = parseFloat(v1[0]);
          }

          if (parseFloat(v1[1]) < this.minY) {
            this.minY = parseFloat(v1[1]);
          }

          var valueThreeD = line[k]["@data"];
          var idThreeD = line[k]["@id"];
          var v1ThreeD = valueThreeD.split(",");

          var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

          var fvalThreeD = {
            id: idThreeD,
            x: v1ThreeD[0],
            y: v1ThreeD[1],
            z: v1ThreeD[2],
          };

          pointarr.push(fval);
          pointarrThreeD.push(fvalThreeD);
        }
      }

      // canvas draw

      this.canvasHeight = this.maxY - this.minY;
      this.canvasWidth = this.maxX - this.minX;

      this.canvas.setHeight(this.canvasHeight + 50);
      this.canvas.setWidth(this.canvasWidth + 50);

      let ratioX = 1;
      let ratioY = 1;

      let multiplierX = 1;
      if (this.maxX - this.minX > this.canvasWidth) {
        ratioX = (this.canvasWidth / (this.maxX - this.minX)) * multiplierX;
      } else {
        ratioX = ((this.maxX - this.minX) / this.canvasWidth) * multiplierX;
      }

      if (this.maxY - this.minY > this.canvasHeight) {
        ratioY =
          (this.canvasHeight / (this.maxY - this, this.minY)) * multiplierX;
      } else {
        ratioY = ((this.maxY - this.minY) / this.canvasHeight) * multiplierX;
      }

      let canvasPoint =
        this.canvasWidth > this.canvasHeight
          ? this.canvasWidth
          : this.canvasHeight;

      let ratio = 1;

      this.canvas.viewportTransform[4] = 0;
      this.canvas.viewportTransform[5] = 0;

      this.canvas.isDrawingMode = false;
      this.canvas.freeDrawingBrush.width = 5;
      this.canvas.freeDrawingBrush.color = "red";

      var pointer = {
        x: 0,
        y: 0,
      };

      let options = { pointer, e: {} }; // required for Fabric 4.3.1

      // this.canvas.freeDrawingBrush.onMouseDown(pointer, options);

      for (var i = 0; i < paths.length; i++) {
        // for (var i = 0; i < 2; i++) {
        const points = [];
        const pointsDistance = [];
        var mv1 = paths[i].split(",");

        /**/

        for (var m = 0; m < pointarr.length; m++) {
          if (pointarr[m].id == mv1[0]) {
            points.push(new THREE.Vector3(pointarr[m].x, pointarr[m].y, 0));

            pointsDistance.push(
              new THREE.Vector3(pointarr[m].x, pointarr[m].y, pointarr[m].z)
            );
            //pointsDistance.push(new THREE.Vector3(pointarrThreeD[m].x, pointarrThreeD[m].y, pointarrThreeD[m].z));

            // points.push(new THREE.Vector3(2, 4, 6));
          }
          if (pointarr[m].id == mv1[1]) {
            points.push(new THREE.Vector3(pointarr[m].x, pointarr[m].y, 0));
            pointsDistance.push(
              new THREE.Vector3(pointarr[m].x, pointarr[m].y, pointarr[m].z)
            );
            // points.push(new THREE.Vector3(8, 10, 12));

            //pointsDistance.push(new THREE.Vector3(pointarrThreeD[m].x, pointarrThreeD[m].y, pointarrThreeD[m].z));
          }
        }

        let lineId = mv1[3];

        let distanceObject = {};
        let isWallPenetration = false;
        let designator = "";

        for (var facesIndex = 0; facesIndex < faceArray.length; facesIndex++) {
          let faceObject = faceArray[facesIndex];
          if (faceObject["POLYGON"]["@path"] == lineId) {
            distanceObject["size"] = faceObject["POLYGON"]["@size"];
            distanceObject["unroundedsize"] =
              faceObject["POLYGON"]["@unroundedsize"];
            isWallPenetration =
              faceObject["@type"] == "WALLPENETRATION" ? true : false;
            designator = faceObject["@designator"];

            // break;
          }
        }

        var line = null;

        var color = isWallPenetration ? "#fe741f" : "black";

        line = new fabric.Line(
          [
            (points[0].x - this.minX) * ratioX,
            (points[0].y - this.minY) * ratioY,
            (points[1].x - this.minX) * ratioX,
            (points[1].y - this.minY) * ratioY,
          ],
          {
            stroke: color,
            strokeWidth: 2,
            selectable: false,
            evented: false,
          }
        );

        var distance = parseFloat(
          pointsDistance[0].distanceTo(pointsDistance[1])
        ).toFixed(2);

        // Render the rectanle in canvas
        this.canvas.add(line);
        lineArray.push(line);

        let textLeftPosition = line.get("x1");
        let textTopPosition = line.get("y1");
        let moveLeft = false;
        let moveTop = false;

        if (line.get("x1") == line.get("x2")) {
          textTopPosition = (line.get("y1") + line.get("y2")) / 2;

          moveTop = true;
          if (isWallPenetration) {
            textLeftPosition = line.get("x2") - 15;
          } else {
            textLeftPosition = line.get("x2") + 5;
          }
        } else if (line.get("y1") == line.get("y2")) {
          textLeftPosition = (line.get("x1") + line.get("x2")) / 2;
          moveLeft = true;

          if (isWallPenetration) {
            textTopPosition = line.get("y2") - 15;
          } else {
            textTopPosition = line.get("y2") + 5;
          }
        }

        if (distanceObject["unroundedsize"] == null) {
          break;
        }

        var text = new fabric.Text(distanceObject["unroundedsize"], {
          fontFamily: "Delicious_500",
          fontSize: 10,
          left: textLeftPosition,
          top: textTopPosition,
          fill: color,
        });

        labelArray.push(text);

        if (moveLeft) {
          text.set(
            "left",
            text.getBoundingRect().left - text.getBoundingRect().width / 2
          );
        } else if (moveTop) {
          text.set(
            "top",
            text.getBoundingRect().top - text.getBoundingRect().height / 2
          );
        }

        //text.setLeft(text.getBoundingRect().left - (text.getBoundingRect().width/2));

        this.canvas.add(text);

        this.canvas.renderAll();

        // Connectors

        if (i == 0) {
          var circle = this.makeCircle(
            line.get("x1"),
            line.get("y1"),
            null,
            line
          );
          // this.canvas.add(circle);
        } else {
          var circle = this.makeCircle(
            lineArray[i - 1].get("x2"),
            lineArray[i - 1].get("y2"),
            lineArray[i - 1],
            line
          );
          // this.canvas.add(circle);
        }

        //canvas2.freeDrawingBrush.onMouseMove(pointer, options);
      }

      let canvasHeight = document.querySelector("div.open.tab-content")
        .clientHeight;

      let canvasWidth = document.querySelector("div.open.tab-content")
        .clientWidth;

      this.canvas.setHeight(canvasHeight);
      this.canvas.setWidth(canvasWidth);
    }

    this.canvas.on(
      "object:moving",
      function (e) {
        var p = e.target;

        p.line1 && p.line1.set({ x2: p.left, y2: p.top });
        p.line2 && p.line2.set({ x1: p.left, y1: p.top });
        this.canvas.renderAll();
      }.bind(this)
    );

    this.canvas.on(
      "mouse:wheel",
      function (opt) {
        var delta = opt.e.deltaY;
        var zoom = this.canvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 20) zoom = 20;
        if (zoom < 0.01) zoom = 0.01;
        this.canvas.setZoom(zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }.bind(this)
    );

    this.canvas.toggleDragMode(true);
  }

  makeCircle(left, top, line1, line2) {
    var c = new fabric.Circle({
      left: left,
      top: top,
      strokeWidth: 5,
      radius: 3,
      fill: "#fff",
      stroke: "#666",
    });
    c.hasControls = c.hasBorders = false;

    c.line1 = line1;
    c.line2 = line2;

    return c;
  }

  render() {
    return (
      <div>
        <canvas id="measurementcanvas" />
      </div>
    );
  }
}
