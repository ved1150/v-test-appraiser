import api from "./apis/api";

class ManageCardService {
  getManageCardList(data) {
    return api.manageCards.getManageCardList(data);
  }

  deleteManageCard(data) {
    return api.manageCards.deleteManageCard(data);
  }

  setDefaultCard(data) {
    return api.manageCards.setDefaultCard(data);
  }

  getHostedProfilePageRequestToken(data) {
    return api.manageCards.getHostedProfilePageRequestToken(data);
  }
}

export default new ManageCardService();
