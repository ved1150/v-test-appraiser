import api from "./api";
import jobService from "../jobService";
import authenticationService from "../authenticationService";

export default class AppointmentSlotsApi {
  postAppointmentSlot = (data) => {
    const requestData = {
      ...data,
      appraiserId: authenticationService.getUserId(),
    };
    return api.post(`appointmentslots`, requestData);
  };
  getAppointmentSlot = (data) => {
    const { startDate, endDate } = data;
    return api.get(
      `appointmentslots?appraiserId=${authenticationService.getUserId()}&endDate=${endDate}&startDate=${startDate}`
    );
  };
}
