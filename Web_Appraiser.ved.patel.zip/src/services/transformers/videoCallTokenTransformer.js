import _ from "lodash";

export function dehydrateVideoCallURL(data) {
  return _.omitBy(
    {
      jobOrderId: data.jobOrderId,
      phone: data.phone,
      email: data.email,
      templateId: data.templateId,
      name: data.name,
      isRecording: data.isRecording ? 1 : 0,
    },
    _.isUndefined
  );
}
