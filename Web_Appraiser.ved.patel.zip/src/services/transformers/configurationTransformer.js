export function hydrateConfiguration(data) {
  return {
    id: data.id,
    type: data.type,
    value: data.value,
    isCallRecording:
      (data && data.value == "true") || data.value == true ? true : false,
  };
}
