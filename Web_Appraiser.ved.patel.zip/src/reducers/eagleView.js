import * as actionTypes from "../actions/actionTypes";

const createOrderState = {
  createOrderStart: false,
  createOrderSuccess: null,
  createOrderError: null,
};

const defaultStates = {
  ...createOrderState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.CREATE_ORDER_START:
      return {
        ...state,
        createOrderStart: true,
        createOrderSuccess: null,
        createOrderError: null,
      };
    case actionTypes.CREATE_ORDER_SUCCESS:
      return {
        ...state,
        createOrderStart: false,
        createOrderSuccess: action.payload,
        createOrderError: null,
      };
    case actionTypes.CREATE_ORDER_ERROR:
      return {
        ...state,
        createOrderStart: false,
        createOrderSuccess: null,
        createOrderError: action.payload,
      };
    default:
      return state;
  }
};
