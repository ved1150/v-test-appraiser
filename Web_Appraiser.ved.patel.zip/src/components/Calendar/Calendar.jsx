import React, { useState, useEffect } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import _ from "lodash";
import "./calendar.scss";
import AvailableSlotModal from "./AvailableSlotModal";
import appointmentSlotsService from "../../services/appointmentSlotsService";
import { modifyDate, convert24to12Hr } from "./helper";
import moment from "moment";
import ConfirmationModal from "./../common/confirmationModal";
import calendarService from "./../../services/calendarService";
import {
  APPOINMENT_SLOT_DELETE_MESSSAGE,
  UNEXPECTED_ERROR_MESSAGE,
  APPOINMENT_CANCEL_MESSSAGE,
} from "./../../constants/commonMessages";
import { customToast } from "./../../helpers/customToast";
import ConfirmationMsgModal from "./../common/confirmationMsgModal";
import classnames from "classnames";
import { isUTCDateInBetween } from "./../../helpers/commonJSFunction";
import Tooltip from "@mui/material/Tooltip";
import { connect, useDispatch } from "react-redux";
import { StartLoading, StopLoading } from "../../actions/UIAction";
import { useTranslation } from "react-i18next";
import SentryUtils from "../../errors/SentryUtils";
function Calendar(props) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [eventData, setEventData] = useState([]);
  const [confirmationModal, setConfirmationModal] = useState(false);
  const [selectedSlotId, setSelectedSlotId] = useState(false);
  const [updateData, setUpdateData] = useState(false);
  const [cancelAppointmentModal, setCancelAppointmentModal] = useState(false);
  const [reason, setReason] = useState("");
  const [selectedAppointmentDetails, setSelectedAppointmentDetails] = useState(
    {}
  );
  const [eventAction, setEventAction] = useState("");
  const [callStartTime, setCallStartTime] = useState("");
  const dispatch = useDispatch();
  document.documentElement.style.setProperty(
    "--fc-button-active-bg-color",
    "#e1dede"
  );
  document.documentElement.style.setProperty(
    "--fc-button-active-border-color",
    "#e1dede"
  );
  document.documentElement.style.setProperty(
    "--fc-button-text-color",
    "#000000"
  );

  useEffect(() => {
    (async () => {
      try {
        if (startDate !== null && endDate !== null) {
          dispatch(StartLoading());
          const response = await appointmentSlotsService.get({
            startDate,
            endDate,
          });
          dispatch(StopLoading());
          const { slotDate, slotDetail } = response[0];
          if (slotDate === null && slotDetail.length === 0) {
            return;
          }
          const data = [];
          response.forEach((event) => {
            event.slotDetail.forEach((slot) => {
              let cd = moment.utc().format("YYYY-MM-DD HH:mm:ss");
              let mcd = moment(cd, "YYYY-MM-DD HH:mm:ss").utc();
              if (mcd.isBefore(slot.slotDateEndTime)) {
                const date = moment
                  .utc(slot.slotDateStartTime)
                  .local()
                  .format("YYYY-MM-DD");
                const slotStartTime = moment
                  .utc(slot.slotDateStartTime)
                  .local()
                  .format("HH:mm");
                const slotDateEndTime = moment
                  .utc(slot.slotDateEndTime)
                  .local()
                  .format("HH:mm");
                data.push({
                  slotId: slot.slotId,
                  status: slot.status,
                  appointmentId: slot.appointmentId,
                  slotDateStartTime: slot.slotDateStartTime,
                  slotDateEndTime: slot.slotDateEndTime,
                  date: slot.slotStartDate,
                  title: `${convert24to12Hr(
                    slotStartTime
                  )} to ${convert24to12Hr(slotDateEndTime)}`,
                  appointmentDetails: slot.appointmentDetails,
                  callStartTime: slot.callStartTime,
                  // green #058711
                  color:
                    slot.status === "AVAILABLE"
                      ? "#909090"
                      : slot.status === "COMPLETED"
                      ? "#9370db"
                      : slot.status === "BOOKED" &&
                        !_.isNil(slot.appointmentDetails.callUrl) &&
                        checkForCallstarted(
                          slot.slotDateStartTime,
                          slot.slotDateEndTime
                        )
                      ? "#058711"
                      : slot.status === "CANCELLED"
                      ? "#EC2947"
                      : slot.status === "RESCHEDULED"
                      ? "#FF8125"
                      : "#334AA6",
                });
              }
            });
          });
          setEventData(data);
        }
      } catch (err) {
        SentryUtils.captureException(err);
      }
    })();
  }, [startDate, endDate, open, updateData]);

  const checkForCallstarted = (startDateTime, endDateTime) => {
    const inBetween = isUTCDateInBetween(startDateTime, endDateTime);
    return inBetween;
  };

  const handleViewChange = (args) => {
    const { start, end } = args;
    const fromDate = modifyDate(start);
    const toDate = modifyDate(end);
    setStartDate(fromDate);
    setEndDate(toDate);
  };

  const handleEventClick = () => {
    setConfirmationModal(!confirmationModal);
  };

  const deleteEvent = () => {
    calendarService
      .deleteAppointmentSlot(selectedSlotId)
      .then((res) => {
        if (res) {
          setUpdateData(!updateData);
          setConfirmationModal(!confirmationModal);
          customToast.success(APPOINMENT_SLOT_DELETE_MESSSAGE);
        } else {
        }
      })
      .catch((err) => {
        throw err;
      });
  };
  const handleModal = (flag, obj) => {
    let newDateObj = null;
    if (!_.isNil(obj)) {
      newDateObj = {
        day: obj.date.getDate(),
        month: obj.date.getMonth() + 1,
        year: obj.date.getFullYear(),
      };
    }
    setSelectedDate(newDateObj);
    setTimeout(() => {
      setOpen(flag);
    }, 200);
  };

  const cancleEvent = () => {
    const data = {
      appointmentId: selectedSlotId,
      status: "CANCELLED",
      reason: reason,
    };
    calendarService
      .cancelAppointmentSlot(data)
      .then((res) => {
        if (res) {
          setUpdateData(!updateData);
          handleCancelAppointment();
          customToast.success(APPOINMENT_CANCEL_MESSSAGE);
        } else {
        }
      })
      .catch((err) => {
        throw err;
      });
  };

  const handleCancelAppointment = (
    slotId,
    appointmentDetails,
    callStartTime
  ) => {
    setCancelAppointmentModal(!cancelAppointmentModal);
    if (slotId) {
      setEventAction("Cancel");
      setSelectedSlotId(slotId);
      setSelectedAppointmentDetails(appointmentDetails);
      setCallStartTime(callStartTime);
    } else {
    }
  };

  const handleDeleteSlot = (slotId) => {
    setConfirmationModal(!confirmationModal);
    slotId && setSelectedSlotId(slotId);
  };

  const checkPastdate = (date, startDateTime) => {
    const dateDiff = moment(date).diff(moment().toDate(), "days");
    if (dateDiff >= 0) {
      if (moment(date).isSame(moment().toDate(), "day")) {
        const currentTime = moment(new Date(), "h:mm A");
        const tempTime = moment.utc(startDateTime).local().format("h:mm A");
        return moment(tempTime, "h:mm A").isBefore(currentTime);
      } else {
        return false;
      }
    } else {
      return true;
    }
  };

  const handleJoincall = (slotId, appointmentDetails, callStartTime) => {
    setCancelAppointmentModal(!cancelAppointmentModal);
    if (slotId) {
      setEventAction("Join");
      setSelectedSlotId(slotId);
      setSelectedAppointmentDetails(appointmentDetails);
      setCallStartTime(callStartTime);
    } else {
    }
  };

  return (
    <section className="content-wapper">
      <h1>{t("WEB_LABELS.Calendar")}</h1>
      <div className="common-panel calendar-view">
        <div className="calendar-indicators">
          <ul>
            <li>{t("WEB_LABELS.Appointment_Status_Color")}:</li>
            <li>
              <Tooltip
                title={t("WEB_LABELS.Available_Appointment_Time_Slot")}
                arrow
              >
                <span className="gray"></span>
              </Tooltip>
            </li>
            <li>
              <Tooltip title={t("WEB_LABELS.Scheduled_Appointment")} arrow>
                <span className="blue"></span>
              </Tooltip>
            </li>
            <li>
              <Tooltip title={t("WEB_LABELS.Rescheduled_Appointment")} arrow>
                <span className="orange"></span>
              </Tooltip>
            </li>
            <li>
              <Tooltip title={t("WEB_LABELS.Cancelled_Appointment")} arrow>
                <span className="red"></span>
              </Tooltip>
            </li>
            <li>
              <Tooltip title={t("WEB_LABELS.Ongoing_Appointment")} arrow>
                <span className="green"></span>
              </Tooltip>
            </li>
            <li>
              <Tooltip title={t("WEB_LABELS.Completed_Appointment")} arrow>
                <span className="purple"></span>
              </Tooltip>
            </li>
          </ul>
        </div>
        <FullCalendar
          plugins={[dayGridPlugin, interactionPlugin]}
          dayMaxEvents={5}
          initialView="dayGridMonth"
          dateClick={(e) => {
            handleModal(true, e);
          }}
          headerToolbar={{
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,dayGridWeek,dayGridDay",
          }}
          datesSet={(args) => handleViewChange(args)}
          events={eventData}
          eventContent={renderEventContent}
        />
        {open && (
          <AvailableSlotModal
            open={open}
            onClose={() => handleModal(false, null)}
            selectedDate={selectedDate}
          />
        )}
        {confirmationModal && (
          <ConfirmationModal
            cancelEvent={() => {
              handleDeleteSlot();
            }}
            title={t(
              "WEB_LABELS.Are_you_sure_you_want_to_delete_this_Appointment_Time_Slot"
            )}
            cancelText={t("COMMON_MESSAGES.No")}
            confirmText={t("COMMON_MESSAGES.Yes")}
            confirmEvent={deleteEvent}
          ></ConfirmationModal>
        )}
        {cancelAppointmentModal && (
          <ConfirmationMsgModal
            from="calendar"
            eventAction={eventAction}
            handleCancelAppointment={handleCancelAppointment}
            handleConfirmationModal={cancleEvent}
            setReason={setReason}
            callType=""
            appointmentDetails={selectedAppointmentDetails}
            callStartTime={callStartTime}
          ></ConfirmationMsgModal>
        )}
      </div>
    </section>
  );

  function renderEventContent(eventInfo) {
    const status = eventInfo.event.extendedProps.status;
    return status === "AVAILABLE" ? (
      <div
        onClick={() => {
          !checkPastdate(
            eventInfo.event.startStr,
            eventInfo.event.extendedProps.slotDateStartTime
          ) && handleDeleteSlot(eventInfo.event.extendedProps.slotId);
        }}
      >
        <b>{eventInfo.event.title}</b>
      </div>
    ) : status === "BOOKED" &&
      !_.isNil(eventInfo.event.extendedProps.appointmentDetails.callUrl) &&
      checkForCallstarted(
        eventInfo.event.extendedProps.slotDateStartTime,
        eventInfo.event.extendedProps.slotDateEndTime
      ) ? (
      <div
        onClick={() =>
          handleJoincall(
            _.get(
              eventInfo.event.extendedProps,
              ["appointmentDetails", "appointmentId"],
              ""
            ),
            eventInfo.event.extendedProps.appointmentDetails,
            eventInfo.event.extendedProps.callStartTime
          )
        }
      >
        <b>{eventInfo.event.title}</b>
      </div>
    ) : status === "BOOKED" ? (
      <div
        onClick={() => {
          !checkPastdate(
            eventInfo.event.startStr,
            eventInfo.event.extendedProps.slotDateStartTime
          ) &&
            handleCancelAppointment(
              _.get(
                eventInfo.event.extendedProps,
                ["appointmentDetails", "appointmentId"],
                ""
              ),
              eventInfo.event.extendedProps.appointmentDetails,
              eventInfo.event.extendedProps.callStartTime
            );
        }}
      >
        <b>{eventInfo.event.title}</b>
      </div>
    ) : (
      <div>
        <b>{eventInfo.event.title}</b>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.profile,
  };
};

export default connect(mapStateToProps, {})(Calendar);
