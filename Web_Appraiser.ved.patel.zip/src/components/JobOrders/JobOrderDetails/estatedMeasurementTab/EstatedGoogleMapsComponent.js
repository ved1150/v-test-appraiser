import { useEffect, useRef } from "react";
const CustomGoogleMapsComponent = (props) => {
  const ref = useRef();
  useEffect(() => {
    const estatedData = props;
    let map = new window.google.maps.Map(ref.current, {
      center: {
        lat: estatedData["data"]["address"]["latitude"],
        lng: estatedData["data"]["address"]["longitude"],
      },
    });
    const feature = {
      type: "Feature",
      geometry: estatedData["data"]["boundary"]["geojson"],
    };
    map.data.addGeoJson(feature);
    let bounds = new window.google.maps.LatLngBounds();
    map.data.forEach(function (feature) {
      feature.getGeometry().forEachLatLng(function (latlng) {
        bounds.extend(latlng);
      });
    });
    map.fitBounds(bounds);
  });
  return <div className="estate-map" ref={ref} id="map" />;
};
export default CustomGoogleMapsComponent;
