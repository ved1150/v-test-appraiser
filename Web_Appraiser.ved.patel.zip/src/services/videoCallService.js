import api from "./apis/api";
import { dehydrateVideoCallURL } from "./transformers/";
class VideoCallService {
  createQuickCall(requestData) {
    return api.videoCall.geneateQuickCall(dehydrateVideoCallURL(requestData));
  }
}

export default new VideoCallService();
