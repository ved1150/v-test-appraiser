import _ from "lodash";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import AsyncImage from "../../common/AsyncImage";
import ViewImage from "../../JobOrders/JobOrderDetails/Models/viewImage";

const RequestRescanHistoryImages = (props) => {
  const { t } = useTranslation();
  const [selectedImageIndexForView, setSelectedImageIndexForView] =
    useState("");
  const [enableImageView, setEnableImageView] = useState(false);

  const viewImage = (imgIndex) => {
    toggleViewImage();
    setSelectedImageIndexForView(imgIndex);
  };

  const toggleViewImage = () => {
    setEnableImageView(!enableImageView);
  };

  return (
    <div
      style={{ position: "fixed" }}
      className="center-modal rrh-center-modal open"
    >
      {enableImageView && (
        <ViewImage
          selectedImageIndexForView={selectedImageIndexForView}
          imageList={props?.requestRescanHistoryImagesModalData?.map((e) => {
            return { original: e };
          })}
          toggleViewImage={toggleViewImage}
        ></ViewImage>
      )}
      <div className="inner-modal big-area">
        <div className="comman-modal-main">
          <div className="side-head">
            {t("Request_Rescan_History_Markup_Images")}
            <button
              onClick={() => {
                props.setShowRequestRescanHistoryImagesModal(false);
                props.setRequestRescanHistoryImagesModalData(null);
              }}
              className="close-modal"
            >
              <i className="icon-close-image"></i>
            </button>
          </div>
          <div className="modal-body scroll-bar-style">
            <div className="captured-images">
              <ul className="list scroll-bar-style">
                {props?.requestRescanHistoryImagesModalData &&
                  _.map(
                    props?.requestRescanHistoryImagesModalData,
                    (img, id) => (
                      <li key={id}>
                        <div className="saved-images-box">
                          <div className="images-box over-hidden">
                            <div
                              className="viewbtn"
                              onClick={() => viewImage(id)}
                            >
                              <button>
                                <i className="icon-eye"></i>
                              </button>
                            </div>
                            <div>
                              <AsyncImage imageUrl={img} />
                            </div>
                          </div>
                        </div>
                      </li>
                    )
                  )}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestRescanHistoryImages;
