import api from "./api";

export default class TransactionHistoryApi {
  fetch(data) {
    let queryParams = `page=${data.page}&size=${data.size}`;
    if (data?.searchText && data?.searchText?.trim()?.length > 0) {
      queryParams += `&searchText=${data.searchText}`;
    }
    if (data.fromDate) {
      data.fromDate += " 00:00:00";
    }
    if (data.toDate) {
      data.toDate += " 23:59:59";
    }
    const reqBody = {
      transactionStatus: data.transactionStatus,
      fromDate: data.fromDate,
      toDate: data.toDate,
    };
    return api.post(`/getTransactionHistory?${queryParams}`, reqBody);
  }

  fetchStatus(data) {
    return api.post(`/getTransactionStatus`, data);
  }

  exportTransactionHistory(data) {
    let queryParams = null;
    if (data?.searchText && data?.searchText?.trim()?.length > 0) {
      queryParams += `searchText=${data.searchText}`;
    }
    if (data.fromDate) {
      data.fromDate += " 00:00:00";
    }
    if (data.toDate) {
      data.toDate += " 23:59:59";
    }
    const reqBody = {
      transactionStatus: data.transactionStatus,
      fromDate: data.fromDate,
      toDate: data.toDate,
    };
    return api.post(
      `/export-transaction-history?${queryParams ? queryParams : ""}`,
      reqBody
    );
  }
}
