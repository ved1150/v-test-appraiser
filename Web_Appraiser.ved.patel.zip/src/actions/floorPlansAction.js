import * as actionTypes from "./actionTypes";
import floorPlansService from "../services/floorPlansService";
import { StartLoading, StopLoading } from "./UIAction";
import { customToast } from "../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "../constants/commonMessages";

const startFetchFloorPlans = () => {
  return {
    type: actionTypes.FETCH_FLOORPLANS_START,
  };
};

const successFetchFloorPlans = (data) => {
  return {
    type: actionTypes.FETCH_FLOORPLANS_SUCCESS,
    payload: data,
  };
};

const errorFetchFloorPlans = (error) => {
  return {
    type: actionTypes.FETCH_FLOORPLANS_ERROR,
    payload: error,
  };
};

export const fetchFloorPlans = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchFloorPlans());
    return floorPlansService
      .getFloorPlans(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchFloorPlans(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchFloorPlans(err));
      });
  };
};

const startDownloadImage = () => {
  return {
    type: actionTypes.DOWNLOAD_IMAGE_START,
  };
};

const successDownloadImage = (data) => {
  return {
    type: actionTypes.DOWNLOAD_IMAGE_SUCCESS,
    payload: data,
  };
};

const errorDownloadImage = (error) => {
  return {
    type: actionTypes.DOWNLOAD_IMAGE_ERROR,
    payload: error,
  };
};

export const downloadImage = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startDownloadImage());
    return floorPlansService
      .downloadImage(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successDownloadImage(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorDownloadImage(data));
        throw err;
      });
  };
};

const startDownloadZip = () => {
  return {
    type: actionTypes.DOWNLOAD_ZIP_START,
  };
};

const successDownloadZip = (data) => {
  return {
    type: actionTypes.DOWNLOAD_ZIP_SUCCESS,
    payload: data,
  };
};

const errorDownloadZip = (error) => {
  return {
    type: actionTypes.DOWNLOAD_ZIP_ERROR,
    payload: error,
  };
};

export const downloadZip = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startDownloadZip());
    return floorPlansService
      .downloadZip(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successDownloadZip(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorDownloadZip(data));
        throw err;
      });
  };
};
