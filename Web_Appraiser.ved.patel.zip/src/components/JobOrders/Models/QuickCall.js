import React, { Component } from "react";
import { connect } from "react-redux";
import _ from "lodash";

import PhoneInput from "./../../common/PhoneInput";
import CustomSwitch from "../../common/CustomSwitch";
import Button from "../../common/Button";

import { getVideoCallURL } from "../../../actions/videoCallAction";
import { createMeasurement } from "../../../actions/measurementAction";
import { withTranslation } from "react-i18next";
import {
  validateEmailWithRequired,
  validatePhoneWithRequired,
  validateTextWithRequired,
  validateRequired,
  validateInvitationTypeTab,
} from "../../../helpers";
import {
  CALL_LINK_SUCCESS_MESSAGE,
  UNEXPECTED_ERROR_MESSAGE,
} from "../../../constants/commonMessages";
import { customToast } from "../../../helpers/customToast";
import jobService from "../../../services/jobService";
import SentryUtils from "../../../errors/SentryUtils";
import "./quickCall.scss";
import { logEvent } from "firebase/analytics";
import getAnalyticsInstance from "../../../services/analytics";

const initialState = {
  name: {
    value: "Property owner",
    error: "",
  },
  phone: {
    value: "",
    error: "",
  },
  email: {
    value: "",
    error: "",
  },
  address: {
    value: "3134  Doctors Drive, Los Angeles. California. 90017",
    error: "",
  },
  message: {
    value: "",
    error: "",
  },
  isRecording: {
    value: false,
    error: "",
  },
  invitationTypeTab: {
    sms: true,
    email: false,
    error: "",
  },
  charLimit: 400,
  callUUID: "",
  country: "us",
  country_code: "1",
  submitting: false,
};

const textBoxMessage =
  "Hello Participant, This is - please join me for a secure video call. Click on the following link:";
let callURL = "";
class QuickCall extends Component {
  videoCallURL = {};

  constructor(props) {
    super();

    this.state = {
      ...initialState,
    };

    this.handleChange = this.handleChange.bind(this);

    //To change tabs(SMS,Email) for Add participant
    this.invitationTypeChanged = this.invitationTypeChanged.bind(this);
  }

  async componentDidMount() {
    let message = textBoxMessage;
    const {
      configurationDetail: { isCallRecording },
      t,
    } = this.props;

    this.setState(
      {
        message: {
          value: message,
        },
        isRecording: {
          value: isCallRecording,
        },
      },
      () => {}
    );
  }

  async componentWillUnmount() {
    this.setState({
      phone: {
        value: "",
        error: "",
      },
      email: {
        value: "",
        error: "",
      },
    });
  }

  async invitationTypeChanged(tab, checked) {
    let message = textBoxMessage + " " + callURL;
    const { invitationTypeTab } = this.state;
    if (tab === "sms") {
      invitationTypeTab.sms = checked;
    } else if (tab === "email") {
      invitationTypeTab.email = checked;
    }

    invitationTypeTab.error = validateInvitationTypeTab(invitationTypeTab);

    this.setState({ invitationTypeTab });
  }

  async resetState() {
    this.setState(
      {
        ...initialState,
      },
      () => {}
    );
  }

  async handleChange(validationFunc, e) {
    const { name, value } = e.target;

    this.setState((state) => ({
      [name]: {
        ...state[name],
        value: value,
        validateOnChange: true,
        error: validationFunc(value),
      },
    }));
  }

  async handlePhoneChange(name, value) {
    this.setState((state) => ({
      [name]: {
        ...state[name],
        value: value,
        validateOnChange: true,
        error: validatePhoneWithRequired(value),
      },
    }));
  }

  async handleRecordingChange(name, value) {
    this.setState((state) => ({
      [name]: {
        ...state[name],
        value: value,
        validateOnChange: true,
      },
    }));
  }

  async sendMeasurement(e) {
    const { email, phone } = this.state;
    const {
      createMeasurement,
      selectedJobOrder: { address, id, name },
      userId,
      hideQuickCall,
    } = this.props;

    const invitationTypeTabError = validateInvitationTypeTab(
      this.state.invitationTypeTab
    );

    let phoneError = false;
    let emailError = false;

    const sendMeasurementObj = {
      address,
      appraiserId: userId,
      jobOrderId: id,
      name,
    };

    if (this.state.invitationTypeTab.sms) {
      sendMeasurementObj.phoneNumber = phone.value;
      phoneError = validatePhoneWithRequired(this.state.phone.value);
    }
    if (this.state.invitationTypeTab.email) {
      sendMeasurementObj.emailId = email.value;
      emailError = validateEmailWithRequired(this.state.email.value);
    }

    if (
      [phoneError, emailError, invitationTypeTabError].every((e) => e === false)
    ) {
      this.setState({ submitting: { value: true } });
      createMeasurement(sendMeasurementObj)
        .then((res) => {
          const {
            status,
            data: { data, message },
          } = res;
          if (status === 200 && Object.keys(data).length > 0) {
            customToast.success(message);
            this.setState({
              submitting: { value: false },
              phone: {
                value: "",
                error: "",
              },
              email: {
                value: "",
                error: "",
              },
            });
            hideQuickCall();
          }
        })
        .catch((err) => {
          this.setState({ submitting: { value: false } });
        });
    } else {
      this.setState((state) => ({
        phone: {
          ...state.phone,
          validateOnChange: true,
          error: phoneError,
        },
        email: {
          ...state.email,
          validateOnChange: true,
          error: emailError,
        },
        invitationTypeTab: {
          ...state.invitationTypeTab,
          validateOnChange: true,
          error: invitationTypeTabError,
        },
      }));
    }
  }

  async sendInvitation(e) {
    const {
      selectedJobOrder: { id, name },
      t,
    } = this.props;
    const nameError = validateTextWithRequired(this.state.name.value);
    const messageError = validateRequired(this.state.message.value);
    const addressError = validateRequired(this.state.address.value);
    const invitationTypeTabError = validateInvitationTypeTab(
      this.state.invitationTypeTab
    );
    let phoneError = false;
    let emailError = false;

    let requestData = {
      jobOrderId: id,
      templateId: "337e5140-3b7e-4000-b674-3e09f9423da3",
      name: name,
      isRecording: this.state.isRecording.value,
    };

    if (this.state.invitationTypeTab.sms) {
      requestData.phone = this.state.phone.value;
      phoneError = validatePhoneWithRequired(this.state.phone.value);
    }
    if (this.state.invitationTypeTab.email) {
      requestData.email = this.state.email.value;
      emailError = validateEmailWithRequired(this.state.email.value);
    }

    if (
      [
        nameError,
        messageError,
        phoneError,
        emailError,
        addressError,
        invitationTypeTabError,
      ].every((e) => e === false)
    ) {
      try {
        this.setState({ submitting: { value: true } });
        let videoURLResult = await this.props.getVideoCallURL(requestData);
        this.setState({ submitting: { value: false } });
        this.props.setIsQuickCallGenerated(true);
        customToast.success(t("COMMON_MESSAGES.CALL_LINK_SUCCESS_MESSAGE"));
        this.props.hideQuickCall(videoURLResult.data.appraiserRoomLink);
        if (process.env.REACT_APP_SENTRY_ENV == "Production") {
          getAnalyticsInstance().then((analytics) => {
            logEvent(analytics, "Invite Session", { name: "" + " " + "" });
          });
        } else {
        }
      } catch (err) {
        SentryUtils.captureException(err);
        customToast.error(t("COMMON_MESSAGES.UNEXPECTED_ERROR_MESSAGE"));
      }
    } else {
      this.setState((state) => ({
        name: {
          ...state.name,
          validateOnChange: true,
          error: nameError,
        },
        address: {
          ...state.address,
          validateOnChange: true,
          error: addressError,
        },
        phone: {
          ...state.phone,
          validateOnChange: true,
          error: phoneError,
        },
        email: {
          ...state.email,
          validateOnChange: true,
          error: emailError,
        },
        message: {
          ...state.message,
          validateOnChange: true,
          error: messageError,
        },
        invitationTypeTab: {
          ...state.invitationTypeTab,
          validateOnChange: true,
          error: invitationTypeTabError,
        },
      }));
    }
  }

  render() {
    const {
      name,
      email,
      message,
      phone,
      address,
      invitationTypeTab,
      country,
      country_code,
      isRecording,
    } = this.state;
    const { isMeasurmentLinkVisible, hideQuickCall, t } = this.props;

    let characterLimitText = "";
    if (this.state.charLimit - message.value.length > 0) {
      characterLimitText =
        this.state.charLimit - message.value.length + " characters remaining";
    } else {
      characterLimitText = "Character Limit Exceeded";
    }

    return (
      <>
        <div className="comman-modal right-side open">
          <div className="comman-modal-main">
            <div className="side-head">
              {isMeasurmentLinkVisible
                ? t("WEB_TOOLTIPS.SelfInspectionLink")
                : t("WEB_LABELS.Quick_Call")}
              <button
                className="close-modal"
                onClick={() => {
                  hideQuickCall();
                }}
              >
                <i className="icon-close-image"></i>
              </button>
            </div>
            <div className="comman-modal-body quick-call scroll-bar-style">
              <div className="form-group">
                <label>{t("WEB_LABELS.Job_Order_ID")}</label>
                <input
                  disabled="disabled"
                  type="text"
                  className="form-control"
                  name=""
                  placeholder=""
                  value={_.get(
                    this.props,
                    ["selectedJobOrder", "orderNo"],
                    "--"
                  )}
                />
              </div>
              {isMeasurmentLinkVisible ? (
                <>
                  <div className="form-group">
                    <label>{t("WEB_LABELS.Property_Address")}</label>
                    <input
                      type="text"
                      className="form-control"
                      name="address"
                      placeholder="3134  Doctors Drive, Los Angeles. California. 90017"
                      value={_.get(
                        this.props,
                        ["selectedJobOrder", "address"],
                        "--"
                      )}
                      onChange={(e) => this.handleChange(validateRequired, e)}
                      onBlur={(e) => this.handleChange(validateRequired, e)}
                      disabled="disabled"
                    />

                    <div className="text-danger">{address.error}</div>
                  </div>

                  <div className="form-group">
                    <label>{t("WEB_LABELS.Name")}</label>
                    <input
                      type="text"
                      className="form-control"
                      name="name"
                      onChange={(e) =>
                        this.handleChange(validateTextWithRequired, e)
                      }
                      onBlur={(e) =>
                        this.handleChange(validateTextWithRequired, e)
                      }
                      value={_.get(
                        this.props,
                        ["selectedJobOrder", "name"],
                        "--"
                      )}
                      placeholder="Property Owner Name"
                      disabled="disabled"
                    />
                    <div className="text-danger">{name.error}</div>
                  </div>
                </>
              ) : (
                <>
                  <div className="form-group">
                    <label>{t("WEB_LABELS.Property_Owner_Name")}</label>
                    <input
                      type="text"
                      className="form-control"
                      name="name"
                      onChange={(e) =>
                        this.handleChange(validateTextWithRequired, e)
                      }
                      onBlur={(e) =>
                        this.handleChange(validateTextWithRequired, e)
                      }
                      value={_.get(
                        this.props,
                        ["selectedJobOrder", "name"],
                        "--"
                      )}
                      placeholder="Property Owner Name"
                      disabled="disabled"
                    />
                    <div className="text-danger">{name.error}</div>
                  </div>

                  <div className="form-group">
                    <label>{t("WEB_LABELS.Address")}</label>
                    <input
                      type="text"
                      className="form-control"
                      name="address"
                      placeholder="3134  Doctors Drive, Los Angeles. California. 90017"
                      value={_.get(
                        this.props,
                        ["selectedJobOrder", "address"],
                        "--"
                      )}
                      onChange={(e) => this.handleChange(validateRequired, e)}
                      onBlur={(e) => this.handleChange(validateRequired, e)}
                      disabled="disabled"
                    />

                    <div className="text-danger">{address.error}</div>
                  </div>
                </>
              )}

              <div className="check-group">
                <div className="check-group-inner">
                  <div className="check-btn">
                    <label>
                      <input
                        type="checkbox"
                        id="sms"
                        name="invitation-type"
                        onChange={(e) => {}}
                        onClick={(e) =>
                          this.invitationTypeChanged("sms", e.target.checked)
                        }
                        checked={invitationTypeTab.sms}
                      />
                      <span>{t("WEB_LABELS.Cell_Phone")}</span>
                    </label>
                  </div>
                  <div className="check-btn">
                    <label>
                      <input
                        type="checkbox"
                        id="sms"
                        name="invitation-type"
                        onChange={(e) => {}}
                        onClick={(e) =>
                          this.invitationTypeChanged("email", e.target.checked)
                        }
                        checked={invitationTypeTab.email}
                      />
                      <span>{t("WEB_LABELS.Email")}</span>
                    </label>
                  </div>
                </div>
                <div className="text-danger">{invitationTypeTab.error}</div>
              </div>

              {/* Phone number */}

              {invitationTypeTab.sms && (
                <div className="form-group">
                  <PhoneInput
                    country={"us"}
                    name={"phone"}
                    value={phone.value}
                    onChange={(value) => {
                      this.handlePhoneChange("phone", value);
                    }}
                    countryCodeEditable={false}
                    onlyCountries={["us"]}
                    enableSearch={false}
                    placeholder={t("WEB_LABELS.enter_phone_number")}
                  />
                  <div className="text-danger">{phone.error}</div>
                </div>
              )}

              {/* Phone number ends */}

              {/* Email address */}

              {invitationTypeTab.email && (
                <div className="form-group">
                  <input
                    type="email"
                    className="form-control"
                    name="email"
                    placeholder="abc@gmail.com"
                    onChange={(e) =>
                      this.handleChange(validateEmailWithRequired, e)
                    }
                    onBlur={(e) =>
                      this.handleChange(validateEmailWithRequired, e)
                    }
                    value={email.value}
                  />
                  <div className="text-danger">{email.error}</div>
                </div>
              )}

              {/* Email address ends */}

              {/* Message Starts */}
              {/* <div className="form-group">
                <label>Message</label>
                <textarea
                  className="form-control"
                  rows="5"
                  placeholder=""
                  name="message"
                  onBlur={(e) => this.handleChange(validateRequired, e)}
                  onChange={(e) => this.handleChange(validateRequired, e)}
                  value={message.value}
                ></textarea>
                <div className="message text-right">{characterLimitText}</div>

                <div className="text-danger">{message.error}</div>
              </div> */}
              {/* Message Ends */}

              {!isMeasurmentLinkVisible && (
                <div className="switch-group">
                  <CustomSwitch
                    checked={isRecording.value}
                    onChange={(event) =>
                      this.handleRecordingChange(
                        "isRecording",
                        event.target.checked
                      )
                    }
                    name="isRecording"
                  />
                  <label>{t("WEB_LABELS.Record_Virtual_Call")}</label>
                </div>
              )}
              <div className="button-group text-center">
                <Button
                  className="blue-btn"
                  disabled={this.state.submitting.value}
                  onClick={(e) => {
                    isMeasurmentLinkVisible
                      ? this.sendMeasurement(e)
                      : this.sendInvitation(e);
                  }}
                >
                  {isMeasurmentLinkVisible
                    ? t("BUTTONS.Send")
                    : t("BUTTONS.Invite_and_Join")}
                  {this.state.submitting.value && (
                    <div className="loader-spin"></div>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  getVideoCallURL: (requestData) => dispatch(getVideoCallURL(requestData)),
  createMeasurement: (data) => dispatch(createMeasurement(data)),
});

const connectedQuickCall = connect(
  null,
  mapDispatchToProps
)(withTranslation()(QuickCall));
export { connectedQuickCall as QuickCall };
