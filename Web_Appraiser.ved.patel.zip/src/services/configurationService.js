import api from "./apis/api";
import { hydrateConfiguration } from "./transformers/configurationTransformer";

class ConfigurationService {
  get(uuid) {
    return api.configuration
      .get(uuid)
      .then((res) => hydrateConfiguration(res.data.data));
  }
}

export default new ConfigurationService();
