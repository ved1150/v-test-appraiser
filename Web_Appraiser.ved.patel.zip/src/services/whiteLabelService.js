import api from "./apis/api";

class WhiteLabelService {
  getTheme() {
    return api.whiteLabel.getTheme();
  }
}

export default new WhiteLabelService();
