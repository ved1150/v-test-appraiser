import { useState } from "react";

const Assesments = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Assessments{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {props.estatedData.data.assessments.map((value) =>
          Object.keys(value).map((key) => (
            <li key={`assesments_${key}_${value[key]}`}>
              {key === "year" ? (
                <b>{value[key]}</b>
              ) : (
                <>
                  <div style={{ textTransform: "capitalize" }}>
                    {key.split("_").join(" ")}
                  </div>
                  <div>{value[key] ?? "N/A"}</div>
                </>
              )}
            </li>
          ))
        )}
      </ul>
    </>
  );
};

export default Assesments;
