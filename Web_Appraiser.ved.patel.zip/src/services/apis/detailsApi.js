import api from "./api";

export default class DetailsAPI {
  getDetails(data) {
    return api.get(`/joborders/${data}`);
  }

  getCallDetails(data) {
    return api.get(`/joborders/callhistory?joborderId=${data}`);
  }
}
