import api from "./api";
export default class JobAPI {
  getImages(data) {
    return api.get(`/joborder/${data}/picture`);
  }

  downloadImages(data) {
    return api.downloadPost(`/joborder/download`, {
      jobOrderId: data.joborder_id,
      selectedImages: data.selected_images,
    });
  }

  deleteImages(data) {
    return api.post(`/call/delete-picture`, data);
  }
}
