import axios from "axios";
import AuthAPI from "./authApi";
import JobAPI from "./jobApi";
import VideoCallAPI from "./videoCallApi";
import CalendarAPI from "./calendarApi";
import ImageAPI from "./imageApi";
import RecordingsAPI from "./recordingsApi";
import FloorPlansAPI from "./floorPlansApi";
import NotesAPI from "./notesAPi";
import ConfigurationApi from "./configurationApi";
import AppointmentSlotsApi from "./appointmentSlotsApi";
import DetailsApi from "./detailsApi";
import JobOrderDetailsApi from "./jobOrderDetailsApi";
import MeasurementAPI from "./measurementApi";
import EagleViewAPI from "./eagleViewApi";
import AttachmentAPI from "./attachmentApi";
import Authentication from "./authenticationApi";
import ProfileAPI from "./profileAPI";
import sessionStorage from "./../sessionStorage";
import localStorage from "./../storage";
import RelarAPI from "./relarApi";
import FloorAPI from "./floorAPI";
import JobOrdersManagementAPI from "./jobOrdersManagementApi";
import WhiteLabel from "./whiteLabelApi";
import ManageCardsAPI from "./manageCardsApi";
import JobOrderTypes from "./jobOrderTypesApi";
import _ from "lodash";
import {
  storageTypes,
  loginType,
  TempX_TenantKey,
} from "./../../constants/appConstant";
import QuestionnaireAPI from "./questionnaireApi";
import TechnicianJobAPI from "./technicianJobApi";
import SentryUtils from "../../errors/SentryUtils";
import {
  startFileDownload,
  stopFileDownload,
} from "../../actions/downloadAction";
import { StartErrorModal, StartReLogin } from "../../actions/errorPopUpAction";
import store from "../../store";
import { getSubDomainFromURL } from "../../helpers";
import authenticationService from "../authenticationService";
import { isTokenExpired } from "../../helpers/validation";
import i18next from "i18next";
import { customToast } from "../../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "../../constants/commonMessages";
import PDRReportsAPI from "./PDRReportsApi";
import TransactionHistory from "./transactionHistoryApi";

const BASEURL = process.env.REACT_APP_API_END_POINT;
const TIMEOUTFORUPLOADFILE = 1800000;
const STATICTOKEN = process.env.REACT_APP_TOKEN;
let IsToastExist = false;
class API {
  __auth = new AuthAPI();
  __job = new JobAPI();
  __technicianJob = new TechnicianJobAPI();
  __videoCall = new VideoCallAPI();
  __calendar = new CalendarAPI();
  __image = new ImageAPI();
  __recordings = new RecordingsAPI();
  __floorplans = new FloorPlansAPI();
  __relars = new RelarAPI();
  __floors = new FloorAPI();
  __notes = new NotesAPI();
  __configuration = new ConfigurationApi();
  __appointmentSlots = new AppointmentSlotsApi();
  __details = new DetailsApi();
  __jobOrderDetails = new JobOrderDetailsApi();
  __measurement = new MeasurementAPI();
  __eagleView = new EagleViewAPI();
  __attachment = new AttachmentAPI();
  __authentication = new Authentication();
  __profile = new ProfileAPI();
  __questionnaire = new QuestionnaireAPI();
  __jobOrdersManagement = new JobOrdersManagementAPI();
  __whiteLabel = new WhiteLabel();
  __PDRReports = new PDRReportsAPI();
  __manageCards = new ManageCardsAPI();
  __transactionHistory = new TransactionHistory();
  __jobOrderTypes = new JobOrderTypes();

  api = axios.create({
    baseURL: BASEURL,
    transformRequest: [(data) => JSON.stringify(data)],
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });

  downloadApi = axios.create({
    baseURL: BASEURL,
    transformRequest: [(data) => JSON.stringify(data)],
    responseType: "blob",
    headers: {
      Accept: "application/zip",
      "Content-Type": "application/json",
    },
  });

  downloadApiGet = axios.create({
    baseURL: BASEURL,
    transformRequest: [(data) => JSON.stringify(data)],
    responseType: "blob",
    onDownloadProgress: (progressEvent) => {
      let percentCompleted = Math.round(
        (progressEvent.loaded * 100) / progressEvent.total
      );
      store.dispatch(startFileDownload(percentCompleted));
      if (percentCompleted === 100) {
        store.dispatch(stopFileDownload(0));
      }
    },
  });

  formsApi = axios.create({
    baseURL: BASEURL,
    timeout: TIMEOUTFORUPLOADFILE,
    headers: { "Content-Type": "multipart/form-data" },
  });

  downloadBlobApi = axios.create({
    baseURL: BASEURL,
    transformRequest: [(data) => JSON.stringify(data)],
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    responseType: "blob",
  });

  downloadPdf = axios.create({
    baseURL: BASEURL,
    transformRequest: [(data) => JSON.stringify(data)],
    responseType: "blob",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  });

  get auth() {
    return this.__auth;
  }

  get job() {
    return this.__job;
  }

  get technicianJob() {
    return this.__technicianJob;
  }

  get videoCall() {
    return this.__videoCall;
  }

  get calendar() {
    return this.__calendar;
  }

  get image() {
    return this.__image;
  }

  get recordings() {
    return this.__recordings;
  }

  get floorplans() {
    return this.__floorplans;
  }

  get relars() {
    return this.__relars;
  }

  get notes() {
    return this.__notes;
  }

  get floors() {
    return this.__floors;
  }
  get configuration() {
    return this.__configuration;
  }

  get appointmentSlots() {
    return this.__appointmentSlots;
  }

  get details() {
    return this.__details;
  }

  get jobOrderDetails() {
    return this.__jobOrderDetails;
  }

  get mesurement() {
    return this.__measurement;
  }

  get eagleView() {
    return this.__eagleView;
  }

  get attachment() {
    return this.__attachment;
  }

  get authentication() {
    return this.__authentication;
  }

  get profile() {
    return this.__profile;
  }

  get questionnaire() {
    return this.__questionnaire;
  }

  get jobOrdersManagement() {
    return this.__jobOrdersManagement;
  }

  get whiteLabel() {
    return this.__whiteLabel;
  }

  get PDRReports() {
    return this.__PDRReports;
  }

  get manageCards() {
    return this.__manageCards;
  }

  get transactionHistory() {
    return this.__transactionHistory;
  }

  get jobOrderTypes() {
    return this.__jobOrderTypes;
  }

  get(url, ...args) {
    return this.sendRequestInternal(this.api.get, url, ...args);
  }

  post(url, ...args) {
    return this.sendRequestInternal(this.api.post, url, ...args);
  }

  patch(url, ...args) {
    return this.sendRequestInternal(this.api.patch, url, ...args);
  }

  delete(url, ...args) {
    return this.sendRequestInternal(this.api.delete, url, ...args);
  }

  put(url, ...args) {
    return this.sendRequestInternal(this.api.put, url, ...args);
  }

  downloadPost(url, ...args) {
    return this.sendRequestInternal(this.downloadApi.post, url, ...args);
  }

  downloadGet(url, ...args) {
    return this.sendRequestInternal(this.downloadApiGet.get, url, ...args);
  }

  downloadBlobPost(url, ...args) {
    return this.sendRequestInternal(this.downloadBlobApi.post, url, ...args);
  }
  downloadPdfPost(url, ...args) {
    return this.sendRequestInternal(this.downloadPdf.post, url, ...args);
  }

  postMultipartFormData(url, data, onUploadProgress) {
    return this.sendRequestInternal(
      (u, a) => this.formsApi.post(u, a, { onUploadProgress }),
      url,
      data
    );
  }

  putMultipartFormData(url, data, onUploadProgress) {
    return this.sendRequestInternal(
      (u, a) => this.formsApi.put(u, a, { onUploadProgress }),
      url,
      data
    );
  }
  sendRequestInternal(requestFunc, url, ...args) {
    let token;
    if (sessionStorage.get("storageType") == storageTypes.sessionStorage) {
      token = sessionStorage.get("token");
    } else {
      token = localStorage.get("token");
    }
    const X_TenantKey = getSubDomainFromURL();
    const currentTenantSubDomain =
      authenticationService.getTenantDetails() &&
      _.get(
        JSON.parse(authenticationService.getTenantDetails()),
        ["tenantSubDomain"],
        ""
      );
    let currentTenant;
    if (args && args?.[0]?.useCatalogMaster) {
      currentTenant = args?.[0]?.xTenant;
    } else {
      currentTenant = currentTenantSubDomain || X_TenantKey || TempX_TenantKey;
    }
    this.api.defaults.headers.common["X-Tenant"] = currentTenant;
    this.downloadApi.defaults.headers.common["X-Tenant"] = currentTenant;
    this.downloadApiGet.defaults.headers.common["X-Tenant"] = currentTenant;
    this.formsApi.defaults.headers.common["X-Tenant"] = currentTenant;
    this.downloadBlobApi.defaults.headers.common["X-Tenant"] = currentTenant;
    this.downloadPdf.defaults.headers.common["X-Tenant"] = currentTenant;

    // let tokenType = "";
    if (token) {
      if (isTokenExpired() && args[0]?.callWithStaticToken !== true) {
        store.dispatch(StartReLogin());
        return new Promise(function (resolve, reject) {
          let sessionObj = { ignoreSentryRV: true };
          reject(sessionObj);
        });
      } else {
        this.api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
        this.downloadApi.defaults.headers.common[
          "Authorization"
        ] = `Bearer ${token}`;
        this.downloadApiGet.defaults.headers.common[
          "Authorization"
        ] = `Bearer ${token}`;
        this.formsApi.defaults.headers.common[
          "Authorization"
        ] = `Bearer ${token}`;
        this.downloadBlobApi.defaults.headers.common[
          "Authorization"
        ] = `Bearer ${token}`;
        this.downloadPdf.defaults.headers.common[
          "Authorization"
        ] = `Bearer ${token}`;
      }
      // tokenType = "auth";
    } else {
      this.api.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${STATICTOKEN}`;
      this.downloadApi.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${STATICTOKEN}`;
      this.downloadApiGet.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${STATICTOKEN}`;
      this.formsApi.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${STATICTOKEN}`;
      // tokenType = "static";
    }

    if (args && args?.[0]?.useCatalogMaster) {
      this.api.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${args?.[0]?.token}`;
    }
    if (args[0]?.callWithStaticToken === true) {
      this.api.defaults.headers.common[
        "Authorization"
      ] = `Bearer ${STATICTOKEN}`;
      // tokenType = "static";
    }

    return requestFunc(url, ...args)
      .then((response) => {
        IsToastExist = false;
        return response;
      })
      .catch((error) => {
        const additionalInfoObject = {
          sendRequestInternal_params: {
            url,
            args,
          },
        };
        // if (
        //   ["Development", "Test"].includes(process.env.REACT_APP_SENTRY_ENV)
        // ) {
        //   additionalInfoObject["tokenType"] = tokenType;
        // }
        if (axios.isAxiosError(error)) {
          if (
            _.get(error, ["response", "data", "code"], "") === 400 &&
            _.get(error, ["response", "config", "url"], "") === "user/login"
          ) {
          } else {
            SentryUtils.captureApiException(error, additionalInfoObject);
          }
        } else {
          SentryUtils.captureException(error, additionalInfoObject);
        }
        if (error.response) {
          if (_.get(error, ["response", "data", "code"], "") === 403) {
            if (
              sessionStorage.get("storageType") == storageTypes.sessionStorage
            ) {
              sessionStorage.clearAll();
              window.location = "/unauthorized";
            } else {
              localStorage.clearAll();
              window.location = "/unauthorized";
            }
          } else if (
            _.get(error, ["response", "data", "status"], "") === 401 ||
            _.get(error, ["response", "data", "code"], "") === 401
          ) {
            const {
              response: { data },
            } = error;
            if (!IsToastExist) {
              IsToastExist = true;
              customToast.error(data.message);
            }
            if (
              sessionStorage.get("storageType") == storageTypes.sessionStorage
            ) {
              sessionStorage.clearAll();
              window.location = "/sign-in";
            } else {
              localStorage.clearAll();
              window.location = "/sign-in";
            }
          } else if (
            _.get(error, ["response", "data", "code"], "") === 400 ||
            _.get(error, ["response", "data", "code"], "") === 404
          ) {
            const {
              response: { data },
            } = error;
            if (!IsToastExist) {
              IsToastExist = true;
              customToast.error(data.message);
            }
          } else {
            let errorReason = _.get(error, ["response", "data", "message"])
              ? _.get(error, ["response", "data", "message"])
              : _.get(error, ["message"]);
            const errorPayload = {
              errorCode: _.get(error, ["response", "status"], ""),
              errorReason: errorReason,
            };
            store.dispatch(StartErrorModal(errorPayload));
          }
        } else if (!navigator.onLine && !IsToastExist) {
          IsToastExist = true;
          customToast.error(
            i18next.t(
              "ERROR_MESSAGES.You_are_offline_Check_your_internet_connection"
            )
          );
        } else if (!IsToastExist) {
          IsToastExist = true;
          customToast.error(UNEXPECTED_ERROR_MESSAGE);
        }
        setTimeout(() => {
          IsToastExist = false;
        }, 2000);
        throw error;
      });
  }
}

export default new API();
