import { useState } from "react";

const Taxes = (props) => {
  const [show, setShow] = useState(false);
  return (
    <>
      <h4>
        Taxes{" "}
        <button onClick={() => setShow(!show)} class="image">
          <i class={show ? "icon-minus" : "icon-plus"}></i>
        </button>
      </h4>
      <ul
        style={{
          display: show ? "block" : "none",
        }}
      >
        {props.estatedData.data.taxes.map((value) =>
          Object.keys(value).map((key) => (
            <li key={`taxes_${key}`}>
              {key === "year" ? (
                <b>{value[key]}</b>
              ) : (
                <>
                  <div style={{ textTransform: "capitalize" }}>
                    {key.split("_").join(" ")}
                  </div>
                  {Array.isArray(value[key]) && (
                    <div>
                      {value[key] && value[key].isNotEmpty
                        ? value[key].join(",")
                        : "N/A"}
                    </div>
                  )}
                  {!Array.isArray(value[key]) && (
                    <div>{value[key] ?? "N/A"}</div>
                  )}
                </>
              )}
            </li>
          ))
        )}
      </ul>
    </>
  );
};

export default Taxes;
