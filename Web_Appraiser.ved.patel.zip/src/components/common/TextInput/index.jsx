import React from "react";
import { useTranslation } from "react-i18next";
const TextInput = (props) => {
  const { t } = useTranslation();
  const {
    type,
    name,
    placeholder,
    value,
    onChange,
    onBlur,
    error,
    touched,
    disabled,
    showRules = false,
  } = props;

  return (
    <div className="form-group">
      <div className="inner-form-group">
        <input
          type={type}
          className="form-control"
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          disabled={disabled}
        />
        {props.icon ? props.icon : ""}
        <div
          className={
            showRules
              ? "password_view_status inner_pswd_position showRules"
              : "password_view_status inner_pswd_position "
          }
          id="passwordstrgth"
          hidden=""
        >
          <div className="password-relative">
            <ul className="list-unstyled">
              <li className="">
                <span className="validation-content">
                  {t("ERROR_MESSAGES.showPasswordRules.min8Char")}
                </span>
              </li>
              <li className="">
                <span className="validation-content">
                  {t("ERROR_MESSAGES.showPasswordRules.oneSpecialChar")}
                </span>
              </li>
              <li className="">
                <span className="validation-content">
                  {t("ERROR_MESSAGES.showPasswordRules.oneNumericChar")}
                </span>
              </li>
              <li className="">
                <span className="validation-content">
                  {t("ERROR_MESSAGES.showPasswordRules.oneUpperLowerChar")}
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {error && touched && <div className="form-error">{t(error)}</div>}
    </div>
  );
};

export default TextInput;
