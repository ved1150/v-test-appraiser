/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect, useCallback } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import Tooltip from "@mui/material/Tooltip";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Pagination from "@mui/material/Pagination";
import { useTranslation } from "react-i18next";
import "./index.scss";
import {
  DATE_FORMAT,
  jobOrdersPerPage,
  ROLE,
} from "./../../constants/appConstant";
import Button from "../common/Button";
import NoDataView from "../JobOrders/JobOrderDetails/Common/noDataView";
import TextInput from "../common/TextInput";
import {
  fetchTransactionHistory,
  fetchTransactionStatus,
  exportTransactionHistory,
} from "../../actions/transactionHistoryAction";
import TransactionHistoryFiltersModal from "./TransactionHistoryFiltersModal";
import moment from "moment";
import { generateHtmlTransactionPdf } from "./TransactionPdfGeneration";
import { downloadPDFFromHTML } from "../../actions/measurementAction";
import CustomPagination from "../common/CustomPagination";

const TransactionHistory = (props) => {
  const { t } = useTranslation();
  const tenantTheme = useSelector(
    (state) => state?.whiteLabel?.getTenantThemeSuccess
  );
  const cachedImages = useSelector(
    (state) => state?.cachedCapturedImages?.cachedCapturedImages
  );
  const tableHead = [
    { key: "jobOrderID", label: t("WEB_LABELS.Job_Order_ID"), width: "10%" },
    {
      key: "customerName",
      label: t("WEB_LABELS.Customer_Name") + "\n" + t("WEB_LABELS.Address"),
      width: "15%",
    },
    { key: "cardNumber", label: t("WEB_LABELS.Card_Number"), width: "15%" },
    { key: "amount", label: t("Amount"), width: "15%" },
    { key: "transactionStatus", label: t("Transaction_Status"), width: "20%" },
    {
      key: "transactionDateTime",
      label: t("Transaction_Date_Time"),
      width: "20%",
    },
    {
      key: "action",
      label: t("WEB_LABELS.Action"),
      disableSorting: true,
      width: "15%",
    },
  ];
  const [pageNo, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [startPoint, setStartPoint] = useState(1);
  const [endPoint, setEndPoint] = useState(pageSize);
  const [offset, setOffset] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [refreshJobOrder, setRefreshJoborder] = useState(false);
  const [jobOrderList, setJobrOrderList] = useState([]);
  const [searchInpValue, setSearchInpValue] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const [
    openTransactionHistoryFilterModal,
    setOpenTransactionHistoryFilterModal,
  ] = useState(false);

  const [transactionStatus, setTransactionStatus] = useState(null);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [fetchDone, setFetchDone] = useState(false);

  useEffect(() => {
    const filter = {
      page: pageNo - 1,
      size: pageSize,
      transactionStatus,
      fromDate: fromDate && moment(fromDate).format("YYYY-MM-DD"),
      toDate: toDate && moment(toDate).format("YYYY-MM-DD"),
    };

    if (searchTerm) {
      filter.searchText = searchTerm;
    }
    setFetchDone(false);
    props
      .fetchTransactionHistory(filter)
      .then((res) => {
        if (res) {
          setJobrOrderList(
            res?.payload?.data?.data?.tranactionDetailsList?.list
          );
          const count = _.get(
            res,
            [
              "payload",
              "data",
              "data",
              "tranactionDetailsList",
              "page",
              "totalCount",
            ],
            0
          );
          setTotalCount(count);
          setStartPoint(pageSize * (pageNo - 1) + 1);
          if (pageSize * pageNo > count) {
            setEndPoint(count);
          } else {
            setEndPoint(pageSize * pageNo);
          }
          const totalPage = _.get(
            res,
            [
              "payload",
              "data",
              "data",
              "tranactionDetailsList",
              "page",
              "totalPage",
            ],
            0
          );
          if (pageNo > totalPage) {
            setCurrentPage(1);
            setOffset(0);
            setStartPoint(1);
          }
        }
      })
      .finally(() => {
        setFetchDone(true);
      });

    props.fetchTransactionStatus({});
  }, [
    pageNo,
    pageSize,
    refreshJobOrder,
    searchTerm,
    transactionStatus,
    fromDate,
    toDate,
  ]);

  const handlePageSize = (e) => {
    setOffset(0);
    setCurrentPage(1);
    setPageSize(e.target.value);
  };

  const handlePagination = (event, value) => {
    setOffset(value);
    setCurrentPage(value);
  };

  const handleJobOrder = () => {
    setRefreshJoborder(!refreshJobOrder);
  };

  // Search Start

  const handleSearchChange = (value) => {
    setSearchTerm(value);
  };

  const debounceSearchFn = useCallback(
    _.debounce((value) => handleSearchChange(value), 500),
    []
  );

  const debouncedSearchChange = (event) => {
    const {
      target: { value },
    } = event;
    setSearchInpValue(value);

    debounceSearchFn(value.trim());
  };

  // Search End

  return (
    <section className="content-wapper">
      <TransactionHistoryFiltersModal
        openTransactionHistoryFilterModal={openTransactionHistoryFilterModal}
        setOpenTransactionHistoryFilterModal={
          setOpenTransactionHistoryFilterModal
        }
        transactionStatus={transactionStatus}
        setTransactionStatus={setTransactionStatus}
        fromDate={fromDate}
        setFromDate={setFromDate}
        toDate={toDate}
        setToDate={setToDate}
      />
      <h1>{t("Transaction_History")}</h1>
      <div className="common-panel panel-table-height">
        <div className="panel-body tx-history-list-body">
          <div class="breadcrub-button">
            <div class="right-side">
              {/* <b style={{ fontSize: 18 }}>
                Available Credits: $
                {_.get(
                  props,
                  [
                    "transactionHistory",
                    "fetchTransactionHistorySuccess",
                    "data",
                    "data",
                    "creditAmount",
                  ],
                  0
                )}
              </b>{" "}
              &emsp; */}
              <Button
                disabled={
                  props.transactionHistory.exportTransactionHistoryStart
                    ? true
                    : null
                }
                className="blue-btn"
                onClick={() => {
                  const filter = {
                    transactionStatus,
                    fromDate: fromDate && moment(fromDate).format("YYYY-MM-DD"),
                    toDate: toDate && moment(toDate).format("YYYY-MM-DD"),
                  };

                  if (searchTerm) {
                    filter.searchText = searchTerm;
                  }

                  props
                    .exportTransactionHistory(filter)
                    .then((data) => {
                      const contentType = _.get(data, [
                        "headers",
                        "content-type",
                      ]);
                      const blob = new Blob([data.data], {
                        type: contentType,
                      });
                      if (
                        window.navigator &&
                        window.navigator.msSaveOrOpenBlob
                      ) {
                        window.navigator.msSaveOrOpenBlob(blob);
                        return;
                      }
                      const url = window.URL.createObjectURL(blob);
                      let link = document.createElement("a");
                      link.href = url;
                      const filename = "TransactionHistory.csv";
                      link.setAttribute("download", filename);
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    })
                    .catch((error) => {});
                }}
              >
                {props.transactionHistory.exportTransactionHistoryStart
                  ? t("Exporting")
                  : t("Export_All")}
              </Button>
            </div>
          </div>
          <div class="filter-view-segment">
            <ul class="filter-view-list">
              {transactionStatus && (
                <li class="filter-list-item">
                  <div class="list-view">
                    {t("Transaction_Status")}: <span>{transactionStatus}</span>{" "}
                    <button
                      onClick={() => {
                        setTransactionStatus(null);
                      }}
                    >
                      <i class="icon-close-image"></i>
                    </button>
                  </div>
                </li>
              )}
              {fromDate && toDate && (
                <li class="filter-list-item">
                  <div class="list-view">
                    {t("Transaction_Date")}:{" "}
                    <span>
                      {moment(fromDate).format("MM/DD/YYYY")} -{" "}
                      {moment(toDate).format("MM/DD/YYYY")}
                    </span>{" "}
                    <button
                      onClick={() => {
                        setFromDate(null);
                        setToDate(null);
                      }}
                    >
                      <i class="icon-close-image"></i>
                    </button>
                  </div>
                </li>
              )}
            </ul>
          </div>
          <div className="filter-box">
            <div className="show-entries">
              {t("COMMON_MESSAGES.Show")}
              <select onChange={handlePageSize}>
                {jobOrdersPerPage.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.displayName}
                  </option>
                ))}
              </select>
              {t("COMMON_MESSAGES.entries")}
            </div>
            <div className="filter-segment">
              <div className="search-box">
                <TextInput
                  className="form-control"
                  type="text"
                  name="search"
                  value={searchInpValue}
                  onChange={debouncedSearchChange}
                  placeholder={t("WEB_LABELS.Search")}
                  icon={
                    <div className="search-icon">
                      <i className="icon-search"></i>
                    </div>
                  }
                />
              </div>
              <div className="filter-button">
                <button
                  className="blue-btn"
                  onClick={() => {
                    setOpenTransactionHistoryFilterModal(
                      !openTransactionHistoryFilterModal
                    );
                  }}
                >
                  <i className="icon-filter" style={{ fontSize: 12 }}></i>
                  {t("BUTTONS.Filter")}
                </button>
              </div>
            </div>
          </div>
          {fetchDone && totalCount !== 0 ? (
            <TableContainer>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    {tableHead.map((head, key) =>
                      head.key === "customerName" ? (
                        <TableCell style={{ width: head.width }} key={key}>
                          <div>{head.label.split("\n")[0]}</div>
                          <div style={{ fontWeight: "normal" }}>
                            {head.label.split("\n")[1]}
                          </div>
                        </TableCell>
                      ) : (
                        <TableCell style={{ width: head.width }} key={key}>
                          {head.label}
                        </TableCell>
                      )
                    )}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {props?.transactionHistory?.fetchTransactionHistorySuccess?.data?.data?.tranactionDetailsList?.list?.map(
                    (d, id) => {
                      return (
                        <TableRow key={d.id}>
                          <TableCell scope="row">{d.jobOrderNumber}</TableCell>
                          <TableCell>
                            {d.customerName ? d.customerName : "-"}
                            <br />
                            {d.address ? d.address : "-"}
                          </TableCell>
                          <TableCell>{d.cardNumber}</TableCell>
                          <TableCell>
                            $
                            {d.refundStatus === "PARTIALLY"
                              ? d.refundAmount
                              : d.amountPaid}
                          </TableCell>
                          <TableCell>{d.transactionStatus}</TableCell>
                          <TableCell>
                            {d.transactionDateTime
                              ? d.transactionDateTime
                              : "-"}
                          </TableCell>
                          <TableCell>
                            <div className="action-wrapper">
                              <ul className="btn-list">
                                {(d?.transactionStatus === "Paid" ||
                                  d?.transactionStatus === "Refund") && (
                                  <li>
                                    <Tooltip title={t("View_PDF")} arrow>
                                      <Button
                                        onClick={() => {
                                          const htmlTemplate =
                                            generateHtmlTransactionPdf({
                                              ...tenantTheme,
                                              ...d,
                                              cachedTenantLogo:
                                                cachedImages[
                                                  tenantTheme?.tenantLogo
                                                ],
                                            });
                                          props
                                            .downloadPDFFromHTML({
                                              htmlContent: htmlTemplate,
                                            })
                                            .then((pdfData) => {
                                              window.open(
                                                window.URL.createObjectURL(
                                                  pdfData.data
                                                ),
                                                "_blank"
                                              );
                                            });
                                        }}
                                      >
                                        <i className="icon-Download-PDF"></i>
                                      </Button>
                                    </Tooltip>
                                  </li>
                                )}
                              </ul>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    }
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <div className="no-data-found-container">
              {!fetchDone ? (
                <div className="no-data-found">
                  <div className="box">
                    <div className="loader-spin"></div>
                  </div>
                </div>
              ) : (
                <NoDataView
                  text={t("Transaction_History")}
                  icon={"app-icon-Transaction-History"}
                />
              )}
            </div>
          )}

          <div className="pagination-wrapper">
            {totalCount !== 0 && (
              <span className="show-results">
                {t("COMMON_MESSAGES.Showing")} {startPoint}{" "}
                {t("COMMON_MESSAGES.to")} {endPoint} {t("COMMON_MESSAGES.of")}{" "}
                {totalCount} {t("COMMON_MESSAGES.entries")}
              </span>
            )}

            <CustomPagination
              shape="rounded"
              limit={pageSize}
              offset={offset}
              total={_.get(
                props,
                [
                  "transactionHistory",
                  "fetchTransactionHistorySuccess",
                  "data",
                  "data",
                  "tranactionDetailsList",
                  "page",
                  "totalCount",
                ],
                0
              )}
              count={_.get(
                props,
                [
                  "transactionHistory",
                  "fetchTransactionHistorySuccess",
                  "data",
                  "data",
                  "tranactionDetailsList",
                  "page",
                  "totalPage",
                ],
                0
              )}
              page={pageNo}
              onChange={handlePagination}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

const mapStateToProps = (state) => {
  return {
    transactionHistory: state.transactionHistory,
  };
};

export default connect(mapStateToProps, {
  fetchTransactionHistory,
  fetchTransactionStatus,
  exportTransactionHistory,
  downloadPDFFromHTML,
})(TransactionHistory);
