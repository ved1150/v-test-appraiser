import React, { useEffect, useState } from "react";
import Collapse from "@mui/material/Collapse";
import _ from "lodash";
import Button from "../../../common/Button";
import Questionnaire from "./Questionnaire";
import { formatPhoneNumber } from "./../../../../helpers/commonJSFunction";

import { useTranslation } from "react-i18next";
import moment from "moment";
const DetailsTab = (props) => {
  const { t } = useTranslation();
  const [callDetails, setCallDetails] = useState([
    ...props.details.fetchCallDetailsSuccess,
  ]);

  const [showQuestionnaire, setShowQuestionnaire] = useState(false);

  useEffect(() => {
    props.fetchDetails(props.jobOrderId);
    props.fetchCallDetails(props.jobOrderId).then((res) => {
      if (res) {
        setCallDetails([...res]);
      } else {
      }
    });
  }, []);

  const toggleSelectedDiv = (id, value) => {
    let tempArr = [...callDetails];
    tempArr = tempArr.map((temp, key) => {
      if (key === id) {
        temp.collapseIn = value;
      }
      return temp;
    });
    setCallDetails([...tempArr]);
  };

  const toggleQuestionnaire = () => {
    setShowQuestionnaire(!showQuestionnaire);
  };

  const appointmentScheduledDate = () => {
    const {
      jobOrders,
      details: { fetchDetailsSuccess },
    } = props;
    if (!_.isEmpty(jobOrders)) {
      const matchedJobOrder = jobOrders.find(
        (x) => x.id === fetchDetailsSuccess.id
      );

      if (matchedJobOrder?.jobOrderAppointment?.slotDate) {
        const slotDate = moment(
          matchedJobOrder.jobOrderAppointment.slotDate
        ).format("MM/DD/YYYY");

        const slotStartTime = moment
          .utc(matchedJobOrder.jobOrderAppointment.sloteDateStartTime)
          .local()
          .format("hh:mm A");

        const slotEndTime = moment
          .utc(matchedJobOrder.jobOrderAppointment.slotDateEndTime)
          .local()
          .format("hh:mm A");

        return `${slotDate} ${slotStartTime}-${slotEndTime}`;
      } else {
        return "--";
      }
    }
    return null;
  };

  return (
    <>
      <div>
        <div className="details-height scroll-bar-style">
          <div className="job-panel">
            <div className="details-head">
              {t("WEB_LABELS.Job_Order_Details")}
            </div>
            <div className="details-body">
              <div style={{ borderBottom: "0px" }} className="detail-list">
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Job_Order_ID")}:{" "}
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "orderNo"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Job_Order_Assignee")}:
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "assignee"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Property_Type")}:
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "propertyType"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Assigned_Date")}:
                    <span>
                      {_.get(
                        props,
                        [
                          "details",
                          "fetchDetailsSuccess",
                          "formatedAssignedDate",
                        ],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Job_Order_Status")}:
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "jobOrderStatus"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Appointment_Scheduled_Date")}:
                    <span>{appointmentScheduledDate()}</span>
                  </h4>
                </div>
              </div>
              <div className="detail-list">
                <div className="box">
                  <h4>
                    {t("Job_Order_Source")}:
                    <span>
                      {props?.details?.fetchDetailsSuccess?.jobOrderSource
                        ? props.details.fetchDetailsSuccess.jobOrderSource
                        : "--"}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("Job_Order_Type")}:
                    <span>
                      {props?.details?.fetchDetailsSuccess?.jobOrderType
                        ? props.details.fetchDetailsSuccess.jobOrderType
                        : "--"}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("Demo_Job_Order")}:
                    <span>
                      {_.isUndefined(
                        props?.details?.fetchDetailsSuccess?.isDemoJobOrder
                      )
                        ? "--"
                        : props?.details?.fetchDetailsSuccess?.isDemoJobOrder
                        ? t("COMMON_MESSAGES.Yes")
                        : t("COMMON_MESSAGES.No")}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("Payment_Status")}:
                    <span>
                      {props?.details?.fetchDetailsSuccess?.paymentStatus}
                    </span>
                  </h4>
                </div>
                <div className="box"></div>
                <div className="box"></div>
              </div>
            </div>
          </div>

          <div className="job-panel">
            <div className="details-head">
              {t("WEB_LABELS.Customer_Details")}
            </div>
            <div className="details-body">
              <div className="detail-list">
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Name")}:
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "name"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Address")}:
                    <a
                      href={
                        "http://maps.google.co.in/maps?q=" +
                        _.get(props, [
                          "details",
                          "fetchDetailsSuccess",
                          "address",
                        ])
                      }
                      className="address"
                      target="_blank"
                      rel="noreferrer"
                    >
                      <i className="icon-address-location"></i>
                    </a>
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "address"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Phone_Number")}
                    <span>
                      {formatPhoneNumber(
                        _.get(
                          props,
                          ["details", "fetchDetailsSuccess", "phone"],
                          "--"
                        )
                      )}
                    </span>
                  </h4>
                </div>
                <div className="box">
                  <h4>
                    {t("WEB_LABELS.Email")}:
                    <span>
                      {_.get(
                        props,
                        ["details", "fetchDetailsSuccess", "email"],
                        "--"
                      )}
                    </span>
                  </h4>
                </div>
              </div>
            </div>
          </div>

          {_.size(callDetails) !== 0 &&
            callDetails.map((detail, id) => (
              <div className="job-panel" key={id}>
                <div className="details-head">
                  {t("WEB_LABELS.Call_Details")} {id + 1}
                  {detail.collapseIn && (
                    <button
                      className="image"
                      onClick={() => toggleSelectedDiv(id, false)}
                    >
                      <i className="icon-minus"></i>
                    </button>
                  )}
                  {!detail.collapseIn && (
                    <button
                      className="image"
                      onClick={() => toggleSelectedDiv(id, true)}
                    >
                      <i className="icon-plus"></i>
                    </button>
                  )}
                </div>
                <Collapse in={detail.collapseIn}>
                  <div className="details-body">
                    <div className="detail-list">
                      <div className="box">
                        <h4>
                          {t("WEB_LABELS.No_of_Participants")}:{" "}
                          <span>{_.size(detail.participants)}</span>
                        </h4>
                      </div>
                      <div className="box">
                        <h4>
                          {t("WEB_LABELS.Call_Recorded")}:
                          <span>{detail.isRecording}</span>
                        </h4>
                      </div>
                      <div className="box">
                        <h4>
                          {t("WEB_LABELS.Call_Start")}:
                          <span>{detail.formatedCallStart}</span>
                        </h4>
                      </div>
                      <div className="box">
                        <h4>
                          {t("WEB_LABELS.Call_End")}:
                          <span>{detail.formatedCallEnd}</span>
                        </h4>
                      </div>
                      <div className="box">
                        <h4>
                          {t("WEB_LABELS.Duration")}:
                          <span>{detail.duration}</span>
                        </h4>
                      </div>
                    </div>
                    {_.size(detail.participants) !== 0 &&
                      detail.participants.map((participant, pid) => (
                        <div className="detail-list" key={pid}>
                          <div className="box">
                            <h4>
                              {t("WEB_LABELS.Name")}:{" "}
                              <span>{participant.name}</span>
                            </h4>
                          </div>
                          <div className="box">
                            <h4>
                              {t("WEB_LABELS.Cell_Phone")}:{" "}
                              <span>
                                {formatPhoneNumber(participant.mobile)}
                              </span>
                            </h4>
                          </div>
                          <div className="box">
                            <h4>
                              {t("WEB_LABELS.Email")}:
                              <span>{participant.email}</span>
                            </h4>
                          </div>
                        </div>
                      ))}
                  </div>
                </Collapse>
              </div>
            ))}
        </div>
        <div className="job-button-list">
          <ul>
            {/* <li>
              <Button className="blue-btn">
                <i className="icon-inspection-form"></i>Inspection Form
              </Button>
            </li> */}
            <li>
              <Button className="blue-btn" onClick={toggleQuestionnaire}>
                <i className="icon-Questionnaire-Form"></i>
                {t("BUTTONS.Questionnaire_Form")}
              </Button>
            </li>
            {/* <li>
              <Button className="blue-btn">
                <i className="icon-Measurement-Details"></i>Measurement Details
              </Button>
            </li> */}
            {/* <li>
            <Button className="blue-btn">
              <i className="icon-Attach-Document"></i>Attach Document
            </Button>
          </li> */}
          </ul>
        </div>
      </div>
      {showQuestionnaire && (
        <Questionnaire
          showQuestionnaire={showQuestionnaire}
          toggleQuestionnaire={toggleQuestionnaire}
          jobOrderId={props.jobOrderId}
        />
      )}
    </>
  );
};

export default DetailsTab;
