import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import Button from "../../common/Button";
import { floorName } from "../../../constants/enums";
import moment from "moment/moment";
import { completeJobOrder } from "../../../actions/jobOrderDetailsAction";
import { customToast } from "../../../helpers/customToast";

const CompleteTechnicianJobOrder = (props) => {
  const [selectedFloorScanId, setSelectedFloorScanId] = useState(null);
  const floorScanReportList = useSelector(
    (state) => state?.technicianJob?.fetchFloorScanReportListSuccess?.data?.data
  );
  const dispatch = useDispatch();
  return (
    <div
      className={
        props.openCompleteInspectionModal
          ? "comman-modal complete-job-order right-side open"
          : "comman-modal complete-job-order right-side"
      }
    >
      <div className="comman-modal-main">
        <div className="side-head">
          <span className="icon">
            <i className="icon-complete-job-order"></i>
          </span>
          Select Report
          <button
            className="close-modal"
            onClick={() => props.setOpenCompleteInspectionModal(false)}
          >
            <i className="icon-close-image"></i>
          </button>
        </div>
        <div className="comman-modal-body scroll-bar-style">
          <div>
            {floorScanReportList?.map((e) => {
              return (
                <div key={e.floorScanId}>
                  <input
                    type="radio"
                    name="floor-scan-report-list"
                    value={e.floorScanId}
                    onChange={(fsrlRadio) => {
                      setSelectedFloorScanId(fsrlRadio.target.value);
                    }}
                  />
                  &emsp;
                  <span style={{ fontSize: 16, fontWeight: 450 }}>
                    {
                      floorName
                        .filter((f) => e?.floorScanIndex === f.id)
                        ?.map((f) => f.value)?.[0]
                    }
                    &nbsp; ({e.floorScanNumber}) &nbsp;
                    <span style={{ color: "#A9A9A9", float: "right" }}>
                      {moment(e.floorScanUploadedAt).isValid() &&
                        moment
                          .utc(e.floorScanUploadedAt)
                          .local()
                          .format("MM/DD/YYYY hh:mm a")}
                    </span>
                  </span>
                  <hr style={{ marginRight: -10, marginLeft: -10 }} />
                </div>
              );
            })}
          </div>
          <br></br>
          <span>
            <b>Note:</b> Please Select floor plan which needs to be added in the
            final report.
          </span>
          <div className="text-center">
            <Button
              disabled={!selectedFloorScanId ? true : null}
              className="blue-btn"
              onClick={() => {
                if (selectedFloorScanId) {
                  let formData = new FormData();
                  formData.append(
                    "jobOrderCompleteRequest",
                    JSON.stringify({
                      floorScanIds: [selectedFloorScanId],
                      jobOrderId: props.selectedJobOrderIdForCompleteInspection,
                    })
                  );
                  dispatch(completeJobOrder(formData))
                    .then((response) => {
                      if (response?.data?.status === "JOB_ORDER_COMPLETED") {
                        customToast.success("Job Order Completed Successfully");
                      }
                    })
                    .finally(() => {
                      props.setOpenCompleteInspectionModal(false);
                      props.setRefresh(!props.refresh);
                    });
                }
              }}
            >
              Complete Inspection
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompleteTechnicianJobOrder;
