import * as actionTypes from "../actions/actionTypes";

const relarState = {
  fetchRelarStart: false,
  fetchRelarSuccess: [],
  fetchRelarError: null,
};

const defaultStates = {
  ...relarState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_RELAR_START:
      return {
        ...state,
        fetchRelarStart: true,
        fetchRelarSuccess: [],
        fetchRelarError: null,
      };
    case actionTypes.FETCH_RELAR_SUCCESS:
      return {
        ...state,
        fetchRelarStart: false,
        fetchRelarSuccess: action.payload,
        fetchRelarError: null,
      };
    case actionTypes.FETCH_RELAR_ERROR:
      return {
        ...state,
        fetchRelarStart: false,
        fetchRelarSuccess: [],
        fetchRelarError: action.payload,
      };
    default:
      return state;
  }
};
