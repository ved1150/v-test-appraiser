import * as actionTypes from "./actionTypes";
import mesurementService from "../services/measurementService";
import { StartLoading, StopLoading } from "./UIAction";
const startMesurementJson = () => {
  return {
    type: actionTypes.MEASUREMENT_JSON_START,
  };
};

const successMesurementJson = (data) => {
  return {
    type: actionTypes.MESUREMENT_JSON_SUCCESS,
    payload: data,
  };
};
const errorMesurementJson = (error) => {
  return {
    type: actionTypes.MESUREMENT_JSON_ERROR,
    payload: error,
  };
};

export function loadMeasurementJson(JobOrderID) {
  return (dispatch) => {
    dispatch(startMesurementJson());
    dispatch(StartLoading());
    return mesurementService
      .get(JobOrderID)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successMesurementJson(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorMesurementJson(err));
      });
  };
}

const startAvailableMeasurementData = () => {
  return {
    type: actionTypes.AVAILABLE_MEASUREMENT_START,
  };
};

const successAvailableMeasurementData = (data) => {
  return {
    type: actionTypes.AVAILABLE_MEASUREMENT_SUCCESS,
    payload: data,
  };
};
const errorAvailableMeasurementData = (error) => {
  return {
    type: actionTypes.AVAILABLE_MEASUREMENT_ERROR,
    payload: error,
  };
};

export function loadAvailableMeasurementData(JobOrderID) {
  return (dispatch) => {
    dispatch(startAvailableMeasurementData());
    dispatch(StartLoading());
    return mesurementService
      .getAvailableMeasurementData(JobOrderID)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successAvailableMeasurementData(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorAvailableMeasurementData(err));
      });
  };
}

const startFloorScanIndex = () => {
  return {
    type: actionTypes.FLOOR_SCAN_INDEX_START,
  };
};

const successFloorScanIndex = (data) => {
  return {
    type: actionTypes.FLOOR_SCAN_INDEX_SUCCESS,
    payload: data,
  };
};
const errorFloorScanIndex = (error) => {
  return {
    type: actionTypes.FLOOR_SCAN_INDEX_ERROR,
    payload: error,
  };
};

export function loadFloorScanIndex(JobOrderID) {
  return (dispatch) => {
    dispatch(startFloorScanIndex());
    dispatch(StartLoading());
    return mesurementService
      .getFloorScanIndex(JobOrderID)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFloorScanIndex(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFloorScanIndex(err));
      });
  };
}

export function saveMeasurementJson(data) {
  return (dispatch) => {
    return mesurementService.save(data);
  };
}

export const fetchEstatedData = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    return mesurementService
      .requestEstatedData(data)
      .then((data) => {
        dispatch(StopLoading());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
      });
  };
};

// CREATE MEASUREMENT ACTIONS START
const startCreateMeasurement = () => {
  return {
    type: actionTypes.CREATE_MEASUREMENT_START,
  };
};

const successCreateMeasurement = (data) => {
  return {
    type: actionTypes.CREATE_MEASUREMENT_SUCCESS,
    payload: data,
  };
};
const errorCreateMeasurement = (error) => {
  return {
    type: actionTypes.CREATE_MEASUREMENT_ERROR,
    payload: error,
  };
};

export function createMeasurement(data) {
  return (dispatch) => {
    dispatch(startCreateMeasurement());
    dispatch(StartLoading());
    return mesurementService
      .create(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successCreateMeasurement(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorCreateMeasurement(err));
      });
  };
}

const startFloorScanJsons = () => {
  return {
    type: actionTypes.FLOORSCAN_JSONS_START,
  };
};

const successFloorScanJsons = (data) => {
  return {
    type: actionTypes.FLOORSCAN_JSONS_SUCCESS,
    payload: data,
  };
};
const errorFloorScanJsons = (error) => {
  return {
    type: actionTypes.FLOORSCAN_JSONS_ERROR,
    payload: error,
  };
};

export function loadFloorScanJsons(data) {
  return (dispatch) => {
    dispatch(startFloorScanJsons());
    dispatch(StartLoading());
    return mesurementService
      .getFloorScanJsons(data)
      .then(({ data }) => {
        dispatch(StopLoading());
        dispatch(successFloorScanJsons(data.data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFloorScanJsons(err));
        throw err;
      });
  };
}
// CREATE MEASUREMENT ACTIONS END

const startDownloadReportData = () => {
  return {
    type: actionTypes.DOWNLOAD_REPORT_START,
  };
};

const successDownloadReportData = (data) => {
  return {
    type: actionTypes.DOWNLOAD_REPORT_SUCCESS,
    payload: data,
  };
};
const errorDownloadReportData = (error) => {
  return {
    type: actionTypes.DOWNLOAD_REPORT_ERROR,
    payload: error,
  };
};
export function loadDownloadReportMeasurementJson(JobOrderID) {
  return (dispatch) => {
    dispatch(startDownloadReportData());
    dispatch(StartLoading());
    return mesurementService
      .getDownloadReportMeasurementJson(JobOrderID)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successDownloadReportData(data));
        return data;
      })
      .catch((err) => {
        dispatch(errorDownloadReportData(err));
        dispatch(StopLoading());
        return err;
      });
  };
}
export function downloadPDFFromHTML(body) {
  return (dispatch) => {
    dispatch(StartLoading());
    return mesurementService
      .downloadPDFFromHTML(body)
      .then((data) => {
        dispatch(StopLoading());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        return err;
      });
  };
}

export function sendReportTOHomeOwner(jobOrderId, htmlContent) {
  return (dispatch) => {
    dispatch(StartLoading());
    return mesurementService
      .sendReportTOHomeOwner(jobOrderId, htmlContent)
      .then(({ data }) => {
        dispatch(StopLoading());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        throw err;
      });
  };
}
