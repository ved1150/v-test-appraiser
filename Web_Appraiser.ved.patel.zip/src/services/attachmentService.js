import * as _ from "lodash";
import { getFileFormData } from "../helpers";
import api from "./apis/api";
import { deHydrateAttachments, hydrateAttachments } from "./transformers";

class AttachmentService {
  getAttachmentsByJobOrderId(data) {
    return api.attachment
      .getAttachmentsByJobOrderId(deHydrateAttachments(data))
      .then((res) => hydrateAttachments(_.get(res, "data.data", [])));
  }

  addAttachment(file, fileName, extraPayload) {
    const fileFormData = getFileFormData(file, fileName, extraPayload);
    return api.attachment.addAttachment(fileFormData);
  }

  deleteAttachment(attachmentId) {
    return api.attachment.deleteAttachment(attachmentId);
  }

  downloadAttachment(attachmentId) {
    return api.attachment.downloadAttachment(attachmentId);
  }

  downloadAttachments(payload) {
    return api.attachment.downloadAttachments(payload);
  }
}

export default new AttachmentService();
