import * as actionTypes from "../actions/actionTypes";
import { STATUS_TENANT_NOT_FOUND } from "../constants/appConstant";
import whiteLabelService from "../services/whiteLabelService";

const getTenantThemeStart = () => {
  return {
    type: actionTypes.GET_TENANT_THEME_START,
  };
};

const getTenantThemeSuccess = (data) => {
  return {
    type: actionTypes.GET_TENANT_THEME_SUCCESS,
    payload: data,
  };
};

const getTenantThemeError = (error) => {
  return {
    type: actionTypes.GET_TENANT_THEME_ERROR,
    payload: error,
  };
};

export const getTenantTheme = () => async (dispatch) => {
  dispatch(getTenantThemeStart());
  return whiteLabelService
    .getTheme()
    .then((response) => {
      if (response?.data?.data) {
        const {
          headerBackgroundColor,
          headerTextColor,
          buttonBackgroundColor,
          buttonTextColor,
          linkTextColor,
        } = response?.data?.data;
        if (headerBackgroundColor) {
          document
            .querySelector(":root")
            .style.setProperty("--header_bg_color", headerBackgroundColor);
        }
        if (headerTextColor) {
          document
            .querySelector(":root")
            .style.setProperty("--header_text_color", headerTextColor);
        }
        if (buttonBackgroundColor) {
          document
            .querySelector(":root")
            .style.setProperty("--button_bg_color", buttonBackgroundColor);
        }
        if (buttonTextColor) {
          document
            .querySelector(":root")
            .style.setProperty("--button_text_color", buttonTextColor);
        }
        if (linkTextColor) {
          document
            .querySelector(":root")
            .style.setProperty("--link_color", linkTextColor);
        }
      }
      dispatch(getTenantThemeSuccess(response?.data?.data));
      return response;
    })
    .catch((error) => {
      dispatch(getTenantThemeError(error));
      if (
        error?.response?.data?.status === STATUS_TENANT_NOT_FOUND &&
        !window.location.host.includes("localhost")
      ) {
        window.location.href = `${process.env.REACT_APP_PORTAL_URL}invalid-domain`;
      } else {
        throw error;
      }
    });
};
