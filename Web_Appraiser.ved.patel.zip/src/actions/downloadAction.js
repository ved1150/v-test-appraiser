import * as actionTypes from "./actionTypes";

export const startFileDownload = (payload) => {
  return {
    type: actionTypes.DOWNLOAD_FILE_START,
    payload,
  };
};

export const stopFileDownload = () => {
  return {
    type: actionTypes.DOWNLOAD_FILE_STOP,
  };
};
