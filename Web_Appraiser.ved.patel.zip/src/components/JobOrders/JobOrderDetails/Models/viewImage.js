import React, { useState } from "react";
import AsyncImage from "../../../common/AsyncImage";

const ViewImage = (props) => {
  const [currentIndex, setCurrentIndex] = useState(
    props.selectedImageIndexForView
  );

  const handlePrevBtn = () => {
    setCurrentIndex(currentIndex - 1);
  };

  const handleNextBtn = () => {
    setCurrentIndex(currentIndex + 1);
  };

  return (
    <div className="download_images_sec">
      <div className="download_img_header">
        <div className="image_count">
          <p>
            {currentIndex + 1} / {props.imageList.length}
          </p>
        </div>
        <div className="download_img_btn">
          <div className="download_img_icon">
            {/* <button type="button"><i className="icon-play"></i></button>
                <button type="button"><i className="icon-full-screen"></i></button>
                <button type="button"><i className="icon-download-img"></i></button> */}
            <button onClick={props.toggleViewImage} type="button">
              <i className="icon-close-image"></i>
            </button>
          </div>
        </div>
      </div>
      {currentIndex != 0 && (
        <div className="left_arrow">
          <button onClick={() => handlePrevBtn()} type="button">
            <i className="icon-previous-arrow"></i>
          </button>
        </div>
      )}
      {currentIndex != props.imageList.length - 1 && (
        <div className="right_arrow">
          <button
            disabled={currentIndex == props.imageList.length - 1}
            onClick={() => handleNextBtn()}
            type="button"
          >
            <i className="icon-next-arrow"></i>
          </button>
        </div>
      )}
      <div className="image_content">
        <AsyncImage imageUrl={props.imageList[currentIndex].original} />
      </div>
    </div>
  );
};

export default ViewImage;
