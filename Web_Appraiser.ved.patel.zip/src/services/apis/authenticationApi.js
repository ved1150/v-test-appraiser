import api from "./api";

export default class AuthenticationAPI {
  fetchToken(data) {
    return api.post(`/user/verify-access-token?access=${data}`, "");
  }

  logIn(formData, headerData) {
    return api.post("user/login", formData, headerData);
  }

  forgotPassword(formData) {
    return api.post("user/forgot-password", formData);
  }

  resetPassword(formData) {
    return api.post("user/reset-password", formData);
  }

  signOut() {
    return api.delete("/user/logout");
  }

  fetchLink(payload) {
    return api.get(`/getlink?encToken=${encodeURIComponent(payload)}`);
  }

  switchTenant(tenantSubDomain, headerData) {
    return api.get(
      `/switch-tenant?tenantSubDomain=${tenantSubDomain}`,
      headerData
    );
  }

  switchTechnician(headerData, subDomain) {
    return api.post(`/technician/validate-token/${subDomain}`, headerData);
  }

  fetchStates() {
    return api.get("/master-state");
  }
}
