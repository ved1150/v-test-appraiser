import api from "./apis/api";
import { hydratePDRDetails } from "./transformers/jobOrderDetailsTransformer";

class fetchPDRDetails {
  fetchPDRDetails(data) {
    return api.PDRReports.fetchPDRDetails(data).then(hydratePDRDetails);
  }
}

export default new fetchPDRDetails();
