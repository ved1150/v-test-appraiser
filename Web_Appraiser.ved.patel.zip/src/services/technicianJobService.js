import { getFileFormData } from "../helpers";
import api from "./apis/api";
import storage from "./storage";
import {
  dyHydrateTechnicianJobOrders,
  dyHydrateFloorscanList,
  dyHydrateFloorScanStatus,
  dyHydrateFloorscanDetails,
  deHydratePlyRetryData,
} from "./transformers/technicianJobTransformer";

const USERID = "USERID";

class JobService {
  getTechnicianJobOrders(data) {
    return api.technicianJob.getTechnicianJobOrders(
      dyHydrateTechnicianJobOrders(data)
    );
  }
  deleteTechnicianJobOrders(jobOrderId) {
    return api.technicianJob.deleteTechnicianJobOrder(jobOrderId);
  }
  getUserId() {
    return storage.get(USERID);
  }
  setUserId(value) {
    storage.set(USERID, value);
  }
  getFloorscanList(data) {
    return api.technicianJob.getFloorScanList(dyHydrateFloorscanList(data));
  }
  updateFloorScanImage(data) {
    const { floorScanId, file, fileName } = data;
    const fileFormData = getFileFormData(file, fileName);
    return api.technicianJob.updateFloorScanImageAPI(floorScanId, fileFormData);
  }
  updateFloorScanStatus(data) {
    return api.technicianJob.updateFloorScanStatus(
      dyHydrateFloorScanStatus(data)
    );
  }
  getFloorscanDetail(id) {
    return api.technicianJob.getFloorScanDetail(dyHydrateFloorscanDetails(id));
  }

  plyRetry(data) {
    return api.technicianJob.plyRetry(deHydratePlyRetryData(data));
  }

  PlyRetryAfterSuccess(data) {
    return api.technicianJob.PlyRetryAfterSuccess(deHydratePlyRetryData(data));
  }

  fetchFloorScanReportList(data) {
    return api.technicianJob.fetchFloorScanReportList(data);
  }

  scanIsOkay(data) {
    return api.technicianJob.scanIsOkay(data);
  }

  getRequestRescanHistory(data) {
    return api.technicianJob.getRequestRescanHistory(data);
  }
}

export default new JobService();
