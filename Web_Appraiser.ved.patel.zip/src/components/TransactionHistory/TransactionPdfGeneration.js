export const generateHtmlTransactionPdf = (props) => {
  const {
    headerBackgroundColor,
    appraiserName,
    address,
    jobOrderAssignDate,
    jobOrderNumber,
    jobOrderType,
    customerName,
    jobOrderAddress,
    transactionId,
    transactionDateTime,
    amountPaid,
    cardType,
    appraiserEmail,
    cachedTenantLogo,
    transactionStatus,
    refundStatus,
    jobOrderCharge,
    refundAmount,
    refundDate,
  } = props;
  const htmlTemplateTransactionReport = `
<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam:wght@400;600;700&amp;display=swap" rel="stylesheet" />
<table border="0" cellpadding="0" cellspacing="0" style="border:1px solid #eee;color:#000000; font-family:Be Vietnam,sans-serif; margin:25px auto; width:600px">
    <tbody style="background:#fff">
        <tr style="background-color:#ffffff; border-color:#e9e9ff; border-style:solid; border-width:1px">
            <td style="background-color:${headerBackgroundColor}; text-align:center">
            <div style="padding:15px 0"><img src="${cachedTenantLogo}" style="vertical-align:top; width:210px" /></div>
            </td>
        </tr>
        <tr style="background-color:#ffffff; border-color:#e9e9ff; border-style:solid; border-width:1px">
            <td style="text-align:center">
            <h1 style="padding: 15px 10px 22px 10px; margin: 0;border-bottom: 1px solid #eee;line-height: 1.1;font-size: 24px;">Transaction Invoice for Job Order</h1>
            </td>
        </tr>
        <tr style="background-color:#ffffff; border-color:#e9e9ff; border-style:solid; border-width:1px">
            <td style="text-align:left">
            <div style="padding:30px 30px 40px 30px">
            <p style="padding:0;margin:0">Hi ${appraiserName},</p><br />

            <p style="10px 0 20px 0">This is a receipt for your transaction made on the RemoteVal portal for Incenter AMS job order creation. Following are the details of the transaction and newly created job order.</p>

            <div style="border:1px solid #eee;    background: #f5f5f5; border-bottom:0;width:100%;padding:10px 15px;    box-sizing: border-box;">
            <table style="width:100%;text-align:left">
                <tbody>
                    <tr>
                        <th colspan="3" style="vertical-align: top;">
                            Billing Details
                        </th>
                    </tr>
                </tbody>
            </table>
            </div>

            <div style="border:1px solid #eee;width:100%;">
            <table style="width:100%">
                <tbody>
                    <tr>
                        <td style="vertical-align: top;">
                        <div style="padding:10px 15px;">
                        <p style="margin:0;"><b>Appraiser Address</b></p>

                        <p style="margin:0">${address}</p>

                        <p style="margin:0;"><b>Email</b></p>

                        <p style="margin:0;padding-bottom:5px">${appraiserEmail}</p>
                        </div>
                        </td>
                        <td style="text-align:right">
                        <div style="padding:10px 15px;">
                        <p style="margin:0;"><b>Assign Date</b></p>

                        <p style="margin:0;padding-bottom:5px">${jobOrderAssignDate}</p>
                        </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>

            <div style="border:1px solid #eee;border-top:0;    background: #f5f5f5;width:100%;padding:10px 15px;    box-sizing: border-box;">
            <table style="width:100%;text-align:left">
                <tbody>
                    <tr>
                        <th colspan="3" style="vertical-align: top;">
                            Job Order Details
                        </th>
                    </tr>
                </tbody>
            </table>
            </div>

            <div style="border:1px solid #eee;border-top:0;width:100%;padding:10px 15px;    box-sizing: border-box;">
            <table style="width:100%;text-align:left">
                <tbody>
                    <tr>
                        <th style="width:25%">Job Order Id</th>
                        <th style="width:25%">Job Order Type</th>
                        <th style="width:50%">Customer Name, Address</th>
                    </tr>
                    <tr>
                        <td>${jobOrderNumber}</td>
                        <td>${jobOrderType}</td>
                        <td>${customerName ?? "-"},<br />
                        ${jobOrderAddress}</td>
                    </tr>
                </tbody>
            </table>
            </div>

            <div style="border:1px solid #eee;    background: #f5f5f5; width:100%;padding:10px 15px;    box-sizing: border-box;">
            <table style="width:100%;text-align:left">
                <tbody>
                    <tr>
                        <th colspan="3" style="vertical-align: top;">
                            Transaction Details
                        </th>
                    </tr>
                </tbody>
            </table>
            </div>

            <div style="border:1px solid #eee;border-top:0;width:100%;padding:10px 15px;    box-sizing: border-box;">
            <table style="width:100%;text-align:left">
                <tbody>
                    <tr>
                        <th>Transaction Id</th>
                        <th>Payment Date</th>
                        <th>Card Type</th>
                        <th>Amount</th>
                    </tr>
                    <tr>
                        <td>${transactionId}</td>
                        <td>${transactionDateTime}</td>
                        <td>${cardType}</td>
                        <td>$ ${amountPaid}</td>
                    </tr>
                </tbody>
            </table>
            </div>
            </div>
            </td>
        </tr>
        <tr style="background-color:#ffffff; border-color:#e9e9ff; border-style:solid; border-width:1px">
            <td style="text-align:center">&nbsp;</td>
        </tr>
        <tr style="background-color:#334aa6; border-color:#e9e9ff; border-style:solid; border-width:1px">
            <td style="background-color:${headerBackgroundColor}; text-align:center">
            <div style="padding:15px;color:#fff ">&copy; 2021 RemoteVal. All Rights Reserved.</div>
            </td>
        </tr>
    </tbody>
</table>`;

  const htmlTemplateTransactionRefundReport = `
<link href="https://fonts.googleapis.com/css2?family=Be+Vietnam:wght@400;600;700&amp;display=swap" />
<table border="0" cellpadding="0" cellspacing="0" style="border:1px solid #eee;color:#000;font-family:Be Vietnam,sans-serif;margin:25px auto;width:600px">
	<tbody style="background:#fff">
		<tr style="background-color:#fff;border-color:#e9e9ff;border-style:solid;border-width:1px">
			<td style="background-color:#fdad00;text-align:center">
				<div style="padding:15px 0">
					<img src="${cachedTenantLogo}" style="vertical-align:top;width:210px" />
				</div>
			</td>
		</tr>
		<tr style="background-color:#fff;border-color:#e9e9ff;border-style:solid;border-width:1px">
			<td style="text-align:center">
				<h1 style="padding:15px 10px 22px 10px;margin:0;border-bottom:1px solid #eee;line-height:1.1;font-size:24px">Refund Invoice for Job Order</h1>
			</td>
		</tr>
		<tr style="background-color:#fff;border-color:#e9e9ff;border-style:solid;border-width:1px">
			<td style="text-align:left">
				<div style="padding:30px 30px 40px 30px">
					<p style="padding:0;margin:0">Hi ${appraiserName},</p>
					<p>Your job order ${refundStatus} refunded. There are more details for your reference.</p>
					<div style="border:1px solid #eee;background:#f5f5f5;border-bottom:0;width:100%;padding:10px 15px;box-sizing:border-box">
						<table style="width:100%;text-align:left">
							<tbody>
								<tr>
									<td colspan="3" style="vertical-align:top">
										<div>
											<p style="margin:0;padding:0">
												<b>Billing Details</b>
											</p>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="border:1px solid #eee;width:100%">
						<table style="width:100%">
							<tbody>
								<tr>
									<td style="vertical-align:top">
										<div style="padding:10px 15px">
											<p style="margin:0">
												<b>Address</b>
											</p>
											<p style="margin:0">${address}</p>
											<p style="margin:0">
												<b>Email</b>
											</p>
											<p style="margin:0;padding-bottom:5px">${appraiserEmail}</p>
										</div>
									</td>
									<td style="text-align:right">
										<div style="padding:10px 15px">
											<p style="margin:0">
												<b>Refund Date</b>
											</p>
											<p style="margin:0;padding-bottom:5px">${refundDate}</p>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="border:1px solid #eee;border-top:0;background:#f5f5f5;width:100%;padding:10px 15px;box-sizing:border-box">
						<table style="width:100%;text-align:left">
							<tbody>
								<tr>
									<td colspan="3" style="vertical-align:top">
										<div>
											<p style="margin:0;padding:0">
												<b>Job Order Details</b>
											</p>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="border:1px solid #eee;border-top:0;width:100%;padding:10px 15px;box-sizing:border-box">
						<table style="width:100%;text-align:left">
							<tbody>
								<tr>
									<th style="width:25%">Job Order Id</th>
									<th style="width:25%">Job Order Type</th>
									<th style="width:50%">Customer Name, Address</th>
								</tr>
								<tr>
									<td>${jobOrderNumber}</td>
									<td>${jobOrderType}</td>
									<td>${customerName ?? "-"},
										<br />
						${jobOrderAddress}
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="border:1px solid #eee;background:#f5f5f5;width:100%;padding:10px 15px;box-sizing:border-box">
						<table style="width:100%;text-align:left">
							<tbody>
								<tr>
									<td colspan="3" style="vertical-align:top">
										<div>
											<p style="margin:0;padding:0">
												<b>Transaction Details</b>
											</p>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="border:1px solid #eee;border-top:0;width:100%;padding:10px 15px;box-sizing:border-box">
						<table style="width:100%;text-align:left">
							<tbody>
								<tr>
									<th>Transaction Id</th>
									<th>Payment Date</th>
									<th>Paid Amount</th>
								</tr>
								<tr>
									<td>${transactionId}</td>
									<td>${transactionDateTime}</td>
									<td style="color:#fdad00">
										<b>$ ${amountPaid}</b>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div style="border-top:0;width:100%;box-sizing:border-box">
						<table style="width:100%;text-align:left;border-spacing:0">
							<tbody>
								<tr>
									<th colspan="2" style="padding:10px 15px;border:1px solid #eee">Subtotal</th>
									<td style="padding:10px 15px;border:1px solid #eee;text-align:right">$ ${refundAmount}</td>
								</tr>
								<tr>
									<th colspan="2" style="padding:10px 15px;border:1px solid #eee">Payment Method</th>
									<td style="padding:10px 15px;border:1px solid #eee;text-align:right">Card</td>
								</tr>
								<tr>
									<th colspan="2" style="padding:10px 15px;border:1px solid #eee">Job Order Charge</th>
									<td style="padding:10px 15px;border:1px solid #eee;text-align:right">-$ ${jobOrderCharge}</td>
								</tr>
								<tr>
									<th colspan="2" style="padding:10px 15px;border:1px solid #eee">Total</th>
									<td style="padding:10px 15px;border:1px solid #eee;text-align:right">$ ${
                    refundAmount - jobOrderCharge
                  }</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</td>
		</tr>
		<tr style="background-color:#fff;border-color:#e9e9ff;border-style:solid;border-width:1px">
			<td style="text-align:center">&nbsp;</td>
		</tr>
		<tr style="background-color:#334aa6;border-color:#e9e9ff;border-style:solid;border-width:1px">
			<td style="background-color:#fdad00;text-align:center">
				<div style="padding:15px;color:#fff">&copy; 2021 RemoteVal. All Rights Reserved.</div>
			</td>
		</tr>
	</tbody>
</table>
`;

  const htmlTemplate =
    transactionStatus === "Paid"
      ? htmlTemplateTransactionReport
      : htmlTemplateTransactionRefundReport;

  return new XMLSerializer().serializeToString(
    new DOMParser().parseFromString(htmlTemplate, "text/html")
  );
};

export const openPdfFromBlob = (props) => {};
