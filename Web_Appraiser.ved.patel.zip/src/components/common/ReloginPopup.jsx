import React from "react";
import { useTranslation } from "react-i18next";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { StopReLogin } from "../../actions/errorPopUpAction";
import { redirectToUnAuthPage } from "../../helpers/validation";

export default function ReloginPopup() {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();

  const handleRedirection = () => {
    dispatch(StopReLogin());
    redirectToUnAuthPage(history);
  };
  return (
    <div className="error-popup open ">
      <div className="error-info">
        <div className="content">
          <p> {t("COMMON_MESSAGES.Session_Expired")}</p>
        </div>
        <div className="bottom-btn">
          <button
            class="blue-btn"
            onClick={handleRedirection}
            className="blue-btn"
          >
            {t("BUTTONS.Ok")}
          </button>
          &nbsp;
        </div>
        <br />
      </div>
    </div>
  );
}
