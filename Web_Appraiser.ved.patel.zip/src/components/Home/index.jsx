import React, { useState, useEffect } from "react";
import { NavLink, useHistory } from "react-router-dom";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import logo from "../../images/logo.svg";

import englishLanguage from "../../images/all-flag/English.svg";
import spanishLanguage from "../../images/all-flag/Spanish.svg";
import ArabicLanguage from "../../images/all-flag/Arabic.svg";
import FrenchLanguage from "../../images/all-flag/French.svg";
import IndiaLanguage from "../../images/all-flag/India.svg";
import PhilippinesLanguage from "../../images/all-flag/Philippines.svg";
import VietnameseLanguage from "../../images/all-flag/Vietnamese.svg";
import ChineseLanguage from "../../images/all-flag/Chinese.svg";
import KoreanLanguage from "../../images/all-flag/Korean.svg";
import RussianLanguage from "../../images/all-flag/Russian.svg";
import TurkishLanguage from "../../images/all-flag/Turkish.svg";

import { connect, useSelector } from "react-redux";
import "../../styles/_iconmoon.scss";
import "./index.scss";
import _ from "lodash";
import {
  fetchProfileDetails,
  fetchTenantDropdownList,
} from "./../../actions/profileAction";
import authenticationService from "../../services/authenticationService";
import { signOut, switchTenant } from "./../../actions/authenticationAction";
import { updateNavBar, updateHeader } from "../../actions/UIAction";
import { useTranslation } from "react-i18next";
import i18n from "./../../translations/i18n";
import storage from "../../services/storage";
import { ROLE, TempX_TenantKey } from "../../constants/appConstant";
import DisplayErrorModal from "./../../components/common/DisplayErrorModal/DisplayErrorModal";
import AsyncImage from "../common/AsyncImage";
import { isTokenExpired } from "../../helpers";
import { StartReLogin } from "../../actions/errorPopUpAction";
import store from "../../store";
import { StoreActions } from "../../actions/jobAction";

const Home = (props) => {
  const { t } = useTranslation();
  const [manageCardsActive, setManageCardsActive] = useState(null); // remove this once designer give icons.
  const [tenantList, setTenantList] = useState([]);
  const userRole = authenticationService.getUserRole()
    ? authenticationService.getUserRole()
    : null;
  const currentTenantSubDomain = authenticationService.getTenantDetails()
    ? JSON.parse(authenticationService.getTenantDetails()).tenantSubDomain
    : null;
  const currentTenantStorageType = authenticationService.getStorageType()
    ? authenticationService.getStorageType()
    : null;
  useEffect(() => {
    const token = authenticationService.getToken();
    let profileData = props.profile.fetchProfileDetailsSuccess?.userId;
    if (token && _.isNil(profileData)) {
      props.fetchProfileDetails();
      props.fetchTenantDropdownList().then((data) => {
        const tList = _.get(data, ["data", "data", "list"], []);
        setTenantList(tList);
      });
    }
  }, []);

  const [open, setOpen] = useState(true);
  const [language, setLanguage] = useState(
    sessionStorage.getItem("selectedLanguage")
      ? sessionStorage.getItem("selectedLanguage")
      : "english"
  );
  const [anchorEl, setAnchorEl] = React.useState(null);
  let history = useHistory();

  const handleDrawer = () => {
    setOpen(!open);
  };

  const handleLanguageClick = (event) => {
    setTimeout(() => {
      document
        .querySelector("div#contolled-language")
        .getElementsByClassName("MuiPaper-root")[0]
        .classList.add("MuiPaper-root-home");
    }, 100);
    setAnchorEl(event.currentTarget);
  };

  const handleLanguageClose = (item, e) => {
    switch (item) {
      case "english": {
        i18n.changeLanguage("en");
        break;
      }
      case "arabic": {
        i18n.changeLanguage("ar");
        break;
      }
      case "cantonese": {
        i18n.changeLanguage("yue");
        break;
      }
      case "french": {
        i18n.changeLanguage("fr");
        break;
      }
      case "hindi": {
        i18n.changeLanguage("hi");
        break;
      }
      case "japanese": {
        i18n.changeLanguage("ja");
        break;
      }
      case "korean": {
        i18n.changeLanguage("ko");
        break;
      }
      case "mandarin": {
        i18n.changeLanguage("cmn");
        break;
      }
      case "tagalog": {
        i18n.changeLanguage("tl");
        break;
      }
      case "vietnamese": {
        i18n.changeLanguage("vi");
        break;
      }
      case "spanish": {
        i18n.changeLanguage("es");
        break;
      }
      case "russian": {
        i18n.changeLanguage("ru");
        break;
      }
      case "turkish": {
        i18n.changeLanguage("tr");
        break;
      }
    }
    if (typeof item == "string") {
      setLanguage(item);
      sessionStorage.setItem("selectedLanguage", item);
    }
    setAnchorEl(null);
  };

  const signOut = () => {
    if (!props.showHeader) {
      props.updateHeader();
      props.updateNavBar();
    }
    props.signOut().then((res) => {
      if (res.status === 200) {
        history.replace("/sign-in");
      }
    });
  };

  const handleSidebarItemClick = () => {
    if (!props.showHeader) {
      props.updateHeader();
      props.updateNavBar();
    }
    storage.remove("activeTab");
  };
  const switchTenantClick = (tenantSubDomain) => {
    const xTenantKey = currentTenantSubDomain || TempX_TenantKey;
    let getUserRole = authenticationService.getUserRole();
    if (isTokenExpired()) {
      store.dispatch(StartReLogin());
      return new Promise(function (resolve, reject) {
        let sessionObj = { ignoreSentryRV: true };
        reject(sessionObj);
      });
    } else {
      if (userRole) {
        getUserRole = Buffer.from(userRole).toString("base64");
      } else if (getUserRole) {
        getUserRole = Buffer.from(getUserRole).toString("base64");
      }
      if (window.location.host.includes("localhost")) {
        window.location.href = `/switch-tenant/${tenantSubDomain}?xtenant=${xTenantKey}&tenantToken=${authenticationService.getToken()}`;
      } else {
        window.location.href = `https://${tenantSubDomain}.${
          process.env.REACT_APP_DOMAIN_URL
        }/switch-tenant/${tenantSubDomain}?xtenant=${xTenantKey}&tenantToken=${authenticationService.getToken()}&userRole=${getUserRole}&type=${currentTenantStorageType}`;
      }
    }
  };
  const {
    uiloading,
    isNavOpen,
    showHeader,
    errorModalloading,
    tenantDropDown,
    centerLoaderLoading,
  } = props;
  const tenantLogo = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess?.tenantLogo;
  });
  return (
    <>
      {errorModalloading && <DisplayErrorModal />}
      <section className="site-wapper">
        {centerLoaderLoading && (
          <div className="wrapper-loading">
            <div className="loader-spin"></div>
          </div>
        )}
        <nav className={`site-nav ${isNavOpen === true ? "open" : ""}`}>
          <div className="inner-nav">
            <div className="company-logo">
              <div className="pic">
                {!_.isEmpty(tenantLogo) ? (
                  <AsyncImage useStaticToken={true} imageUrl={tenantLogo} />
                ) : (
                  <img src={logo} alt="logo" className="on-open" />
                )}
                <i className="icon-drop-bottom"></i>
                <button className="close-menu" onClick={handleDrawer}>
                  <i className="icon-close-image"></i>
                </button>
              </div>
              <div className="company-logo-dropdown">
                <ul>
                  {tenantDropDown &&
                    tenantDropDown.map((head, key) => (
                      <li key={key}>
                        <button
                          onClick={() => {
                            if (
                              currentTenantSubDomain != head.tenantSubDomain
                            ) {
                              store.dispatch(StoreActions({}));
                              switchTenantClick(head.tenantSubDomain);
                            }
                          }}
                        >
                          {/* <img src={head.logoPath} alt="" />{" "} */}
                          <div className="tenant-branding">
                            <div className="tenant-logo">
                              <AsyncImage imageUrl={head.logoPath} />
                            </div>
                            <div className="tenant-title">
                              {head.tenantName}
                            </div>
                          </div>
                          {currentTenantSubDomain == head.tenantSubDomain && (
                            <i className="icon-true1"></i>
                          )}
                        </button>
                      </li>
                    ))}
                </ul>
              </div>
            </div>
            <div className="profile">
              <span className="name">
                {_.get(
                  props,
                  ["profile", "fetchProfileDetailsSuccess", "fullName"],
                  ""
                )}
              </span>
            </div>
            <ul className="menu-list">
              <li>
                <NavLink
                  to="/?"
                  exact
                  isActive={(match, location) => {
                    let isActive = false;
                    if (match !== null) {
                      isActive = match.isExact;
                    }
                    return (
                      isActive ||
                      location.pathname.includes("/joborder") ||
                      location.pathname.includes("/my-job-orders") ||
                      location.pathname.includes("/view-floorscan") ||
                      location.pathname.includes("/job-order")
                    );
                  }}
                >
                  <button onClick={handleSidebarItemClick}>
                    <span className="icn-img">
                      <i className="icon-job-order-management"></i>
                    </span>
                    <span className="text">
                      {t("WEB_LABELS.My_Job_Orders")}
                    </span>
                  </button>
                </NavLink>
              </li>
              {userRole !== ROLE.TECHNICIAN && (
                <>
                  <li>
                    <NavLink to="/calendar" exact activeClassName="active">
                      <button
                        onClick={() => {
                          store.dispatch(StoreActions({}));
                          handleSidebarItemClick();
                        }}
                      >
                        <span className="icn-img">
                          <i className="icon-date-picker"></i>
                        </span>
                        <span className="text">{t("WEB_LABELS.Calendar")}</span>
                      </button>
                    </NavLink>
                  </li>
                  <li>
                    <NavLink
                      to="/cards"
                      exact
                      activeClassName="active"
                      isActive={(match, location) => {
                        let isActive = false;
                        if (match !== null) {
                          isActive = match.isExact;
                        }
                        const __isActive =
                          isActive || location.pathname.includes("/cards");
                        setManageCardsActive(__isActive);
                        return __isActive;
                      }}
                    >
                      <button
                        onClick={() => {
                          store.dispatch(StoreActions({}));
                          handleSidebarItemClick();
                        }}
                      >
                        <span className="icn-img">
                          <img
                            style={{ width: "20px" }}
                            src={
                              manageCardsActive
                                ? "/images/manage_cards.png"
                                : "/images/manage_cards_2.png"
                            }
                            alt="Card Icon"
                          />
                        </span>
                        <span className="text">
                          {t("WEB_LABELS.Manage_Cards")}
                        </span>
                      </button>
                    </NavLink>
                  </li>
                  <li>
                    <NavLink
                      to="/transaction-history"
                      exact
                      activeClassName="active"
                      isActive={(match, location) => {
                        let isActive = false;
                        if (match !== null) {
                          isActive = match.isExact;
                        }
                        return (
                          isActive ||
                          location.pathname.includes("/transaction-history")
                        );
                      }}
                    >
                      <button
                        onClick={() => {
                          store.dispatch(StoreActions({}));
                          handleSidebarItemClick();
                        }}
                      >
                        <span className="icn-img">
                          <i className="app-icon-Transaction-History"></i>
                        </span>
                        <span className="text">{t("Transaction_History")}</span>
                      </button>
                    </NavLink>
                  </li>
                </>
              )}
              <li>
                <NavLink
                  to="/profile"
                  exact
                  isActive={(match, location) => {
                    let isActive = false;
                    if (match !== null) {
                      isActive = match.isExact;
                    }
                    return isActive || location.pathname.includes("/profile");
                  }}
                >
                  <button
                    onClick={() => {
                      store.dispatch(StoreActions({}));
                      handleSidebarItemClick();
                    }}
                  >
                    <span className="icn-img">
                      <i className="icon-profile-settings"></i>
                    </span>
                    <span className="text">{t("WEB_LABELS.Profile")}</span>
                  </button>
                </NavLink>
              </li>
            </ul>
          </div>
          <div className="sign-out">
            <button onClick={signOut}>
              <i className="icon-signout"></i>
              <div className="sign-out-text">{t("BUTTONS.Sign_Out")}</div>
            </button>
          </div>
        </nav>
        <main
          className={showHeader ? "site-content" : "site-content full-screen"}
        >
          <header className="top-header">
            <div className="toggle-icon">
              <button onClick={() => props.updateNavBar()}>
                <i className="icon-hamburger-menu"></i>
              </button>
              {uiloading && <div className="loader-spin"></div>}
            </div>
            {userRole && userRole !== ROLE.TECHNICIAN && (
              <div className="language">
                <button
                  id="contolled-language"
                  className={
                    anchorEl
                      ? "contolled-language active"
                      : "contolled-language"
                  }
                  onClick={handleLanguageClick}
                >
                  {language === "english" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={englishLanguage} alt="english" />
                      </div>
                      <div className="text">
                        English <span>English</span>
                      </div>
                    </>
                  )}
                  {language === "hindi" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={IndiaLanguage} alt="hindi" />
                      </div>
                      <div className="text">
                        Hindi <span>हिन्दी</span>
                      </div>
                    </>
                  )}
                  {language === "arabic" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={ArabicLanguage} alt="Arabic" />
                      </div>
                      <div className="text">
                        Arabic <span>عربى</span>
                      </div>
                    </>
                  )}
                  {language === "french" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={FrenchLanguage} alt="french" />
                      </div>
                      <div className="text">
                        French <span>Français</span>
                      </div>
                    </>
                  )}
                  {language === "japanese" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={ChineseLanguage} alt="japanese" />
                      </div>
                      <div className="text">
                        Japanese <span>日本</span>
                      </div>
                    </>
                  )}
                  {language === "korean" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={KoreanLanguage} alt="korean" />
                      </div>
                      <div className="text">
                        Korean <span>한국인</span>
                      </div>
                    </>
                  )}
                  {language === "spanish" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={spanishLanguage} alt="spanish" />
                      </div>
                      <div className="text">
                        Spanish <span>Español</span>
                      </div>
                    </>
                  )}
                  {language === "vietnamese" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={VietnameseLanguage} alt="vietnamese" />
                      </div>
                      <div className="text">
                        Vietnamese <span>Tiếng Việt</span>
                      </div>
                    </>
                  )}
                  {language === "tagalog" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={PhilippinesLanguage} alt="tagalog" />
                      </div>
                      <div className="text">
                        Tagalog <span>Tagalog</span>
                      </div>
                    </>
                  )}
                  {language === "mandarin" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={ChineseLanguage} alt="mandarin" />
                      </div>
                      <div className="text">
                        Mandarin <span>普通话</span>
                      </div>
                    </>
                  )}
                  {language === "cantonese" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={ChineseLanguage} alt="cantonese" />
                      </div>
                      <div className="text">
                        Cantonese <span>粵語</span>
                      </div>
                    </>
                  )}
                  {language === "russian" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={RussianLanguage} alt="russian" />
                      </div>
                      <div className="text">
                        Russian <span>русский</span>
                      </div>
                    </>
                  )}
                  {language === "turkish" && (
                    <>
                      <div className="img language-signin-image">
                        <img src={TurkishLanguage} alt="turkish" />
                      </div>
                      <div className="text">
                        Turkish <span>Türk</span>
                      </div>
                    </>
                  )}
                </button>
                <Menu
                  id="contolled-language"
                  anchorOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "left",
                  }}
                  anchorEl={anchorEl}
                  keepMounted
                  open={Boolean(anchorEl)}
                  onClose={handleLanguageClose}
                  TransitionProps={{
                    appear: false,
                  }}
                >
                  <MenuItem
                    className={`${language === "arabic" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("arabic", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={ArabicLanguage} alt="arabic" />
                      </div>
                      <div className="text">
                        Arabic <span>عربى</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "cantonese" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("cantonese", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={ChineseLanguage} alt="cantonese" />
                      </div>
                      <div className="text">
                        Cantonese <span>粵語</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "english" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("english", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={englishLanguage} alt="english" />
                      </div>
                      <div className="text">
                        English <span>English</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "french" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("french", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={FrenchLanguage} alt="french" />
                      </div>
                      <div className="text">
                        French <span>Français</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "hindi" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("hindi", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={IndiaLanguage} alt="hindi" />
                      </div>
                      <div className="text">
                        Hindi <span>हिन्दी</span>
                      </div>
                    </button>
                  </MenuItem>

                  <MenuItem
                    className={`${language === "japanese" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("japanese", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={ChineseLanguage} alt="japanese" />
                      </div>
                      <div className="text">
                        Japanese <span>日本</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "korean" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("korean", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={KoreanLanguage} alt="korean" />
                      </div>
                      <div className="text">
                        Korean <span>한국인</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "mandarin" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("mandarin", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={ChineseLanguage} alt="mandarin" />
                      </div>
                      <div className="text">
                        Mandarin <span>普通话</span>
                      </div>
                    </button>
                  </MenuItem>
                  <MenuItem
                    className={`${language === "spanish" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("spanish", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={spanishLanguage} alt="spanish" />
                      </div>
                      <div className="text">
                        Spanish <span>Español</span>
                      </div>
                    </button>
                  </MenuItem>

                  <MenuItem
                    className={`${language === "tagalog" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("tagalog", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={PhilippinesLanguage} alt="tagalog" />
                      </div>
                      <div className="text">
                        Tagalog <span>Tagalog</span>
                      </div>
                    </button>
                  </MenuItem>

                  <MenuItem
                    className={`${language === "vietnamese" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("vietnamese", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={VietnameseLanguage} alt="vietnamese" />
                      </div>
                      <div className="text">
                        Vietnamese <span>Tiếng Việt</span>
                      </div>
                    </button>
                  </MenuItem>

                  <MenuItem
                    className={`${language === "russian" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("russian", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={RussianLanguage} alt="russian" />
                      </div>
                      <div className="text">
                        Russian <span>русский</span>
                      </div>
                    </button>
                  </MenuItem>

                  <MenuItem
                    className={`${language === "turkish" ? "active" : ""}`}
                    onClick={(e) => handleLanguageClose("turkish", e)}
                  >
                    <button>
                      <div className="img">
                        <img src={TurkishLanguage} alt="turkish" />
                      </div>
                      <div className="text">
                        Turkish <span>Türk</span>
                      </div>
                    </button>
                  </MenuItem>
                </Menu>
              </div>
            )}
          </header>
          {props.children}
        </main>
      </section>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    uiloading: state.ui && state.ui.uiloading,
    centerLoaderLoading: state.ui && state.ui.centerLoaderLoading,
    profile: state.profile,
    isNavOpen: state.ui && state.ui.isNavOpen,
    showHeader: state.ui && state.ui.showHeader,
    errorModalloading: _.get(state, ["errorReducer", "errorModalloading"]),
    tenantDropDown: _.get(
      state,
      ["profile", "fetchTenantListSuccess", "data", "data", "list"],
      []
    ),
  };
};

export default connect(mapStateToProps, {
  fetchProfileDetails,
  signOut,
  updateNavBar,
  fetchTenantDropdownList,
  switchTenant,
  updateHeader,
})(Home);
