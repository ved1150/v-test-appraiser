import React, { useEffect, useState, useRef } from "react";
import _ from "lodash";
import NoDataView from "./../Common/noDataView";
import { CAPTURED_IMAGES, CAPTURED_IMAGES_ICON } from "./../Common/commonText";
import classnames from "classnames";
import { customToast } from "./../../../../helpers/customToast";
import { IMAGE_DOWNLOAD_MESSSAGE } from "./../../../../constants/commonMessages";
import Button from "../../../common/Button";
import { useTranslation } from "react-i18next";
import AsyncImage from "../../../common/AsyncImage";
import { useDispatch, useSelector } from "react-redux";
import { setPrimaryPictureForReportPDF } from "../../../../actions/jobOrderDetailsAction";
import Tooltip from "@mui/material/Tooltip";
import ConfirmationModal from "../../../common/confirmationModal";
var tempArr = [];
const pageSize = 20;
const ImageTab = (props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const [imageList, setImageList] = useState([]);
  const [allImagesChecked, setAllImagesChecked] = useState(false);
  const [disabledDownloadBtn, setDisabledDownloadBtn] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [deleteSubmitting, setDeleteSubmitting] = useState(false);
  const [disabledDeleteBtn, setDisabledDeleteBtn] = useState(true);
  const [showCoverPhotoSetModal, setShowCoverPhotoSetModal] = useState(false);
  const [showCoverPhotoRemoveModal, setShowCoverPhotoRemoveModal] =
    useState(false);
  const [imageForPrimaryPictureSetRemove, setImageForPrimaryPictureSetRemove] =
    useState(null);
  const fetchImagesStart = useSelector(
    (state) => state?.image?.fetchImageStart
  );
  const primaryPictures = useSelector(
    (state) => state?.details?.fetchDetailsSuccess?.primaryPictures ?? []
  );
  const fetchDetailsStart = useSelector(
    (state) => state?.details?.fetchDetailsStart
  );
  const [refresh, setRefresh] = useState(true);
  const [allImages, setAllImages] = useState([]);
  const [pageNo, setPageNo] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [imageCount, SetImageCount] = useState(0);
  const arrayListRef = useRef();

  useEffect(() => {
    props.fetchImages(props.jobOrderId).then((res) => {
      setPageNo(1);
      let imageList = res?.slice(0, pageSize);
      let imageCount = _.size(res);
      setImageList(_.cloneDeep(imageList));
      SetImageCount(imageCount);
      setAllImages(_.cloneDeep(res));
      setTotalPages(Math.ceil(imageCount / pageSize));
    });
  }, [refresh]);

  const viewImage = (imgIndex) => {
    props.viewImage(imgIndex);
  };

  const selectOneImage = (selectedImage, id) => {
    let index = tempArr.findIndex(
      (img) => img.originalName == selectedImage.originalName
    );
    let newArr = [];
    [...imageList].map((value, key) => {
      newArr.push(value);
    });
    if (index > -1) {
      tempArr.splice(index, 1);
      newArr[id].checked = false;
      setImageList([...newArr]);
    } else {
      tempArr.push({ ...selectedImage });
      newArr[id].checked = true;
      setImageList([...newArr]);
    }

    if (tempArr.length == imageList.length) {
      setAllImagesChecked(!allImagesChecked);
    } else {
      setAllImagesChecked(false);
    }

    if (tempArr.length > 0) {
      setDisabledDownloadBtn(false);
      setDisabledDeleteBtn(false);
    } else {
      setDisabledDownloadBtn(true);
      setDisabledDeleteBtn(true);
    }
  };

  const selectAllImage = () => {
    tempArr = [];
    if (allImagesChecked) {
      setAllImagesChecked(!allImagesChecked);
    } else {
      setAllImagesChecked(!allImagesChecked);
      tempArr = [...imageList];
    }

    let imageArr = [];
    imageArr = [...imageList];
    if (allImagesChecked) {
      imageArr.map((value, key) => {
        value.checked = false;
      });
      setImageList([...imageArr]);
      setDisabledDownloadBtn(true);
      setDisabledDeleteBtn(true);
    } else {
      imageArr.map((value, key) => {
        value.checked = true;
      });
      setImageList([...imageArr]);
      setDisabledDownloadBtn(false);
      setDisabledDeleteBtn(false);
    }
  };

  const downloadImage = () => {
    setDisabledDownloadBtn(true);
    setDisabledDeleteBtn(true);
    setSubmitting(true);
    const imagesForDownload = tempArr.map((i) => i.originalName);
    props
      .downloadImages({
        joborder_id: props.jobOrderId,
        selected_images: imagesForDownload,
      })
      .then((res) => {
        setSubmitting(false);
        tempArr = [];
        const disposition = res.request.getResponseHeader(
          "Content-Disposition"
        );
        let fileName = "";
        let filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
        let matches = filenameRegex.exec(disposition);
        if (matches != null && matches[1]) {
          fileName = matches[1].replace(/['"]/g, "");
        }

        const contentType = _.get(res, ["headers", "content-type"]);
        const blob = new Blob([res.data], { type: contentType });
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob);
          return;
        }
        const url = window.URL.createObjectURL(blob);
        let link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        let imageArr = [...imageList];
        imageArr.map((value, key) => {
          value.checked = false;
        });
        setImageList([...imageArr]);
        setAllImagesChecked(false);
        customToast.success(t("COMMON_MESSAGES.IMAGE_DOWNLOAD_MESSSAGE"));
      });
  };

  const deleteImage = () => {
    setDisabledDownloadBtn(true);
    setDisabledDeleteBtn(true);
    setDeleteSubmitting(true);
    const newTempArr = _.cloneDeep(tempArr);
    const imagesForDownload = newTempArr.map((temp) => {
      if (temp.primaryPicture) {
        removePdfCoverPhoto(temp, 1);
      }
      return temp.originalName;
    });
    props.deleteImages(imagesForDownload).then((res) => {
      setAllImagesChecked(false);
      SetImageCount(imageCount - _.size(imagesForDownload));
      setDeleteSubmitting(false);
      setRefresh(!refresh);
      customToast.success("Image(s) Deleted Successfully");
    });
  };

  const removePdfCoverPhoto = (img, from = 0) => {
    setAllImagesChecked(false);
    setDisabledDownloadBtn(true);
    setDisabledDeleteBtn(true);
    tempArr = [];
    dispatch(
      setPrimaryPictureForReportPDF({
        callPicturesId: img.callPicturesId,
        jobOrderId: props.jobOrderId,
        primary: false,
      })
    )
      .then((_) => {
        customToast.success(t("Remove_PDF_Cover_Photo_Successfully"));
        from == 0 && setRefresh(!refresh);
      })
      .finally(() => {
        setImageForPrimaryPictureSetRemove(null);
        props.fetchDetails(props.jobOrderId);
      });
  };

  const setAsPdfCoverPhoto = (img) => {
    setAllImagesChecked(false);
    setDisabledDownloadBtn(true);
    setDisabledDeleteBtn(true);
    tempArr = [];
    if (!fetchDetailsStart) {
      Promise.all(
        primaryPictures?.map((_primaryPicture) =>
          dispatch(
            setPrimaryPictureForReportPDF({
              callPicturesId: _primaryPicture.id,
              jobOrderId: props.jobOrderId,
              primary: false,
            })
          )
        )
      )
        .then((_) => {
          dispatch(
            setPrimaryPictureForReportPDF({
              callPicturesId: img.callPicturesId,
              jobOrderId: props.jobOrderId,
              primary: true,
            })
          ).then((_) => {
            customToast.success(t("Set_PDF_Cover_Photo_Successfully"));
            setRefresh(!refresh);
          });
        })
        .finally(() => {
          setImageForPrimaryPictureSetRemove(null);
        })
        .finally(() => {
          props.fetchDetails(props.jobOrderId);
        });
    }
  };

  const onScroll = () => {
    if (arrayListRef.current && pageNo < totalPages) {
      const { scrollTop, scrollHeight, clientHeight } = arrayListRef.current;
      if (scrollTop + clientHeight + 10 >= scrollHeight) {
        const startPoint = pageNo * pageSize;
        const endPoint = startPoint + pageSize;
        const nextImages = allImages.slice(startPoint, endPoint);
        setPageNo(pageNo + 1);
        setImageList([...imageList, ...nextImages]);
      }
    }
  };

  return (
    <div>
      {fetchImagesStart || _.size(imageList) === 0 ? (
        <div className="no-data-found-container">
          {fetchImagesStart ? (
            <div className="no-data-found">
              <div className="box">
                <div className="loader-spin"></div>
              </div>
            </div>
          ) : (
            <NoDataView
              text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.CAPTURED_IMAGES")}
              icon={CAPTURED_IMAGES_ICON}
            />
          )}
        </div>
      ) : (
        <div className="captured-images">
          <div className="dl-btn">
            <div className="decs-image">
              <div className="no-image">
                <i className="icon-images"></i> {t("WEB_LABELS.Images")}{" "}
                {imageCount}
              </div>
              <div className="check-all">
                <div className="check-btn">
                  <label>
                    <input
                      type="checkbox"
                      id="allImages"
                      onChange={() => selectAllImage()}
                      checked={allImagesChecked}
                      name="check"
                    />
                    <span>{t("BUTTONS.Select_All")}</span>
                  </label>
                </div>
              </div>
            </div>
            <div className="download-btn">
              <Button
                disabled={disabledDeleteBtn || deleteSubmitting}
                onClick={deleteImage}
                className={classnames("blue-btn", {
                  disable: disabledDeleteBtn,
                })}
              >
                {!allImagesChecked
                  ? t("BUTTONS.Delete")
                  : t("BUTTONS.Delete_All")}{" "}
                {deleteSubmitting && <div className="loader-spin"></div>}
              </Button>
              <Button
                disabled={disabledDownloadBtn || submitting}
                onClick={downloadImage}
                className={classnames("blue-btn", {
                  disable: disabledDownloadBtn,
                })}
              >
                {!allImagesChecked
                  ? t("BUTTONS.Download")
                  : t("BUTTONS.Download_All")}{" "}
                {submitting && <div className="loader-spin"></div>}
              </Button>
            </div>
          </div>

          <ul
            className="list scroll-bar-style"
            onScroll={onScroll}
            ref={arrayListRef}
          >
            {imageList &&
              _.map(imageList, (img, id) => (
                <li key={id} className={classnames({ active: img.checked })}>
                  <div className="saved-images-box">
                    <div className="images-box">
                      <div className="check-btn">
                        <label>
                          <input
                            type="checkbox"
                            onClick={() => selectOneImage(img, id)}
                            id={id}
                            name="check"
                            checked={img.checked}
                          />
                          <span></span>
                        </label>
                      </div>
                      {img?.primaryPicture && (
                        <div
                          className="removePdfCoverPhotoBtn"
                          onClick={() => {
                            setShowCoverPhotoRemoveModal(true);
                            setImageForPrimaryPictureSetRemove(img);
                          }}
                        >
                          {t("Remove_PDF_Cover_Photo")}
                        </div>
                      )}
                      <div className="time">
                        {_.get(img, ["capturedImageTime", "year"], 0)
                          ? `${_.get(
                              img,
                              ["capturedImageTime", "year"],
                              0
                            )} ${t("WEB_LABELS.years")} `
                          : _.get(img, ["capturedImageTime", "day"], 0)
                          ? `${_.get(img, ["capturedImageTime", "day"], 0)} ${t(
                              "WEB_LABELS.days"
                            )} `
                          : _.get(img, ["capturedImageTime", "hour"], 0)
                          ? `${_.get(
                              img,
                              ["capturedImageTime", "hour"],
                              0
                            )} ${t("WEB_LABELS.hrs")} `
                          : _.get(img, ["capturedImageTime", "minute"], 0)
                          ? `${_.get(
                              img,
                              ["capturedImageTime", "minute"],
                              0
                            )} ${t("WEB_LABELS.mins")} `
                          : _.get(img, ["capturedImageTime", "second"], 0)
                          ? `${_.get(
                              img,
                              ["capturedImageTime", "second"],
                              0
                            )} ${t("WEB_LABELS.secs")} `
                          : ""}
                        {t("WEB_LABELS.ago")}
                      </div>
                      <div className="viewbtn" onClick={() => viewImage(id)}>
                        <button>{t("WEB_LABELS.View")}</button>
                      </div>
                      {!img?.primaryPicture && !fetchDetailsStart && (
                        <div
                          className="setAsPdfCoverPhotobtn"
                          onClick={() => {
                            setShowCoverPhotoSetModal(true);
                            setImageForPrimaryPictureSetRemove(img);
                          }}
                        >
                          <Tooltip
                            placement="bottom-end"
                            title={t("Set_As_PDF_Cover_Photo")}
                            arrow
                          >
                            <button>
                              <i className="icon-images"></i>
                            </button>
                          </Tooltip>
                        </div>
                      )}
                      <AsyncImage imageUrl={img.thumb} />
                    </div>
                  </div>
                </li>
              ))}
          </ul>
        </div>
      )}
      {showCoverPhotoSetModal && (
        <ConfirmationModal
          cancelEvent={() => {
            setShowCoverPhotoSetModal(false);
            setImageForPrimaryPictureSetRemove(null);
          }}
          title={t("Set_As_PDF_Cover_Photo_Confirm_Message")}
          cancelText={t("COMMON_MESSAGES.No")}
          confirmText={t("COMMON_MESSAGES.Yes")}
          confirmEvent={() => {
            setShowCoverPhotoSetModal(false);
            setAsPdfCoverPhoto(imageForPrimaryPictureSetRemove);
          }}
        ></ConfirmationModal>
      )}
      {showCoverPhotoRemoveModal && (
        <ConfirmationModal
          cancelEvent={() => {
            setShowCoverPhotoRemoveModal(false);
            setImageForPrimaryPictureSetRemove(null);
          }}
          title={t("Remove_PDF_Cover_Photo_Confirm_Message")}
          cancelText={t("COMMON_MESSAGES.No")}
          confirmText={t("COMMON_MESSAGES.Yes")}
          confirmEvent={() => {
            setShowCoverPhotoRemoveModal(false);
            removePdfCoverPhoto(imageForPrimaryPictureSetRemove, 0);
          }}
        ></ConfirmationModal>
      )}
    </div>
  );
};

export default ImageTab;
