import api from "./api";

export default class JobOrderTypesApi {
  list(data) {
    return api.get("/joborderTypes", { params: data });
  }
}
