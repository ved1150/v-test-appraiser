import React, { useEffect, useState } from "react";
import _ from "lodash";
import Pagination from "@mui/material/Pagination";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import NoDataView from "./../Common/noDataView";
import { RECORDINGS, MEASUREMENTS_ICON } from "./../Common/commonText";
import { customToast } from "./../../../../helpers/customToast";
import { RECORDING_DOWNLOAD_MESSSAGE } from "./../../../../constants/commonMessages";
import { useTranslation } from "react-i18next";
import Button from "../../../common/Button";
import RelarFilterBox from "./relarFilterBox";
import "./recordingTab.scss";
import moment from "moment";
import { jobOrdersPerPage } from "./../../../../constants/appConstant";
import NoDataRelarView from "./NoDataRelarView";
import CustomPagination from "../../../common/CustomPagination";

const RelarTab = (props) => {
  const { t } = useTranslation();

  const tableHead = [
    { key: "apn", label: t("WEB_LABELS.APN") },
    { key: "address", label: t("WEB_LABELS.Address") },
    { key: "city", label: t("WEB_LABELS.City") },
    { key: "state", label: t("WEB_LABELS.State") },
    { key: "zip", label: t("WEB_LABELS.Zip_Code") },
    { key: "price", label: t("WEB_LABELS.Price") },
    { key: "beds", label: t("WEB_LABELS.Beds") },
    { key: "baths", label: t("WEB_LABELS.Bath") },
    { key: "size", label: t("WEB_LABELS.House_Size") },
    { key: "distance", label: t("WEB_LABELS.Distance") },
    { key: "statusDate", label: t("WEB_LABELS.Date") },
  ];

  const [sortBy, setSortBy] = useState("distance");
  const [direction, setDirection] = useState("desc");
  const [relarList, setRelarList] = useState([]);
  const [relarCompsType, SetRelarCompsType] = useState("Sold");
  const [pageNo, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [isFilteredData, setIsFilteredData] = useState(false);
  const [startPoint, setStartPoint] = useState(1);
  const [endPoint, setEndPoint] = useState(pageSize);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPage, SetTotalPage] = useState(0);
  const [filterOpen, SetFilterOpen] = useState(false);
  const [filterOldData, setFilterOldData] = useState([]);
  const [filterApplyData, setFilterApplyData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [relarStatus, setRelarStatus] = useState({
    status: null,
    isAPICalled: false,
    relarListExist: false,
  });

  useEffect(() => {
    const filter = {
      direction,
      sortBy,
      relarCompsType,
      jobOrderId: props.jobOrderId,
      pageNo,
      pageSize,
    };
    if (!isFilteredData && filterApplyData.length == 0) {
      props
        .fetchRelar(filter)
        .then((data) => {
          setIsLoading(false);
          const count = _.get(data, ["pagination", "totalCount"], 0);
          setRelarStatus({
            status: data.status,
            isAPICalled: true,
            relarListExist: count == 0 ? false : true,
          });
          setTotalCount(count);
          setStartPoint(parseInt(pageSize * (pageNo - 1) + 1));
          if (pageSize * pageNo > count || count < pageSize * pageNo) {
            setEndPoint(count);
          } else {
            setEndPoint(pageSize * pageNo);
          }

          const total_Page = _.get(data, ["pagination", "totalPage"], 0);
          SetTotalPage(total_Page);
          if (pageNo > total_Page) {
            setCurrentPage(1);
            setStartPoint(1);
          }
          if (totalCount > 0) {
            setRelarList(data.data);
          }
        })
        .catch((err) => {
          setRelarList([]);
          setIsLoading(false);
        });
    } else {
      const total_filter_data = filterApplyData?.length;
      const filter_props = { ...filterOldData };
      filter_props.pagination = {
        direction: direction.toLocaleUpperCase(),
        page: pageNo,
        size: pageSize,
        sortBy,
      };

      setTotalCount(total_filter_data);

      if (
        pageSize * pageNo > total_filter_data ||
        total_filter_data < pageSize * pageNo
      ) {
        setEndPoint(total_filter_data);
      } else {
        setEndPoint(pageSize * pageNo);
      }

      const total_Page = Math.ceil(total_filter_data / pageSize);
      SetTotalPage(total_Page);
      if (pageNo > total_Page) {
        setCurrentPage(1);
        setStartPoint(1);
      }
      if (total_filter_data > 0) {
        props
          .filterRelar(filter_props)
          .then((data) => {
            setRelarList(data.data);
          })
          .catch((err) => {
            setRelarList([]);
          });
      }
    }
  }, [
    relarCompsType,
    totalCount,
    filterApplyData,
    isFilteredData,
    pageNo,
    pageSize,
    direction,
    sortBy,
  ]);

  useEffect(() => {}, [relarList]);
  const handleSorting = (cellId) => {
    const isAsc = sortBy === cellId && direction === "desc";
    setDirection(isAsc ? "asc" : "desc");
    setSortBy(cellId);
  };

  const handleChange = (e) => {
    SetRelarCompsType(e.target.value);
  };
  const handlePagination = (event, value) => {
    setCurrentPage(value);
  };
  const handleSizeChange = (e) => {
    const p_size = e.target.value;
    setCurrentPage(1);
    if (p_size > totalCount) {
      setPageSize(totalCount);
    } else {
      setPageSize(p_size);
    }
  };

  const getFilterAttrib = (filterData) => {
    const postdata = filterData;

    Object.keys(postdata).map((item) => {
      if (
        postdata[item] == "" ||
        postdata[item] == 0 ||
        postdata[item] == undefined
      ) {
        delete postdata[item];
      }
    });
    if (filterData.startStatusDate && filterData.endStatusDate) {
      const startDate = filterData.startStatusDate;
      const endDate = filterData.endStatusDate;
      postdata.startStatusDate = moment(startDate).format(
        "yyyy-MM-DD HH:mm:ss"
      );
      postdata.endStatusDate = moment(endDate).format("yyyy-MM-DD HH:mm:ss");
    }
    postdata.jobOrderId = props.jobOrderId;

    postdata.pagination = {
      direction: direction.toLocaleUpperCase(),
      page: pageNo,
      size: pageSize,
      sortBy,
    };
    setFilterOldData(postdata);
    const filter = {
      direction,
      sortBy,
      relarCompsType,
      jobOrderId: props.jobOrderId,
      pageNo: 0,
      pageSize: pageSize,
    };
    props
      .filterRelar(postdata)
      .then((data) => {
        setFilterApplyData(data.data);
        const countRecord = data.data.length;
        setTotalCount(countRecord);
        SetFilterOpen(false);
        setIsFilteredData(true);
      })

      .catch((err) => {
        setRelarList([]);
      });
  };
  const renderOriginalProperyAssociatedData = (key) => {
    switch (key) {
      case "address":
        const _address =
          _.get(props, ["details", "fetchDetailsSuccess", "address1"], "") +
          " " +
          _.get(props, ["details", "fetchDetailsSuccess", "address2"], "");
        return _address.trim().length === 0 ? "-" : _address;
      case "city":
        return _.get(props, ["details", "fetchDetailsSuccess", "city"], "-");
      case "state":
        return _.get(props, ["details", "fetchDetailsSuccess", "state"], "-");
      case "zip":
        return _.get(
          props,
          ["details", "fetchDetailsSuccess", "propertyZip"],
          "-"
        );
      default:
        return "-";
    }
  };

  return (
    <div>
      {filterOpen ? (
        <>
          <RelarFilterBox
            filterOpen={filterOpen}
            SetFilterOpen={SetFilterOpen}
            getFilterAttrib={getFilterAttrib}
            filterOldData={filterOldData}
          />
        </>
      ) : null}

      <div className="filter-box">
        <div className="show-entries">
          {t("COMMON_MESSAGES.Show")}
          <select
            onChange={(e) => {
              handleSizeChange(e);
            }}
          >
            {jobOrdersPerPage.map((item) => (
              <option key={item.value} value={item.value}>
                {item.displayName}
              </option>
            ))}
          </select>
          {t("COMMON_MESSAGES.entries")}
        </div>
        <div className="filter-segment">
          <div className="search-box" style={{ display: "flex" }}>
            <select className="form-control" onChange={handleChange}>
              <option selected value="Sold">
                {t("WEB_LABELS.MLS_Sales")}
              </option>
              <option value="Pending">
                {t("WEB_LABELS.MLS_Pending_Sales")}
              </option>
              <option value="Open">{t("WEB_LABELS.MLS_Open")}</option>
              <option value="Expired">{t("WEB_LABELS.MLS_Expired")} </option>
            </select>
            <div className="filter-button">
              <button
                className="MuiButtonBase-root MuiButton-root MuiButton-text blue-btn"
                onClick={() => {
                  SetFilterOpen((prev) => !prev);
                }}
              >
                <i className="icon-filter"></i>
                {t("BUTTONS.Filter")}
              </button>
            </div>
          </div>
        </div>
      </div>
      {_.size(relarList) === 0 || isLoading ? (
        <div className="no-data-found-container">
          <div className="no-data-found">
            <div className="box">
              {isLoading ? (
                <div className="loader-spin"></div>
              ) : (
                <NoDataRelarView
                  jobOrderId={props.jobOrderId}
                  requestRelar={props.requestRelar}
                  icon={MEASUREMENTS_ICON}
                  shouldRequestRelar={relarStatus}
                />
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="racording scroll-bar-style relar-bar-style">
          {/* <div className="download-btn text-right"><button className="blue-btn">Download All</button></div> */}
          <TableContainer className="relar-segment">
            <Table className="relar-table" aria-label="simple table">
              <TableHead>
                {/* <TableRow className="original-data-row">
                  {tableHead.map((head, key) => (
                    <TableCell
                      key={`associated_property_original_data_${head.key}`}
                    >
                      {renderOriginalProperyAssociatedData(head.key)}
                    </TableCell>
                  ))}
                </TableRow> */}
                <TableRow className="sorting-data-row">
                  {tableHead.map((head, key) => (
                    <TableCell
                      key={key}
                      sortDirection={sortBy === head.key ? direction : false}
                    >
                      {head.disableSorting ? (
                        head.label
                      ) : (
                        <TableSortLabel
                          active={sortBy === head.key}
                          direction={sortBy === head.key ? direction : "asc"}
                          onClick={() => {
                            handleSorting(head.key);
                          }}
                        >
                          {head.label}
                        </TableSortLabel>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {relarList?.map((d, id) => (
                  <TableRow key={id}>
                    <TableCell>{d.apn}</TableCell>
                    <TableCell>{d.address}</TableCell>
                    <TableCell>{d.city}</TableCell>
                    <TableCell>{d.state}</TableCell>
                    <TableCell>{d.zip}</TableCell>
                    <TableCell>{d.price}</TableCell>
                    <TableCell>{d.beds}</TableCell>
                    <TableCell>{d.baths}</TableCell>
                    <TableCell>{d.size}</TableCell>
                    <TableCell>{d.distance}</TableCell>
                    <TableCell>{d.statusDate}</TableCell>

                    {/* <TableCell>
                      {d.status !== "COMPLETED" && t("BUTTONS.Available_Soon")}
                      {d.status === "COMPLETED" && (
                        <button
                          className={`download ${
                            _.get(
                              props,
                              ["recordings", "downloadRecordingStart"],
                              false
                            )
                              ? "disable-download"
                              : ""
                          }`}
                          onClick={() => downloadRecording(d)}
                          disabled={_.get(
                            props,
                            ["recordings", "downloadRecordingStart"],
                            false
                          )}
                        >
                          <i className="icon-download"></i>
                          <span>{t("BUTTONS.Download")}</span>
                        </button>
                      )}
                    </TableCell> */}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      )}
      <div className="pagination-wrapper">
        {totalCount !== 0 && (
          <span className="show-results">
            {t("COMMON_MESSAGES.Showing")} {startPoint}{" "}
            {t("COMMON_MESSAGES.to")} {endPoint} {t("COMMON_MESSAGES.of")}{" "}
            {totalCount} {t("COMMON_MESSAGES.entries")}
          </span>
        )}

        <CustomPagination
          shape="rounded"
          limit={pageSize}
          total={totalCount}
          count={totalPage}
          page={pageNo}
          onChange={handlePagination}
        />
      </div>
    </div>
  );
};

export default RelarTab;
