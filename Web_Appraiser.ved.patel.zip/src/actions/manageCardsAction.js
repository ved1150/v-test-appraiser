import { StartLoading, StopLoading } from "./UIAction";
import * as actionTypes from "./actionTypes";
import manageCardsService from "../services/manageCardsService";

const startManageCardList = () => {
  return {
    type: actionTypes.MANAGE_CARDS_LIST_START,
  };
};

const successManageCardList = (data) => {
  return {
    type: actionTypes.MANAGE_CARDS_LIST_SUCCESS,
    payload: data,
  };
};

const errorManageCardList = (error) => {
  return {
    type: actionTypes.MANAGE_CARDS_LIST_ERROR,
    payload: error,
  };
};

export function getManageCardList(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startManageCardList());
    return manageCardsService
      .getManageCardList(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successManageCardList(data?.data?.data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorManageCardList(err));
      });
  };
}

const startDeleteCard = () => {
  return {
    type: actionTypes.DELETE_CARDS_START,
  };
};

const successDeleteCard = (data) => {
  return {
    type: actionTypes.DELETE_CARDS_SUCCESS,
    payload: data,
  };
};

const errorDeleteCard = (error) => {
  return {
    type: actionTypes.DELETE_CARDS_ERROR,
    payload: error,
  };
};

export function deleteManageCard(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startDeleteCard());
    return manageCardsService
      .deleteManageCard(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successDeleteCard(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorDeleteCard(err));
      });
  };
}

const startSetDefaultCard = () => {
  return {
    type: actionTypes.SET_DEFAULT_CARDS_START,
  };
};

const successSetDefaultCard = (data) => {
  return {
    type: actionTypes.SET_DEFAULT_CARDS_SUCCESS,
    payload: data,
  };
};

const errorSetDefaultCard = (error) => {
  return {
    type: actionTypes.SET_DEFAULT_CARDS_ERROR,
    payload: error,
  };
};

export function setDefaultCard(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startSetDefaultCard());
    return manageCardsService
      .setDefaultCard(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successSetDefaultCard(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorSetDefaultCard(err));
      });
  };
}

const startManageCardGetToken = () => {
  return {
    type: actionTypes.MANAGE_CARDS_GET_TOKEN_START,
  };
};

const successManageCardGetToken = (data) => {
  return {
    type: actionTypes.MANAGE_CARDS_GET_TOKEN_SUCCESS,
    payload: data,
  };
};

const errorManageCardGetToken = (error) => {
  return {
    type: actionTypes.MANAGE_CARDS_GET_TOKEN_ERROR,
    payload: error,
  };
};

export function getManageCardToken(data) {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startManageCardGetToken());
    return manageCardsService
      .getHostedProfilePageRequestToken(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successManageCardGetToken(data?.data?.data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorManageCardGetToken(err));
      });
  };
}
