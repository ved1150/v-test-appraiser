import { Component, createRef } from "react";
import { connect } from "react-redux";
import _ from "lodash";
import {
  deleteAttachment,
  loadAttachments,
  uploadAttachment,
  downloadAttachment,
} from "./../../../../actions/attachmentsAction";
import {
  DATE_TIME_API_FORMAT,
  TIME_SHORT_FORMAT,
} from "./../../../../constants/appConstant";
import { getUTCToLocalDateTimeWithFormat } from "../../../../helpers";
import { customToast } from "./../../../../helpers/customToast";
import { ATTACHMENT_UPLOAD_SIZE_EXCEEDED } from "./../../../../constants/commonMessages";
import "./attachmentDocumentModal.scss";
import NoDataView from "../Common/noDataView";
import { ATTACHMENTS, ATTACHMENTS_ICON } from "../Common/commonText";

import { withTranslation } from "react-i18next";
const AttachmentItem = ({
  fileName,
  user,
  time,
  onDownloadAttachment,
  onDeleteAttachment,
}) => {
  return (
    <div className="box">
      <div className="title">
        <i className="icon-Attach-Document"></i>
        {fileName}
      </div>
      <div className="bottom-list">
        <span className="user">
          <i className="icon-user-management"></i>
          {user}
        </span>
        <div className="rigit-info">
          <span className="time">
            <i className="icon-Time"></i>
            {time}
          </span>
          <span className="delete-down">
            <button onClick={onDownloadAttachment}>
              <i className="icon-download"></i>
            </button>
            {/* <button onClick={onDeleteAttachment}>
              <i className="icon-delete"></i>
            </button> */}
          </span>
        </div>
      </div>
    </div>
  );
};

class AttachmentDocumentModal extends Component {
  constructor() {
    super();
    this.state = {};
    this.uploadRef = createRef();
  }

  componentDidMount() {
    this.props.fetchAttachments({
      jobOrderId: this.props.jobOrderId,
      direction: "desc",
      sortBy: "updatedAt",
    });
  }

  validateAttachDocumentType(file) {
    return (
      ["image/jpeg", "image/png", "application/pdf"].includes(file.type) &&
      (file.name.endsWith(".jpg") ||
        file.name.endsWith(".JPG") ||
        file.name.endsWith(".jpeg") ||
        file.name.endsWith(".JPEG") ||
        file.name.endsWith(".png") ||
        file.name.endsWith(".PNG") ||
        file.name.endsWith(".pdf"))
    );
  }

  onDrop(e) {
    const { t } = this.props;
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (!this.validateAttachDocumentType(file)) {
      return customToast.error(
        t("COMMON_MESSAGES.ATTACHMENT_UPLOAD_UNSUPPORTED_FORMAT")
      );
    }
    if (file.size / (1024 * 1024) >= 10) {
      return customToast.error(ATTACHMENT_UPLOAD_SIZE_EXCEEDED);
    }
    this.uploadFile(file);
  }

  onSelectAttachment(e) {
    const { t } = this.props;
    e.preventDefault();
    const file = e.target.files[0];
    if (!this.validateAttachDocumentType(file)) {
      return customToast.error(
        t("COMMON_MESSAGES.ATTACHMENT_UPLOAD_UNSUPPORTED_FORMAT")
      );
    }
    if (file.size / (1024 * 1024) >= 10) {
      return customToast.error(
        t("COMMON_MESSAGES.ATTACHMENT_UPLOAD_SIZE_EXCEEDED")
      );
    }
    this.uploadFile(file);
  }

  uploadFile = (file) => {
    const fileName = file.name;
    const extraPayload = {
      attachmentDetails: JSON.stringify({
        joborderId: this.props.jobOrderId,
        updatedBy: _.get(
          this.props,
          ["details", "fetchDetailsSuccess", "assignee"],
          ""
        ),
      }),
    };
    this.props
      .uploadAttachment(file, fileName, extraPayload)
      .then(() => {
        this.props.setIsRefreshAttachments(!this.props.isRefreshAttachments);
        this.props.fetchAttachments({
          jobOrderId: this.props.jobOrderId,
          direction: "desc",
          sortBy: "updatedAt",
        });
      })
      .catch((err) => {
        this.props.setIsRefreshAttachments(false);
      });
  };

  formatTime = (date) => {
    return getUTCToLocalDateTimeWithFormat(
      date,
      DATE_TIME_API_FORMAT,
      TIME_SHORT_FORMAT
    );
  };

  downloadAttachment({ fileName, attachmentId }) {
    this.props.downloadAttachment(attachmentId).then((data) => {
      const blob = new Blob([data.data], {
        type: data.headers["content-type"],
      });
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob);
        return;
      }
      const url = URL.createObjectURL(blob);
      let link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  }

  async deleteAttachment(attachmentId) {
    await this.props.deleteAttachment(attachmentId);
    this.props.fetchAttachments({
      jobOrderId: this.props.jobOrderId,
      direction: "desc",
      sortBy: "updatedAt",
    });
  }

  render() {
    const { attachments, uploading, t } = this.props;
    return (
      <div className="comman-modal right-side open">
        <div className="comman-modal-main">
          <div className="side-head">
            <div className="icon">
              <i className="icon-Attach-Document"></i>
              <span className="count">{attachments.length}</span>
            </div>
            {t("BUTTONS.Attach_Document")}
            <button
              className="close-modal"
              onClick={() => this.props.hideAttachmentDocumentModal()}
            >
              <i className="icon-close-image"></i>
            </button>
          </div>
          <div className="comman-modal-body attach-document-modal scroll-bar-style">
            <div
              className="attach-button"
              onDrop={(e) => this.onDrop(e)}
              onDragEnter={(e) => e.preventDefault()}
              onDragOver={(e) => e.preventDefault()}
            >
              <button
                className="drop-btn"
                onClick={() => {
                  this.uploadRef.current.click();
                }}
              >
                <i class="icon-attach"></i>
                {t("WEB_LABELS.Drop_Or_Select_Your_File")}{" "}
                {!!uploading && <div class="loader-spin"></div>}
              </button>
              <input
                hidden
                type="file"
                ref={this.uploadRef}
                onChange={this.onSelectAttachment.bind(this)}
              />
            </div>
            <div className="attach-list">
              {attachments.length > 0 ? (
                attachments.map((item, i) => (
                  <AttachmentItem
                    key={item.attachmentId}
                    fileName={item.fileName}
                    user={item.updatedBy}
                    time={this.formatTime(item.updatedAt)}
                    onDownloadAttachment={() => this.downloadAttachment(item)}
                    onDeleteAttachment={() =>
                      this.deleteAttachment(item.attachmentId)
                    }
                  />
                ))
              ) : (
                <NoDataView
                  text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.ATTACHMENTS")}
                  icon={ATTACHMENTS_ICON}
                ></NoDataView>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  uploadAttachment: (file, fileName, extraPayload) =>
    dispatch(uploadAttachment(file, fileName, extraPayload)),
  deleteAttachment: (attachmentId) => dispatch(deleteAttachment(attachmentId)),
  fetchAttachments: (data) => dispatch(loadAttachments(data)),
  downloadAttachment: (attachmentId) =>
    dispatch(downloadAttachment(attachmentId)),
});

const mapStateToProps = ({ attachments, details }) => ({
  attachments: attachments.attachments || [],
  uploading: attachments.uploading,
  details: details,
});

const connectedAttachmentDocumentModal = connect(
  mapStateToProps,
  mapDispatchToProps
)(withTranslation()(AttachmentDocumentModal));
export { connectedAttachmentDocumentModal as AttachmentDocumentModal };
