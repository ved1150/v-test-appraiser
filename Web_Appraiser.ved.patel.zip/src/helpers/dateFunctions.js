import moment from "moment";

export function getUTCToLocalDateTimeWithFormat(
  dateTime,
  inputFormat,
  outputFormat
) {
  return moment.utc(dateTime, inputFormat).local().format(outputFormat);
}
