import { fabric } from "fabric";
export function createTextGroup(
  myLine,
  unRoundedSizeFeetLabel,
  angle,
  angleDeg,
  roomFontSize = 12
) {
  var lineLeft = new fabric.Path("M 1 1 L 10 1", {
    left: myLine.x1,
    top: myLine.y1,
    stroke: "black",
    strokeWidth: 1,
    fill: true,
    angle: angle - 90,
    originX: "center",
  });

  var lineRight = new fabric.Path("M 1 1 L 10 1", {
    left: myLine.x2,
    top: myLine.y2,
    stroke: "black",
    strokeWidth: 1,
    fill: true,
    angle: angle + 90,
    originX: "center",
  });

  var text = new fabric.Text(unRoundedSizeFeetLabel, {
    originX: "center",
    originY: "center",
    fontSize: roomFontSize,
    fontFamily: '"Roboto", sans-serif',
    fontWeight: 500,
    textBackgroundColor: "white",
    centeredRotation: false,
    textAlign: "center",
    type: "MEASUREMENT-BOX-TEXT",
  });
  // finished
  if (angleDeg >= -45 && angleDeg < 45) {
    text.set("angle", angleDeg);
  } else if (angleDeg >= 45 && angleDeg < 135) {
    text.set("flipY", true);
    text.set("flipX", true);
    text.set("angle", angleDeg);
  } else if (angleDeg >= 135 || angleDeg < -135) {
    text.set("flipY", true);
    text.set("flipX", true);
    text.set("angle", angleDeg);
  } else if (angleDeg >= -135 && angleDeg < -45) {
    text.set("flipY", true);
    text.set("flipX", true);
    text.set("angle", angleDeg);
  }
  let group = new fabric.Group([myLine, lineLeft, lineRight], {
    type: "MEASUREMENT-BOX-TEXT-GROUP",
  });
  group.add(text);
  group.setControlsVisibility({
    tr: false,
    tl: false,
    br: false,
    bl: false,
    ml: true,
    mr: true,
    mt: false,
    mb: false,
    mtr: false,
  });
  return group;
}
export function getLocation(text, indexedLine, midPointX, midPointY) {
  let centerOrigin = new fabric.Point(text.left, text.top);
  let radians = fabric.util.degreesToRadians(indexedLine.angle);
  const x = indexedLine.x1 - (midPointX - text.left);
  const y = indexedLine.y1 - (midPointY - text.top);
  const x2 = indexedLine.x2 - (midPointX - text.left);
  const y2 = indexedLine.y2 - (midPointY - text.top);
  let objectOrigin = new fabric.Point(x, y);
  let new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);

  let objectOrigin2 = new fabric.Point(x2, y2);
  let new_loc2 = fabric.util.rotatePoint(objectOrigin2, centerOrigin, radians);

  return { x1: new_loc.x, y1: new_loc.y, x2: new_loc2.x, y2: new_loc2.y };
}
