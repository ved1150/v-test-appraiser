import Switch from "@mui/material/Switch";

export default function DefaultCustomSwitch({ checked, onChange }) {
  return (
    <Switch
      sx={[
        !checked && {
          ".MuiSwitch-thumb": {
            color: "#fafafa",
          },
        },
        {
          ".MuiSwitch-switchBase.Mui-checked": {
            transform: "translateX(20px)",
            color: `${getComputedStyle(
              document.querySelector(":root")
            ).getPropertyValue("--button_bg_color")}`,
          },
        },
        {
          ".MuiSwitch-switchBase.Mui-checked+.MuiSwitch-track": {
            backgroundColor: `${getComputedStyle(
              document.querySelector(":root")
            ).getPropertyValue("--button_bg_color")}`,
          },
        },
      ]}
      checked={checked}
      onChange={onChange}
    />
  );
}
