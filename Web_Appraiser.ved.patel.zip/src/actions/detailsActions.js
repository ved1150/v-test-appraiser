import * as actionTypes from "./actionTypes";
import detailsService from "../services/detailsService";
import { StartLoading, StopLoading } from "./UIAction";

const startFetchDetails = () => {
  return {
    type: actionTypes.FETCH_DETAILS_START,
  };
};

const successFetchDetails = (data) => {
  return {
    type: actionTypes.FETCH_DETAILS_SUCCESS,
    payload: data,
  };
};

const errorFetchDetails = (error) => {
  return {
    type: actionTypes.FETCH_DETAILS_ERROR,
    payload: error,
  };
};

const startFetchCallDetails = () => {
  return {
    type: actionTypes.FETCH_CALL_DETAILS_START,
  };
};

const successFetchCallDetails = (data) => {
  return {
    type: actionTypes.FETCH_CALL_DETAILS_SUCCESS,
    payload: data,
  };
};

const errorFetchCallDetails = (error) => {
  return {
    type: actionTypes.FETCH_CALL_DETAILS_ERROR,
    payload: error,
  };
};

export const fetchDetails = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchDetails());
    return detailsService
      .getDetails(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchDetails(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchDetails(err));
      });
  };
};

export const fetchCallDetails = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchCallDetails());
    return detailsService
      .getCallDetails(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchCallDetails(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchCallDetails(err));
      });
  };
};
