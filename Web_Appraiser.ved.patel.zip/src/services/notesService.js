import api from "./apis/api";
import { hydrateNotes } from "./transformers/jobOrderDetailsTransformer";

class NotesService {
  getNotes(data) {
    return api.notes.getNotes(data).then(hydrateNotes);
  }
}

export default new NotesService();
