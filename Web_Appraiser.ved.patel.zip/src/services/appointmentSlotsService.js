import api from "./apis/api";
import jobService from "./jobService";
import { hydrateAvailabilities } from "./transformers/slotsTransformer";
import authenticationService from "./authenticationService";

class AppointmentSlotsService {
  post(data) {
    const requestData = {
      ...data,
    };
    return api.post(`appointmentslots`, requestData);
  }

  get(data) {
    const { startDate, endDate, userId } = data;
    return api
      .get(`appointmentslots?endDate=${endDate}&startDate=${startDate}`)
      .then((res) => hydrateAvailabilities(res.data.data));
  }
}

export default new AppointmentSlotsService();
