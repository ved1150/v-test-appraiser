import api from "./api";

export default class AttachmentAPI {
  getAttachmentsByJobOrderId(data) {
    return api.get(
      `/attachment/get/${data.jobOrderId}?direction=${data.direction}&sortBy=${data.sortBy}`
    );
  }

  addAttachment(formData) {
    return api.postMultipartFormData(`/attachment/add`, formData);
  }

  deleteAttachment(attachmentId) {
    return api.delete(`/attachment/delete/${attachmentId}`);
  }

  downloadAttachment(attachmentId) {
    return api.get(`/attachment/get/${attachmentId}`, {
      headers: {
        Accept: "*/*",
      },
      responseType: "blob",
    });
  }

  downloadAttachments(payload) {
    return api.downloadPost(`/joborder/downloadzip`, {
      jobOrderId: payload.joborder_id,
      selectedImages: payload.selected_file_uuid,
    });
  }
}
