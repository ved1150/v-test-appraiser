import { fabric } from "fabric";
import "fabric-history";
import _ from "lodash";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import bgimg from "./../../../../images/box-pattern.png";
import { customToast } from "../../../../helpers/customToast";
import { ERROR_IN_PDF } from "../../../../constants/commonMessages";
import i18n from "i18next";
import SentryUtils from "../../../../errors/SentryUtils";
import { getLabelPositionOuter, getRoomData } from "./Intersection";
import { createTextGroup, getLocation } from "./addLineArrow";
import {
  GLA_BORDER_COLOR,
  GLA_ROOM_COLOR,
  NON_GLA_BORDER_COLOR,
  NON_GLA_ROOM_COLOR,
  PARTITION_COLOR,
  PARTITION_DOOR_COLOR,
  PARTITION_INSIDE_DOOR_COLOR,
  PARTITION_WINDOW_COLOR,
  PARTITION_WINDOW_COLOR_BORDER,
} from "./utilityTwoD";
import { doorDirectionEnum } from "../../../../constants/enums";
const lineStokeWidth = 4;
let jobOrderId = 0,
  designatorWiseObjectArray = {},
  roomWiseLineAndTextObjects = {},
  roomLinesGroup = [],
  roomTextGroup = [],
  PIXEL_TO_FOOT_CONSTANT = 1,
  ratio = 1,
  ratioX = 1,
  ratioY = 1,
  zoomlevel = 100, // this is 1 meter = 100 pixels , based on ios auto conversation.
  originalFloorPlan = null,
  updatedFloorPlan = null,
  roomArray = [],
  roomWiseFontSize = {},
  canvas = null,
  maxX = 0,
  maxY = 0,
  minX = null,
  minY = null,
  canvasWidth = 953,
  canvasHeight = 478,
  selectedFloor = 0,
  baseFontSize = 14,
  wallThickness = 6,
  canvasCursorLayer = null,
  jobDetails = null,
  iscompleteJO = false,
  gla_area = 0,
  tenantLogo = null;
export async function generateImage(
  json,
  details,
  _tenantLogo,
  _jobOrderId,
  _iscompleteJO = false
) {
  jobDetails = details;
  jobOrderId = _jobOrderId;
  iscompleteJO = _iscompleteJO;
  tenantLogo = _tenantLogo;
  canvasCursorLayer = document.createElement("canvas");
  canvasCursorLayer.id = "CursorLayer";
  canvas = new fabric.Canvas("CursorLayer", {
    selection: false,
  });
  fabric.Canvas.prototype.getItemByAttr = function (attr, name) {
    var object = null,
      objects = this.getObjects();
    for (var i = 0, len = this.size(); i < len; i++) {
      if (objects[i][attr] && objects[i][attr] === name) {
        object = objects[i];
        break;
      }
    }
    return object;
  };

  originalFloorPlan = _.cloneDeep(json);
  updatedFloorPlan = _.cloneDeep(json);
  return await showTheListFromJsonRoomWise(updatedFloorPlan);
}
async function showTheListFromJsonRoomWise(json) {
  var jsonObject = json;
  var floorArray = [];
  try {
    if (jsonObject && jsonObject.EAGLEVIEW_EXPORT.STRUCTURES != null) {
      var roofPoints = jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
      if (!roofPoints[0] || !roofPoints[0]["@autoSnappedXY"]) {
        return await prepareHTML([], {});
      } else {
        var dataStructure = _.get(
          jsonObject,
          ["EAGLEVIEW_EXPORT", "STRUCTURES"],
          {}
        );
        wallThickness = _.get(dataStructure, ["@exteriorWallThickness"], 6);
        var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
        var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

        var roofPointsArray = roofPoints[0]["POINT"];

        var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
        var linesArray = lines[0].LINE;

        var faceArray = roofObject[0]["FACES"]["FACE"];

        designatorWiseObjectArray = {};

        let roomChildrenArray = [];

        for (
          let faceArrayIndex = 0;
          faceArrayIndex < faceArray.length;
          faceArrayIndex++
        ) {
          let roomFaceObject = faceArray[faceArrayIndex];
          if (
            designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
            roomFaceObject["@type"] == "ROOM"
          ) {
            roomChildrenArray = [];
            designatorWiseObjectArray[roomFaceObject["@id"]] = [];
            designatorWiseObjectArray[roomFaceObject["@id"]].push(
              roomFaceObject
            );
            let children = roomFaceObject["@children"];
            roomChildrenArray = children.split(",");
            for (
              let roomChildrenIndex = 0;
              roomChildrenIndex < roomChildrenArray.length;
              roomChildrenIndex++
            ) {
              let roomId = roomChildrenArray[roomChildrenIndex];
              for (
                let wallFaceObjectIndex = 0;
                wallFaceObjectIndex < faceArray.length;
                wallFaceObjectIndex++
              ) {
                let faceObject = faceArray[wallFaceObjectIndex];
                if (
                  faceObject["POLYGON"]["@path"].trim().length > 0 &&
                  roomId == faceObject["@id"]
                ) {
                  var lineId = faceObject["POLYGON"]["@path"];
                  for (
                    let lineArrayIndex = 0;
                    lineArrayIndex < linesArray.length;
                    lineArrayIndex++
                  ) {
                    let lineObject = linesArray[lineArrayIndex];
                    if (lineObject["@id"] == lineId) {
                      var linePointObjectArray = [];
                      var linePoints = lineObject["@path"].split(",");
                      for (
                        var linePointsIndex = 0;
                        linePointsIndex < linePoints.length;
                        linePointsIndex++
                      ) {
                        for (
                          let roofPointsArrayIndex = 0;
                          roofPointsArrayIndex < roofPointsArray.length;
                          roofPointsArrayIndex++
                        ) {
                          let roofPointObject =
                            roofPointsArray[roofPointsArrayIndex];
                          if (
                            roofPointObject["@id"] ==
                            linePoints[linePointsIndex]
                          ) {
                            linePointObjectArray.push(roofPointObject);

                            break;
                          }
                        }
                      }
                      lineObject["linePointObjectArray"] = linePointObjectArray;
                      linesArray[lineArrayIndex] = lineObject;
                      faceObject["LINE"] = lineObject;
                      faceArray[faceArrayIndex] = faceObject;
                    }
                  }
                  designatorWiseObjectArray[roomFaceObject["@id"]].push(
                    faceObject
                  );
                }
              }
            }
          } else {
            //TBD. NOT IN USE.
          }
        }
        canvas.viewportTransform[4] = 0;
        canvas.viewportTransform[5] = 0;
        canvas.isDrawingMode = false;
        canvas.freeDrawingBrush.width = 5;
        canvas.freeDrawingBrush.color = "red";
        roomArray = Object.keys(designatorWiseObjectArray);
        for (
          let roomArrayIndex = 0;
          roomArrayIndex < roomArray.length;
          roomArrayIndex++
        ) {
          let roomObjectArray =
            designatorWiseObjectArray[roomArray[roomArrayIndex]];
          roomWiseFontSize[roomArray[roomArrayIndex]] = baseFontSize;

          for (
            let roomObjectArrayIndex = 0;
            roomObjectArrayIndex < roomObjectArray.length;
            roomObjectArrayIndex++
          ) {
            let wallObject = roomObjectArray[roomObjectArrayIndex];
            if (wallObject.LINE == null) {
              floorArray.push({
                floorId: parseInt(wallObject["@floorindex"]),
                floorName: wallObject["@floor"],
              });
              continue;
            }

            var linePointObjectArray = wallObject.LINE.linePointObjectArray;

            for (
              let linePointObjectArrayInedex = 0;
              linePointObjectArrayInedex < linePointObjectArray.length;
              linePointObjectArrayInedex++
            ) {
              var value1 =
                linePointObjectArray[linePointObjectArrayInedex][
                  "@autoSnappedXY"
                ];
              if (value1 == null) {
                break;
              }
              var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
              var v1 = value1.split(",");
              var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

              if (parseFloat(v1[0]) > maxX) {
                maxX = parseFloat(v1[0]);
              }

              if (parseFloat(v1[1]) > maxY) {
                maxY = parseFloat(v1[1]);
              }

              if (minX == null) {
                minX = maxX;
              }
              if (minY == null) {
                minY = maxY;
              }

              if (parseFloat(v1[0]) < minX) {
                minX = parseFloat(v1[0]);
              }

              if (parseFloat(v1[1]) < minY) {
                minY = parseFloat(v1[1]);
              }
            }
          }
        }

        minX = minX - 120;
        minY = minY - 120;
        canvas.setHeight(canvasHeight + 50);
        canvas.setWidth(canvasWidth + 50);

        ratioX = 1;
        ratioY = 1;

        let multiplierX = 1;
        if (maxX - minX < canvasWidth) {
          ratioX = (canvasWidth / (maxX - minX)) * multiplierX;
        } else {
          ratioX = ((maxX - minX) / canvasWidth) * multiplierX;
        }

        if (maxY - minY < canvasHeight) {
          ratioY = (canvasHeight / (maxY - this, minY)) * multiplierX;
        } else {
          ratioY = ((maxY - minY) / canvasHeight) * multiplierX;
        }

        ratioX = Math.ceil(ratioX);
        ratioY = Math.ceil(ratioY);

        let maxRatio = ratioX > ratioY ? ratioX : ratioY;

        ratio = 1 / maxRatio;
        // ratio = 1 ;

        zoomlevel =
          _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"]) &&
          !_.isNaN(
            _.parseInt(
              _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"])
            )
          )
            ? _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"])
            : zoomlevel;
        let metertofeet = 3.28084;
        let pixeltometer = 1 / zoomlevel;
        let pixeltofeet = pixeltometer * metertofeet;
        PIXEL_TO_FOOT_CONSTANT = pixeltofeet;

        floorArray = _.uniq(floorArray);
        floorArray = _.uniqBy(floorArray, "floorId");

        floorArray = _.sortBy(floorArray, ["floorId"]);
        canvas.setHeight(canvasHeight);
        canvas.setWidth(canvasWidth);
        let imgDetails = [];
        let areaDetails = {};
        for (let i = 0; i < floorArray.length; i++) {
          selectedFloor = floorArray[i]["floorId"];
          drawFloorPlan();
          canvas.renderAll();
          await timer(200);
          imgDetails.push({
            image: downloadImage(),
            area: getAreaDetails(selectedFloor, floorArray[i]["floorName"]),
          });
          areaDetails = getAreaDetails();
          canvas.clear();
        }
        return await prepareHTML(imgDetails, areaDetails);
      }
    } else {
      return await prepareHTML([], {});
    }
  } catch (e) {
    SentryUtils.captureException(e);
    customToast.error(ERROR_IN_PDF);
    return false;
  }
}
const timer = (ms) => new Promise((res) => setTimeout(res, ms));
function downloadImage() {
  const dataURL = canvas.toDataURL({
    width: canvas.width,
    height: canvas.height,
    left: 0,
    top: 0,
    format: "png",
  });
  return dataURL;
}
function getAreaDetails(selectedFloor, floorName) {
  let roomObjectArray = [];
  let totalGLA = 0;
  let totalHeight = 0;
  let totalNonGLA = 0;
  let totalWallsThickness = 0;
  let totalRoomsArea = 0;
  let areaObject = {};
  var roomArray = Object.keys(designatorWiseObjectArray);
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < roomArray.length;
    roomArrayIndex++
  ) {
    roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];
    if (
      selectedFloor &&
      roomObjectArray.filter((el) => el["@type"] == "ROOM")[0]["@floorindex"] !=
        selectedFloor
    ) {
      continue;
    }
    let doorArr = _.filter(roomObjectArray, function (n) {
      return n["@type"] == "WALLPENETRATION" && n["@mode"] == "DOOR";
    });
    roomObjectArray.doorCount = _.size(doorArr);
    let windowArr = _.filter(roomObjectArray, function (n) {
      return n["@type"] == "WALLPENETRATION" && n["@mode"] == "WINDOW";
    });
    roomObjectArray.windowCount = _.size(windowArr);
    let roomObject = _.find(roomObjectArray, (room) => room["@type"] == "ROOM");
    if (roomObject) {
      let walls = roomObject["@children"].split(",");
      let totalWallThickness = _.size(walls) * wallThickness;
      totalWallThickness = totalWallThickness / 12;
      //  totalWallThickness = totalWallThickness;
      let roomArea = Number(roomObject["@editedArea"]);
      let totalMeasurement = roomArea + totalWallThickness;
      if (roomObject["@measuretype"] == "GLA") {
        totalGLA = totalGLA + totalMeasurement;
      } else if (roomObject["@measuretype"] == "Non-GLA") {
        totalNonGLA = totalNonGLA + totalMeasurement;
      } else {
      }
      let cheight = roomObject["@height"]
        ? parseFloat(roomObject["@height"])
        : 0;
      totalWallsThickness = totalWallsThickness + totalWallThickness;
      totalRoomsArea = totalRoomsArea + roomArea;
      totalHeight = cheight > totalHeight ? cheight : totalHeight;
      roomObjectArray.wallCount = _.size(walls);
      roomObjectArray.totalWallThickness = totalWallThickness.toFixed(2);
      roomObjectArray.roomArea = roomArea.toFixed(2);
    }
  }
  areaObject = {
    floorName,
    totalGLA: totalGLA > 0 ? totalGLA.toFixed(2) : totalGLA.toFixed(2),
    totalNonGLA:
      totalNonGLA > 0 ? totalNonGLA.toFixed(2) : totalNonGLA.toFixed(2),
    totalArea: (totalGLA + totalNonGLA).toFixed(2),
    totalWallsThickness: totalWallsThickness.toFixed(2),
    totalRoomsArea: totalRoomsArea.toFixed(2),
    totalHeight: totalHeight.toFixed(2),
  };
  return areaObject;
}
function drawFloorPlan() {
  setTimeout(() => {
    canvas.setBackgroundColor(
      {
        source: bgimg,
      },
      canvas.renderAll.bind(canvas)
    );
  }, 10);

  roomArray = Object.keys(designatorWiseObjectArray);

  let currentZoomLevel = canvas.getZoom();
  let calculatedFontSize = baseFontSize * currentZoomLevel;
  let roomWiseLineAndTextObjectsRef = getRoomData(
    designatorWiseObjectArray,
    selectedFloor,
    minX,
    minY,
    ratio
  );
  let selectedFloorRooms = [];
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < roomArray.length;
    roomArrayIndex++
  ) {
    let roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];
    if (roomObjectArray[0]["@floorindex"] == selectedFloor) {
      selectedFloorRooms.push(roomArray[roomArrayIndex]);
    }
  }

  //Now start drawing

  for (
    let roomArrayIndex = 0;
    roomArrayIndex < selectedFloorRooms.length;
    roomArrayIndex++
  ) {
    var areaName = "";
    var roomArea = "";
    var roomID = "";
    var measureType = "";
    var roomFontSize = 0;
    let roomAreaLabelLeft = 0;
    let roomAreaLabelTop = 0;
    let roomLabelAngle = 0;

    let roomObjectArray =
      designatorWiseObjectArray[selectedFloorRooms[roomArrayIndex]];

    //if(roomLinesGroup[""])

    roomLinesGroup = [];
    roomTextGroup = [];
    let polygonpoints = [];
    var wallNo = 0;
    for (
      let roomObjectArrayIndex = 0;
      roomObjectArrayIndex < roomObjectArray.length;
      roomObjectArrayIndex++
    ) {
      let wallObject = roomObjectArray[roomObjectArrayIndex];
      let wallID = wallObject["@id"];

      if (wallObject.LINE == null) {
        areaName = wallObject["@areaname"];
        roomArea = wallObject["@editedArea"];
        roomID = wallObject["@id"];
        measureType = wallObject["@measuretype"];
        roomAreaLabelLeft = wallObject["@areaLabelLeft"]
          ? (parseFloat(wallObject["@areaLabelLeft"]) - minX) * ratio
          : 0;
        roomAreaLabelTop = wallObject["@areaLabelTop"]
          ? (parseFloat(wallObject["@areaLabelTop"]) - minY) * ratio
          : 0;
        roomLabelAngle = wallObject["@labelAngle"];

        roomFontSize = roomWiseFontSize[roomID];

        roomWiseLineAndTextObjects[roomID] = {};
        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
        roomWiseLineAndTextObjects[roomID]["roomCircleGroup"] = [];
        roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = {};
        roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

        continue;
      }

      let isWallPenetration =
        wallObject["@type"] == "WALLPENETRATION" ? true : false;
      if (isWallPenetration == false) {
        //TBD
      } else {
        continue;
      }

      var linePointObjectArray = wallObject.LINE.linePointObjectArray;
      var poligonObject = wallObject.POLYGON;

      let points = [];

      for (
        let linePointObjectArrayInedex = 0;
        linePointObjectArrayInedex < linePointObjectArray.length;
        linePointObjectArrayInedex++
      ) {
        var value1 =
          linePointObjectArray[linePointObjectArrayInedex]["@autoSnappedXY"];

        if (value1 == null) {
          break;
        }
        var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
        var v1 = value1.split(",");
        var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
        points.push(fval);
      }
      if (points.length < 2) {
        break;
      }

      var line = null;

      //var color = wallNo % 2 == 0 ? "#fe741f" : "black";
      var color = "black";

      polygonpoints.push({
        x: (points[0].x - minX) * ratio,
        y: (points[0].y - minY) * ratio,
      });
      polygonpoints.push({
        x: (points[1].x - minX) * ratio,
        y: (points[1].y - minY) * ratio,
      });

      line = new fabric.Line(
        [
          (points[0].x - minX) * ratio,
          (points[0].y - minY) * ratio,
          (points[1].x - minX) * ratio,
          (points[1].y - minY) * ratio,
        ],
        {
          stroke: color,
          strokeWidth: lineStokeWidth,
          selectable: false,
          evented: false,
          id: wallID,
          roomID: roomID,
          type: "WALL-LINE",
          linePointObjectArray: linePointObjectArray,
          unroundedsize: wallObject["POLYGON"]["@editedUnroundedsize"],
          size: wallObject["POLYGON"]["@editedSize"],
          areaName: areaName,
          roomArea: roomArrayIndex,
        }
      );

      roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
      roomLinesGroup.push(line);

      if (isWallPenetration == false) {
        wallNo++;
      } else {
      }
    }

    let roomCenterPointX = 0;
    let roomCenterPointY = 0;

    for (
      var roomLinesGroupArrayIndex = 0;
      roomLinesGroupArrayIndex < roomLinesGroup.length;
      roomLinesGroupArrayIndex++
    ) {
      //var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";
      var color = "black";

      // Connectors

      var circle = null;
      if (roomLinesGroupArrayIndex == 0) {
        circle = makeCircle(
          roomLinesGroup[0].get("x1"),
          roomLinesGroup[0].get("y1"),
          roomLinesGroup[roomLinesGroup.length - 1],
          roomLinesGroup[0],
          color
        );

        // canvas.add(circle);
      } else {
        if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
          circle = makeCircle(
            roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
            roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
            roomLinesGroup[roomLinesGroupArrayIndex - 1],
            roomLinesGroup[roomLinesGroupArrayIndex],
            color
          );
        } else {
          circle = makeCircle(
            roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
            roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
            roomLinesGroup[roomLinesGroupArrayIndex - 1],
            roomLinesGroup[roomLinesGroupArrayIndex],
            color
          );
        }
      }
      roomCenterPointX +=
        (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
          roomLinesGroup[roomLinesGroupArrayIndex].x2) /
        2;
      roomCenterPointY +=
        (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
          roomLinesGroup[roomLinesGroupArrayIndex].y2) /
        2;
    }

    let totalPoints = roomLinesGroup.length;

    let areaLabelLeft = roomCenterPointX / totalPoints;
    let areaLabelTop = roomCenterPointY / totalPoints;

    var centreTextObject = null;
    if (canvas.getItemByAttr("id", roomID) != null) {
      centreTextObject = canvas.getItemByAttr("id", roomID);
      centreTextObject.set(
        "left",
        areaLabelLeft - centreTextObject.getBoundingRect().width / 2
      );

      centreTextObject.set(
        "top",
        areaLabelTop - centreTextObject.getBoundingRect().height / 2
      );
    } else {
      let displayRoomArea = "";
      if (roomArea.trim().length == 0) {
        roomArea = ".";
      } else {
        displayRoomArea = roomArea;
      }

      let roomAreaSpilts = roomArea.split(".");
      let tempCalculatedAreaInFoot =
        roomAreaSpilts && roomAreaSpilts.length > 0 ? roomAreaSpilts[0] : "";
      let tempCalculatedAreaPoints =
        roomAreaSpilts && roomAreaSpilts.length > 1 ? roomAreaSpilts[1] : "";
      let calculatedArea =
        tempCalculatedAreaInFoot != ""
          ? tempCalculatedAreaInFoot + "' " + tempCalculatedAreaPoints + "''"
          : "";

      let AreaNameLabel = "\n" + areaName;
      let centerBoxText =
        (displayRoomArea.length > 0 && !isNaN(displayRoomArea)
          ? parseFloat(displayRoomArea).toFixed(1)
          : displayRoomArea) + AreaNameLabel;
      centreTextObject = new fabric.Text(centerBoxText, {
        fontFamily: '"Roboto", sans-serif',
        fontSize: roomFontSize + 1,
        left: roomAreaLabelLeft || areaLabelLeft,
        top: roomAreaLabelTop || areaLabelTop,
        angle: roomLabelAngle || 0,
        fill: "#555555",
        id: roomID,
        objectCaching: false,
        textAlign: "center",
        selectable: false,
        textAlign: "center",
        type: "CENTRE-BOX-TEXT",
        // backgroundColor:"red",
      });

      if (!roomAreaLabelLeft) {
        centreTextObject.set(
          "left",
          areaLabelLeft - centreTextObject.getBoundingRect().width / 2
        );

        centreTextObject.set(
          "top",
          areaLabelTop - centreTextObject.getBoundingRect().height / 2
        );
      }
      // roomTextGroup.push(centreTextObject);
      // roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(
      //   centreTextObject
      // );
    }
    polygonpoints = _.uniqWith(polygonpoints, _.isEqual);
    const poly = new fabric.Polygon(polygonpoints, {
      fill: measureType == "GLA" ? GLA_ROOM_COLOR : NON_GLA_ROOM_COLOR,
      strokeWidth: 4,
      stroke: measureType == "GLA" ? GLA_BORDER_COLOR : NON_GLA_BORDER_COLOR,
      cornerColor: "black",
      roomID: roomID,
      ID: "POLY-" + roomID,
    });
    if (!roomAreaLabelLeft) {
      var polygonCenter = poly.getCenterPoint();
      centreTextObject.set(
        "left",
        polygonCenter.x - centreTextObject.getBoundingRect().width / 2
      );
      centreTextObject.set(
        "top",
        polygonCenter.y - centreTextObject.getBoundingRect().height / 2
      );
    }
    roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = poly;
    for (
      var roomLinesGroupArrayIndex = 0;
      roomLinesGroupArrayIndex < roomLinesGroup.length;
      roomLinesGroupArrayIndex++
    ) {
      let indexedLine = roomLinesGroup[roomLinesGroupArrayIndex];
      let wallID = indexedLine.get("id");
      let sizes = indexedLine.get("unroundedsize").split(".");
      let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";
      let tempPoints = sizes && sizes.length > 1 ? sizes[1] : "";
      let unRoundedSizeFeetLabel = tempFoot + "' " + tempPoints + "''";
      let polygonpointsclone =
        roomWiseLineAndTextObjects[indexedLine.roomID]["roomPolyGroup"];
      var coordinateForLable = coordinateForlable(
        indexedLine.x1,
        indexedLine.x2,
        indexedLine.y1,
        indexedLine.y2,
        areaLabelLeft,
        areaLabelTop
      );

      var text = new fabric.Text(unRoundedSizeFeetLabel, {
        fontFamily: '"Roboto", sans-serif',
        fontSize: baseFontSize,
        left: coordinateForLable.x,
        top: coordinateForLable.y,
        angle: coordinateForLable.orientation,
        fill: color,
        id: wallID,
        roomID: roomID,
        objectCaching: false,
        type: "LABEL",
        selectable: false,
        originX: "center",
        originY: "center",
      });
      let midPointX = (indexedLine.x1 + indexedLine.x2) / 2; //mid-point of line
      let midPointY = (indexedLine.y1 + indexedLine.y2) / 2;
      text = getLabelPositionOuter(
        text,
        midPointX,
        midPointY,
        coordinateForLable.orientation,
        polygonpointsclone,
        roomWiseLineAndTextObjectsRef,
        indexedLine
      );
      if (text) {
        const locations = getLocation(text, indexedLine, midPointX, midPointY);
        const lineZ = new fabric.Line(
          [locations.x1, locations.y1, locations.x2, locations.y2],
          {
            strokeWidth: 1,
            fill: "black",
            stroke: "black",
            originX: "center",
            originY: "center",
          }
        );
        text = createTextGroup(
          lineZ,
          unRoundedSizeFeetLabel,
          text.angle,
          coordinateForLable.orientation
        );
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
        //for alha release we are hiding the wall label.
        roomTextGroup.push(text);
      }
    }

    var roomDrawingObjectArray = [poly].concat(roomTextGroup);

    var group = new fabric.Group(roomDrawingObjectArray, {
      id: "GROUP-" + roomID,
      roomID: roomID,
      lockScalingX: true,
      lockScalingY: true,
      objectCaching: false,
      selectable: true,
      type: "GROUP",
      subTargetCheck: true,
      backgroundColor: "red",
      fill: "blue",
    });

    group.setControlsVisibility({
      mt: false,
      mb: false,
      ml: false,
      mr: false,
    });
    canvas.add(centreTextObject);
    canvas.add(group);
    group.initialLeft = group.left;
    group.initialTop = group.top;
  }
  createDoorsAndWindows();
  createLableForExterior();
  createLineForExterior();
  canvas.renderAll();
}
function createLineForExterior() {
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let linesViaAddLine = faceArray.filter((el) => el["@type"] == "LINE");
  for (let i = 0; i < linesViaAddLine.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@childrenLine"] &&
        el["@childrenLine"].split(",").includes(linesViaAddLine[i]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == linesViaAddLine[i].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");

      if (pointpath.length === 2) {
        let point1 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[0])[0]
          ["@dataXY"].split(",");

        let point2 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[1])[0]
          ["@dataXY"].split(",");

        const _fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - minX) * ratio,
            (parseFloat(point1[1]) - minY) * ratio,
            (parseFloat(point2[0]) - minX) * ratio,
            (parseFloat(point2[1]) - minY) * ratio,
          ],
          {
            id: linesViaAddLine[i]["@id"],
            visible: true,
            roomID: parentroom[0]["@id"],
            objectCaching: false,
            type: "LINE",
            stroke: PARTITION_COLOR,
            originX: "center",
            originY: "center",
            selectable: true,
            strokeUniform: true,
            strokeWidth: 4,
            padding: 4,
          }
        );
        canvas.add(_fabricLine);
      }
    }
  }
}
function createLableForExterior() {
  var roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  var roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  var roofPointsArray = roofPoints[0]["POINT"];
  var lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  var linesArray = lines[0].LINE;
  var faceArray = roofObject[0]["FACES"]["FACE"];
  let labels = faceArray.filter((el) => el["@type"] == "LABEL");
  for (let labelindex = 0; labelindex < labels.length; labelindex++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@childrenLabel"] &&
        el["@childrenLabel"].split(",").includes(labels[labelindex]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == labels[labelindex].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      let point = roofPointsArray
        .filter((el) => el["@id"] == pointpath[0])[0]
        ["@dataXY"].split(",");
      let RectX = (parseFloat(point[0]) - minX) * ratio;
      let RectY = (parseFloat(point[1]) - minY) * ratio;
      const textLabel = new fabric.IText(labels[labelindex]["@text"], {
        fontFamily: '"Roboto", sans-serif',
        fill: "black",
        id: labels[labelindex]["@id"],
        roomID: parentroom[0]["@id"],
        type: "textLabel",
        fontSize: baseFontSize,
        left: RectX,
        top: RectY,
        padding: 5,
        textAlign: "center",
        visible: true,
        hasControls: false,
        lockScalingX: true,
        lockScalingY: true,
      });
      canvas.add(textLabel);
    }
  }
}
function createDoorsAndWindows() {
  var roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  var roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  var roofPointsArray = roofPoints[0]["POINT"];
  var lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  var linesArray = lines[0].LINE;
  var faceArray = roofObject[0]["FACES"]["FACE"];
  let doors = faceArray.filter((el) => el["@type"] == "WALLPENETRATION");
  for (let doorindex = 0; doorindex < doors.length; doorindex++) {
    const parentwall = faceArray.filter((el) =>
      el["@children"].split(",").includes(doors[doorindex]["@id"])
    );
    const parentroom = faceArray.filter((el) =>
      el["@children"].split(",").includes(parentwall[0]["@id"])
    );
    if (parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == doors[doorindex].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      let point1 = roofPointsArray
        .filter((el) => el["@id"] == pointpath[0])[0]
        ["@autoSnappedXY"].split(",");
      let point2 = roofPointsArray
        .filter((el) => el["@id"] == pointpath[1])[0]
        ["@autoSnappedXY"].split(",");
      let pointspos = [
        (point1[0] - minX) * ratio,
        (point1[1] - minY) * ratio,
        (point2[0] - minX) * ratio,
        (point2[1] - minY) * ratio,
      ];
      var anglePipePoints = [];
      var circlePoint = new fabric.Circle({
        radius: 2,
        fill: "rgba(0,0,0,0)",
        //fill: 'white',
        left: pointspos[0],
        top: pointspos[1],
        selectable: false,
        originX: "center",
        originY: "center",
        hoverCursor: "auto",
      });

      canvas.add(circlePoint);

      var circlePoint1 = new fabric.Circle({
        radius: 2,
        fill: "rgba(0,0,0,0)",
        //fill: 'white',
        left: pointspos[2],
        top: pointspos[3],
        selectable: false,
        originX: "center",
        originY: "center",
        hoverCursor: "auto",
      });

      canvas.add(circlePoint1);

      anglePipePoints.push(circlePoint);
      anglePipePoints.push(circlePoint1);
      if (anglePipePoints.length > 1) {
        let startPoint = anglePipePoints[anglePipePoints.length - 2];
        let endPoint = anglePipePoints[anglePipePoints.length - 1];

        let line = new fabric.Line(
          [
            startPoint.get("left"),
            startPoint.get("top"),
            endPoint.get("left"),
            endPoint.get("top"),
          ],
          {
            stroke: PARTITION_DOOR_COLOR,
            strokeWidth: 3,
            hasControls: false,
            hasBorders: false,
            selectable: false,
            type: "DW",
            isDoor: doors[doorindex]["@mode"] == "DOOR",
            linePointObjectArray: doorline[0]["@path"],
            wallID: parentwall[0]["@id"],
            originX: "center",
            originY: "center",
            roomID: parentroom[0]["@id"],
            id: doors[doorindex]["@id"],
            unroundedsize: doors[doorindex]["POLYGON"]["@editedUnroundedsize"],
            size: doors[doorindex]["POLYGON"]["@editedSize"],
          }
        );
        if (doors[doorindex]["@mode"] !== "DOOR") {
          const wline = _.cloneDeep(line);
          wline.type = "Clone-DW";
          wline.stroke = PARTITION_WINDOW_COLOR_BORDER;
          wline.strokeWidth = 5;
          wline.id = "wclone-" + doors[doorindex]["@id"];
          canvas.add(wline);
        }
        //line = this.setHoverCusror(line);
        canvas.add(line);
      }
    }
  }
}
function makeCircle(
  left,
  top,
  line1,
  line2,
  color = "red",
  editedRoomAngle = 0
) {
  var c = new fabric.Circle({
    left: left,
    top: top,
    strokeWidth: 6,
    radius: 3,
    fill: "#fff",
    stroke: color,
    type: "connector",
    angle: editedRoomAngle,
    originX: "center",
    originY: "center",
  });
  c.hasControls = c.hasBorders = false;

  c.line1 = line1;
  c.line2 = line2;

  return c;
}
function coordinateForlable(x0, x1, y0, y1, centreX, centreY, length) {
  let midPointX = (x0 + x1) / 2; //mid-point of line
  let midPointY = (y0 + y1) / 2;
  let distanceFromMidpoint = Math.sqrt(
    Math.pow(centreX - midPointX, 2) + Math.pow(centreY - midPointY, 2)
  );
  let lambda = 0.1;
  let lablePointX = (lambda * centreX + midPointX) / (lambda + 1);
  let lablePointY = (lambda * centreY + midPointY) / (lambda + 1);
  let orientation = Math.atan2(y1 - y0, x1 - x0) * (180.0 / Math.PI);

  return {
    x: lablePointX,
    y: lablePointY,
    orientation,
  };
}

async function prepareHTML(imgDetails, areaObject) {
  const doc = new jsPDF("p", "px", [640, 880], true);
  doc.internal.scaleFactor = 2;
  const pageWidth =
    doc.internal.pageSize.width || doc.internal.pageSize.getWidth();
  const pageHeight =
    doc.internal.pageSize.height || doc.internal.pageSize.getHeight();

  let Body = `<html>
	<head>
	</head><body style="height:0px;overflow:auto;">
  <table id="firstPage" style="width:70%;height:1050px;margin: 0 auto">
			<tbody>
				<tr>
        <td style="padding:10px;text-align:center" colspan="2">
						<div style="padding:0 0 0 0"> <img src=${tenantLogo} width="350px;" alt=""></div>
						<div style="width: 100%;margin: 0;  padding: 0;">
							<h1 style="text-transform: uppercase;font-size: 65px;letter-spacing: 1px;">Inspection Report</h1>
						</div>
					</td>
			  </tr>
				
			</tbody>
		</table>`;
  Body += `<div id="jodetails" style="width:70%;height:1050px;margin: 0 auto">
  <div style="width:100%;padding:10px;border-bottom: 1px solid #bdbdbd">
			<div style="float:left">
			<img src=${tenantLogo} height="30px" alt="">
			</div>
			<div style="float:right;padding: 10px 0;margin-right:20px;">
				1
			</div>
			<div style="clear:both">
			</div>
		</div>
  <table  style="width:100%;">
  <tbody>
    <tr>
      <td style="padding:10px;" colspan="2">    
        <div style="width: 100%;padding: 10px; margin: 0 auto;background: #1c375c; color:#fff"> <p><b>${i18n.t(
          "WEB_LABELS.Job_Order_Details"
        )}</b></p> </div>
        <div style="width: 100%;margin: 0 auto; border: 1px solid #bdbdbd; padding: 0;background: #eee;">
          <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Job_Order_ID"
          )}:</b>  ${_.get(jobDetails, ["orderNo"], "--")}</p></div>
          <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Job_Order_Assignee"
          )}:</b> ${_.get(jobDetails, ["assignee"], "--")}</p></div>
          <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Property_Type"
          )}:</b> ${_.get(jobDetails, ["propertyType"], "--")}</p></div>
          <div  style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Assigned_Date"
          )}:</b>${_.get(jobDetails, ["formatedAssignedDate"], "--")}</p></div>
          <div style="padding: 10px;"><p><b>${i18n.t(
            "WEB_LABELS.Job_Order_Status"
          )}:</b> ${_.get(jobDetails, ["jobOrderStatus"], "--")}</p></div>
        </div>
      </td>
    </tr>
    <tr>
      <td style="padding:10px;" colspan="2">    
        <div style="width: 100%;padding: 10px; margin: 0 auto;background: #1c375c; color:#fff"> <p><b>${i18n.t(
          "WEB_LABELS.Customer_Details"
        )}</b></p> </div>
        <div style="width: 100%;margin: 0 auto; border: 1px solid #bdbdbd; padding: 0;background: #eee;">
          <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Name"
          )}:</b> ${_.get(jobDetails, ["name"], "--")}</p></div>
          <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Address"
          )}:</b>  ${_.get(jobDetails, ["address"], "--")}</p></div>
          <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Cell_Phone"
          )}:</b> ${_.get(jobDetails, ["phone"], "--")}</p></div>
          <div style="padding: 10px;border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
            "WEB_LABELS.Email"
          )}:</b> ${_.get(jobDetails, ["email"], "--")}</p></div>
         </div>
      </td>
    </tr>`;
  if (areaObject.totalRoomsArea) {
    Body += ` <tr>
					<td style="padding:10px;" colspan="2">    
						<div style="width: 100%;padding: 10px; margin: 0 auto;background: #1c375c; color:#fff"> <p><b>${i18n.t(
              "WEB_LABELS.Total"
            )} ${i18n.t("WEB_LABELS.Area")}</b></p> </div>
						<div style="width: 100%;margin: 0 auto; border: 1px solid #bdbdbd; padding: 0;background: #eee;">
							<div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
                "WEB_LABELS.Total_Room_Units_Square_Feet"
              )}:</b> ${areaObject.totalRoomsArea}</p></div>
							<div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
                "WEB_LABELS.Total_Walls_Square_Feet"
              )}:</b> ${areaObject.totalWallsThickness}</p></div>
							<div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
                "WEB_LABELS.Total_GLA_Square_Feet"
              )}:</b> ${areaObject.totalGLA}</p></div>
							<div style="padding: 10px;border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
                "WEB_LABELS.Total_Non_GLA_Square_Feet"
              )}:</b> ${areaObject.totalNonGLA}</p></div>
							<div style="padding: 10px;"><p><b>${i18n.t(
                "WEB_LABELS.Total_Square_Feet"
              )}:</b> ${areaObject.totalArea}</p></div>
            </div>
					</td>
				</tr>`;
  }
  Body += `</tbody>
</table></div>`;

  for (let i = 0; i < imgDetails.length; i++) {
    Body += `<div id="measurementdetails${i}" style="width:70%;height:1050px;margin: 0 auto">
    <div style="width:100%;padding:10px;border-bottom: 1px solid #bdbdbd">
        <div style="float:left">
        <img src=${tenantLogo} height="30px" alt="">
        </div>
        <div style="float:right;padding: 10px 0;margin-right:20px;">
          ${i + 2}
        </div>
        <div style="clear:both">
        </div>
      </div>
    <table  style="width:100%;padding:10px;">
    <tbody>
      <tr>
        <td style="padding:;" colspan="2" >    
          <div style="width: 100%;padding: 10px; margin: 0 auto;background: #1c375c; color:#fff"> <p><b>${
            imgDetails[i].area.floorName
          }</b></p> </div>
        </td>
      </tr>
      <tr>
        <td style="padding:;" colspan="2" >    
          <div style="padding:15px 10px 0">
            <div class="" style="float:left;margin-right:15px">	
              <div style="width:20px;float:left;height:20px;margin-right:10px;background:${GLA_ROOM_COLOR};border:1px solid ${GLA_BORDER_COLOR};display:inline-block">
              </div> GLA
            </div>
            <div class="" style="float:left;margin-right:15px">	
              <div style="width:20px;float:left;height:20px;margin-right:10px;background:${NON_GLA_ROOM_COLOR};border:1px solid ${NON_GLA_BORDER_COLOR};display:inline-block">
              </div> NON-GLA
            </div>
            <div class="" style="float:left;margin-right:15px">	
              <div style="width:20px;float:left;height:20px;margin-right:10px;background:rgb(255 255 255 / 50%);border:1px solid #000;display:inline-block">
              </div> Door
            </div>
            <div class="" style="float:left;margin-right:15px;display:none">	
              <div style="width:20px;float:left;height:20px;margin-right:10px;background:rgb(153, 153, 153);border:1px solid #000;display:inline-block">
              </div> Window
            </div>
            <div style="clear:both;margin:0;padding:0"></div>
          </div>
        </td>
      </tr>
      <tr>
        <td style="text-align:center;padding-left:0;" colspan="2" >    
          <div style="width:${canvasWidth};height:${canvasHeight};margin: 0 auto; border: 1px solid #bdbdbd; padding: 0;background: #fff;">
            <img src="${
              imgDetails[i].image
            }" style="width:${canvasWidth};height:${canvasHeight}" alt="">
          </div>
        </td>
      </tr>
      <tr>
        <td >  
          <div style="width: 100%;margin: 0 auto; border: 1px solid #bdbdbd; padding: 0;background: #eee;">
            <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
              "WEB_LABELS.Total_Room_Units_Square_Feet"
            )}:</b> ${imgDetails[i].area.totalRoomsArea}</p></div>
            <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
              "WEB_LABELS.Total_Walls_Square_Feet"
            )}:</b> ${imgDetails[i].area.totalWallsThickness}</p></div>
            <div style="padding: 10px; border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
              "WEB_LABELS.Total_GLA_Square_Feet"
            )}:</b> ${imgDetails[i].area.totalGLA}</p></div>
            <div style="padding: 10px;border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
              "WEB_LABELS.Total_Non_GLA_Square_Feet"
            )}:</b> ${imgDetails[i].area.totalNonGLA}</p></div>
            <div style="padding: 10px;border-bottom: 1px solid #bdbdbd;"><p><b>${i18n.t(
              "WEB_LABELS.Total_Square_Feet"
            )}:</b> ${imgDetails[i].area.totalArea}</p></div>
            <div style="padding: 10px;"><p><b>${i18n.t(
              "WEB_LABELS.Height_Feet"
            )}:</b> ${imgDetails[i].area.totalHeight}</p></div>
          </div>
        </td>
      </tr>
    </tbody>
  </table></div>`;
  }
  Body += "</body></html>";
  let htmlel = document.createElement("html");
  htmlel.innerHTML = Body;
  document.body.appendChild(htmlel);
  const firstPage = await html2canvas(document.querySelector("#firstPage"), {
    scale: 4,
  });
  doc.addImage(firstPage.toDataURL(), "PNG", 0, 0, 640, 800, undefined, "FAST");
  doc.addPage();
  const canvas = await html2canvas(document.querySelector("#jodetails"), {
    scale: 4,
  });
  doc.addImage(canvas.toDataURL(), "PNG", 0, 0, 640, 800, undefined, "FAST");
  if (imgDetails.length > 0) doc.addPage();

  for (let i = 0; i < imgDetails.length; i++) {
    const canvas = await html2canvas(
      document.querySelector("#measurementdetails" + i),
      { scale: 4 }
    );
    doc.addImage(canvas.toDataURL(), "PNG", 0, 0, 640, 800, undefined, "FAST");
    if (imgDetails.length - 1 != i) doc.addPage();
  }
  document.body.removeChild(htmlel);
  // addFooters(doc, pageWidth, pageHeight);
  let formdata = new FormData();
  formdata.append("file", doc.output("blob"), jobOrderId + ".pdf");
  formdata.append(
    "jobOrderCompleteRequest",
    JSON.stringify({
      jobOrderId: jobOrderId,
      glaSquareFootage: areaObject.totalGLA ? areaObject.totalGLA : 0.0,
    })
  );
  if (!iscompleteJO) {
    doc.save(_.get(jobDetails, ["address"], "Inspection") + "_Report.pdf");
  }
  return formdata;
}
const addFooters = (doc, pageWidth, pageHeight) => {
  const pageCount = doc.internal.getNumberOfPages();
  doc.setFontSize(14);
  for (var i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFont("Roboto", "normal");
    doc.setTextColor(0);
    doc.text(
      _.get(jobDetails, ["address"], "--"),
      pageWidth / 2,
      pageHeight - 6,
      "center"
    );
  }
};
