export const rotateXPoints = (p) => {
  const cos = Math.cos(-Math.PI / 2);
  const sin = Math.sin(-Math.PI / 2);
  let y = p.y * cos - p.z * sin;
  let z = p.z * cos + p.y * sin;
  p.y = y;
  p.z = z;
  return p;
};

export const getCurrentZoomFactorDevice = (width, height) => {
  let zoomFactor = (width / height) * 100.0;
  return Math.ceil(zoomFactor / 50) * 50;
};
export const convert2DPointsFrom3D = (pointsIn3D, width, height) => {
  let zoomFactor = parseFloat(getCurrentZoomFactorDevice(width, height));
  var pointsIn2D = [];
  pointsIn3D.forEach((pointIn3D) => {
    let x = zoomFactor * pointIn3D.x + width;
    let y = height - zoomFactor * pointIn3D.z;
    pointsIn2D.push({ x, y });
  });
  var transformed2DPoints = transform2DPoints(pointsIn2D);
  let yData = transformed2DPoints.map((el) => el.y);
  yData = yData.sort();
  let maxY = yData[yData.length - 1];
  let minY = yData[0];
  transformed2DPoints = transformed2DPoints.map((el) => {
    return { x: el.x, y: maxY - el.y + minY };
  });
  pointsIn3D.forEach((el, i) => {
    transformed2DPoints[i].dx = pointsIn3D[i].x;
    transformed2DPoints[i].dy = pointsIn3D[i].y;
    transformed2DPoints[i].dz = pointsIn3D[i].z;
    transformed2DPoints[i].scaleX = pointsIn3D[i].scaleX;
    transformed2DPoints[i].scaleY = pointsIn3D[i].scaleY;
    if (pointsIn3D[i].doorDirection) {
      transformed2DPoints[i].doorDirection = pointsIn3D[i].doorDirection;
    }
  });
  return transformed2DPoints;
};
const transform2DPoints = (vertices) => {
  var point2dList = [];
  if (vertices.length >= 2) {
    let zerothVertex = vertices[0];
    let firstVertex = vertices[1];
    let slope =
      (firstVertex.y - zerothVertex.y) / (firstVertex.x - zerothVertex.x);
    let isPositiveSlope = slope >= 0;
    let degree = (Math.atan(slope) * 180) / Math.PI;
    let offsetAngle = isPositiveSlope ? 360 - degree : 180 - degree;
    for (let i = 0; i < vertices.length; i++) {
      if (i == 0) {
        point2dList.push(zerothVertex);
      } else {
        let originalPoint = vertices[i];
        let centerPoint = {
          x: zerothVertex.x,
          y: zerothVertex.y,
        };
        let transformedPoint = rotatePoint(
          originalPoint,
          centerPoint,
          offsetAngle
        );
        point2dList.push(transformedPoint);
      }
    }
  }
  return point2dList;
};
const rotatePoint = (pointToRotate, centerPoint, angleInDegrees) => {
  let angleInRadians = angleInDegrees * (Math.PI / 180);
  let cosTheta = Math.cos(angleInRadians);
  let sinTheta = Math.sin(angleInRadians);
  let x =
    cosTheta * (pointToRotate.x - centerPoint.x) -
    sinTheta * (pointToRotate.y - centerPoint.y) +
    centerPoint.x;
  let y =
    sinTheta * (pointToRotate.x - centerPoint.x) +
    cosTheta * (pointToRotate.y - centerPoint.y) +
    centerPoint.y;
  return { x: x, y: y };
};

export const coordinateForlable = (
  x0,
  x1,
  y0,
  y1,
  centreX,
  centreY,
  length
) => {
  let midPointX = (x0 + x1) / 2; //mid-point of line
  let midPointY = (y0 + y1) / 2;
  let distanceFromMidpoint = Math.sqrt(
    Math.pow(centreX - midPointX, 2) + Math.pow(centreY - midPointY, 2)
  );
  let lambda = 0.1;
  // let lambda = approximateDistanceFromLine /(distanceFromMidpoint - approximateDistanceFromLine);
  let lablePointX = (lambda * centreX + midPointX) / (lambda + 1);
  let lablePointY = (lambda * centreY + midPointY) / (lambda + 1);
  let orientation = Math.atan2(y1 - y0, x1 - x0) * (180.0 / Math.PI);

  return {
    x: lablePointX,
    y: lablePointY,
    orientation,
  };
};

export const getLabelPosition = (text, midPointX, midPointY, angleDeg) => {
  text.set("flipY", false);
  text.set("flipX", false);
  if (angleDeg >= -45 && angleDeg < 45) {
    text.set("left", midPointX);
    text.set("top", midPointY - 10);
  } else if (angleDeg >= 45 && angleDeg < 135) {
    text.set("left", midPointX + 10);
    text.set("top", midPointY);
  } else if (angleDeg >= 135 || angleDeg < -135) {
    text.set("left", midPointX);
    text.set("top", midPointY + 10);
    text.set("flipX", true);
  } else if (angleDeg >= -135 && angleDeg < -45) {
    text.set("left", midPointX - 10);
    text.set("top", midPointY);
  }
  return text;
};
