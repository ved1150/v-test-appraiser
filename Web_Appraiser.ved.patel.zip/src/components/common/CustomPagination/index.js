import Pagination from "@mui/material/Pagination";
export default function CustomPagination({
  count,
  limit,
  page,
  total,
  onChange,
}) {
  return (
    <Pagination
      shape="rounded"
      count={count}
      limit={limit}
      page={page}
      total={total}
      onChange={onChange}
      sx={[
        {
          ".MuiPaginationItem-root": {
            color: "#3f51b5",
            fontWeight: 500,
          },
          ".MuiPaginationItem-root:hover": {
            backgroundColor: "rgba(63, 81, 181, 0.04)",
          },
          ".MuiPaginationItem-root.Mui-selected": {
            backgroundColor: "transparent",
          },
          ".MuiPaginationItem-root.Mui-selected:hover": {
            backgroundColor: "rgba(245, 0, 87, 0.04)",
          },
          ".Mui-selected": {
            color: "#f50057",
            fontWeight: 500,
          },
        },
      ]}
    />
  );
}
