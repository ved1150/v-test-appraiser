import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
const NoDataRelarView = (props) => {
  const { t } = useTranslation();
  const [message, setMessage] = useState();
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
    if (props.shouldRequestRelar.status == "RELAR_REQUEST_FAILED") {
      setMessage("WEB_LABELS.Relar_Could_Not_Locate_This_Address");
    }
    if (
      props.shouldRequestRelar.status != "RELAR_REQUEST_FAILED" &&
      props.shouldRequestRelar.isAPICalled &&
      !props.shouldRequestRelar.relarListExist
    ) {
      setIsLoading(true);
      props
        .requestRelar(props.jobOrderId)
        .then((res) => {
          setIsLoading(false);
          if (
            res?.data?.data?.status == "RELAR_REQUEST_ALREADY_SENT" ||
            res?.data?.data?.status == "RELAR_REQUEST_SENT"
          ) {
            setMessage("WEB_LABELS.Relar_Data_Is_Requested");
          } else if (res?.data?.data?.status == "RELAR_REQUEST_SUCCESS") {
            setMessage("WEB_LABELS.Relar_Data_Not_Found");
          }
        })
        .catch(() => {
          setIsLoading(false);
          setMessage("Failed to execute Relar request");
        });
    }
  }, [props.shouldRequestRelar]);
  return (
    <div className="no-data-found">
      <div className="box">
        {isLoading ? (
          <div className="loader-spin"></div>
        ) : (
          <div>
            <i className="icon-Measurement-Details"></i>
            <p>{t(message)}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NoDataRelarView;
