import * as actionTypes from "./actionTypes";
import jobOrdersManagementService from "./../services/jobOrdersManagementService";
import { customToast } from "../helpers/customToast";
import i18n from "../translations/i18n";

const createJobOrderStart = () => {
  return {
    type: actionTypes.CREATE_JOBORDER_START,
  };
};

const createJobOrderSuccess = (data) => {
  return {
    type: actionTypes.CREATE_JOBORDER_SUCCESS,
    payload: data,
  };
};

const createJobOrderError = (error) => {
  return {
    type: actionTypes.CREATE_JOBORDER_ERROR,
    payload: error,
  };
};

export const createJobOrder = (data) => (dispatch) => {
  dispatch(createJobOrderStart());
  return jobOrdersManagementService
    .createJobOrder(data)
    .then((response) => {
      customToast.success(i18n.t("Job_Order_Created_Successfully"));
      return dispatch(createJobOrderSuccess(response));
    })
    .catch((error) => {
      dispatch(createJobOrderError(error));
      throw error;
    });
};

const editJobOrderStart = () => {
  return {
    type: actionTypes.EDIT_JOBORDER_START,
  };
};

const editJobOrderSuccess = (data) => {
  return {
    type: actionTypes.EDIT_JOBORDER_SUCCESS,
    payload: data,
  };
};

const editJobOrderError = (error) => {
  return {
    type: actionTypes.EDIT_JOBORDER_ERROR,
    payload: error,
  };
};

export const editJobOrder = (jobOrderId, data) => (dispatch) => {
  dispatch(editJobOrderStart());
  return jobOrdersManagementService
    .editJobOrder(jobOrderId, data)
    .then((response) => {
      customToast.success(i18n.t("Job_Order_Updated_Successfully"));
      return dispatch(editJobOrderSuccess(response));
    })
    .catch((error) => {
      dispatch(editJobOrderError(error));
      throw error;
    });
};
