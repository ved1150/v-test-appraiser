import React, { useState, useEffect } from "react";
import _ from "lodash";
import { useTranslation } from "react-i18next";
import { Button } from "@mui/material";
import { floorName } from "../../../../constants/enums";
import { measurementTypes } from "../../../../constants/appConstant";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { loadFloorScanJsons } from "../../../../actions/measurementAction";
import { calculateWallThicknessForRoom } from "./utilityTwoD";
const AreaDetails = (props) => {
  const { t } = useTranslation();
  const reportData = useSelector((state) => state.details.reportData);
  const [roomDetailsArray, setRoomDetailsArray] = useState([]);
  const [areaObjectArray, setAreaObjectArray] = useState([]);
  const [floorscanJsons, setFloorscanJsons] = useState([]);
  const { id } = useParams();
  const [step, setStep] = useState(
    !_.isEmpty(props.floorListForVideo) &&
      props.floorListForVideo.some((item) => item?.floorTagNameList?.length)
      ? 1
      : 2
  );
  const dispatch = useDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [hasPublishFloors, setHasPublishFloors] = useState(false);
  const [videoFloorScan, setVideoFloorScan] = useState([]);
  const handleAreaChange = (e) => {
    const floorScanId = e.target.options?.[e.target.selectedIndex]?.id;
    const floorscanPayload = floorscanJsons.map((item) =>
      item.floorScanId === floorScanId
        ? { ...item, floorTagNameList: [e.target.value] }
        : item
    );
    setFloorscanJsons(floorscanPayload);
  };
  useEffect(() => {
    if (props.floorListForVideo) {
      setFloorscanJsons(
        props.floorListForVideo.map(
          (floor) =>
            floor.floorTagNameList?.length && {
              floorScanId: floor.floorScanId,
              floorTagNameList: [floor.floorTagNameList[0]],
            }
        )
      );
    }
  }, [props.floorListForVideo]);

  useEffect(() => {
    const hasPublish =
      props.selectedMeasurementType == measurementTypes[3].id &&
      !_.isEmpty(props.floorListForVideo) &&
      props.floorListForVideo.some((item) => item?.floorTagNameList?.length);
    setHasPublishFloors(hasPublish);
    setStep(hasPublish ? 1 : 2);
  }, [props.floorListForVideo]);

  useEffect(() => {
    let roomObjectArray = [];
    let roomsObjectArray = [];
    let areaObjectArray = [];
    if (!_.isNil(props.areaDetails)) {
      const roomArray = Object.keys(props.areaDetails);
      for (
        let FloorIndex = 0;
        FloorIndex <= props.floorList.length;
        FloorIndex++
      ) {
        let totalGLA = 0;
        let totalHeight = 0;
        let totalNonGLA = 0;
        let totalWallsThickness = 0;
        let totalArea = 0;
        let totalRoomsArea = 0;
        let areaObject = {};
        let totalHeightCalc = [];
        let totalAreaCalc = [];
        let totalGLACalc = [];
        let totalNonGLACalc = [];
        let totalRoomsAreaCalc = [];
        let totalWallsThicknessCalc = [];
        for (
          let roomArrayIndex = 0;
          roomArrayIndex < roomArray.length;
          roomArrayIndex++
        ) {
          roomObjectArray = props.areaDetails[roomArray[roomArrayIndex]];
          if (
            props.floorList[FloorIndex] &&
            roomObjectArray.filter((el) => el["@type"] == "ROOM")[0][
              "@floorindex"
            ] != props.floorList[FloorIndex].floorId
          ) {
            continue;
          }
          let doorArr = _.filter(roomObjectArray, function (n) {
            return n["@type"] == "WALLPENETRATION" && n["@mode"] == "DOOR";
          });
          roomObjectArray.doorCount = _.size(doorArr);
          let windowArr = _.filter(roomObjectArray, function (n) {
            return n["@type"] == "WALLPENETRATION" && n["@mode"] == "WINDOW";
          });
          roomObjectArray.windowCount = _.size(windowArr);
          let roomObject = _.find(
            roomObjectArray,
            (room) => room["@type"] == "ROOM"
          );
          if (roomObject && roomObject["@additionalType"] != 1) {
            let walls = roomObject["@children"].split(",");
            const roofObject = [
              props.originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF,
            ];
            const faceArray = roofObject[0]["FACES"]["FACE"];
            let totalWallThickness = calculateWallThicknessForRoom(
              roomObject,
              faceArray,
              props.wallThickness
            );
            let roomArea = Number(roomObject["@editedArea"]);
            let totalMeasurement = roomArea + totalWallThickness;
            if (roomObject["@measuretype"] == "GLA") {
              totalGLA = totalGLA + totalMeasurement;
              totalGLACalc.push(totalMeasurement);
            } else if (roomObject["@measuretype"] == "Non-GLA") {
              totalNonGLA = totalNonGLA + totalMeasurement;
              totalNonGLACalc.push(totalMeasurement);
            } else {
            }
            let cheight = roomObject["@height"]
              ? parseFloat(roomObject["@height"])
              : 0;
            totalWallsThickness = totalWallsThickness + totalWallThickness;
            totalWallsThicknessCalc.push(totalWallThickness.toFixed(2));
            totalAreaCalc.push(parseFloat(totalMeasurement).toFixed(2));
            totalRoomsArea = totalRoomsArea + roomArea;
            totalRoomsAreaCalc.push(roomArea.toFixed(2));
            totalHeight = cheight > totalHeight ? cheight : totalHeight;
            // totalHeightCalc.push(cheight);
            roomObjectArray.wallCount = _.size(walls);
            roomObjectArray.totalWallThickness = totalWallThickness.toFixed(2);
            roomObjectArray.roomArea = roomArea.toFixed(2);
          }
          roomsObjectArray.push(roomObjectArray);

          areaObject = {
            floorName: props.floorList[FloorIndex]
              ? props.floorList[FloorIndex].floorName
              : "",
            totalGLA: totalGLA > 0 ? totalGLA.toFixed(2) : totalGLA.toFixed(2),
            totalNonGLA:
              totalNonGLA > 0 ? totalNonGLA.toFixed(2) : totalNonGLA.toFixed(2),
            totalArea: (totalGLA + totalNonGLA).toFixed(2),
            totalAreaCalc: totalAreaCalc.join(" + "),
            totalWallsThickness: totalWallsThickness.toFixed(2),
            // totalAreaCalc : totalAreaCalc > 0 ? totalAreaCalc.join(" + ") : "",
            // totalWallsThicknessCalc: totalWallsThicknessCalc.join(" + "),
            // totalGLAClac: totalGLAClac.join(" + "),
            totalWallsThicknessCalc:
              totalWallsThickness > 0
                ? "(" + totalWallsThicknessCalc.join(" + ") + ")"
                : "",
            totalRoomsArea: totalRoomsArea.toFixed(2),
            totalRoomsAreaCalc:
              totalRoomsArea > 0
                ? "(" + totalRoomsAreaCalc.join(" + ") + ")"
                : "",
            totalNonGLACalc: totalNonGLACalc.join(" + "),
            totalGLACalc:
              totalGLA > 0 ? "(" + totalGLACalc.join(" + ") + ")" : "",
            totalNonGLACalc:
              totalNonGLA > 0 ? "(" + totalNonGLACalc.join(" + ") + ")" : "",
            // totalRoomsAreaCalc: totalRoomsAreaCalc.join(" + "),
            totalHeight: totalHeight.toFixed(2),
            // totalHeightCalc: totalHeight > 0 ? totalHeightCalc.join(" + ") : "",
            // totalHeightCalc: totalHeightCalc.join(" + ")
          };
        }
        areaObjectArray.push(areaObject);
      }
      setRoomDetailsArray(roomsObjectArray);
      setAreaObjectArray(areaObjectArray);
    }
  }, [props.areaDetails]);

  const toggleAreaDetails = () => {
    props.toggleAreaDetails();
  };

  const handleNext = () => {
    setIsLoading(true);
    const data = {
      floorScanJsonRequest: floorscanJsons,
      jobOrderId: id,
      types: [measurementTypes[3].name],
    };
    dispatch(loadFloorScanJsons(data))
      .then(() => {
        setIsLoading(false);
        setStep(2);
      })
      .catch((e) => {
        setIsLoading(false);
      });
  };

  const createRoomsData = () => {
    if (reportData.floorScanJsonData) {
      let overallTotalWallThicknessCalc = [];
      let overallTotalRoomsAreaCalc = [];
      let overallTotalGLACalc = [];
      let overallTotalNonGLACalc = [];
      let overallAllWallThicknessSum = 0;
      let overallTotalRoomsArea = 0;
      let overallTotalGLA = 0;
      let overallTotalNonGLA = 0;
      const result = reportData.floorScanJsonData.map((item) => {
        const [fsJSON] = item.floorScanJsonList;
        let structures = fsJSON.floorJsonData.EAGLEVIEW_EXPORT.STRUCTURES;
        const ImmutablefaceArray = structures.ROOF.FACES.FACE;
        let faceArray = structures.ROOF.FACES.FACE;

        const wallThickness = _.get(structures, ["@exteriorWallThickness"], 6);
        faceArray = faceArray.filter(
          (item) => item["@type"] === "ROOM" && item["@additionalType"] != 1
        );
        let totalWallThicknessCalc = [];
        let totalRoomsAreaCalc = [];
        let totalGLACalc = [];
        let totalNonGLACalc = [];
        let allWallThicknessSum = 0;
        let totalRoomsArea = 0;
        let totalGLA = 0;
        let totalNonGLA = 0;
        let totalHeight = 0;
        for (let roomIndex = 0; roomIndex < faceArray.length; roomIndex++) {
          const roomData = faceArray[roomIndex];
          let walls = roomData["@children"].split(",");
          let roomArea = parseFloat(roomData["@editedArea"]);
          //let totalWallThickness = _.size(walls) * wallThickness;
          //totalWallThickness /= 12;
          const totalWallThickness = calculateWallThicknessForRoom(
            roomData,
            ImmutablefaceArray,
            wallThickness
          );
          totalWallThicknessCalc.push(totalWallThickness.toFixed(2));
          overallTotalWallThicknessCalc.push(totalWallThickness.toFixed(2));
          allWallThicknessSum += parseFloat(totalWallThickness);
          overallAllWallThicknessSum += parseFloat(totalWallThickness);
          totalRoomsArea += roomArea;
          overallTotalRoomsArea += roomArea;
          totalRoomsAreaCalc.push(parseFloat(roomArea).toFixed(2));
          overallTotalRoomsAreaCalc.push(parseFloat(roomArea).toFixed(2));
          let totalMeasurement = roomArea + totalWallThickness;
          totalHeight += parseFloat(roomData["@height"]) || 0;
          if (roomData["@measuretype"] == "GLA") {
            totalGLA = totalGLA + totalMeasurement;
            overallTotalGLA += totalMeasurement;
            totalGLACalc.push(parseFloat(totalMeasurement).toFixed(2));
            overallTotalGLACalc.push(parseFloat(totalMeasurement).toFixed(2));
          } else if (roomData["@measuretype"] == "Non-GLA") {
            totalNonGLA = totalNonGLA + totalMeasurement;
            overallTotalNonGLA += totalMeasurement;
            totalNonGLACalc.push(parseFloat(totalMeasurement).toFixed(2));
            overallTotalNonGLACalc.push(
              parseFloat(totalMeasurement).toFixed(2)
            );
          }
        }
        totalWallThicknessCalc = totalWallThicknessCalc.length
          ? "(" + totalWallThicknessCalc.join(" + ") + ")"
          : "";
        totalRoomsAreaCalc = totalRoomsAreaCalc.length
          ? "(" + totalRoomsAreaCalc.join(" + ") + ")"
          : "";
        totalGLACalc = totalGLACalc.length
          ? "(" + totalGLACalc.join(" + ") + ")"
          : "";
        totalNonGLACalc = totalNonGLACalc.length
          ? "(" + totalNonGLACalc.join(" + ") + ")"
          : "";

        return {
          floorScanId: item.floorScanId,
          tagName: fsJSON?.tagName,
          totalRoomsArea: totalRoomsArea.toFixed(2),
          totalGLA: totalGLA.toFixed(2),
          totalNonGLA: totalNonGLA.toFixed(2),
          totalArea: (totalGLA + totalNonGLA).toFixed(2),
          allWallThicknessSum: allWallThicknessSum.toFixed(2),
          totalRoomsAreaCalc,
          totalWallThicknessCalc,
          totalGLACalc,
          totalNonGLACalc,
          totalHeight: totalHeight.toFixed(2),
        };
      });

      overallTotalWallThicknessCalc = overallTotalWallThicknessCalc.length
        ? "(" + overallTotalWallThicknessCalc.join(" + ") + ")"
        : "";
      overallTotalRoomsAreaCalc = overallTotalRoomsAreaCalc.length
        ? "(" + overallTotalRoomsAreaCalc.join(" + ") + ")"
        : "";
      overallTotalGLACalc = overallTotalGLACalc.length
        ? "(" + overallTotalGLACalc.join(" + ") + ")"
        : "";
      overallTotalNonGLACalc = overallTotalNonGLACalc.length
        ? "(" + overallTotalNonGLACalc.join(" + ") + ")"
        : "";
      setVideoFloorScan([
        ...result,
        {
          isOverallCalculation: true,
          floorScanId: null,
          tagName: null,
          totalRoomsArea: overallTotalRoomsArea.toFixed(2),
          totalGLA: overallTotalGLA.toFixed(2),
          totalNonGLA: overallTotalNonGLA.toFixed(2),
          totalArea: (overallTotalGLA + overallTotalNonGLA).toFixed(2),
          totalRoomsAreaCalc: overallTotalRoomsAreaCalc,
          totalWallThicknessCalc: overallTotalWallThicknessCalc,
          allWallThicknessSum: overallAllWallThicknessSum.toFixed(2),
          totalGLACalc: overallTotalGLACalc,
          totalNonGLACalc: overallTotalNonGLACalc,
        },
      ]);
    }
  };
  useEffect(() => {
    createRoomsData();
  }, [reportData]);

  return (
    <div className="comman-modal property-details right-side open">
      <div className="comman-modal-main">
        <div className="side-head">
          {t("BUTTONS.Property_Details")}
          <button className="close-modal" onClick={() => toggleAreaDetails()}>
            <i className="icon-close-image"></i>
          </button>
        </div>
        {step === 1 && (
          <div className="comman-modal-body technician-details-modal scroll-bar-style">
            {props.floorListForVideo.map((floor) =>
              floorName.map(
                (floorname) =>
                  floorname.id === floor.floorIndexList && (
                    <div class="form-group">
                      <label>{floorname.value}</label>
                      <select
                        className="form-control"
                        name="areaType"
                        onChange={handleAreaChange}
                      >
                        {floor.floorTagNameList?.map((floorname) => (
                          <option
                            key={floorname}
                            value={floorname}
                            id={floor.floorScanId}
                          >
                            {floorname}
                          </option>
                        ))}
                      </select>
                    </div>
                  )
              )
            )}
            <div className="button-group text-center mt-15">
              <Button
                type="submit"
                disabled={isLoading}
                className="blue-btn"
                onClick={handleNext}
              >
                Next
                {isLoading && <div className="loader-spin"></div>}
              </Button>
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="comman-modal-body scroll-bar-style">
            <div className="custom-tab">
              <div className="tab-content open" style={{ display: "block" }}>
                <div className="details">
                  {!hasPublishFloors
                    ? !_.isNil(areaObjectArray) &&
                      areaObjectArray.map((areaObject, id) => (
                        <div>
                          <h4>
                            {!areaObject.floorName && t("WEB_LABELS.Total")}{" "}
                            {t("WEB_LABELS.Area")}{" "}
                            {areaObject.floorName &&
                              t("WEB_LABELS.of") + " " + areaObject.floorName}
                          </h4>
                          <ul>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Room_Units_Square_Feet")}:{" "}
                                {areaObject.totalRoomsAreaCalc}
                              </div>
                              <div>{areaObject.totalRoomsArea}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Walls_Square_Feet")}:{" "}
                                {areaObject.totalWallsThicknessCalc}
                              </div>
                              <div>{areaObject.totalWallsThickness}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_GLA_Square_Feet")}:{" "}
                                {areaObject.totalGLACalc}
                              </div>
                              <div>{areaObject.totalGLA}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Non_GLA_Square_Feet")}:{" "}
                                {areaObject.totalNonGLACalc}
                              </div>
                              <div>{areaObject.totalNonGLA}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Square_Feet")}: (
                                {areaObject.totalGLA} + {areaObject.totalNonGLA}
                                )
                              </div>
                              <div>{areaObject.totalArea}</div>
                            </li>
                            {areaObject.floorName && (
                              <li>
                                <div>{t("WEB_LABELS.Height_Feet")}:</div>
                                <div>{areaObject.totalHeight}</div>
                              </li>
                            )}
                          </ul>
                        </div>
                      ))
                    : videoFloorScan.map((floorData) => (
                        <div>
                          {
                            <h4>
                              {!floorData.tagName && t("WEB_LABELS.Total")}{" "}
                              {t("WEB_LABELS.Area")}{" "}
                              {floorData.tagName && (
                                <>
                                  {t("WEB_LABELS.of")} {floorData.tagName}
                                </>
                              )}
                            </h4>
                          }
                          <ul>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Room_Units_Square_Feet")}:{" "}
                                {floorData.totalRoomsAreaCalc}
                              </div>
                              <div>{floorData.totalRoomsArea}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Walls_Square_Feet")}:{" "}
                                {floorData.totalWallThicknessCalc}
                              </div>
                              <div>{floorData.allWallThicknessSum}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_GLA_Square_Feet")}:{" "}
                                {floorData.totalGLACalc}
                              </div>
                              <div>{floorData.totalGLA}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Non_GLA_Square_Feet")}:{" "}
                                {floorData.totalNonGLACalc}
                              </div>
                              <div>{floorData.totalNonGLA}</div>
                            </li>
                            <li>
                              <div>
                                {t("WEB_LABELS.Total_Square_Feet")}: (
                                {floorData.totalGLA} + {floorData.totalNonGLA})
                              </div>
                              <div>{floorData.totalArea}</div>
                            </li>
                            {floorData.floorScanId && (
                              <li>
                                <div>{t("WEB_LABELS.Height_Feet")}:</div>
                                <div>{floorData.totalHeight}</div>
                              </li>
                            )}
                          </ul>
                        </div>
                      ))}
                  {hasPublishFloors && (
                    <div className="button-group text-center mt-15">
                      <Button
                        type="submit"
                        className="blue-btn"
                        onClick={() => setStep(1)}
                      >
                        Back
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AreaDetails;
