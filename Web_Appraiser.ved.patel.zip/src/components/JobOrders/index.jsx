/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect, useCallback, useRef } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import Tooltip from "@mui/material/Tooltip";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Pagination from "@mui/material/Pagination";
import { useTranslation } from "react-i18next";
import {
  getJobOrders,
  scheduleAppoinment,
  rescheduleAppoinment,
  resendAppointment,
  autoSnap,
  payForJobOrder,
  StoreActions,
} from "../../actions/jobAction";
import { LoadConfigurationDetail } from "../../actions/callConfigrurationActions";
import "./index.scss";
import { QuickCall } from "./Models/QuickCall";
import ScheduleAppoinment from "./scheduleAppoinment";
import {
  APPOINTMENT_STATUS,
  jobOrdersPerPage,
  ROLE,
  VSI_JO_TYPE,
} from "./../../constants/appConstant";
import classnames from "classnames";
import ConfirmationMsgModal from "./../common/confirmationMsgModal";
import ConfirmationModal from "./../common/confirmationModal";
import calendarService from "./../../services/calendarService";
import {
  JOB_ORDER_DELETE_MESSSAGE,
  UNEXPECTED_ERROR_MESSAGE,
  APPOINMENT_CANCEL_MESSSAGE,
} from "./../../constants/commonMessages";

import { customToast } from "./../../helpers/customToast";

import {
  CALL_RECORDING,
  scheduleAppointmentStatus,
  reScheduleAppointmentStatus,
  callTypes,
} from "../../constants/appConstant";

import {
  isUTCDateInBetween,
  scrollIntoView,
} from "./../../helpers/commonJSFunction";
import Button from "../common/Button";
import jobService from "../../services/jobService";
import NoDataView from "./JobOrderDetails/Common/noDataView";
import {
  JOB_ORDERS,
  JOB_ORDERS_ICON,
} from "./JobOrderDetails/Common/commonText";
import TextInput from "../common/TextInput";
import { StartLoading, StopLoading } from "../../actions/UIAction";
import store from "../../store";
import CustomPagination from "../common/CustomPagination";
import DefaultCustomSwitch from "../common/DefaultCustomSwitch";
let isManual = false;

const JobOrders = (props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const tableHead = [
    { key: "jobOrderID", label: t("WEB_LABELS.Job_Order_ID"), width: "10%" },
    {
      key: "jobOrderAssignee",
      label: t("WEB_LABELS.Customer_Name") + "\n" + t("WEB_LABELS.Address"),
      width: "10%",
    },

    {
      key: "assignedDate",
      label: t("WEB_LABELS.Assigned_Date"),
      width: "15%",
    },
    {
      key: "inspectionDate",
      label: t("WEB_LABELS.Inspection_Date"),
      width: "15%",
    },
    {
      key: "jobOrderStatus",
      label: t("WEB_LABELS.Job_Order_Status"),
      width: "10%",
    },
    {
      key: "jobOrderSource",
      label: t("Job_Order_Source") + "\n" + t("Job_Order_Type"),
      width: "10%",
    },
    {
      key: "autoSnap",
      label: t("WEB_LABELS.Auto_Snap_On_Off"),
      width: "10%",
    },
    {
      key: "action",
      label: t("WEB_LABELS.Action"),
      disableSorting: true,
      width: "17%",
    },
  ];
  const [pageNo, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [startPoint, setStartPoint] = useState(1);
  const [endPoint, setEndPoint] = useState(pageSize);
  const [offset, setOffset] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [isQuickCallVisible, setQuickCallVisible] = useState(false);
  const [isMeasurmentLinkVisible, setMeasurementLinkVisible] = useState(false);
  const [isScheduleAppoinmentVisible, setScheduleAppoinmentVisible] =
    useState(false);
  const [selectedJobOrder, setSelectedJobOrder] = useState({});

  const [refreshJobOrder, setRefreshJoborder] = useState(false);
  const [joinCall, setJoinCall] = useState(false);
  const [callType, setCallType] = useState("");
  const [confirmationModal, setConfirmationModal] = useState(false);
  const [deletedJobOrderId, setDeletedJobOrderId] = useState(null);
  const [jobOrderList, setJobrOrderList] = useState([]);
  const [searchInpValue, setSearchInpValue] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [cardNotAddedModal, setCardNotAddedModal] = useState(false);
  const [
    duplicateTransactionSubmmitedModal,
    setDuplicateTransactionSubmmitedModal,
  ] = useState(false);
  const [showPayButtonConfirmationModal, setShowPayButtonConfirmationModal] =
    useState(false);
  const [
    payButtonConfirmationModalJoDetails,
    setPayButtonConfirmationModalJoDetails,
  ] = useState(null);
  const [isQuickCallGenerated, setIsQuickCallGenerated] = useState(false);
  const scrollableListRef = useRef();
  const hideQuickCall = (callURL = null) => {
    setQuickCallVisible(false);

    if (callURL) {
      if (jobOrderList.length > 0) {
        let tempJobOrderList = jobOrderList.map((job) =>
          job.id === selectedJobOrder.id
            ? {
                ...job,
                quickCallUrl: callURL,
              }
            : job
        );
        setJobrOrderList(tempJobOrderList);
      }
      setTimeout(() => {
        window.open(callURL, "_blank");
      }, 1000);
    }
  };

  const showQuickCall = (jobOrderDisplayId, order) => {
    setSelectedJobOrder(order);
    setQuickCallVisible(true);
  };

  useEffect(() => {
    props.LoadConfigurationDetail(CALL_RECORDING);
  }, []);

  useEffect(() => {
    if (isManual) {
      storeDataInRedux({});
    }
    const filter = {
      pageNo,
      pageSize,
    };

    if (searchTerm) {
      filter.searchText = searchTerm;
    }
    const actionFilter = _.get(
      props,
      ["job", "storeActionsData", "jobOrders"],
      {}
    );
    if (actionFilter?.jobOrderId && !isManual) {
      if (actionFilter?.searchText) {
        setSearchInpValue(actionFilter?.searchText);
        setSearchTerm(actionFilter?.searchText);
        filter.searchText = actionFilter?.searchText;
      }
      setOffset(actionFilter?.offset);
      setCurrentPage(actionFilter?.pageNo);
      setStartPoint(actionFilter?.startPoint);
      setEndPoint(actionFilter?.endPoint);
      setPageSize(actionFilter?.pageSize);
      filter.pageNo = actionFilter?.pageNo;
      filter.pageSize = actionFilter?.pageSize;
    }
    if (
      filter.pageNo == pageNo &&
      filter.pageSize == pageSize &&
      (filter.searchText ? filter.searchText == searchInpValue : true)
    ) {
      props
        .getJobOrders(filter)
        .then((res) => {
          if (res) {
            setJobrOrderList(res.data);
            const count = _.get(res, ["pagination", "totalCount"], 0);
            setTotalCount(count);
            setStartPoint(pageSize * (pageNo - 1) + 1);
            if (pageSize * pageNo > count) {
              setEndPoint(count);
            } else {
              setEndPoint(pageSize * pageNo);
            }
            const totalPage = _.get(res, ["pagination", "totalPage"], 0);
            if (pageNo > totalPage) {
              setCurrentPage(1);
              setOffset(0);
              setStartPoint(1);
            }
          }
        })
        .finally(() => {
          if (!isManual) {
            setTimeout(() => {
              scrollIntoView(scrollableListRef);
              storeDataInRedux(
                filter,
                actionFilter?.jobOrderId,
                _.get(props, ["job", "storeActionsData", "floorScans"], {})
              );
            }, 10);
          } else if (isManual) {
            storeDataInRedux(filter);
            isManual = false;
          }
        });
    }
  }, [pageNo, pageSize, refreshJobOrder, searchTerm, isQuickCallGenerated]);

  const handlePageSize = (e) => {
    isManual = true;
    setOffset(0);
    setCurrentPage(1);
    setPageSize(e.target.value);
  };

  const handlePagination = (event, value) => {
    if (!_.isEqual(value, pageNo)) {
      isManual = true;
      setOffset(value);
      setCurrentPage(value);
    }
  };

  if (!props.job.jobOrders) {
    return <section className="content-wapper"></section>;
  }

  const toggleMeasurementLink = (data) => {
    setMeasurementLinkVisible(!isMeasurmentLinkVisible);
    if (data) {
      setSelectedJobOrder(data);
    }
  };

  const toggleScheduleAppoinment = (data) => {
    setScheduleAppoinmentVisible(!isScheduleAppoinmentVisible);
    data && setSelectedJobOrder(data);
  };

  const handleJobOrder = () => {
    setRefreshJoborder(!refreshJobOrder);
  };

  const handleJobOrderDetails = (jobOrderId) => {
    storeDataInRedux(
      _.get(props, ["job", "storeActionsData", "jobOrders"], {}),
      jobOrderId
    );
    props.history.push(`joborder/${jobOrderId}`);
  };

  //Delete Job Order Start
  const handleJobOrderDelete = (jobOrderId) => {
    setConfirmationModal(!confirmationModal);
    setDeletedJobOrderId(jobOrderId);
  };
  const handleCancelDeleteJobOrder = () => {
    setConfirmationModal(!confirmationModal);
  };
  const deleteJobOrderEvent = () => {
    jobService
      .deleteJobOrders(deletedJobOrderId)
      .then((data) => {
        customToast.success(JOB_ORDER_DELETE_MESSSAGE);
        setRefreshJoborder(!refreshJobOrder);
      })
      .catch((err) => {
        throw err;
      });
    setConfirmationModal(!confirmationModal);
  };
  //Delete Job Order End

  const cancelAppointment = (data) => {
    return calendarService
      .cancelAppointmentSlot(data)
      .then((res) => {
        if (res) {
          customToast.success(APPOINMENT_CANCEL_MESSSAGE);
          handleJobOrder();
        }
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };

  const checkForCallstarted = (startDateTime, endDateTime) => {
    const inBetween = isUTCDateInBetween(startDateTime, endDateTime);
    return inBetween;
  };

  const toggleJoinCall = (jobOrder, type) => {
    setJoinCall(!joinCall);
    if (jobOrder) {
      setSelectedJobOrder(jobOrder);
      setCallType(type);
    } else {
    }
  };

  const opencallURL = (callUrl) => {
    callUrl && window.open(callUrl, "_blank");
  };

  const handleAutoSnapChange = (checked, jobOrderId) => {
    const { autoSnap } = props;

    const reqData = {
      jobOrderId,
      checked,
    };

    autoSnap(reqData);
  };

  const debounceFn = useCallback(
    _.debounce(
      (checked, jobOrderId) => handleAutoSnapChange(checked, jobOrderId),
      500
    ),
    []
  );

  const debouncedAutoSnapChange = (e, jobOrderId) => {
    const {
      target: { checked },
    } = e;

    if (jobOrderList.length > 0) {
      let tempJobOrderList = jobOrderList.map((job) =>
        job.id === jobOrderId
          ? {
              ...job,
              autoSnapshot: checked,
            }
          : job
      );

      setJobrOrderList(tempJobOrderList);
    }
    debounceFn(checked, jobOrderId);
  };

  // Search Start

  const handleSearchChange = (value) => {
    isManual = true;
    setSearchTerm(value);
  };

  const debounceSearchFn = useCallback(
    _.debounce((value) => handleSearchChange(value), 500),
    []
  );

  const debouncedSearchChange = (event) => {
    const {
      target: { value },
    } = event;
    setSearchInpValue(value);

    debounceSearchFn(value.trim());
  };

  // Search End

  // Quick Call Start
  // This function will check the call status first and according to that it will show the modals and also will be helpful to update the quick call button color(i.e green or blue)
  const handleQuickCall = (id, d) => {
    if (d.quickCallUrl) {
      dispatch(StartLoading());
      jobService
        .checkJobOrderCallStatus(d.id)
        .then((res) => {
          dispatch(StopLoading());
          if (res.status === 200) {
            const { data } = res;
            if (data.callStatus === "ENDED" || data.callStatus === "EXPIRED") {
              showQuickCall(id + 1, d);
              if (d.quickCallUrl) {
                let tempJobOrderList = jobOrderList.map((job) =>
                  job.id === d.id
                    ? {
                        ...job,
                        quickCallUrl: null,
                      }
                    : job
                );
                setJobrOrderList(tempJobOrderList);
              }
            } else {
              toggleJoinCall(d, callTypes.QUICK_CALL);
            }
          }
        })
        .catch((err) => {
          dispatch(StopLoading());
        });
    } else {
      showQuickCall(id + 1, d);
    }
  };

  // Quick Call End

  const handleYesPayForJobOrder = () => {
    props
      .payForJobOrder(payButtonConfirmationModalJoDetails.id)
      .then((res) => {
        if (res?.payload?.data?.status === "STATUS_NO_CARD") {
          setCardNotAddedModal(true);
        } else if (res?.payload?.data?.status === "CHARGE_CARD") {
          customToast.success(t("Payment_Done_Message_JO_Activated"));
          setRefreshJoborder(!refreshJobOrder);
        } else if (res?.payload?.data?.status === "STATUS_TRANSACTION_FAILED") {
          setDuplicateTransactionSubmmitedModal(true);
        }
      })
      .finally(() => {
        setPayButtonConfirmationModalJoDetails(null);
      });
  };

  const storeDataInRedux = (data, jobOrderId = null, floorScans = {}) => {
    store.dispatch(
      StoreActions({
        jobOrders: {
          pageNo: data.pageNo,
          pageSize: data.pageSize,
          searchText: data.searchText,
          jobOrderId: jobOrderId,
          startPoint: startPoint,
          endPoint: endPoint,
          offset: offset,
        },
        floorScans: floorScans,
      })
    );
  };

  return (
    <section className="content-wapper">
      <h1>{t("WEB_LABELS.My_Job_Orders")}</h1>
      <div className="common-panel panel-table-height">
        <div className="panel-body">
          <div class="breadcrub-button">
            {useSelector(
              (state) =>
                state?.profile?.fetchProfileDetailsSuccess?.userRole ===
                ROLE.APPRAISER
            ) && (
              <div class="right-side">
                <Button
                  className="blue-btn"
                  onClick={() => {
                    storeDataInRedux({});
                    props.history.push("/job-order");
                  }}
                >
                  {t("Create_Job_Order")}
                </Button>
              </div>
            )}
          </div>
          <div className="filter-box">
            <div className="show-entries">
              {t("COMMON_MESSAGES.Show")}
              <select onChange={handlePageSize} value={pageSize}>
                {jobOrdersPerPage.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.displayName}
                  </option>
                ))}
              </select>
              {t("COMMON_MESSAGES.entries")}
            </div>
            <div className="filter-segment">
              <div className="demo-job-order-indicator">
                <Tooltip title={t("Demo_Job_Order")} arrow>
                  <span className="demo-type"></span>
                </Tooltip>
              </div>
              <div className="search-box">
                <TextInput
                  className="form-control"
                  type="text"
                  name="search"
                  value={searchInpValue}
                  onChange={debouncedSearchChange}
                  placeholder={t("WEB_LABELS.Search")}
                  icon={
                    <div className="search-icon">
                      <i className="icon-search"></i>
                    </div>
                  }
                />
              </div>
              <div className="filter-button"></div>
            </div>
          </div>
          {!props?.job?.loading && totalCount !== 0 ? (
            <TableContainer>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    {tableHead.map((head, key) =>
                      head.key === "jobOrderAssignee" ||
                      head.key === "jobOrderSource" ? (
                        <TableCell style={{ width: head.width }} key={key}>
                          <div>{head.label.split("\n")[0]}</div>
                          <div style={{ fontWeight: "normal" }}>
                            {head.label.split("\n")[1]}
                          </div>
                        </TableCell>
                      ) : (
                        <TableCell style={{ width: head.width }} key={key}>
                          {head.label}
                        </TableCell>
                      )
                    )}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {jobOrderList.map((d, id) => {
                    const status = _.get(
                      d,
                      ["jobOrderAppointment", "status"],
                      ""
                    );
                    const isOrderSourceVsi = VSI_JO_TYPE.includes(
                      d?.jobOrderSource?.trim()?.toLowerCase()
                    );
                    const actionJOId = _.get(
                      props,
                      ["job", "storeActionsData", "jobOrders", "jobOrderId"],
                      ""
                    );
                    return (
                      <TableRow
                        ref={d.id === actionJOId ? scrollableListRef : null}
                        className={`${
                          d.id === actionJOId
                            ? d.isDemoJobOrder
                              ? "demo-job-order selected-item"
                              : "selected-item"
                            : d.isDemoJobOrder
                            ? "demo-job-order"
                            : ""
                        }`}
                        key={d.id}
                      >
                        <TableCell scope="row">
                          {d.isDemoJobOrder || d.isPaymentDone ? (
                            d.orderNo
                          ) : (
                            <Tooltip
                              title={t(
                                !d.isCardAdded
                                  ? "Enter_Card_Details_Warning"
                                  : "Payment_Pending"
                              )}
                              arrow
                            >
                              <span style={{ color: "red" }}>
                                {d.orderNo} <i className="icon-information"></i>
                              </span>
                            </Tooltip>
                          )}
                        </TableCell>
                        <TableCell>
                          <div>
                            <b>{d.name}</b>
                          </div>
                          <div>{d.address}</div>
                        </TableCell>
                        <TableCell>
                          {d.assignDate ? d.assignDate : "--"}
                        </TableCell>
                        <TableCell>
                          {d.inspectionDate ? d.inspectionDate : "--"}
                        </TableCell>
                        <TableCell>
                          {d.jobStatus ? d.jobStatus : "--"}
                        </TableCell>
                        <TableCell>
                          <div>
                            <b>{d.jobOrderSource ? d.jobOrderSource : "-"}</b>
                          </div>
                          <div>{d.jobOrderType ? d.jobOrderType : "-"}</div>
                        </TableCell>
                        <TableCell>
                          <Tooltip
                            title={
                              d.autoSnapshot
                                ? t("WEB_LABELS.Turn_Off")
                                : t("WEB_LABELS.Turn_On")
                            }
                            arrow
                          >
                            <DefaultCustomSwitch
                              checked={d.autoSnapshot}
                              onChange={(e) => debouncedAutoSnapChange(e, d.id)}
                              name="autoSnap"
                              inputProps={{ "aria-label": "Auto Snap" }}
                            />
                          </Tooltip>
                        </TableCell>
                        <TableCell>
                          <div className="action-wrapper">
                            <ul className="btn-list">
                              {!d.isDemoJobOrder && !d.isPaymentDone && (
                                <li>
                                  <Tooltip title={t("Pay")} arrow>
                                    <Button
                                      disabled={
                                        props?.job?.payForOrderStart
                                          ? "true"
                                          : null
                                      }
                                      onClick={() => {
                                        setPayButtonConfirmationModalJoDetails(
                                          d
                                        );
                                        setShowPayButtonConfirmationModal(true);
                                      }}
                                    >
                                      <i className="app-icon-pay-button"></i>
                                    </Button>
                                  </Tooltip>
                                </li>
                              )}
                              {(d.isOrderSourceVsi ||
                                d.isDemoJobOrder ||
                                d.isPaymentDone) && (
                                <li>
                                  <Tooltip
                                    title={t("WEB_TOOLTIPS.View_Details")}
                                    arrow
                                  >
                                    <Button
                                      onClick={() =>
                                        handleJobOrderDetails(d.id)
                                      }
                                    >
                                      <i className="icon-view-detail"></i>
                                    </Button>
                                  </Tooltip>
                                </li>
                              )}
                              {!isOrderSourceVsi &&
                                (d.isDemoJobOrder || d.isPaymentDone) && (
                                  <li>
                                    <Tooltip
                                      title={
                                        d.quickCallUrl
                                          ? t("WEB_TOOLTIPS.Join_Call")
                                          : t("WEB_TOOLTIPS.Quick_Call")
                                      }
                                      arrow
                                    >
                                      <Button
                                        className={classnames({
                                          active: d.quickCallUrl,
                                        })}
                                        onClick={() => handleQuickCall(id, d)}
                                      >
                                        <i className="icon-quick-call"></i>
                                      </Button>
                                    </Tooltip>
                                  </li>
                                )}
                              {!isOrderSourceVsi &&
                                (d.isDemoJobOrder || d.isPaymentDone) && (
                                  <li>
                                    <Tooltip
                                      title={t(
                                        "WEB_TOOLTIPS.SelfInspectionLink"
                                      )}
                                      arrow
                                    >
                                      <Button
                                        onClick={() => toggleMeasurementLink(d)}
                                      >
                                        <i className="icon-Measurement-Details"></i>
                                      </Button>
                                    </Tooltip>
                                  </li>
                                )}
                              {!isOrderSourceVsi &&
                                (d.isDemoJobOrder || d.isPaymentDone) && (
                                  <li
                                    className={classnames({
                                      active:
                                        status ===
                                        APPOINTMENT_STATUS.SESSSION_STARTED.key,
                                      disabled:
                                        status ===
                                        APPOINTMENT_STATUS.CALL_COMPLETED.key,
                                    })}
                                  >
                                    {(_.isNil(d.jobOrderAppointment) ||
                                      _.includes(
                                        scheduleAppointmentStatus,
                                        status
                                      )) && (
                                      <Tooltip
                                        title={t(
                                          "WEB_TOOLTIPS.Schedule_Appointment"
                                        )}
                                        arrow
                                      >
                                        {status ===
                                        APPOINTMENT_STATUS.CALL_COMPLETED
                                          .key ? (
                                          <Button
                                            disabled={
                                              status ===
                                              APPOINTMENT_STATUS.CALL_COMPLETED
                                                .key
                                            }
                                          >
                                            <i className="icon-schedule-appointment"></i>
                                          </Button>
                                        ) : (
                                          <Button
                                            onClick={() =>
                                              toggleScheduleAppoinment(d)
                                            }
                                          >
                                            <i className="icon-schedule-appointment"></i>
                                          </Button>
                                        )}
                                      </Tooltip>
                                    )}
                                    {_.includes(
                                      reScheduleAppointmentStatus,
                                      status
                                    ) && (
                                      <Tooltip
                                        title={
                                          status ==
                                          APPOINTMENT_STATUS.NEW_APPOINTMENT.key
                                            ? t("WEB_TOOLTIPS.Virtual_Call")
                                            : (status ==
                                                APPOINTMENT_STATUS
                                                  .CONFIRMED_BY_PO.key ||
                                                status ==
                                                  APPOINTMENT_STATUS.RESCHEDULED
                                                    .key) &&
                                              checkForCallstarted(
                                                d.jobOrderAppointment
                                                  .sloteDateStartTime,
                                                d.jobOrderAppointment
                                                  .slotDateEndTime
                                              )
                                            ? t("WEB_TOOLTIPS.Start_Call")
                                            : t("WEB_TOOLTIPS.Virtual_Call")
                                        }
                                        arrow
                                      >
                                        <Button
                                          className={classnames("video-icon", {
                                            active:
                                              (status ==
                                                APPOINTMENT_STATUS
                                                  .CONFIRMED_BY_PO.key ||
                                                status ==
                                                  APPOINTMENT_STATUS.RESCHEDULED
                                                    .key) &&
                                              checkForCallstarted(
                                                d.jobOrderAppointment
                                                  .sloteDateStartTime,
                                                d.jobOrderAppointment
                                                  .slotDateEndTime
                                              ),
                                          })}
                                          onClick={() => {
                                            (status ==
                                              APPOINTMENT_STATUS.CONFIRMED_BY_PO
                                                .key ||
                                              status ==
                                                APPOINTMENT_STATUS.RESCHEDULED
                                                  .key) &&
                                            checkForCallstarted(
                                              d.jobOrderAppointment
                                                .sloteDateStartTime,
                                              d.jobOrderAppointment
                                                .slotDateEndTime
                                            )
                                              ? toggleJoinCall(
                                                  d,
                                                  callTypes.SCHEDULE_CALL
                                                )
                                              : toggleScheduleAppoinment(d);
                                          }}
                                        >
                                          <i className="icon-video-call"></i>
                                        </Button>
                                      </Tooltip>
                                    )}
                                  </li>
                                )}
                              {!isOrderSourceVsi &&
                                (d.isDemoJobOrder || d.isPaymentDone) &&
                                d.isSelfCreated && (
                                  <li>
                                    <Tooltip title={t("Edit_Job_Order")} arrow>
                                      <button
                                        onClick={() => {
                                          props.history.push(
                                            `/job-order/${d.id}`,
                                            { isSelfCreated: true }
                                          );
                                        }}
                                      >
                                        <i className="icon-bookmark-edit"></i>
                                      </button>
                                    </Tooltip>
                                  </li>
                                )}
                              {!isOrderSourceVsi && (
                                <li>
                                  <Tooltip
                                    title={t("WEB_TOOLTIPS.Delete_Job_Order")}
                                    arrow
                                  >
                                    <Button
                                      className="delete-btn"
                                      onClick={() => handleJobOrderDelete(d.id)}
                                    >
                                      <i className="icon-Delete"></i>
                                    </Button>
                                  </Tooltip>
                                </li>
                              )}
                            </ul>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <div className="no-data-found-container">
              {props?.job?.loading ? (
                <div className="no-data-found">
                  <div className="box">
                    <div className="loader-spin"></div>
                  </div>
                </div>
              ) : (
                <NoDataView
                  text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.JOB_ORDERS")}
                  icon={JOB_ORDERS_ICON}
                />
              )}
            </div>
          )}

          <div className="pagination-wrapper">
            {totalCount !== 0 && (
              <span className="show-results">
                {t("COMMON_MESSAGES.Showing")} {startPoint}{" "}
                {t("COMMON_MESSAGES.to")} {endPoint} {t("COMMON_MESSAGES.of")}{" "}
                {totalCount} {t("COMMON_MESSAGES.entries")}
              </span>
            )}

            <CustomPagination
              limit={pageSize}
              offset={offset}
              total={_.get(
                props,
                ["job", "jobOrders", "pagination", "totalCount"],
                0
              )}
              count={_.get(
                props,
                ["job", "jobOrders", "pagination", "totalPage"],
                0
              )}
              page={pageNo}
              onChange={handlePagination}
            />
          </div>
        </div>
      </div>

      {isQuickCallVisible && (
        <QuickCall
          hideQuickCall={hideQuickCall}
          configurationDetail={props.configurationDetail}
          selectedJobOrder={selectedJobOrder}
          setIsQuickCallGenerated={setIsQuickCallGenerated}
        />
      )}
      {isMeasurmentLinkVisible && (
        <QuickCall
          hideQuickCall={toggleMeasurementLink}
          configurationDetail={props.configurationDetail}
          isMeasurmentLinkVisible={isMeasurmentLinkVisible}
          selectedJobOrder={selectedJobOrder}
          userId={_.get(
            props,
            ["profile", "fetchProfileDetailsSuccess", "userId"],
            ""
          )}
        />
      )}
      {isScheduleAppoinmentVisible && (
        <ScheduleAppoinment
          toggleScheduleAppoinment={toggleScheduleAppoinment}
          selectedJobOrder={selectedJobOrder}
          scheduleAppoinment={props.scheduleAppoinment}
          rescheduleAppoinment={props.rescheduleAppoinment}
          resendAppointment={props.resendAppointment}
          handleJobOrder={handleJobOrder}
          job={props.job}
          history={props.history}
          configurationDetail={props.configurationDetail}
          cancelAppointment={cancelAppointment}
          userId={_.get(
            props,
            ["profile", "fetchProfileDetailsSuccess", "userId"],
            ""
          )}
        />
      )}
      {joinCall && (
        <ConfirmationMsgModal
          from="JobOrder"
          eventAction="Join"
          selectedJobOrder={selectedJobOrder}
          handleCancelAppointment={toggleJoinCall}
          handleConfirmationModal={{}}
          callType={callType}
        ></ConfirmationMsgModal>
      )}
      {confirmationModal && (
        <ConfirmationModal
          cancelEvent={() => {
            handleCancelDeleteJobOrder();
          }}
          title={t(
            "COMMON_MESSAGES.Are_You_Sure_You_Want_to_Delete_This_Job_Order"
          )}
          cancelText={t("COMMON_MESSAGES.No")}
          confirmText={t("COMMON_MESSAGES.Yes")}
          confirmEvent={deleteJobOrderEvent}
        ></ConfirmationModal>
      )}
      {cardNotAddedModal && (
        <ConfirmationModal
          hideCancel={true}
          title={t("Enter_Card_Details_Warning_2")}
          confirmText={t("BUTTONS.Ok")}
          confirmEvent={() => {
            setCardNotAddedModal(false);
          }}
        ></ConfirmationModal>
      )}
      {duplicateTransactionSubmmitedModal && (
        <ConfirmationModal
          hideCancel={true}
          title={t("Subsequent_Transaction_Submitted")}
          confirmText={t("BUTTONS.Ok")}
          confirmEvent={() => {
            setDuplicateTransactionSubmmitedModal(false);
          }}
        ></ConfirmationModal>
      )}
      {showPayButtonConfirmationModal && (
        <ConfirmationModal
          cancelText={t("COMMON_MESSAGES.No")}
          cancelEvent={() => {
            setShowPayButtonConfirmationModal(false);
            setPayButtonConfirmationModalJoDetails(null);
          }}
          title={
            t("Pay_Button_Confirmation_Message_Part_1") +
            ` $${payButtonConfirmationModalJoDetails.jobOrderTypePriceValue} ` +
            t("Pay_Button_Confirmation_Message_Part_2")
          }
          confirmText={t("COMMON_MESSAGES.Yes")}
          confirmEvent={() => {
            setShowPayButtonConfirmationModal(false);
            handleYesPayForJobOrder();
          }}
        ></ConfirmationModal>
      )}
    </section>
  );
};

const mapStateToProps = (state) => {
  return {
    job: state.job,
    configurationDetail: _.get(
      state,
      ["callConfiguration", "configurationDetail"],
      {}
    ),
    profile: state.profile,
  };
};

export default connect(mapStateToProps, {
  getJobOrders,
  scheduleAppoinment,
  rescheduleAppoinment,
  LoadConfigurationDetail,
  resendAppointment,
  autoSnap,
  payForJobOrder,
})(JobOrders);
