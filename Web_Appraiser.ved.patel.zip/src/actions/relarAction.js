import * as actionTypes from "./actionTypes";
import relarService from "../services/relarService";
import { StartLoading, StopLoading } from "./UIAction";
import { customToast } from "../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "../constants/commonMessages";

const startFetchRelars = () => {
  return {
    type: actionTypes.FETCH_RELAR_START,
  };
};

const successFetchRelars = (data) => {
  return {
    type: actionTypes.FETCH_RELAR_SUCCESS,
    payload: data,
  };
};

const errorFetchRelars = (error) => {
  return {
    type: actionTypes.FETCH_RELAR_ERROR,
    payload: error,
  };
};

export const fetchRelar = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchRelars());
    return relarService
      .getRelars(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchRelars(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchRelars(err));
      });
  };
};
export const filterRelar = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchRelars());
    return relarService
      .filterRelars(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchRelars(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchRelars(err));
      });
  };
};
export const requestRelar = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    return relarService
      .requestRelar(data)
      .then((data) => {
        dispatch(StopLoading());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
      });
  };
};
