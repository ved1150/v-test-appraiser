import api from "./api";
import { hydrateJobOrders } from "../transformers/jobTransformer";

export default class JobAPI {
  getJobOrders(data) {
    const queryParams = {
      page: data.page,
      size: data.size,
    };

    if (data.searchText) {
      queryParams.searchText = data.searchText;
    }
    return api
      .get("joborders", {
        params: queryParams,
      })
      .then((res) => {
        return hydrateJobOrders(res.data.data);
      });
  }
  deleteJobOrder(jobOrderId) {
    return api.delete(`joborders/${jobOrderId}`);
  }
  scheduleAppoinment(data) {
    return api.post(`/appointment/create`, data);
  }

  getAppointmentSlotByDate(data) {
    return api.get(`/getAppointments/${data.date}`);
  }

  rescheduleAppoinment(data, appointmentId) {
    return api.post(`/appointment/update/${appointmentId}`, data);
  }

  resendAppointment(data) {
    return api.post("/appointment/resend", data);
  }

  autoSnap(data) {
    return api.put("/joborders/update-autosnapshot", data);
  }

  checkJobOrderCallStatus(jobOrderId) {
    return api.get(`/job-order-call-status/${jobOrderId}`);
  }

  payForJobOrder(jobOrderId) {
    return api.post(`/payForJobOrder/${jobOrderId}`);
  }
}
