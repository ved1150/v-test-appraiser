export const convert24to12Hr = (time) => {
  const H = +time.substr(0, 2);
  const h = H % 12 || 12;
  const ampm = H < 12 || H === 24 ? "AM" : "PM";
  const timeString = `${h}${time.substr(2, 3)} ${ampm}`;
  return timeString;
};

export const modifyDate = (date) => {
  const day = date.getDate() < 10 ? `0${date.getDate()}` : `${date.getDate()}`;
  const month =
    date.getMonth() + 1 < 10
      ? `0${date.getMonth() + 1}`
      : `${date.getMonth() + 1}`;
  const year = date.getFullYear();
  return `${year}-${month}-${day} 00:00:00`;
};
