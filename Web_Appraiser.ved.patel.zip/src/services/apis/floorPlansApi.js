import api from "./api";

export default class FloorPlansAPI {
  getFloorPlans(data) {
    return api.get(`/floorscan/${data.jobOrderId}?direction=${data.direction}`);
  }

  downloadImage(data) {
    return api.get(data);
  }

  downloadZip(data) {
    return api.get(data);
  }
}
