import moment from "moment";
import _ from "lodash";
import { DATE_FORMAT } from "../../constants/appConstant";

const hydrateFloor = (data) => {
  return {
    floorIndex: data.floorIndex,
    floorPlanPath: data.floorPlanPath,
    floorPlanViewPath: data.floorPlanViewPath,
    floorScanId: data.floorScanId,
    floorScanNumber: data.floorScanNumber,
    jobOrderId: data.jobOrderId,
    orderNumber: data.orderNumber,
    pdfPath: data.pdfPath,
    plyPath: data.plyPath,
    plyViewPath: data.plyViewPath,
    status: data.status,
    zipPath: data.zipPath,
    videoPath: data.videoPath,
    pinLocation: data.pinLocation,
    floorScanType: data.floorScanType,
    wallThickness: data.wallThickness,
    floorScanObjPoints: data.floorScanObjPoints,
    floorScan3dAutoSaveJson: data.floorScan3dAutoSaveJson,
  };
};

export const hydrateFloors = (data) => {
  return {
    data: hydrateFloor(data.data.data),
  };
};

export const deHydrateFloors = (data) => {
  return {
    floorScanId: data.id,
  };
};
