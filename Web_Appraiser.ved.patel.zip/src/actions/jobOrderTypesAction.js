import * as actionTypes from "../actions/actionTypes";
import jobOrderTypesService from "../services/jobOrderTypesService";
import { StartLoading, StopLoading } from "./UIAction";

const listJobOrderTypeStart = () => {
  return {
    type: actionTypes.LIST_JOB_ORDER_TYPE_START,
  };
};

const listJobOrderTypeSuccess = (data) => {
  return {
    type: actionTypes.LIST_JOB_ORDER_TYPE_SUCCESS,
    payload: data,
  };
};

const listJobOrderTypeError = (error) => {
  return {
    type: actionTypes.LIST_JOB_ORDER_TYPE_ERROR,
    payload: error,
  };
};

export const listJobOrderTypes = (data) => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(listJobOrderTypeStart());
  return jobOrderTypesService
    .listJobOrderTypes(data)
    .then((response) => {
      dispatch(StopLoading());
      return dispatch(listJobOrderTypeSuccess(response));
    })
    .catch((error) => {
      dispatch(StopLoading());
      dispatch(listJobOrderTypeError(error));
      throw error;
    });
};
