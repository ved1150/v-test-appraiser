import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { useTranslation } from "react-i18next";
import {
  getManageCardList,
  setDefaultCard,
  deleteManageCard,
} from "../../actions/manageCardsAction";
import "./index.scss";
import NoDataView from "../JobOrders/JobOrderDetails/Common/noDataView";
import { MANAGE_CARDS_ICON } from "../JobOrders/JobOrderDetails/Common/commonText";
import { customToast } from "../../helpers/customToast";
import { Tooltip } from "@mui/material";

const ManageCardsList = (props) => {
  const { t } = useTranslation();
  const [manageCardList, setManageCardList] = useState(null);
  const [savedCardsList, setSavedCardsList] = useState(null);
  const [defaultCardList, setDefaultCardList] = useState(null);
  const [customerProfileId, setCustomerProfileId] = useState(null);
  const [cardToDelete, setCardToDelete] = useState(null);
  const [cardToDefault, setCardToDefault] = useState(null);

  useEffect(() => {
    props.getManageCardList().then((res) => {
      if (res) {
        setManageCardList(res?.data?.data?.cardDataList);
        setSavedCardsList(
          res?.data?.data?.cardDataList?.filter((card) => !card?.isDefaultCard)
        );
        setDefaultCardList(
          res?.data?.data?.cardDataList?.filter((card) => card?.isDefaultCard)
        );
        setCustomerProfileId(res?.data?.data?.customerProfileId);
      }
    });
  }, []);

  const getCardIcon = (cardType) => {
    switch (cardType?.trim()?.toLowerCase()?.replaceAll(" ", "")) {
      case "americanexpress":
        return "amex.svg";
      case "discover":
        return "discover.svg";
      case "jcb":
        return "jcb.svg";
      case "visa":
        return "visa.svg";
      case "mastercard":
        return "mastercard.svg";
      default:
        return "generic.svg";
    }
  };

  const customCardComponent = (card) => {
    return (
      <div className="vcol-4">
        <div className="card-box">
          <div className="card-box-detail">
            <div className="box-wrap">
              <span className="card-title">{t("WEB_LABELS.Card_Number")}:</span>
              <div className="card-desc">{card?.cardNumber ?? "N/A"}</div>
            </div>
            <div className="box-wrap">
              <span className="card-title">{t("WEB_LABELS.Card_Type")}:</span>
              <div className="card-desc">
                <Tooltip title={card?.cardType ?? "N/A"} arrow>
                  <img
                    src={`/images/card-icons/${getCardIcon(card?.cardType)}`}
                    height="24"
                    alt="card-icon"
                  />
                </Tooltip>
              </div>
            </div>
            <div className="box-wrap">
              <span className="card-title">{t("WEB_LABELS.Expiry")}:</span>
              <div className="card-desc">{card?.expirationDate ?? "N/A"}</div>
            </div>
          </div>
          <div className="card-box-button">
            {!card?.isDefaultCard && (
              <button
                disabled={
                  props?.manageCards?.deleteCardLoading &&
                  cardToDelete === card?.customerPaymentProfileId
                    ? "true"
                    : null
                }
                onClick={() => {
                  setCardToDelete(card?.customerPaymentProfileId);
                  props
                    .deleteManageCard({
                      customerPaymentProfileId: card?.customerPaymentProfileId,
                      customerProfileId: customerProfileId,
                    })
                    .then((data) => {
                      if (data?.data?.success) {
                        customToast.success(t("Card_Delete_Success"));
                        props.getManageCardList().then((res) => {
                          if (res) {
                            setManageCardList(res?.data?.data?.cardDataList);
                            setSavedCardsList(
                              res?.data?.data?.cardDataList?.filter(
                                (card) => !card?.isDefaultCard
                              )
                            );
                            setDefaultCardList(
                              res?.data?.data?.cardDataList?.filter(
                                (card) => card?.isDefaultCard
                              )
                            );
                            setCustomerProfileId(
                              res?.data?.data?.customerProfileId
                            );
                          }
                        });
                      }
                    })
                    .finally(() => {
                      setCardToDelete(null);
                    });
                }}
                className="blue-btn"
              >
                {t("BUTTONS.Delete")}
                {props?.manageCards?.deleteCardLoading &&
                cardToDelete === card?.customerPaymentProfileId ? (
                  <div className="loader-spin"></div>
                ) : null}
              </button>
            )}
            {card?.isDefaultCard && (
              <button className="blue-btn" disabled>
                {t("BUTTONS.Default")}
              </button>
            )}
            <button
              onClick={() => {
                props.history.push("/cards/manage", {
                  isEditCard: true,
                  paymentProfileId: card?.customerPaymentProfileId,
                });
              }}
              className="blue-btn"
            >
              {t("WEB_TOOLTIPS.Edit")}
            </button>
            {!card?.isDefaultCard && (
              <button
                disabled={
                  props?.manageCards?.defaultCardLoading &&
                  cardToDefault === card?.customerPaymentProfileId
                    ? "true"
                    : null
                }
                onClick={() => {
                  setCardToDefault(card?.customerPaymentProfileId);
                  props
                    .setDefaultCard({
                      customerPaymentProfileId: card?.customerPaymentProfileId,
                      customerProfileId: customerProfileId,
                    })
                    .then((data) => {
                      if (data?.data?.success) {
                        customToast.success(t("Card_Default_Success"));
                        props.getManageCardList().then((res) => {
                          if (res) {
                            setManageCardList(res?.data?.data?.cardDataList);
                            setSavedCardsList(
                              res?.data?.data?.cardDataList?.filter(
                                (card) => !card?.isDefaultCard
                              )
                            );
                            setDefaultCardList(
                              res?.data?.data?.cardDataList?.filter(
                                (card) => card?.isDefaultCard
                              )
                            );
                            setCustomerProfileId(
                              res?.data?.data?.customerProfileId
                            );
                          }
                        });
                      }
                    })
                    .finally(() => {
                      setCardToDefault(null);
                    });
                }}
                className="blue-btn"
              >
                {t("BUTTONS.Make_As_Default")}
                {props?.manageCards?.defaultCardLoading &&
                cardToDefault === card?.customerPaymentProfileId ? (
                  <div className="loader-spin"></div>
                ) : null}
              </button>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <section className="content-wapper">
        <div className="breadcrumb">
          <ul>
            <li>{t("WEB_LABELS.Manage_Cards")}</li>
          </ul>
        </div>
        <div className="common-panel lander-magement relative-panel">
          <div className="right-btn">
            <button
              className="blue-btn"
              onClick={() => {
                props.history.push("/cards/manage", {
                  isAddCard: true,
                });
              }}
            >
              {t("BUTTONS.Add_Card")}
            </button>
          </div>
          <div className="panel-body">
            {defaultCardList && defaultCardList.length > 0 && (
              <div className="default-card-header">{t("Default_Card")}</div>
            )}
            <div className="vrow">
              {defaultCardList &&
                defaultCardList.length > 0 &&
                defaultCardList?.map((card) => customCardComponent(card))}
            </div>
            {savedCardsList && savedCardsList.length > 0 && (
              <div
                className={
                  defaultCardList?.length === 0
                    ? "default-card-header"
                    : "saved-cards-header"
                }
              >
                {t("Saved_Cards")}
              </div>
            )}
            <div className="vrow">
              {savedCardsList &&
                savedCardsList.length > 0 &&
                savedCardsList?.map((card) => customCardComponent(card))}
            </div>
            {(!manageCardList || manageCardList?.length === 0) && (
              <div className="no-data-found-container">
                <div className="no-data-found">
                  <div className="box">
                    {props?.manageCards?.listCardsLoading ? (
                      <div className="loader-spin"></div>
                    ) : (
                      <>
                        <img
                          style={{ width: "100px" }}
                          src="/images/manage_cards_2.png"
                          alt="No Cards"
                        />
                        <p>{`${t(
                          "COMMON_MESSAGES.JOB_ORDER_DETAILS.There_is_No"
                        )} ${t("COMMON_MESSAGES.No_Cards_Available")} ${t(
                          "COMMON_MESSAGES.JOB_ORDER_DETAILS.Available"
                        )}`}</p>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    manageCards: state.manageCards,
  };
};

export default connect(mapStateToProps, {
  getManageCardList,
  setDefaultCard,
  deleteManageCard,
})(ManageCardsList);
