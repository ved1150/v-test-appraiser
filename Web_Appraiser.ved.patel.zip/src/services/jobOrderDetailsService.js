import api from "./apis/api";

class JobOrderDetailsService {
  completeJO(data, joborderId) {
    return api.jobOrderDetails.completeJO(data, joborderId);
  }

  setPrimaryPictureForReportPDF(data) {
    return api.jobOrderDetails.setPrimaryPictureForReportPDF(data);
  }
}

export default new JobOrderDetailsService();
