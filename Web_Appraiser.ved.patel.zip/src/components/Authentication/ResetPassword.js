import React, { useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { connect, useSelector } from "react-redux";
import { resetPassword } from "../../actions/authenticationAction";
import { Formik } from "formik";
import * as Yup from "yup";
import TextInput from "../common/TextInput";
import Button from "./../common/Button";
import { resetPasswordMessages } from "../../constants/validationerrorMessages";
import "./index.scss";
import Logo from "../../images/blue-logo.svg";
import AsyncImage from "../common/AsyncImage";
import { isEmpty, get } from "lodash";
import "./ResetPassword.scss";
import DisplayErrorModal from "../common/DisplayErrorModal/DisplayErrorModal";
const ResetPassword = (props) => {
  const [submitLoading, setSubmitLoading] = useState(false);
  let history = useHistory();
  let { userId } = useParams();

  const [newPasswordType, setNewPasswordType] = useState("password");
  const [confirmPasswordType, setConfirmPasswordType] = useState("password");

  React.useEffect(() => {
    if (!userId) {
      history.push("/");
    }
  }, []);

  const togglePasswordVisibility = (type, category) => {
    if (category === "new") {
      setNewPasswordType(type);
    } else {
      setConfirmPasswordType(type);
    }
  };

  const tenantLogo = useSelector((state) => {
    return state?.whiteLabel?.getTenantThemeSuccess?.tenantLogo;
  });

  return (
    <>
      {props.errorModalloading && <DisplayErrorModal />}
      <section className="main-authaticatoin-wraper">
        <div className="auth-center-segment">
          <div className="auth-logo-top">
            {!isEmpty(tenantLogo) ? (
              <AsyncImage useStaticToken={true} imageUrl={tenantLogo} />
            ) : (
              <img src={Logo} alt="logo" />
            )}
          </div>
          <div className="auth-form-field-section">
            <Formik
              initialValues={{ newPassword: "", confirmPassword: "" }}
              onSubmit={(values, { setSubmitting }) => {
                setSubmitLoading(true);
                props
                  .resetPassword(
                    {
                      newPassword: values.newPassword,
                      userId,
                    },
                    props.history
                  )
                  .then((res) => {
                    setSubmitLoading(false);
                  })
                  .catch((e) => setSubmitLoading(false));
                setSubmitting(false);
              }}
              validationSchema={Yup.object().shape({
                newPassword: Yup.string()
                  .required(
                    "ERROR_MESSAGES.changePasswordMessages.newPasswordRequired"
                  )
                  .min(
                    8,
                    "ERROR_MESSAGES.changePasswordMessages.mustBe8Characters"
                  )
                  .matches(
                    /[A-Z]/,
                    "ERROR_MESSAGES.changePasswordMessages.mustBeUppercase"
                  )
                  .matches(
                    /[a-z]/,
                    "ERROR_MESSAGES.changePasswordMessages.mustBeLowercase"
                  )
                  .matches(
                    /[!@#$%^&*]/,
                    "ERROR_MESSAGES.changePasswordMessages.specialCharacter"
                  )
                  .matches(
                    /[0-9]/,
                    "ERROR_MESSAGES.changePasswordMessages.mustBeDigit"
                  ),
                confirmPassword: Yup.string()
                  .required(
                    "ERROR_MESSAGES.changePasswordMessages.confirmPasswordRequired"
                  )
                  .min(
                    8,
                    "ERROR_MESSAGES.changePasswordMessages.mustBe8Characters"
                  )
                  .matches(
                    /[A-Z]/,
                    "ERROR_MESSAGES.changePasswordMessages.mustBeUppercase"
                  )
                  .matches(
                    /[a-z]/,
                    "ERROR_MESSAGES.changePasswordMessages.mustBeLowercase"
                  )
                  .matches(
                    /[!@#$%^&*]/,
                    "ERROR_MESSAGES.changePasswordMessages.specialCharacter"
                  )
                  .matches(
                    /[0-9]/,
                    "ERROR_MESSAGES.changePasswordMessages.mustBeDigit"
                  )
                  .when("newPassword", {
                    is: (val) => (val && val.length > 0 ? true : false),
                    then: Yup.string().oneOf(
                      [Yup.ref("newPassword")],
                      "Both password need to be the same"
                    ),
                  }),
              })}
            >
              {(props) => {
                const {
                  values,
                  touched,
                  errors,
                  isSubmitting,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                } = props;
                return (
                  <form className="authatication-form" onSubmit={handleSubmit}>
                    <div className="inner-authaticatio-form">
                      <div className="form-group">
                        <p className="text-center">Reset Password</p>
                      </div>
                      <TextInput
                        type={newPasswordType}
                        name="newPassword"
                        placeholder="New Password"
                        value={values.newPassword}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={errors.newPassword}
                        touched={touched.newPassword}
                        showRules={true}
                        icon={
                          <div
                            className={`auth-icons ${
                              values.newPassword ? "font-eye" : ""
                            }`}
                          >
                            {values.newPassword ? (
                              <>
                                {newPasswordType === "text" ? (
                                  <i
                                    className="icon-eye"
                                    onClick={() =>
                                      togglePasswordVisibility(
                                        "password",
                                        "new"
                                      )
                                    }
                                  ></i>
                                ) : (
                                  <i
                                    className="icon-cross-eye"
                                    onClick={() =>
                                      togglePasswordVisibility("text", "new")
                                    }
                                  ></i>
                                )}
                              </>
                            ) : (
                              <i className="icon-change-password"></i>
                            )}
                          </div>
                        }
                      />
                      <TextInput
                        type={confirmPasswordType}
                        name="confirmPassword"
                        placeholder="Confirm Password"
                        value={values.confirmPassword}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        error={errors.confirmPassword}
                        touched={touched.confirmPassword}
                        icon={
                          <div
                            className={`auth-icons ${
                              values.confirmPassword ? "font-eye" : ""
                            }`}
                          >
                            {values.confirmPassword ? (
                              <>
                                {confirmPasswordType === "text" ? (
                                  <i
                                    className="icon-eye"
                                    onClick={() =>
                                      togglePasswordVisibility(
                                        "password",
                                        "confirm"
                                      )
                                    }
                                  ></i>
                                ) : (
                                  <i
                                    className="icon-cross-eye"
                                    onClick={() =>
                                      togglePasswordVisibility(
                                        "text",
                                        "confirm"
                                      )
                                    }
                                  ></i>
                                )}
                              </>
                            ) : (
                              <i className="icon-change-password"></i>
                            )}
                          </div>
                        }
                      />
                      <div className="form-group text-center">
                        <Button
                          disabled={submitLoading}
                          type="submit"
                          className="blue-btn"
                        >
                          {" "}
                          Submit{" "}
                          {submitLoading && <div className="loader-spin"></div>}
                        </Button>
                      </div>
                    </div>
                  </form>
                );
              }}
            </Formik>
          </div>
        </div>
      </section>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    authentication: state.authentication,
    errorModalloading: get(state, ["errorReducer", "errorModalloading"]),
  };
};

export default connect(mapStateToProps, {
  resetPassword,
})(ResetPassword);
