import React, { useEffect, useRef, useState } from "react";
import _ from "lodash";

import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import NoDataView from "../Common/noDataView";
import { FLOORPLANS_ICON } from "../Common/commonText";
import { useTranslation } from "react-i18next";
import "./floorPlan.scss";
import { floorScanStatusEnum, floorName } from "../../../../constants/enums";
import { Button, Tooltip } from "@mui/material";
import { useHistory } from "react-router-dom";
import { connect, useDispatch, useSelector } from "react-redux";
import { getRequestRescanHistory } from "../../../../actions/technicianJobAction";
import RequestRescanHistory from "../../../FloorScanJob/RequestRescanHistory/RequestRescanHistory";
import RequestRescanHistoryImages from "../../../FloorScanJob/RequestRescanHistory/RequestRescanHistoryImages";
import store from "../../../../store";
import { StoreActions } from "../../../../actions/jobAction";
import { scrollIntoView } from "../../../../helpers";

const FloorPlansTab = (props) => {
  const { t } = useTranslation();
  const tableHead = [
    {
      key: "Floor_Scan",
      label: t("WEB_LABELS.Floor_Scan"),
      disableSorting: true,
    },
    {
      key: "Floor_Name",
      label: t("WEB_LABELS.Floor_Name"),
      disableSorting: true,
    },
    {
      key: "wallThickness",
      label: t("WEB_LABELS.Wall_Thickness"),
      disableSorting: true,
    },
    {
      key: "Technician_Name",
      label: t("WEB_LABELS.Technician_Name"),
      disableSorting: true,
    },
    {
      key: "Floor_Scan_Status",
      label: t("WEB_LABELS.Floor_Scan_Status"),
      disableSorting: true,
    },
    { key: "Created_On", label: t("WEB_LABELS.Created_On") },
    { key: "Action", label: t("WEB_LABELS.Action"), disableSorting: true },
  ];

  const [sortBy, setSortBy] = useState("Created_On");
  const [direction, setDirection] = useState("desc");
  const [floorplansList, setFloorPlansList] = useState([]);
  const history = useHistory();
  const scrollableListRef = useRef();

  useEffect(() => {
    const filter = {
      direction,
      sortBy,
      jobOrderId: props.jobOrderId,
    };

    const actionsData = _.get(props, ["job", "storeActionsData"], {});
    props
      .fetchFloorPlans(filter)
      .then((data) => {
        setFloorPlansList(data);
      })
      .catch((err) => setFloorPlansList([]))
      .finally(() => {
        setTimeout(() => {
          scrollIntoView(scrollableListRef);
          store.dispatch(
            StoreActions({
              jobOrders: actionsData?.jobOrders,
              floorScans: {
                floorScanId: actionsData?.floorScans?.floorScanId,
              },
            })
          );
        }, 10);
      });
  }, [direction, sortBy]);

  const [showRequestRescanHistoryModal, setShowRequestRescanHistoryModal] =
    useState(false);
  const [
    showRequestRescanHistoryImagesModal,
    setShowRequestRescanHistoryImagesModal,
  ] = useState(false);
  const [
    requestRescanHistoryImagesModalData,
    setRequestRescanHistoryImagesModalData,
  ] = useState(null);
  const [historyForfloorScanNumber, setHistoryForfloorScanNumber] =
    useState("");
  const [scanId, setScanId] = useState(null);
  const dispatch = useDispatch();
  useEffect(() => {
    if (!_.isEmpty(scanId) && showRequestRescanHistoryModal) {
      dispatch(getRequestRescanHistory(scanId));
    }
  }, [showRequestRescanHistoryModal]);

  const handleSorting = (cellId) => {
    resetActionsData();
    const isAsc = sortBy === cellId && direction === "desc";
    setDirection(isAsc ? "asc" : "desc");
    setSortBy(cellId);
  };

  const viewImage = (floorPlanPath, floorPlanViewPath) => {
    resetActionsData();
    props.viewImageForFloorPlan(floorPlanPath, floorPlanViewPath);
  };
  const downloadZip = (zipPath) => {
    resetActionsData();
    props.downloadZip(zipPath).then((data) => {
      window.open(data.data, "_blank");
    });
  };
  const fetchFloorLoading = useSelector(
    (state) => state?.floorPlans?.fetchFloorPlansStart
  );

  const resetActionsData = () => {
    store.dispatch(
      StoreActions({
        jobOrders: _.get(props, ["job", "storeActionsData", "jobOrders"], {}),
        floorScans: {},
      })
    );
  };
  return (
    <div>
      {fetchFloorLoading || _.size(floorplansList) === 0 ? (
        <div className="no-data-found-container">
          {fetchFloorLoading ? (
            <div className="no-data-found">
              <div className="box">
                <div className="loader-spin"></div>
              </div>
            </div>
          ) : (
            <NoDataView
              text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.FLOORPLANS")}
              icon={FLOORPLANS_ICON}
            />
          )}
        </div>
      ) : (
        <>
          <div className="racording scroll-bar-style">
            <TableContainer>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    {tableHead.map((head, key) => (
                      <TableCell
                        key={key}
                        sortDirection={sortBy === head.key ? direction : false}
                      >
                        {head.disableSorting ? (
                          head.label
                        ) : (
                          <TableSortLabel
                            active={sortBy === head.key}
                            direction={sortBy === head.key ? direction : "asc"}
                            onClick={() => {
                              handleSorting(head.key);
                            }}
                          >
                            {head.label}
                          </TableSortLabel>
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {floorplansList?.map((d, id) => {
                    const actionFloorScanId = _.get(
                      props,
                      ["job", "storeActionsData", "floorScans"],
                      ""
                    );
                    return (
                      <TableRow
                        ref={
                          d.floorScanId === actionFloorScanId.floorScanId
                            ? scrollableListRef
                            : null
                        }
                        className={`${
                          d.floorScanId === actionFloorScanId.floorScanId
                            ? "selected-item"
                            : ""
                        }`}
                        key={id}
                      >
                        <TableCell>{d.floorScanNumber}</TableCell>
                        <TableCell>
                          {d.floorIndex >= -1 ? (
                            floorName?.map(
                              ({ id, value }, index) =>
                                d.floorIndex === id && <>{value}</>
                            )
                          ) : (
                            <>-</>
                          )}
                        </TableCell>
                        <TableCell>{d.wallThickness}</TableCell>
                        <TableCell>
                          {d.technicianName ? d.technicianName : <>-</>}
                        </TableCell>
                        <TableCell>
                          {d.status ? (
                            floorScanStatusEnum?.map(
                              ({ id, valAppraiser, color }, index) =>
                                d.status === id && (
                                  <div className="chips-box">
                                    <div className={`card-chips ${color}`}>
                                      {valAppraiser}
                                    </div>
                                    <div className="action-wrapper">
                                      <ul className="btn-list">
                                        <li>
                                          <Tooltip
                                            title={t("Request_Rescan_History")}
                                            arrow
                                          >
                                            <Button
                                              onClick={() => {
                                                setScanId(d.floorScanId);
                                                setShowRequestRescanHistoryModal(
                                                  true
                                                );
                                                setHistoryForfloorScanNumber(
                                                  d.floorScanNumber
                                                );
                                              }}
                                            >
                                              <i className="icon-Time"></i>
                                            </Button>
                                          </Tooltip>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                )
                            )
                          ) : (
                            <>-</>
                          )}
                        </TableCell>
                        <TableCell>
                          {d.createdAt ? d.createdAt : <>-</>}
                        </TableCell>
                        <TableCell>
                          {
                            <>
                              <Tooltip title="Explore .Ply" arrow>
                                <button
                                  className={`mr-20 download ${
                                    !d.plyPath ? "disable-download" : ""
                                  }`}
                                  onClick={() => {
                                    store.dispatch(
                                      StoreActions({
                                        jobOrders: _.get(
                                          props,
                                          [
                                            "job",
                                            "storeActionsData",
                                            "jobOrders",
                                          ],
                                          {}
                                        ),
                                        floorScans: {
                                          floorScanId: d.floorScanId,
                                        },
                                      })
                                    );
                                    history.push(
                                      `/view-floorscan/${d.floorScanId}`
                                    );
                                  }}
                                >
                                  <i className="icon-Explore-ply" />
                                </button>
                              </Tooltip>
                              <Tooltip title={t("BUTTONS.Download_Ply")} arrow>
                                <button
                                  className={`mr-20 download ${
                                    !d.plyPath ? "disable-download" : ""
                                  }`}
                                  onClick={() => downloadZip(d.plyPath)}
                                  disabled={!d.plyPath}
                                >
                                  <i className="icon-Download-ply-file"></i>
                                </button>
                              </Tooltip>
                              <Tooltip
                                title={t("BUTTONS.Download_Video")}
                                arrow
                              >
                                <button
                                  className={`mr-20 download ${
                                    !d.zipPath ? "disable-download" : ""
                                  }`}
                                  onClick={() => downloadZip(d.zipPath)}
                                  disabled={!d.zipPath}
                                >
                                  <i className="icon-call-recording"></i>
                                </button>
                              </Tooltip>
                              <Tooltip
                                title={t("BUTTONS.View_Floor_Plan")}
                                arrow
                              >
                                <button
                                  className={`mr-20 download ${
                                    !d.floorPlanViewPath
                                      ? "disable-download"
                                      : ""
                                  }`}
                                  onClick={() =>
                                    viewImage(
                                      d.floorPlanPath,
                                      d.floorPlanViewPath
                                    )
                                  }
                                  disabled={!d.floorPlanViewPath}
                                >
                                  <i className="icon-view-details"></i>
                                </button>
                              </Tooltip>
                              <Tooltip title={t("BUTTONS.Download_PDF")} arrow>
                                <button
                                  className={`download ${
                                    !d.pdfPath ? "disable-download" : ""
                                  }`}
                                  onClick={() => downloadZip(d.pdfPath)}
                                  disabled={!d.pdfPath}
                                >
                                  <i className="icon-Download-PDF"></i>
                                </button>
                              </Tooltip>
                            </>
                          }
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </>
      )}
      <div
        className={
          showRequestRescanHistoryModal
            ? "comman-modal right-side open"
            : "comman-modal right-side "
        }
      >
        <div className="comman-modal-main">
          <div className="side-head">
            {t("Request_Rescan_History")} {historyForfloorScanNumber}
            <button
              className="close-modal"
              onClick={() => {
                setShowRequestRescanHistoryModal(false);
                setRequestRescanHistoryImagesModalData(null);
              }}
            >
              <i className="icon-close-image"></i>
            </button>
          </div>
          <RequestRescanHistory
            setRequestRescanHistoryImagesModalData={
              setRequestRescanHistoryImagesModalData
            }
            setShowRequestRescanHistoryImagesModal={
              setShowRequestRescanHistoryImagesModal
            }
          />
        </div>
      </div>
      {showRequestRescanHistoryImagesModal && (
        <RequestRescanHistoryImages
          requestRescanHistoryImagesModalData={
            requestRescanHistoryImagesModalData
          }
          setRequestRescanHistoryImagesModalData={
            setRequestRescanHistoryImagesModalData
          }
          setShowRequestRescanHistoryImagesModal={
            setShowRequestRescanHistoryImagesModal
          }
        />
      )}
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    details: state.details,
    job: state.job,
  };
};

export default connect(mapStateToProps, {})(FloorPlansTab);
