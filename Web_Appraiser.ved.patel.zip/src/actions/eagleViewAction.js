import * as actionTypes from "./actionTypes";
import eagleViewService from "../services/eagleViewService";

const startCreateOrder = () => {
  return {
    type: actionTypes.CREATE_ORDER_START,
  };
};

const successCreateOrder = (data) => {
  return {
    type: actionTypes.CREATE_ORDER_SUCCESS,
    payload: data,
  };
};

const errorCreateOrder = (error) => {
  return {
    type: actionTypes.CREATE_ORDER_ERROR,
    payload: error,
  };
};

export const createOrder = (data) => {
  return (dispatch) => {
    dispatch(startCreateOrder());
    return eagleViewService
      .createOrder(data)
      .then((data) => {
        dispatch(successCreateOrder(data));
        return data;
      })
      .catch((err) => {
        dispatch(errorCreateOrder(err));
      });
  };
};
