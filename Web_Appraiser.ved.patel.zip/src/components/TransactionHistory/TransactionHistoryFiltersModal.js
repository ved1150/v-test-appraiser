import "./index.scss";
import { useEffect, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";

const TransactionHistoryFiltersModal = (props) => {
  const { t } = useTranslation();
  const [transactionStatus, setTransactionStatus] = useState(
    props.transactionStatus
  );
  const [fromDate, setFromDate] = useState(props.fromDate);
  const [toDate, setToDate] = useState(props.toDate);
  const statusDropDownData = useSelector(
    (state) =>
      state?.transactionHistory?.fetchTransactionStatusSuccess?.data?.data
  );

  useEffect(() => {
    setTransactionStatus(props.transactionStatus);
    setFromDate(props.fromDate);
    setToDate(props.toDate);
  }, [props.transactionStatus, props.fromDate, props.toDate]);

  return (
    <div
      className={
        !props.openTransactionHistoryFilterModal
          ? "comman-modal right-side"
          : "comman-modal right-side open fixed-position z-index2"
      }
    >
      <div
        className="comman-modal-main"
        style={{
          maxWidth: !props.openTransactionHistoryFilterModal ? "0px" : "530px",
        }}
      >
        <div className="side-head">
          <i className="icon-filter" style={{ fontSize: 12 }}></i>&nbsp;{" "}
          {t("BUTTONS.Filter")}
          <button
            className="close-modal"
            onClick={() => {
              setTransactionStatus(props.transactionStatus);
              setFromDate(props.fromDate);
              setToDate(props.toDate);
              props.setOpenTransactionHistoryFilterModal(false);
            }}
          >
            <i className="icon-close-image"></i>
          </button>
        </div>
        <div className="comman-modal-body floorscan-details-modal scroll-bar-style">
          <div className="form-group boot-dropdown">
            <label>{t("Transaction_Status")}</label>
            <select
              className="form-control"
              name="transaction-status"
              placeholder={t("Transaction_Status")}
              value={transactionStatus ?? ""}
              onChange={(e) => {
                const _value = e.target.value;
                setTransactionStatus(_value.isEmpty ? null : _value);
              }}
            >
              <option value={""}>All</option>
              {statusDropDownData?.map((e) => (
                <option value={e}>{e}</option>
              ))}
            </select>
          </div>
          <div className="date-range-picker form-group">
            <label>{t("Transaction_Date")}</label>
            <br />
            <div className="inner-form-group range-date-picker">
              <DatePicker
                className="form-control"
                selected={fromDate}
                onChange={(date) => {
                  if (moment(date).isValid()) {
                    setFromDate(
                      moment(moment(date).format("YYYY-MM-DD")).toDate()
                    );
                  }
                }}
                dateFormat="MM/dd/yyyy"
                placeholderText={t("From_Date")}
                maxDate={toDate}
              />
              <div className="range-separator"></div>
              <DatePicker
                className="form-control"
                selected={toDate}
                onChange={(date) => {
                  if (moment(date).isValid()) {
                    setToDate(
                      moment(moment(date).format("YYYY-MM-DD")).toDate()
                    );
                  }
                }}
                dateFormat="MM/dd/yyyy"
                placeholderText={t("To_Date")}
                minDate={fromDate}
              />
              <div
                onClick={() => {
                  setFromDate(null);
                  setToDate(null);
                }}
                className="range-separator"
              >
                <button className="blue-btn">
                  <i style={{ margin: 0 }} className="icon-close-image"></i>
                </button>
              </div>
            </div>
          </div>
          <div className="text-center">
            <button
              className="blue-btn"
              onClick={() => {
                props.setTransactionStatus(transactionStatus);
                props.setFromDate(fromDate ?? toDate);
                props.setToDate(toDate ?? fromDate);
                props.setOpenTransactionHistoryFilterModal(false);
              }}
            >
              {t("Apply")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionHistoryFiltersModal;
