import React, { useState } from "react";
import { connect } from "react-redux";
import { Link, useHistory } from "react-router-dom";
import { Formik } from "formik";
import * as Yup from "yup";

import TextInput from "../common/TextInput";
import Button from "./../common/Button";

import { changePassword } from "../../actions/authAction";
import { useTranslation } from "react-i18next";
import ConfirmationModal from "../common/confirmationModal";
import { get } from "lodash";
import "./ChangePassword.scss";
const ChangePassword = (props) => {
  const { t } = useTranslation();
  const history = useHistory();
  const [confirmationModal, setConfirmationModal] = useState(false);
  const [cancelModal, setCancelModal] = useState(false);
  const [passwordChangeDetails, setPasswordChangeDetails] = useState(null);
  const [resetFormFun, setResetForm] = useState();

  const changePasswordSubmit = () => {
    if (passwordChangeDetails) {
      setConfirmationModal(false);
      props
        .changePassword(
          {
            oldPassword: passwordChangeDetails.oldPassword,
            newPassword: passwordChangeDetails.newPassword,
          },
          history
        )
        .then((res) => {
          resetFormFun();
        })
        .catch((error) => {});
    }
  };
  return (
    <section className="content-wapper">
      <div className="breadcrumb">
        <ul>
          <li>
            <Link to="/profile">
              <button>{t("WEB_LABELS.Profile")}</button>
            </Link>
          </li>
          <li>{t("BUTTONS.Change_Password")}</li>
        </ul>
      </div>
      <div className="common-panel">
        <div className="panel-head">
          <div className="title">{t("BUTTONS.Change_Password")}</div>
        </div>
        <Formik
          enableReinitialize
          initialValues={{
            oldPassword: get(passwordChangeDetails, "oldPassword", ""),
            newPassword: get(passwordChangeDetails, "newPassword", ""),
            confirmNewPassword: get(passwordChangeDetails, "newPassword", ""),
          }}
          onSubmit={(values, { setSubmitting, resetForm, setFieldTouched }) => {
            setPasswordChangeDetails(values);
            setResetForm(resetForm);
            setConfirmationModal(true);
          }}
          validationSchema={Yup.object().shape({
            oldPassword: Yup.string().required(
              "ERROR_MESSAGES.changePasswordMessages.oldPasswordRequired"
            ),
            newPassword: Yup.string()
              .required(
                "ERROR_MESSAGES.changePasswordMessages.newPasswordRequired"
              )
              .min(8, "ERROR_MESSAGES.changePasswordMessages.mustBe8Characters")
              .matches(
                /[A-Z]/,
                "ERROR_MESSAGES.changePasswordMessages.mustBeUppercase"
              )
              .matches(
                /[a-z]/,
                "ERROR_MESSAGES.changePasswordMessages.mustBeLowercase"
              )
              .matches(
                /[!@#$%^&*]/,
                "ERROR_MESSAGES.changePasswordMessages.specialCharacter"
              )
              .matches(
                /[0-9]/,
                "ERROR_MESSAGES.changePasswordMessages.mustBeDigit"
              )
              .when("oldPassword", {
                is: (val) => (val && val.length > 0 ? true : false),
                then: Yup.string().notOneOf(
                  [Yup.ref("oldPassword")],
                  "ERROR_MESSAGES.changePasswordMessages.differentPassword"
                ),
              }),
            confirmNewPassword: Yup.string()
              .required(
                "ERROR_MESSAGES.changePasswordMessages.confirmPasswordRequired"
              )
              .min(8, "ERROR_MESSAGES.changePasswordMessages.mustBe8Characters")
              .matches(
                /[A-Z]/,
                "ERROR_MESSAGES.changePasswordMessages.mustBeUppercase"
              )
              .matches(
                /[a-z]/,
                "ERROR_MESSAGES.changePasswordMessages.mustBeLowercase"
              )
              .matches(
                /[!@#$%^&*]/,
                "ERROR_MESSAGES.changePasswordMessages.specialCharacter"
              )
              .matches(
                /[0-9]/,
                "ERROR_MESSAGES.changePasswordMessages.mustBeDigit"
              )
              .when("newPassword", {
                is: (val) => (val && val.length > 0 ? true : false),
                then: Yup.string().oneOf(
                  [Yup.ref("newPassword")],
                  "ERROR_MESSAGES.changePasswordMessages.samePassword"
                ),
              }),
          })}
        >
          {(props) => {
            const {
              isValid,
              dirty,
              values,
              touched,
              errors,
              isSubmitting,
              handleChange,
              handleBlur,
              handleSubmit,
            } = props;
            return (
              <form onSubmit={handleSubmit}>
                <div className="panel-body admin-profile">
                  <div className="vrow">
                    <div className="vcol-4">
                      <div className="form-group">
                        <label>
                          {t("WEB_LABELS.Current_Password")}
                          <span className="error-mark">*</span>
                        </label>
                        <TextInput
                          className="form-control"
                          type="password"
                          name="oldPassword"
                          placeholder={t("WEB_LABELS.Current_Password")}
                          value={values.oldPassword}
                          onChange={handleChange}
                          error={errors.oldPassword}
                          touched={touched.oldPassword}
                          onBlur={handleBlur}
                        />
                      </div>
                    </div>
                    <div className="vcol-4">
                      <div className="form-group ruleslist">
                        <label>
                          {t("WEB_LABELS.New_Password")}
                          <span className="error-mark">*</span>
                        </label>
                        <TextInput
                          className="form-control"
                          type="password"
                          name="newPassword"
                          placeholder={t("WEB_LABELS.New_Password")}
                          value={values.newPassword}
                          onChange={handleChange}
                          error={errors.newPassword}
                          touched={touched.newPassword}
                          onBlur={handleBlur}
                          showRules={true}
                        />
                      </div>
                    </div>
                    <div className="vcol-4">
                      <div className="form-group">
                        <label>
                          {t("WEB_LABELS.Confirm_New_Password")}
                          <span className="error-mark">*</span>
                        </label>
                        <TextInput
                          className="form-control"
                          placeholder={t("WEB_LABELS.Confirm_New_Password")}
                          type="password"
                          name="confirmNewPassword"
                          value={values.confirmNewPassword}
                          onChange={handleChange}
                          error={errors.confirmNewPassword}
                          touched={touched.confirmNewPassword}
                          onBlur={handleBlur}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="panel-footer">
                  <Button
                    className="blue-btn"
                    type="submit"
                    disabled={
                      isSubmitting ||
                      !(isValid && (!cancelModal ? dirty : true))
                    }
                  >
                    {t("BUTTONS.Change")}
                  </Button>
                </div>
                {confirmationModal && (
                  <ConfirmationModal
                    cancelEvent={() => {
                      setCancelModal(true);
                      setConfirmationModal(false);
                    }}
                    title={t("WEB_LABELS.Change_Password_Confirmation")}
                    cancelText={t("COMMON_MESSAGES.No")}
                    confirmText={t("COMMON_MESSAGES.Yes")}
                    confirmEvent={changePasswordSubmit}
                  ></ConfirmationModal>
                )}
              </form>
            );
          }}
        </Formik>
      </div>
    </section>
  );
};

const mapStateToProps = (state) => ({});

export default connect(mapStateToProps, {
  changePassword,
})(ChangePassword);
