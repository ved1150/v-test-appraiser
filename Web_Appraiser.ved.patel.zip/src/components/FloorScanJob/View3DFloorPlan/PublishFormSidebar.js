import { Button } from "@mui/material";
import { useFormik } from "formik";
import React, { useEffect, useState } from "react";
import {
  AREA_TYPES,
  Area_Type_Tooltip,
  SHORT_NAME_CHAR_LIMIT,
} from "../../../constants/appConstant";
import * as Yup from "yup";
import { useTranslation } from "react-i18next";
import Tooltip from "@mui/material/Tooltip";
export default function PublishFormSidebar({
  onSubmit,
  floorNameJson,
  setShowPublishSidebar,
  showPublishSidebar,
}) {
  const { t } = useTranslation();
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      floorName: floorNameJson?.value,
      tag: "",
      areaType: "",
    },
    validationSchema: Yup.object().shape({
      areaType: Yup.string().trim().required("Area Type is Required"),
      tag: Yup.string()
        .trim()
        .required("Label/Tag is Required")
        .max(
          SHORT_NAME_CHAR_LIMIT,
          `You can add upto ${SHORT_NAME_CHAR_LIMIT} character only`
        ),
    }),
  });
  useEffect(() => {
    if (!showPublishSidebar) {
      formik.resetForm();
    }
  }, [showPublishSidebar]);

  const newFloorName = `${formik?.values?.floorName?.replace(" ", "")}_${
    formik.values.areaType
  }${formik.values.tag && "_" + formik.values.tag.trim()}`;
  return (
    <>
      <div
        className={
          showPublishSidebar
            ? "comman-modal right-side open"
            : "comman-modal right-side"
        }
      >
        <div className="comman-modal-main">
          <div className="side-head">
            Publish
            <button
              className="close-modal"
              onClick={() => setShowPublishSidebar(false)}
            >
              <i className="icon-close-image"></i>
            </button>
          </div>
          <div className="comman-modal-body technician-details-modal scroll-bar-style">
            <div className="form-group">
              <label>Floor Name</label>
              <div className="relative-box">
                <input
                  disabled
                  type="text"
                  className="form-control"
                  name="floorName"
                  value={formik.values.floorName}
                />
              </div>
            </div>
            <div className="form-group">
              <label className="select-type-ref">
                <span className="type-label">
                  Select Area Type<span className="error-mark">*</span>
                </span>
                <span className="important-tooltip">
                  Why this is important?{" "}
                  <Tooltip title={Area_Type_Tooltip} arrow>
                    <i className="icon-information"></i>
                  </Tooltip>
                </span>
              </label>
              <select
                className="form-control"
                name="areaType"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.areaType}
              >
                <option value="">Select Area Type</option>
                {AREA_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>
                Add Label/Tag
                <span className="error-mark">*</span>
              </label>
              <div className="relative-box">
                <input
                  type="text"
                  className="form-control"
                  name="tag"
                  placeholder="Add Label/Tag"
                  onChange={formik.handleChange}
                  //(e) => {
                  //   formik.setFieldValue("tag", e.target.value.trim());
                  // }
                  onBlur={formik.handleBlur}
                  value={formik.values.tag}
                />
              </div>
              {formik.errors.tag && formik.touched.tag && (
                <div className="form-error">{formik.errors.tag}</div>
              )}
            </div>
            <div className="relative-box">
              <label>Floor Plan Name:</label>{" "}
              <span className="light-black pre-white-space">
                {newFloorName}
              </span>
            </div>
            <div className="button-group text-center mt-15">
              <Button
                disabled={!formik.dirty || !formik.isValid}
                type="submit"
                className="blue-btn"
                onClick={() => {
                  onSubmit(newFloorName);
                }}
              >
                {t("BUTTONS.Submit")}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
