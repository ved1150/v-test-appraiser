import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import _ from "lodash";
import { useTranslation } from "react-i18next";

import MySurvey from "./survey";
import NoDataView from "../Common/noDataView";

import { QUESTIONNAIRE, QUESTIONNAIRE_ICON } from "../Common/commonText";
import {
  getQuestionnaire,
  saveQuestionnaire,
} from "../../../../actions/questionnaireAction";

import "./questionnaire.scss";
import "survey-react/survey.css";

const Questionnaire = (props) => {
  const { t } = useTranslation();

  const [questionnaire, setQuestionnaire] = useState();
  const [questionnaireAnswer, setQuestionnaireAnswer] = useState();

  useEffect(() => {
    props.getQuestionnaire(props.jobOrderId).then((res) => {
      if (res) {
        setQuestionnaire(_.get(res, ["payload", "questionnaireQuestion"], {}));
        setQuestionnaireAnswer(
          _.get(res, ["payload", "questionnaireAnswer"], null)
        );
      }
    });
  }, []);

  const saveQuestionnaire = (data) => {
    const reqData = {
      jobOrderId: props.jobOrderId,
      questionnaireAnswer: JSON.stringify(data),
    };
    props.saveQuestionnaire(reqData).then((res) => {
      props.toggleQuestionnaire();
    });
  };

  return (
    <>
      <div className="comman-modal questionnaire-modal right-side open">
        <div className="comman-modal-main">
          <div className="side-head">
            {t("BUTTONS.Questionnaire_Form")}
            <button className="close-modal" onClick={props.toggleQuestionnaire}>
              <i className="icon-close-image"></i>
            </button>
          </div>
          <div className="comman-modal-body scroll-bar-style">
            {questionnaire ? (
              <div className="questionnaire-form">
                <MySurvey
                  questionnaire={questionnaire}
                  questionnaireAnswer={questionnaireAnswer}
                  saveQuestionnaire={saveQuestionnaire}
                />
              </div>
            ) : props?.questionnaire?.loading ? (
              <div className="no-data-found">
                <div className="box">
                  <div className="loader-spin"></div>
                </div>
              </div>
            ) : (
              <NoDataView text={QUESTIONNAIRE} icon={QUESTIONNAIRE_ICON} />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state) => {
  return {
    questionnaire: state.questionnaire,
  };
};

export default connect(mapStateToProps, {
  getQuestionnaire,
  saveQuestionnaire,
})(Questionnaire);
