import { combineReducers } from "redux";

import authReducers from "./auth";
import jobReducers from "./job";
import technicianJobReducers from "./technicianJob";
import imageReducers from "./image";
import recordingReducers from "./recordings";
import floorPlanReducers from "./floorPlans";
import notes from "./notes";
import callConfigurationReducers from "./callConfiguration";
import detailsReducers from "./details";
import jobOrderDetailsReducers from "./jobOrderDetails";
import eagleViewReducers from "./eagleView";
import attachments from "./attachments";
import uiReducers from "./ui";
import authentication from "./authentication";
import profile from "./profile";
import questionnaireReducer from "./questionnaire";
import cachedCapturedImages from "./cachedCapturedImages";
import errorPopUp from "./errorPopUp";
import whiteLabelReducer from "./whiteLabel";
import downloadFilePercentage from "./downloadFilePercentage";
import PDRReportsReducer from "./PDRReports";
import manageCardsReducer from "./manageCards";
import transactionHistoryReducer from "./transactionHistory";
import jobOrderTypesReducer from "./jobOrderTypes";
const Reducers = combineReducers({
  auth: authReducers,
  job: jobReducers,
  technicianJob: technicianJobReducers,
  image: imageReducers,
  recordings: recordingReducers,
  floorPlans: floorPlanReducers,
  notes: notes,
  callConfiguration: callConfigurationReducers,
  details: detailsReducers,
  jobOrderDetails: jobOrderDetailsReducers,
  eagleView: eagleViewReducers,
  attachments: attachments,
  ui: uiReducers,
  authentication: authentication,
  profile: profile,
  questionnaire: questionnaireReducer,
  cachedCapturedImages: cachedCapturedImages,
  errorReducer: errorPopUp,
  whiteLabel: whiteLabelReducer,
  downloadFilePercentageReducer: downloadFilePercentage,
  PDRReportsReducer: PDRReportsReducer,
  manageCards: manageCardsReducer,
  transactionHistory: transactionHistoryReducer,
  jobOrderTypes: jobOrderTypesReducer,
});

export default Reducers;
