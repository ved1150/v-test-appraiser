import * as actionTypes from "./actionTypes";
import FloorService from "../services/floorPlan";
import { StartLoading, StopLoading } from "./UIAction";

const startFetchFLoor = () => {
  return {
    type: actionTypes.FETCH_FLOOR_START,
  };
};

const successFetchFLoor = (data) => {
  return {
    type: actionTypes.FETCH_FLOOR_SUCCESS,
    payload: data,
  };
};

const errorFetchFLoor = (error) => {
  return {
    type: actionTypes.FETCH_FLOOR_ERROR,
    payload: error,
  };
};

export const fetchFloor = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchFLoor());
    return FloorService.getFloor(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchFLoor());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchFLoor(err));
        throw err;
      });
  };
};

export const fetchFloorContent = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchFLoor());
    return FloorService.getFloorContent(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchFLoor());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchFLoor(err));
      });
  };
};
export const publishJson = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchFLoor());
    return FloorService.publishJson(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchFLoor());
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchFLoor(err));
        throw err;
      });
  };
};

export const fetchZipFileStart = () => {
  return {
    type: actionTypes.FETCH_ZIP_START,
  };
};

export const fetchZipFileSuccess = (payload) => {
  return {
    type: actionTypes.FETCH_ZIP_SUCCESS,
    payload,
  };
};

export const fetchZipFileError = (payload) => {
  return {
    type: actionTypes.FETCH_ZIP_ERROR,
    payload,
  };
};

export function fetchZipFile(payload) {
  return (dispatch) => {
    dispatch(fetchZipFileStart());
    return FloorService.fetchZipFile(payload)
      .then((data) => {
        dispatch(fetchZipFileSuccess(data));
        return data;
      })
      .catch((err) => {
        dispatch(fetchZipFileError(err));
        return {};
      });
  };
}

const startAutoSaveJson = () => {
  return {
    type: actionTypes.AUTO_SAVE_START,
  };
};

const successAutoSaveJson = (data) => {
  return {
    type: actionTypes.AUTO_SAVE_SUCCESS,
    payload: data,
  };
};

const errorAutoSaveJson = (error) => {
  return {
    type: actionTypes.AUTO_SAVE_ERROR,
    payload: error,
  };
};

export const autoSaveThreeDJson = (data) => {
  return (dispatch) => {
    dispatch(startAutoSaveJson());
    return FloorService.autoSaveThreeDJson(data)
      .then((data) => {
        dispatch(successAutoSaveJson());
        return data;
      })
      .catch((err) => {
        dispatch(errorAutoSaveJson(err));
        throw err;
      });
  };
};
