import * as THREE from "three";
import _ from "lodash";
import {
  convert2DPointsFrom3D,
  getCurrentZoomFactorDevice,
  rotateXPoints,
} from "./Logic3d2d";
import { fabric } from "fabric";
import { convertJSON } from "./ConvertJSON";
import { customToast } from "../../../helpers/customToast";
import {
  AREA_TYPES,
  measurementTypes,
  TempX_TenantKey,
  threeDFloorScan,
} from "../../../constants/appConstant";
import { areaLabel, doorDirectionEnum } from "../../../constants/enums";
import { insidePoly } from "../../JobOrders/JobOrderDetails/measurementTab/Intersection";
import { PLYLoader } from "three/examples/jsm/loaders/PLYLoader";
import plyPinFile from "./pin_rotated.ply";
import { Html } from "@react-three/drei";
import {
  PARTITION_DOOR_COLOR,
  PARTITION_INSIDE_DOOR_COLOR,
  PARTITION_WINDOW_COLOR,
} from "../../JobOrders/JobOrderDetails/measurementTab/utilityTwoD";
import { generateReport } from "../../JobOrders/JobOrderDetails/measurementTab/generateReport";
import { getImageViaAxios, getSubDomainFromURL } from "../../../helpers";
import React, { useState } from "react";
export const PARTITION_COLOR = "#636262",
  THREED_DOOR_COLOR = "#FF8B5C",
  THREED_INSIDE_DOOR_COLOR = "#4D68D6",
  THREED_WINDOW_COLOR = "#D29B63";
export const DeleteRoom = (
  e,
  roomId,
  roomName,
  roomArray,
  setRoomArray,
  deletedRoom,
  setDeletedRoom,
  textArray,
  setTextArray,
  windowArray,
  setWindowArray,
  doorArray,
  setDoorArray,
  addChangesToStack,
  partitionArray,
  setPartitionArray,
  areaLabelTextArray,
  setAreaLabelTextArray,
  stairCaseArray,
  setStairCaseArray
) => {
  e.stopPropagation();
  addChangesToStack();
  let roomArrayPop =
    roomName === "partitionwall" ? _.cloneDeep(partitionArray) : roomArray;
  let deletedRoomRef = {
    deleteLabelHistory: [],
    deleteDoorHistory: [],
    room: [],
    deleteWindowHistory: [],
  };
  // Delete Area Label Start
  let existingIndex = -1;
  areaLabelTextArray.forEach((val, index) => {
    if (val.roomID == `room:${roomId}`) {
      existingIndex = index;
    }
  });
  let updateAreaLabel = Object.assign(areaLabelTextArray, []);
  if (existingIndex != -1) {
    updateAreaLabel = [
      ...updateAreaLabel.slice(0, existingIndex),
      ...updateAreaLabel.slice(existingIndex + 1),
    ];
  }
  setAreaLabelTextArray([...updateAreaLabel]);
  // Delete Area Label End

  // Delete Label Start
  let historyLabelArray = [];
  let deletedLabel = textArray.filter((val) => val.roomID === `room:${roomId}`);
  historyLabelArray = deletedLabel;
  let objTextArray = textArray.filter((val) => val.roomID !== `room:${roomId}`);
  setTimeout(() => {
    setTextArray([...objTextArray]);
  }, 100);
  deletedRoomRef.deleteLabelHistory = historyLabelArray;
  // Delete Label End

  // Delete Door Start
  let deletedDoor = [];
  let objDoorArray = [];
  let cloneDoorArray = _.cloneDeep(doorArray);
  cloneDoorArray.forEach((element, i) => {
    if (roomName === "partitionwall") {
      if (element[0].roomId === roomId || element[1].roomId === roomId) {
        deletedDoor.push(cloneDoorArray[i]);
      } else {
        objDoorArray.push(cloneDoorArray[i]);
      }
    } else if (roomName !== "partitionwall") {
      if (
        element[0].parentRoomId === roomId ||
        element[1].parentRoomId === roomId
      ) {
        deletedDoor.push(cloneDoorArray[i]);
      } else {
        objDoorArray.push(cloneDoorArray[i]);
      }
    }
  });
  setDoorArray([...objDoorArray]);
  deletedRoomRef.deleteDoorHistory = deletedDoor;
  // Delete Door End

  // Delete window Start
  let deletedWindow = [];
  let objWindowArray = [];
  for (let win of windowArray) {
    let delWin = win.filter((val) =>
      roomName === "partitionwall"
        ? val.roomId === roomId
        : val.parentRoomId === roomId
    );
    if (delWin.length > 0) {
      deletedWindow.push(delWin);
    }
    let remWin = win.filter((val) =>
      roomName === "partitionwall"
        ? val.roomId !== roomId
        : val.parentRoomId !== roomId
    );
    if (remWin.length > 0) {
      objWindowArray.push(remWin);
    }
  }
  setWindowArray([...objWindowArray]);
  deletedRoomRef.deleteWindowHistory = deletedWindow;
  // Delete window End

  // Delete all partition which is indisde room start
  let partition = _.cloneDeep(partitionArray);
  let delPartition = partition.filter((val) => val.mainRoomId === roomId);
  let remPartition = partition.filter((val) => val.mainRoomId !== roomId);
  setPartitionArray(remPartition);
  deletedRoomRef.deletePartitionHistory = delPartition;
  // Delete all partition which is indisde room end

  // Delete Staircase Start
  let historyStairCaseArray = [];
  let deletedStairCase = stairCaseArray.filter(
    (val) => val.roomID === `room:${roomId}`
  );
  historyStairCaseArray = deletedStairCase;
  let objStairCaseArray = stairCaseArray.filter(
    (val) => val.roomID !== `room:${roomId}`
  );
  setTimeout(() => {
    setStairCaseArray([...objStairCaseArray]);
  }, 100);
  deletedRoomRef.deletedStairCase = historyStairCaseArray;
  // Delete Staircase End

  deletedRoomRef.room = roomArrayPop.filter((val) => val.roomId === roomId)[0];

  setDeletedRoom([...deletedRoom, deletedRoomRef]);
  roomArrayPop = roomArrayPop.filter((val) => val.roomId !== roomId);
  roomName === "partitionwall"
    ? setPartitionArray(roomArrayPop)
    : setRoomArray(roomArrayPop);
};
export const deleteDoor = (
  doorArray,
  setDoorArray,
  windowArray,
  setWindowArray,
  deleteSelectedDoorWin,
  setDeleteSelectedDoorWin,
  addChangesToStack,
  setMarkerPointArray
) => {
  let deleteDoorDetails = deleteSelectedDoorWin.name.split("::");
  if (deleteSelectedDoorWin.isDelete) {
    addChangesToStack({
      doorArray: doorArray,
    });
    let updatedDoorArray = doorArray.filter((val, index) =>
      deleteDoorDetails[1] === "isPartitionDoor"
        ? index != deleteDoorDetails[3]
        : index != deleteDoorDetails[2]
    );
    setMarkerPointArray({ points: null, isMesh: 0 });
    setDoorArray(updatedDoorArray);
  } else if (deleteSelectedDoorWin.isDeleteWindow) {
    addChangesToStack({
      windowArray: windowArray,
    });
    let updatedWindowArray = windowArray.filter((val, index) =>
      deleteDoorDetails[1] === "partitionWindow"
        ? index != deleteDoorDetails[3]
        : index != deleteDoorDetails[2]
    );
    setMarkerPointArray({ points: null, isMesh: 0 });
    setWindowArray(updatedWindowArray);
  }
  setDeleteSelectedDoorWin({
    name: "",
    isDelete: false,
    isDeleteWindow: false,
  });
};
export const deselectSelectedRoom = (deleteRoom, setDeleteRoom) => {
  if (deleteRoom.isDelete) {
    setDeleteRoom({
      roomId: null,
      isDelete: false,
      isAdditional: null,
    });
  }
};
//p is current mouse point and vs is your room array
export const IsInside = (p, vs) => {
  let inside = false;
  for (let i = 0, j = vs?.length - 1; i < vs?.length; j = i++) {
    let xi = vs[i][0],
      yi = vs[i][1];
    let xj = vs[j][0],
      yj = vs[j][1];
    let intersect =
      yi > p.y !== yj > p.y && p.x < ((xj - xi) * (p.y - yi)) / (yj - yi) + xi;
    if (intersect) {
      inside = !inside;
    }
  }
  return inside;
};

export const FindMinDistance = (getDynamicRoomForLabel, points) => {
  let matchingRooms = [];
  for (let i = 0; i < getDynamicRoomForLabel.length; i++) {
    let minDisOfCurrent = null;
    for (let j = 0; j < getDynamicRoomForLabel[i].data.length; j++) {
      let vec = new THREE.Vector3(
        getDynamicRoomForLabel[i].data[j][0],
        getDynamicRoomForLabel[i].data[j][1],
        getDynamicRoomForLabel[i].data[j][2]
      );
      if (minDisOfCurrent == null) {
        getDynamicRoomForLabel[i].minDisc = vec.distanceTo(points);
        minDisOfCurrent = vec.distanceTo(points);
      } else if (vec.distanceTo(points) < minDisOfCurrent) {
        minDisOfCurrent = vec.distanceTo(points);
        getDynamicRoomForLabel[i].minDisc = vec.distanceTo(points);
      }
    }
    getDynamicRoomForLabel[i].index = i;
    matchingRooms.push(getDynamicRoomForLabel[i]);
  }
  return matchingRooms;
};

let selectedPartitionDetails = null,
  selectedRoomDetails = null;
export function PointerDown(
  e,
  drawLine,
  draggingLine,
  setIsDragLine,
  setSelectedPoint,
  setSelectedRoomId,
  setSelectedLineId,
  setIsDownAt,
  setBasePoints,
  addChangesToStack,
  roomArray,
  doorArray,
  windowArray,
  setSelectedLabelId,
  setSelectedTextId,
  textArray,
  partitionArray,
  setIsDragPartitionWall,
  isSelectItem,
  setParentRoomId,
  isAddPartition,
  stairCaseArray,
  selectedRoomStairCase
) {
  selectedPartitionDetails = null;
  selectedRoomDetails = null;
  e.stopPropagation();
  if (!drawLine && e?.object?.name?.includes("circle") && !isAddPartition) {
    draggingLine = true;
    selectedPartitionDetails = {
      partitionArrayIndex: e.eventObject.partitionArrayIndex,
      partitionWallIndex: e.eventObject.partitionWallIndex,
      parentRoomId: e?.eventObject?.parentroomid,
      selectedPoint: e?.object?.name,
      basePoint: e?.object?.basePoints,
    };
    selectedRoomDetails = {
      roomArrayIndex: e.eventObject.roomArrayIndex,
      roomWallIndex: e.eventObject.roomWallIndex,
      parentRoomId: e?.eventObject?.parentroomid,
      selectedPoint: e?.object?.name,
      basePoint: e?.object?.basePoints,
      selectedLineId: e?.object?.lineid,
    };
    addChangesToStack({
      isDragLine: false,
      roomArray: _.cloneDeep(roomArray),
      doorArray: _.cloneDeep(doorArray),
      windowArray: _.cloneDeep(windowArray),
      partitionArray: _.cloneDeep(partitionArray),
    });
    setIsDragLine(true);
    setSelectedRoomId(e?.object?.roomid);
    setSelectedLineId(e?.object?.lineid);
    setBasePoints(e?.object?.basePoints);
    setIsDragPartitionWall(e?.object?.isPartition);
  } else if (
    isSelectItem &&
    !drawLine &&
    e?.target?.id?.includes("labelOuterDiv")
  ) {
    addChangesToStack({
      isDragLine: false,
      roomArray: _.cloneDeep(roomArray),
      doorArray: _.cloneDeep(doorArray),
      windowArray: _.cloneDeep(windowArray),
      textArray: _.cloneDeep(textArray),
      stairCaseArray: _.cloneDeep(stairCaseArray),
    });
    setIsDragLine(true);
    setSelectedLabelId(e?.target?.attributes?.labelid?.textContent);
    setSelectedTextId(e?.target?.attributes?.textid?.textContent);
  } else if (
    isSelectItem &&
    !drawLine &&
    selectedRoomStairCase &&
    e?.target?.id?.includes("stairCase")
  ) {
    addChangesToStack({
      isDragLine: false,
      roomArray: _.cloneDeep(roomArray),
      doorArray: _.cloneDeep(doorArray),
      windowArray: _.cloneDeep(windowArray),
      textArray: _.cloneDeep(textArray),
      stairCaseArray: _.cloneDeep(stairCaseArray),
    });
    // setIsDragLine(true);
  } else {
    setSelectedPoint("");
    setSelectedRoomId(null);
    setSelectedLineId(null);
  }
}

export function PointerMove(
  e,
  drawLine,
  selectedRoomId,
  isDownAt,
  roomArray,
  selectedPoint,
  setSelectedPoint,
  setRoomArray,
  doorArray,
  windowArray,
  selectedLineId,
  setDoorArray,
  setWindowArray,
  basePoints,
  isDragPartitionWall,
  partitionArray,
  setPartitionArray,
  selectedTextId,
  textArray,
  setTextArray,
  selectedLabelId,
  setIsDownAt,
  isDragLine,
  areaLabelTextArray,
  setAreaLabelTextArray,
  setLiveLineMoveData,
  stairCaseArray,
  setStairCaseArray,
  selectedRoomStairCase
) {
  if (!isDragPartitionWall) {
    setLiveLineMoveData([e?.point?.x, e?.point?.y, e?.point?.z]);
  }
  e.stopPropagation();
  if (!drawLine && selectedRoomId !== null) {
    let dragWall = isDragPartitionWall
      ? _.cloneDeep(partitionArray)
      : _.cloneDeep(roomArray);
    if (
      isDragPartitionWall &&
      !_.isNil(selectedPartitionDetails?.parentRoomId)
    ) {
      dragWall[selectedPartitionDetails.partitionArrayIndex].points[
        selectedPartitionDetails.partitionWallIndex
      ] = [e.point.x, e.point.y, e.point.z];
      setPartitionArray(dragWall);
    } else if (!isDragPartitionWall && !_.isNil(selectedRoomDetails)) {
      dragWall[selectedRoomDetails?.roomArrayIndex].data[
        selectedRoomDetails?.roomWallIndex
      ] = [e.point.x, e.point.y, e.point.z];
      setRoomArray(dragWall);
    }
  } else if (
    isDragLine &&
    selectedTextId !== null &&
    selectedLabelId !== null
  ) {
    let variableNameClone = _.cloneDeep(textArray);
    if (selectedTextId.indexOf("arealabel") > -1) {
      variableNameClone = _.cloneDeep(areaLabelTextArray);
    }
    variableNameClone.forEach((element, index) => {
      let selectedRoomForLable = "";
      let minDis = FindMinDistance(roomArray, variableNameClone[index].points);
      let sortedEle = _.orderBy(minDis, ["minDisc"], ["asc"]);
      for (let key = 0; key < sortedEle.length; key++) {
        if (IsInside(e.point, sortedEle[key].data)) {
          selectedRoomForLable = "room:" + sortedEle[key].roomId;
          break;
        }
      }
      let conditionToBeChecked = element?.labelId?.toString();
      if (selectedTextId.indexOf("arealabel") > -1) {
        conditionToBeChecked = `arealabel${element?.labelId?.toString()}`;
      }
      if (conditionToBeChecked === selectedLabelId) {
        if (
          (isDownAt.label === 0 || new Date() - isDownAt.label > 2300) &&
          selectedRoomForLable === ""
        ) {
          customToast.error(
            threeDFloorScan.please_try_to_drag_label_inside_room_area
          );
          setIsDownAt({
            label: new Date(),
            room: 0,
            partition: 0,
            staircase: 0,
          });
        } else if (selectedRoomForLable !== "") {
          variableNameClone[index].points = [e.point.x, e.point.y, e.point.z];
          variableNameClone[index].roomID = selectedRoomForLable;
          if (selectedTextId.indexOf("arealabel") > -1) {
            setAreaLabelTextArray(variableNameClone);
          } else {
            setTextArray(variableNameClone);
          }
        }
      }
    });
  } else if (isDragLine && selectedRoomStairCase) {
    let stairCaseArrayClone = _.cloneDeep(stairCaseArray);
    stairCaseArrayClone.forEach((element, index) => {
      let selectedRoomForStairCase = "";
      let minDis = FindMinDistance(
        roomArray,
        stairCaseArrayClone[index].points
      );
      let sortedEle = _.orderBy(minDis, ["minDisc"], ["asc"]);
      for (let key = 0; key < sortedEle.length; key++) {
        if (IsInside(e.point, sortedEle[key].data)) {
          selectedRoomForStairCase = "room:" + sortedEle[key].roomId;
          break;
        }
      }
      let conditionToBeChecked = `stairCase-${element?.stairCaseId}`;
      if (conditionToBeChecked === selectedRoomStairCase) {
        if (selectedRoomForStairCase === "") {
          customToast.error(
            threeDFloorScan.please_try_to_drag_staircase_inside_room_area
          );
          setIsDownAt({
            label: 0,
            room: 0,
            partition: 0,
            staircase: new Date(),
          });
        } else if (selectedRoomForStairCase !== "") {
          stairCaseArrayClone[index].points = [e.point.x, e.point.y, e.point.z];
          stairCaseArrayClone[index].roomID = selectedRoomForStairCase;
          setStairCaseArray(stairCaseArrayClone);
        }
      }
    });
  }
}

export function PointerUp(
  e,
  drawLine,
  selectedRoomId,
  selectedLineId,
  isDownAt,
  roomArray,
  selectedPoint,
  setSelectedPoint,
  setRoomArray,
  setIsDownAt,
  setDraggedLines,
  draggedLines,
  setSelectedRoomId,
  setSelectedLineId,
  draggingLine,
  setIsDragLine,
  doorArray,
  setDoorArray,
  windowArray,
  setWindowArray,
  basePoints,
  setBasePoints,
  isDragPartitionWall,
  setIsDragPartitionWall,
  partitionArray,
  setPartitionArray,
  setSelectedTextId,
  setSelectedLabelId,
  selectedTextId,
  selectedLabelId,
  isDragLine,
  selectedRoomStairCase,
  setSelectedRoomStairCase
) {
  e.stopPropagation();
  const currentEvent = e;
  if (!drawLine && selectedRoomId !== null) {
    let dragWall = isDragPartitionWall
      ? _.cloneDeep(partitionArray)
      : _.cloneDeep(roomArray);
    if (
      isDragPartitionWall &&
      !_.isNil(selectedPartitionDetails?.parentRoomId)
    ) {
      dragWall[selectedPartitionDetails.partitionArrayIndex].points[
        selectedPartitionDetails.partitionWallIndex
      ] = [currentEvent.point.x, currentEvent.point.y, currentEvent.point.z];
      let currentTouchablePoint = selectedPartitionDetails?.selectedPoint;
      DragPartitionDoor(
        currentEvent,
        doorArray,
        setDoorArray,
        currentTouchablePoint
      );
      currentTouchablePoint = currentTouchablePoint.slice(6).split`,`;
      if (windowArray.length > 0) {
        DragWindow(
          currentEvent,
          windowArray,
          selectedLineId,
          selectedRoomId,
          selectedPartitionDetails?.basePoint,
          currentTouchablePoint,
          setWindowArray,
          true
        );
      }
      setPartitionArray(dragWall);
      setIsDragPartitionWall(false);
    } else if (!isDragPartitionWall && !_.isNil(selectedRoomDetails)) {
      dragWall[selectedRoomDetails?.roomArrayIndex].data[
        selectedRoomDetails?.roomWallIndex
      ] = [currentEvent.point.x, currentEvent.point.y, currentEvent.point.z];

      // Door Winow Drag Start
      let currentTouchablePoint = selectedRoomDetails?.selectedPoint;
      currentTouchablePoint = currentTouchablePoint.slice(6).split`,`;

      if (doorArray.length > 0) {
        DragDoor(
          currentEvent,
          doorArray,
          selectedLineId,
          selectedRoomId,
          selectedRoomDetails?.basePoint,
          currentTouchablePoint,
          setDoorArray,
          false
        );
      }
      if (windowArray.length > 0) {
        DragWindow(
          currentEvent,
          windowArray,
          selectedLineId,
          selectedRoomId,
          selectedRoomDetails?.basePoint,
          currentTouchablePoint,
          setWindowArray,
          false
        );
      }
      // Door Winow Drag End

      setRoomArray(dragWall);
    }
  }
  if (selectedTextId != null) {
    setSelectedTextId(null);
  }
  if (selectedLabelId != null) {
    setSelectedLabelId(null);
  }
  if (selectedRoomId != null) {
    setSelectedRoomId(null);
  }
  if (selectedLineId != null) {
    setSelectedLineId(null);
  }
  if (selectedPoint != "") {
    setSelectedPoint("");
  }
  draggingLine = false;
  if (isDragLine != false) {
    setIsDragLine(false);
  }
  if (isDragPartitionWall != false) {
    setIsDragPartitionWall(false);
  }
  if (!_.isNil(selectedRoomStairCase)) {
    setSelectedRoomStairCase(null);
  }
  selectedPartitionDetails = null;
  selectedRoomDetails = null;
}

export const FindNewCoordinates = (
  basePointXY,
  newLineXY,
  selectedXY,
  doorXY
) => {
  let newX =
    basePointXY[0] +
    (newLineXY.x - basePointXY[0]) *
      (Math.sqrt(
        Math.pow(basePointXY[0] - doorXY[0], 2) +
          Math.pow(basePointXY[1] - doorXY[1], 2)
      ) /
        Math.sqrt(
          Math.pow(basePointXY[0] - parseFloat(selectedXY[0]), 2) +
            Math.pow(basePointXY[1] - parseFloat(selectedXY[1]), 2)
        ));

  let newY =
    basePointXY[1] +
    (newLineXY.y - basePointXY[1]) *
      (Math.sqrt(
        Math.pow(basePointXY[0] - doorXY[0], 2) +
          Math.pow(basePointXY[1] - doorXY[1], 2)
      ) /
        Math.sqrt(
          Math.pow(basePointXY[0] - parseFloat(selectedXY[0]), 2) +
            Math.pow(basePointXY[1] - parseFloat(selectedXY[1]), 2)
        ));
  const newXY = { x: newX, y: newY };
  return newXY;
};

export const DragDoor = (
  e,
  doorArray,
  selectedLineId,
  selectedRoomId,
  basePoints,
  currentTouchablePoint,
  setDoorArray,
  isDragPartitionWall
) => {
  let newDoorArray = doorArray;
  newDoorArray.forEach((doorEl, index) => {
    if (
      !isDragPartitionWall &&
      selectedLineId === 0 &&
      (doorEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}` ||
        doorEl[0].lineId ===
          `custom-line:${selectedRoomId}${basePoints.length - 1}`)
    ) {
      let basePoint =
        doorEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}`
          ? basePoints[selectedLineId + 1]
          : basePoints[basePoints.length - 1];

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[1].points
      );

      newDoorArray[index][0].points[0] = newStartX.x;
      newDoorArray[index][0].points[1] = newStartX.y;
      newDoorArray[index][1].points[0] = newEndY.x;
      newDoorArray[index][1].points[1] = newEndY.y;
      setDoorArray(newDoorArray);
    } else if (
      !isDragPartitionWall &&
      selectedLineId === basePoints.length - 1 &&
      (doorEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}` ||
        doorEl[0].lineId ===
          `custom-line:${selectedRoomId}${selectedLineId - 1}`)
    ) {
      let basePoint =
        doorEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}`
          ? basePoints[0]
          : basePoints[selectedLineId - 1];

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[1].points
      );

      newDoorArray[index][0].points[0] = newStartX.x;
      newDoorArray[index][0].points[1] = newStartX.y;
      newDoorArray[index][1].points[0] = newEndY.x;
      newDoorArray[index][1].points[1] = newEndY.y;
      setDoorArray(newDoorArray);
    } else if (
      !isDragPartitionWall &&
      selectedLineId !== 0 &&
      selectedLineId !== basePoints.length - 1 &&
      (doorEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}` ||
        doorEl[0].lineId ===
          `custom-line:${selectedRoomId}${selectedLineId - 1}`)
    ) {
      let basePoint =
        doorEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}`
          ? basePoints[selectedLineId + 1]
          : basePoints[selectedLineId - 1];

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[1].points
      );

      newDoorArray[index][0].points[0] = newStartX.x;
      newDoorArray[index][0].points[1] = newStartX.y;
      newDoorArray[index][1].points[0] = newEndY.x;
      newDoorArray[index][1].points[1] = newEndY.y;
      setDoorArray(newDoorArray);
    } else if (
      doorEl[0].lineId === `partitionwall:${selectedRoomId}${selectedLineId}`
    ) {
      let basePoint = basePoints;

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        doorEl[1].points
      );

      newDoorArray[index][0].points[0] = newStartX.x;
      newDoorArray[index][0].points[1] = newStartX.y;
      newDoorArray[index][1].points[0] = newEndY.x;
      newDoorArray[index][1].points[1] = newEndY.y;
      setDoorArray(newDoorArray);
    }
  });
};

export const DragWindow = (
  e,
  windowArray,
  selectedLineId,
  selectedRoomId,
  basePoints,
  currentTouchablePoint,
  setWindowArray,
  isDragPartitionWall
) => {
  let newWindowArray = windowArray;
  newWindowArray.forEach((winEl, index) => {
    if (
      !isDragPartitionWall &&
      selectedLineId === 0 &&
      (winEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}` ||
        winEl[0].lineId ===
          `custom-line:${selectedRoomId}${basePoints.length - 1}`)
    ) {
      let basePoint =
        winEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}`
          ? basePoints[selectedLineId + 1]
          : basePoints[basePoints.length - 1];

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[1].points
      );

      newWindowArray[index][0].points[0] = newStartX.x;
      newWindowArray[index][0].points[1] = newStartX.y;
      newWindowArray[index][1].points[0] = newEndY.x;
      newWindowArray[index][1].points[1] = newEndY.y;
      setWindowArray(newWindowArray);
    } else if (
      !isDragPartitionWall &&
      selectedLineId === basePoints.length - 1 &&
      (winEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}` ||
        winEl[0].lineId ===
          `custom-line:${selectedRoomId}${selectedLineId - 1}`)
    ) {
      let basePoint =
        winEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}`
          ? basePoints[0]
          : basePoints[selectedLineId - 1];

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[1].points
      );

      newWindowArray[index][0].points[0] = newStartX.x;
      newWindowArray[index][0].points[1] = newStartX.y;
      newWindowArray[index][1].points[0] = newEndY.x;
      newWindowArray[index][1].points[1] = newEndY.y;
      setWindowArray(newWindowArray);
    } else if (
      !isDragPartitionWall &&
      selectedLineId !== 0 &&
      selectedLineId !== basePoints.length - 1 &&
      (winEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}` ||
        winEl[0].lineId ===
          `custom-line:${selectedRoomId}${selectedLineId - 1}`)
    ) {
      let basePoint =
        winEl[0].lineId === `custom-line:${selectedRoomId}${selectedLineId}`
          ? basePoints[selectedLineId + 1]
          : basePoints[selectedLineId - 1];

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[1].points
      );

      newWindowArray[index][0].points[0] = newStartX.x;
      newWindowArray[index][0].points[1] = newStartX.y;
      newWindowArray[index][1].points[0] = newEndY.x;
      newWindowArray[index][1].points[1] = newEndY.y;
      setWindowArray(newWindowArray);
    } else if (
      winEl[0].lineId === `partitionwall:${selectedRoomId}${selectedLineId}`
    ) {
      let basePoint = basePoints;

      let newStartX = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[0].points
      );
      let newEndY = FindNewCoordinates(
        basePoint,
        e.point,
        currentTouchablePoint,
        winEl[1].points
      );

      newWindowArray[index][0].points[0] = newStartX.x;
      newWindowArray[index][0].points[1] = newStartX.y;
      newWindowArray[index][1].points[0] = newEndY.x;
      newWindowArray[index][1].points[1] = newEndY.y;
      setWindowArray(newWindowArray);
    }
  });
};

export const findMaxRoom = (roomArray, partitionArray) => {
  let roomId = Math.max(...roomArray?.map((val) => val.roomId));
  let partitionWallId = Math.max(...partitionArray?.map((val) => val.roomId));
  if (roomId < partitionWallId) {
    return Math.max(...partitionArray.map((val) => val.roomId));
  } else {
    return Math.max(...roomArray.map((val) => val.roomId));
  }
};

export const findMaxLabelId = (textArray) => {
  return Math.max(...textArray.map((val) => val.labelId));
};

export const findMaxStairCaseId = (stairCaseArray) => {
  return Math.max(...stairCaseArray.map((val) => val.stairCaseId));
};

export const ShowFabNew = (
  roomArray,
  state,
  floorIndex,
  floorName,
  setJsonObject,
  setDrawFloorPlan,
  wallThickness,
  textArray,
  stairCaseArray
) => {
  let roomClone = _.cloneDeep(roomArray);
  roomArray.forEach((el, i) => {
    let data = [];
    let childlines = state.scene.children.filter(
      (child) =>
        child.name.split(":")[0] == "custom-line" &&
        child.name.split(":")[1] == el.roomId
    );
    let childtext = textArray.filter(
      (child) => child.roomID == "room:" + el.roomId
    );
    let textData = [];
    childtext.forEach((delement) => {
      textData.push({
        text: delement.text,
        points: rotateXPoints({
          x: delement.points?.[0],
          y: delement.points?.[1],
          z: delement.points?.[2],
        }),
      });
    });

    let childStairCase = stairCaseArray.filter(
      (child) => child.roomID == "room:" + el.roomId
    );

    let childStairCaseData = [];
    childStairCase.forEach((delement) => {
      childStairCaseData.push({
        points: rotateXPoints({
          x: delement.points?.[0],
          y: delement.points?.[1],
          z: delement.points?.[2],
        }),
        scaleX: delement?.scaleX || 1,
        scaleY: delement?.scaleY || 1,
      });
    });

    let childpartition = state.scene.children.filter((child) => {
      return child.name == "partitionwall" && child.parentroomid == el.roomId;
    });

    let partitionData = [];
    childpartition.forEach((welement) => {
      let parentPartitionId = null;
      state.scene.children
        .filter(
          (filterEl) => filterEl.name?.split("::")?.[1] == "partitionWindow"
        )
        .forEach((child, i) => {
          if (
            child.partitionlineid == welement.roomid &&
            child.parentroomid == el.roomId &&
            parentPartitionId === null
          ) {
            parentPartitionId = `${el.roomId}${child.partitionlineid}`;
          }
        });
      partitionData.push({
        childWindowId: parentPartitionId,
        points: rotateXPoints({
          x: welement.distStart.x,
          y: welement.distStart.y,
          z: welement.distStart.z,
        }),
      });
      partitionData.push({
        childWindowId: parentPartitionId,
        points: rotateXPoints({
          x: welement.distEnd.x,
          y: welement.distEnd.y,
          z: welement.distEnd.z,
        }),
      });
    });

    let partitionDoors = state.scene.children.filter(
      (child) =>
        child.name.split("::")[1] === "isPartitionDoor" &&
        child.parentroomid == el.roomId
    );

    let partitionDoorData = [];
    partitionDoors.forEach((welement) => {
      let partitionDoorStartObj = rotateXPoints({
        x: welement.distStart.x,
        y: welement.distStart.y,
        z: welement.distStart.z,
      });
      let partitionDoorEndObj = rotateXPoints({
        x: welement.distEnd.x,
        y: welement.distEnd.y,
        z: welement.distEnd.z,
      });
      partitionDoorStartObj.doorDirection = welement.doorDirection
        ? welement.doorDirection
        : doorDirectionEnum.inside;
      partitionDoorEndObj.doorDirection = welement.doorDirection
        ? welement.doorDirection
        : doorDirectionEnum.inside;
      partitionDoorData.push(partitionDoorStartObj);
      partitionDoorData.push(partitionDoorEndObj);
    });

    let partitionWindows = state.scene.children.filter(
      (child) =>
        child.name.split("::")[1] === "partitionWindow" &&
        child.parentroomid == el.roomId
    );

    let partitionWindowData = [];
    partitionWindows.forEach((winEl) => {
      let parentPartitionId = null;
      state.scene.children
        .filter((filterEl) => filterEl.name == "partitionwall")
        .forEach((child, i) => {
          if (
            child.roomid == winEl.partitionlineid &&
            child.parentroomid == el.roomId &&
            parentPartitionId === null
          ) {
            parentPartitionId = `${el.roomId}${child.roomid}`;
          }
        });
      partitionWindowData.push({
        partitionId: parentPartitionId,
        points: rotateXPoints({
          x: winEl.distStart.x,
          y: winEl.distStart.y,
          z: winEl.distStart.z,
        }),
      });
      partitionWindowData.push({
        partitionId: parentPartitionId,
        points: rotateXPoints({
          x: winEl.distEnd.x,
          y: winEl.distEnd.y,
          z: winEl.distEnd.z,
        }),
      });
    });

    childlines.forEach((element) => {
      let doorData = [],
        windowData = [];
      let childdoors = state.scene.children.filter(
        (child) =>
          child.name.split("::")[0] == "doors" &&
          child.name.split("::")[1] == element.lineid
      );
      let childwindows = state.scene.children.filter(
        (child) =>
          child.name.split("::")[0] == "windows" &&
          child.name.split("::")[1] == element.lineid
      );

      childdoors.forEach((delement) => {
        let doorDataStartObj = rotateXPoints({
          x: delement.distStart.x,
          y: delement.distStart.y,
          z: delement.distStart.z,
        });
        let doorDataEndObj = rotateXPoints({
          x: delement.distEnd.x,
          y: delement.distEnd.y,
          z: delement.distEnd.z,
        });
        doorDataStartObj.doorDirection = delement.doorDirection
          ? delement.doorDirection
          : doorDirectionEnum.inside;
        doorDataEndObj.doorDirection = delement.doorDirection
          ? delement.doorDirection
          : doorDirectionEnum.inside;
        doorData.push(doorDataStartObj);
        doorData.push(doorDataEndObj);
      });
      childwindows.forEach((welement) => {
        windowData.push(
          rotateXPoints({
            x: welement.distStart.x,
            y: welement.distStart.y,
            z: welement.distStart.z,
          })
        );
        windowData.push(
          rotateXPoints({
            x: welement.distEnd.x,
            y: welement.distEnd.y,
            z: welement.distEnd.z,
          })
        );
      });
      data.push({
        wallid: element.lineid,
        points: rotateXPoints({
          x: element.distStart.x,
          y: element.distStart.y,
          z: element.distStart.z,
        }),
        windowData,
        doorData,
        textData,
        partitionData,
        partitionDoorData,
        partitionWindowData,
        childStairCaseData,
      });
      textData = [];
      partitionData = [];
      partitionDoorData = [];
      partitionWindowData = [];
      childStairCaseData = [];
    });
    roomClone[i].data = data;
  });
  setTimeout(() => {
    let TDroomArray = [];
    let polypointsx = [];
    let polypointsy = [];
    let PointsToBeConverted = [];
    roomClone.forEach((el, i) => {
      let windowData = [];
      el.data.forEach((element) => {
        PointsToBeConverted.push(element.points);
        let textData = [];
        element.textData.forEach((element) => {
          textData.push(element.points);
        });

        let childStairCaseData = [];
        element.childStairCaseData.forEach((element) => {
          childStairCaseData.push({
            ...element.points,
            scaleX: element.scaleX,
            scaleY: element.scaleY,
          });
        });

        let partitionData = [];
        element.partitionData.forEach((partitionEl) => {
          partitionData.push(partitionEl.points);
        });

        let partitionDoorData = [];
        element.partitionDoorData.forEach((partitionEl) => {
          partitionDoorData.push(partitionEl);
        });

        let partitionWindowData = [];
        element.partitionWindowData.forEach((partitionEl) => {
          partitionWindowData.push(partitionEl.points);
        });

        windowData = [...windowData, ...element.doorData];
        windowData = [...windowData, ...element.windowData];
        windowData = [...windowData, ...textData];
        windowData = [...windowData, ...partitionData];
        windowData = [...windowData, ...partitionDoorData];
        windowData = [...windowData, ...partitionWindowData];
        windowData = [...windowData, ...childStairCaseData];
      });
      PointsToBeConverted = [...PointsToBeConverted, ...windowData];
    });
    let TdArray = convert2DPointsFrom3D(
      PointsToBeConverted,
      state.size.width,
      state.size.height
    );
    let startPosition = 0,
      startPositionleft = 0,
      doorposition = [];
    roomClone.forEach((el, i) => {
      let data = [];
      doorposition = [];
      startPositionleft = startPosition;
      el.data.forEach((element) => {
        data.push({
          wallid: element.wallid,
          points: TdArray.slice(startPosition, startPosition + 1),
          doorData: TdArray.slice(
            el.data.length + startPositionleft + doorposition.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length
          ),
          windowData: TdArray.slice(
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length
          ),
          textData: TdArray.slice(
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length
          ),
          partitionData: TdArray.slice(
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length
          ),
          partitionDoorData: TdArray.slice(
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length +
              element.partitionDoorData.length
          ),
          partitionWindowData: TdArray.slice(
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length +
              element.partitionDoorData.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length +
              element.partitionDoorData.length +
              element.partitionWindowData.length
          ),
          childStairCaseData: TdArray.slice(
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length +
              element.partitionDoorData.length +
              element.partitionWindowData.length,
            el.data.length +
              startPositionleft +
              doorposition.length +
              element.doorData.length +
              element.windowData.length +
              element.textData.length +
              element.partitionData.length +
              element.partitionDoorData.length +
              element.partitionWindowData.length +
              element.childStairCaseData.length
          ),
        });
        let textData = [];
        data[data.length - 1].textData.forEach((elm, j) => {
          textData.push({
            points: elm,
            text: element.textData[j].text,
          });
        });
        data[data.length - 1].textData = textData;

        let partitionData = [];
        data[data.length - 1].partitionData.forEach((elm, j) => {
          partitionData.push({
            points: elm,
            childWindowId: element.partitionData[j].childWindowId,
          });
        });
        data[data.length - 1].partitionData = partitionData;

        let partitionWindowData = [];
        data[data.length - 1].partitionWindowData.forEach((elm, j) => {
          partitionWindowData.push({
            points: elm,
            partitionId: element.partitionWindowData[j].partitionId,
          });
        });
        data[data.length - 1].partitionWindowData = partitionWindowData;

        startPosition++;
        doorposition = [
          ...doorposition,
          ...element.doorData,
          ...element.windowData,
          ...element.textData,
          ...element.partitionData,
          ...element.partitionDoorData,
          ...element.partitionWindowData,
          ...element.childStairCaseData,
        ];
      });
      TDroomArray.push({
        ...el,
        data: data,
      });
      startPosition = startPosition + doorposition.length;
    });
    TdArray.forEach((element) => {
      polypointsx.push(element.x);
      polypointsy.push(element.y);
    });
    let maxX = Math.max(...polypointsx);
    let maxY = Math.max(...polypointsy);
    let minX = Math.min(...polypointsx);
    let minY = Math.min(...polypointsy);

    minX = minX - 120;
    minY = minY - 120;

    let ratioX = 1;
    let ratioY = 1;

    let multiplierX = 1;
    if (maxX - minX < state.size.width) {
      ratioX = (state.size.width / (maxX - minX)) * multiplierX;
    } else {
      ratioX = ((maxX - minX) / state.size.width) * multiplierX;
    }

    if (maxY - minY < state.size.height) {
      ratioY = (state.size.height / (maxY - this, minY)) * multiplierX;
    } else {
      ratioY = ((maxY - minY) / state.size.height) * multiplierX;
    }

    ratioX = Math.ceil(ratioX);
    ratioY = Math.ceil(ratioY);
    let maxRatio = ratioX > ratioY ? ratioX : ratioY;

    let ratio = 1 / maxRatio;
    let floorIndexForJson = _.isEmpty(floorIndex) ? floorIndex.toString() : "4";
    let floorNameForJson = floorName.filter((el) => el.id === floorIndex);
    floorNameForJson = floorNameForJson?.[0]?.value
      ? floorNameForJson?.[0]?.value
      : AREA_TYPES[0];
    let copyOriginal = convertJSON(
      TDroomArray,
      minX,
      minY,
      ratio,
      parseFloat(
        getCurrentZoomFactorDevice(state.size.width, state.size.height)
      ),
      floorIndexForJson,
      floorNameForJson,
      wallThickness
    );
    setJsonObject(copyOriginal);
    setDrawFloorPlan(true);
  }, 100);
};

export const createDoorsAndWindows = (
  originalFloorPlan,
  minX,
  minY,
  ratio,
  roomID,
  polygonpoints
) => {
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let doors = faceArray.filter((el) => el["@type"] == "WALLPENETRATION");
  let doorArray = [];
  for (let doorindex = 0; doorindex < doors.length; doorindex++) {
    const parentwall = faceArray.filter((el) =>
      el["@children"].split(",").includes(doors[doorindex]["@id"])
    );
    const parentroom = faceArray.filter(
      (el) =>
        el["@children"].split(",").includes(parentwall[0]["@id"]) &&
        el["@id"] == roomID
    );
    if (parentroom.length > 0) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == doors[doorindex].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      let point1 = roofPointsArray
        .filter((el) => el["@id"] == pointpath[0])[0]
        ["@autoSnappedXY"].split(",");
      let point2 = roofPointsArray
        .filter((el) => el["@id"] == pointpath[1])[0]
        ["@autoSnappedXY"].split(",");
      let pointspos = [
        (point1[0] - minX) * ratio,
        (point1[1] - minY) * ratio,
        (point2[0] - minX) * ratio,
        (point2[1] - minY) * ratio,
      ];

      let line = new fabric.Line(pointspos, {
        stroke:
          doors[doorindex]["@mode"] == "DOOR"
            ? (doors[doorindex]["@doorDirection"]
                ? doors[doorindex]["@doorDirection"]
                : doorDirectionEnum.inside) == doorDirectionEnum.inside
              ? PARTITION_INSIDE_DOOR_COLOR
              : PARTITION_DOOR_COLOR
            : PARTITION_WINDOW_COLOR,
        strokeWidth: 5,
        hasControls: false,
        hasBorders: true,
        selectable: false,
        type: "DW",
        linePointObjectArray: doorline[0]["@path"],
        wallID: parentwall[0]["@id"],
        originX: "center",
        originY: "center",
        roomID: parentroom[0]["@id"],
        id: doors[doorindex]["@id"],
        unroundedsize: doors[doorindex]["POLYGON"]["@editedUnroundedsize"],
        size: doors[doorindex]["POLYGON"]["@editedSize"],
        doorDirection: doors[doorindex]["@doorDirection"]
          ? doors[doorindex]["@doorDirection"]
          : doorDirectionEnum.inside,
      });
      if (doors[doorindex]["@mode"] == "DOOR") {
        let doorShape = createDoorShapeObject(line, polygonpoints);
        doorArray.push(doorShape);
      }
      doorArray.push(line);
    }
  }
  return doorArray;
};

export const createLableForExterior = (
  originalFloorPlan,
  minX,
  minY,
  ratio,
  roomID,
  faceArrayIndex
) => {
  let labelArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  const parentwall = faceArray[faceArrayIndex];
  const childLabelNameArray = parentwall["@childrenLabel"].split(",");
  let labels = faceArray.filter(
    (el) => el["@type"] == "LABEL" && childLabelNameArray.includes(el["@id"])
  );
  for (let labelindex = 0; labelindex < labels.length; labelindex++) {
    let doorline = linesArray.filter(
      (el) => el["@id"] == labels[labelindex].POLYGON["@path"]
    );
    let pointpath = doorline[0]["@path"].split(",");
    let point = roofPointsArray
      .filter((el) => el["@id"] == pointpath[0])[0]
      ["@originalXY"].split(",");
    let RectX = (parseFloat(point[0]) - minX) * ratio;
    let RectY = (parseFloat(point[1]) - minY) * ratio;
    const textLabel = new fabric.IText(labels[labelindex]["@text"], {
      fontFamily: '"Roboto", sans-serif',
      fill: "black",
      id: labels[labelindex]["@id"],
      fontSize: 14,
      roomID: roomID,
      type: "textLabel",
      left: RectX,
      top: RectY,
      padding: 5,
      textAlign: "center",
      visible: true,
      // hasControls: false,
      lockScalingX: true,
      lockScalingY: true,
    });
    labelArray.push(textLabel);
  }
  return labelArray;
};

export const createLinesForExterior = (
  originalFloorPlan,
  minX,
  minY,
  ratio,
  roomID,
  faceArrayIndex
) => {
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let linesObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = linesObject[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  const parentwall = faceArray[faceArrayIndex];
  const childLineArray = parentwall["@childrenLine"]?.split(",");
  let lines = faceArray.filter((el) => {
    return el["@type"] == "LINE" && childLineArray.includes(el["@id"]);
  });
  let partitionArray = [];
  for (let i = 0; i < lines.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@childrenLine"] &&
        el["@childrenLine"].split(",").includes(lines[i]["@id"])
    );
    if (parentroom.length > 0) {
      let linePath = linesArray.filter(
        (el) => el["@id"] == lines[i].POLYGON["@path"]
      );
      let pointpath = linePath[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[0])[0]
          ["@originalXY"].split(",");

        let point2 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[1])[0]
          ["@originalXY"].split(",");

        const fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - minX) * ratio,
            (parseFloat(point1[1]) - minY) * ratio,
            (parseFloat(point2[0]) - minX) * ratio,
            (parseFloat(point2[1]) - minY) * ratio,
          ],
          {
            roomID: roomID,
            stroke: PARTITION_COLOR,
            type: "LINE",
            selectable: false,
            objectCaching: false,
            originX: "center",
            originY: "center",
            strokeUniform: true,
            strokeWidth: 4,
            padding: 4,
          }
        );
        // fabricLine.setCoords();
        partitionArray.push(fabricLine);
      }
    }
  }
  return partitionArray;
};

export const createDoorsForPartition = (
  originalFloorPlan,
  minX,
  minY,
  ratio,
  roomID,
  faceArrayIndex
) => {
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let linesObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = linesObject[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  const parentwall = faceArray[faceArrayIndex];
  const childLineArray = parentwall["@partitionDoor"]?.split(",");
  let lines = faceArray.filter((el) => {
    return (
      el["@type"] == "PARTITION_DOOR" && childLineArray.includes(el["@id"])
    );
  });
  let partitionDoorArray = [];
  for (let i = 0; i < lines.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@partitionDoor"] &&
        el["@partitionDoor"].split(",").includes(lines[i]["@id"])
    );
    if (parentroom.length > 0) {
      let linePath = linesArray.filter(
        (el) => el["@id"] == lines[i].POLYGON["@path"]
      );
      let pointpath = linePath[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[0])[0]
          ["@originalXY"].split(",");

        let point2 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[1])[0]
          ["@originalXY"].split(",");

        const fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - minX) * ratio,
            (parseFloat(point1[1]) - minY) * ratio,
            (parseFloat(point2[0]) - minX) * ratio,
            (parseFloat(point2[1]) - minY) * ratio,
          ],
          {
            roomID: roomID,
            stroke:
              (lines[i]["@doorDirection"]
                ? lines[i]["@doorDirection"]
                : doorDirectionEnum.inside) == doorDirectionEnum.inside
                ? PARTITION_INSIDE_DOOR_COLOR
                : PARTITION_DOOR_COLOR,
            type: "PARTITION_DOOR",
            selectable: true,
            objectCaching: false,
            originX: "center",
            originY: "center",
            strokeUniform: true,
            strokeWidth: 4,
            padding: 4,
            doorDirection: lines[i]["@doorDirection"]
              ? lines[i]["@doorDirection"]
              : doorDirectionEnum.inside,
          }
        );
        if (lines[i]["@mode"] == "PARTITION_DOOR") {
          let doorShape = createDoorShapeObject(fabricLine, faceArrayIndex);
          partitionDoorArray.push(doorShape);
        }
      }
    }
  }
  return partitionDoorArray;
};

export const AddPartition = (
  e,
  partitionArray,
  setPartitionArray,
  partitionFirstArray,
  setPartitionFirstArray,
  roomArray,
  addChangesToStack
) => {
  let mainRoomId = FindParentRoomOfPoint(e.point, roomArray);
  if (partitionFirstArray.length > 0) {
    setPartitionArray([
      ...partitionArray,
      {
        points: [
          partitionFirstArray[0].points,
          [e.point.x, e.point.y, e.point.z],
        ],
        roomId: findMaxRoom(roomArray, partitionArray) + 1,
        type: "partition",
        mainRoomId: partitionFirstArray[0].mainRoomId,
      },
    ]);
    setPartitionFirstArray([]);
    addChangesToStack({
      isDragLine: false,
      partitionArray: _.cloneDeep(partitionArray),
    });
  } else if (mainRoomId !== "") {
    setPartitionFirstArray([
      {
        mainRoomId: mainRoomId,
        points: [e.point.x, e.point.y, e.point.z],
      },
    ]);
  } else {
    customToast.error(
      threeDFloorScan.Please_try_to_edit_the_partition_inside_the_room_area_only
    );
    return;
  }
};

export const FindParentRoomOfPoint = (points, roomArray) => {
  let mainRoomId = "";
  let minDis = FindMinDistance(roomArray, points);
  let sortedEle = _.orderBy(minDis, ["minDisc"], ["asc"]);
  for (let key = 0; key < sortedEle.length; key++) {
    if (IsInside(points, sortedEle[key].data)) {
      mainRoomId = sortedEle[key].roomId;
      break;
    }
  }
  return mainRoomId;
};

export const hasIntersectWall = (x1, y1, x2, y2, x3, y3, x4, y4) => {
  let det, gamma, lambda;
  det = (x2 - x1) * (y4 - y3) - (x4 - x3) * (y2 - y1);
  if (det === 0) {
    return false;
  } else {
    lambda = ((y4 - y3) * (x4 - x1) + (x3 - x4) * (y4 - y1)) / det;
    gamma = ((y1 - y2) * (x4 - x1) + (x2 - x1) * (y4 - y1)) / det;
    return 0 < lambda && lambda < 1 && 0 < gamma && gamma < 1;
  }
};

export const MarkerPointSphere = (props) => {
  return (
    <mesh position={props.args?.points}>
      <torusGeometry args={[0.1, 0.04, 2, 200]} attach="geometry" />
      <meshBasicMaterial color={"#FFB600"} attach="material" />
    </mesh>
  );
};

export const changeAreaDetails = (
  selectedAreaType,
  selectedAreaLabel,
  setSelectedRoomType,
  setSelectedRoom,
  roomArray,
  setRoomArray,
  selectedRoomDetails,
  addChangesToStack,
  areaLabelTextArray,
  setAreaLabelTextArray,
  isSelectItem,
  textArray,
  setTextArray,
  selectedTextId
) => {
  if (selectedRoomDetails.isDelete && selectedAreaType === "Select Area Type") {
    customToast.error(threeDFloorScan.Please_Select_Area_Type);
    return;
  }
  if (selectedTextId && selectedRoomDetails.roomId == null) {
    let updatedLabel = textArray.filter(
      (val, index) => index == selectedTextId.split(":")[1].trim()
    );
    if (updatedLabel.length > 0) {
      updatedLabel[0].text = selectedAreaLabel;
      setTextArray(textArray);
    }
  }
  setSelectedRoomType(selectedAreaType);
  setSelectedRoom(selectedAreaLabel);
  selectedRoomDetails.isDelete &&
    roomArray.forEach((element) => {
      if (element.roomId === selectedRoomDetails.roomId) {
        addChangesToStack();
        element.roomname =
          selectedAreaLabel !== "Select Area Label" ? selectedAreaLabel : "";
        element.areatype = selectedAreaType;
      }
    });
  if (isSelectItem) {
    roomArray.forEach((element) => {
      if (element.roomId === selectedRoomDetails.roomId) {
        element.roomname =
          selectedAreaLabel !== "Select Area Label" ? selectedAreaLabel : "";
        element.areatype = selectedAreaType;
        let existingIndex = -1;
        areaLabelTextArray.forEach((val, index) => {
          if (val.roomID == `room:${element.roomId}`) {
            existingIndex = index;
          }
        });
        let updateAreaLabel = Object.assign(areaLabelTextArray, []);
        if (existingIndex != -1) {
          updateAreaLabel = [
            ...updateAreaLabel.slice(0, existingIndex),
            ...updateAreaLabel.slice(existingIndex + 1),
          ];
        }
        if (selectedAreaLabel !== "Select Area Label") {
          let areaLabelCoords = {
            x:
              (Math.min(...element.data.map((val) => val[0])) +
                Math.max(...element.data.map((val) => val[0]))) /
              2,
            y:
              (Math.min(...element.data.map((val) => val[1])) +
                Math.max(...element.data.map((val) => val[1]))) /
              2,
            z:
              (Math.min(...element.data.map((val) => val[2])) +
                Math.max(...element.data.map((val) => val[2]))) /
              2,
          };
          setAreaLabelTextArray([
            ...updateAreaLabel,
            {
              points: [areaLabelCoords.x, areaLabelCoords.y, areaLabelCoords.z],
              roomID: `room:${selectedRoomDetails.roomId}`,
              labelId:
                areaLabelTextArray && areaLabelTextArray.length > 0
                  ? findMaxLabelId(areaLabelTextArray) + 1
                  : 0,
              text: selectedAreaLabel,
            },
          ]);
        } else {
          setAreaLabelTextArray([...updateAreaLabel]);
        }
      }
    });
  }
  setRoomArray(roomArray);
};

export const resetAreaDetails = (
  Select_Area_Type,
  setSelectedRoomType,
  setSelectedRoom
) => {
  setSelectedRoomType(Select_Area_Type);
  setSelectedRoom(areaLabel?.[0]?.value);
};

// Calculate intersection in one dimension/component
function isPositive(c1, c2, c3, c4) {
  // find left endpoints
  let cl1 = Math.min(c1, c2);
  let cl2 = Math.min(c3, c4);

  // find right endpoints
  let cr1 = Math.max(c1, c2);
  let cr2 = Math.max(c3, c4);

  // find endpoints of intersection
  let c_inter_l = Math.max(cl1, cl2);
  let c_inter_r = Math.min(cr1, cr2);

  // calcuate intersection
  let c_inter = c_inter_r - c_inter_l;
  c_inter = Math.max(c_inter, 0);

  return c_inter;
}

function calcIsInsideLineSegment(line1, line2, pnt) {
  let L2 =
    (line2.x - line1.x) * (line2.x - line1.x) +
    (line2.y - line1.y) * (line2.y - line1.y);
  if (L2 === 0) {
    return false;
  }
  let r =
    ((pnt.x - line1.x) * (line2.x - line1.x) +
      (pnt.y - line1.y) * (line2.y - line1.y)) /
    L2;
  return 0 <= r && r <= 1;
}

export const isIntersectDoor = (
  currentDoorPoint1,
  currentDoorPoint2,
  otherDoorpoint1,
  otherDoorpoint2
) => {
  if (currentDoorPoint1) {
    // Find the intersection of two line segments
    let x_inter = isPositive(
      currentDoorPoint1[0],
      currentDoorPoint2.x,
      otherDoorpoint1[0],
      otherDoorpoint2[0]
    );
    let y_inter = isPositive(
      currentDoorPoint1[1],
      currentDoorPoint2.y,
      otherDoorpoint1[1],
      otherDoorpoint2[1]
    );
    return Math.sqrt(x_inter ** 2 + y_inter ** 2);
  } else {
    let otherDoorpoint1XY = { x: otherDoorpoint1[0], y: otherDoorpoint1[1] };
    let otherDoorpoint2XY = { x: otherDoorpoint2[0], y: otherDoorpoint2[1] };

    return calcIsInsideLineSegment(
      otherDoorpoint1XY,
      otherDoorpoint2XY,
      currentDoorPoint2
    );
  }
};

//This function is used to create DoorShape Object in 3D Preview
// Params needed is Line of door and polygon points of that door room
const createDoorShapeObject = (line, polygonpoints) => {
  let centerOrigin = new fabric.Point(line.x1, line.y1);
  let radians = fabric.util.degreesToRadians(90);
  let objectOrigin = new fabric.Point(line.x2, line.y2);
  let new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);
  let x1 = line.x1,
    y1 = line.y1,
    x2 = line.x2,
    y2 = line.y2;
  let polygonpointsclone = polygonpoints;
  if (line.doorDirection && line.doorDirection == doorDirectionEnum.inside) {
    if (
      !insidePoly(new fabric.Point(new_loc.x, new_loc.y), polygonpointsclone)
    ) {
      x1 = line.x2;
      y1 = line.y2;
      x2 = line.x1;
      y2 = line.y1;
      centerOrigin = new fabric.Point(x1, y1);
      radians = fabric.util.degreesToRadians(90);
      objectOrigin = new fabric.Point(x2, y2);
      new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);
    }
  } else {
    if (
      insidePoly(new fabric.Point(new_loc.x, new_loc.y), polygonpointsclone)
    ) {
      x1 = line.x2;
      y1 = line.y2;
      x2 = line.x1;
      y2 = line.y1;
      centerOrigin = new fabric.Point(x1, y1);
      radians = fabric.util.degreesToRadians(90);
      objectOrigin = new fabric.Point(x2, y2);
      new_loc = fabric.util.rotatePoint(objectOrigin, centerOrigin, radians);
    }
  }
  let doorArc = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
  let doorShape = new fabric.Path(
    `M ${x1} ${y1} L ${x2} ${y2} M ${x1} ${y1} L ${new_loc.x} ${new_loc.y} M ${x2} ${y2}, A ${doorArc}, ${doorArc}, 0 0 1 ${new_loc.x}, ${new_loc.y}`,
    {
      stroke: "black",
      strokeWidth: 1,
      fill: "transparent",
      originX: "center",
      height: line.height,
      width: line.width,
      type: "doorobject",
      selectable: false,
      id: "doorobject_" + line.id,
    }
  );
  return doorShape;
};
export const pinPoint = (scene, pinCoords) => {
  const loader = new PLYLoader();
  loader.load(plyPinFile, function (geometry) {
    const material = new THREE.MeshBasicMaterial({
      side: THREE.DoubleSide,
      depthWrite: true,
      depthTest: true,
      color: "red",
    });
    geometry.computeVertexNormals();
    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = `pinPoint`;
    scene.add(mesh);
    mesh.position.set(pinCoords[0], pinCoords[1], pinCoords[2]);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.oldposition = { x: pinCoords[0], y: pinCoords[1], z: pinCoords[2] };
  });
  return <primitive object={scene} />;
};

export const DragPartitionDoor = (
  e,
  doorArray,
  setDoorArray,
  selectedPoint
) => {
  let doorArrayClone = _.cloneDeep(doorArray);
  doorArrayClone.forEach((doorEl, doorElIndex) => {
    doorEl.forEach((doorPointsEl, doorPointsElIndex) => {
      if (selectedPoint === `circle${doorPointsEl.points?.toString()}`) {
        doorArrayClone[doorElIndex][doorPointsElIndex].points = [
          e.point.x,
          e.point.y,
          e.point.z,
        ];
      }
    });
  });
  setDoorArray(doorArrayClone);
};

export const onMeshPointerMove = (
  e,
  setMarkerPointArray,
  markerPointArray,
  visibilityMarker
) => {
  setTimeout(() => {
    setMarkerPointArray({
      points: e.pointOnLine && visibilityMarker ? e.pointOnLine : null,
      isMesh:
        !e.pointOnLine && !visibilityMarker ? markerPointArray.isMesh + 1 : 0,
    });
  }, 10);
};

export const DoorWindowStartPoint = (props) => {
  return (
    <mesh
      name={"doorWindowStartPoint"}
      renderOrder={999999999999}
      position={props.args}
    >
      <torusGeometry args={[0.1, 0.04, 2, 200]} attach="geometry" />
      <meshBasicMaterial color={"#FFC0CB"} attach="material" />
    </mesh>
  );
};

function findMidPoint(x, y) {
  let midPoint = new THREE.Vector3();
  midPoint.addVectors(x, y);
  midPoint.divideScalar(2);
  return midPoint;
}

export const CreateLabel = (props) => {
  const startingPoint = new THREE.Vector3(
    props.startingPoint.x,
    props.startingPoint.y,
    props.startingPoint.z
  );
  let dimensionText = startingPoint.distanceTo(props.endingPoint);
  let meterToFoot = dimensionText * 3.28084;
  let tempFoot = meterToFoot.toString().split(".");
  let tempInch = parseInt((meterToFoot - tempFoot?.[0]) * 12);
  dimensionText = `${tempFoot?.[0]}' ${tempInch}"`;
  let midPo = findMidPoint(props.startingPoint, props.endingPoint);
  return (
    `${tempFoot?.[0]}′ ${tempInch}` !== "0′ 0" && (
      <mesh position={midPo} text={dimensionText}>
        <Html>
          <span
            style={{ pointerEvents: "none", cursor: "none" }}
            className="measure-anchor"
          >
            <div className="measure-anchor__label">
              <div className="measure-anchor__value" readOnly={true}>
                {tempFoot?.[0]}′ {tempInch}
              </div>
            </div>
          </span>
        </Html>
      </mesh>
    )
  );
};

export const CreateStairCase = (props) => {
  const startingPoint = new THREE.Vector3(
    props.position[0],
    props.position[1],
    props.position[2]
  );
  const [isDrag, setIsDrag] = useState(false);

  const stairs = new Array(Math.round(4 * props.scaleY)).fill("");
  return (
    <>
      <Html
        transform={true}
        position={startingPoint}
        scale={[props.scaleX, props.scaleY, 1]}
        rotation={[0, 0, props.angle]}
        key={props.key}
      >
        <div
          id={`stairCase-${props.stairCaseId}`}
          style={{
            border: `${
              `stairCase-${props.stairCaseId}` ===
                props.selectedRoomStairCase?.toString() &&
              props.isSelectItem &&
              !isDrag &&
              !props.selectedStairObject.scaled
                ? "7px solid red"
                : ""
            }`,
            cursor: "move",
          }}
          onDragStart={(e) => {
            setIsDrag(true);
            props.onDrag(e, true);
          }}
          onDragOver={(e) => {
            props.onDrag(e, false);
          }}
          onDragEnd={(e) => {
            setIsDrag(false);
            props.onDrag(e, false);
          }}
          onDrag={(e) => {
            props.onDrag(e, false);
          }}
          onPointerDown={(e) => {
            props.isSelectItem &&
              props.setSelectedRoomStairCase(e.target?.closest("div")?.id);
            props.isSelectItem && props.setSelectedStairObject();
            props.isSelectItem &&
              !_.isNil(props.selectedRoomStairCase) &&
              props.pointerDown(e);
          }}
        >
          <table
            style={{
              fontFamily: "arial",
              borderCollapse: "collapse",
              width: "100%",
            }}
          >
            <tbody>
              {stairs.map(() => {
                return (
                  <tr>
                    <td
                      style={{
                        border: "2px solid #000000",
                        textAlign: "left",
                        padding: "8px",
                      }}
                    ></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Html>
    </>
  );
};

export const downloadReport = async (
  loadFloorScanJsons,
  selectedFloors2D,
  selectedFloors3D,
  setIsDownloadReport,
  setIsSendReport,
  jobOrderId,
  tenantLogoUrl,
  addressMapUrl,
  tenantDetails,
  setShowDownloadReportModal,
  setTenantLogoUrl,
  tenantLogo,
  downloadPDFFromHTML,
  jobDetails,
  action,
  sendReportTOHomeOwner
) => {
  if (action == "SEND_EMAIL") {
    setIsSendReport(true);
  } else {
    setIsDownloadReport(true);
  }
  const X_TenantKey = getSubDomainFromURL();
  const xTenant = X_TenantKey != "" ? X_TenantKey : TempX_TenantKey;
  // getImageViaAxios params - url, tokenType, tenant.
  getImageViaAxios(tenantLogo, true, xTenant).then((data) => {
    const reader = new window.FileReader();
    reader.readAsDataURL(data.data);
    reader.onload = () => {
      setTenantLogoUrl(reader.result);
      const data = {
        floorScanJsonRequest: selectedFloors3D,
        jobOrderId: jobOrderId,
        types: [measurementTypes[3].name, measurementTypes[0].name],
        format: 0,
      };
      loadFloorScanJsons(data).then(async (res) => {
        let payload = await generateReport(
          _.get(res, ["data", "floorScanJsonData"], {}),
          jobDetails,
          _.isEmpty(reader.result) ? "" : reader.result,
          jobOrderId,
          addressMapUrl,
          _.get(res, ["data", "jsonData"], {}),
          selectedFloors2D,
          tenantDetails,
          ""
        );
        let parser = new DOMParser();
        let doc = parser.parseFromString(payload, "text/html");
        let temp = new XMLSerializer().serializeToString(doc);
        if (action === "SEND_EMAIL") {
          sendReportTOHomeOwner(jobOrderId, { htmlContent: temp })
            .then((data) => {
              customToast.success("Email is sent to registered email address");
              setIsSendReport(false);
              setShowDownloadReportModal(false);
            })
            .catch((err) => {
              setIsSendReport(false);
              setShowDownloadReportModal(false);
            });
        } else {
          downloadPDFFromHTML({ htmlContent: temp })
            .then((pdfData) => {
              const downloadurl = window.URL.createObjectURL(
                new Blob([pdfData.data])
              );
              const link = document.createElement("a");
              link.href = downloadurl;
              // TODO for naming the response can have wins in headers
              link.setAttribute(
                "download",
                _.get(jobDetails, ["address"], "Inspection") + "_Report.pdf"
              ); //or any other extension
              document.body.appendChild(link);
              link.click();
              setIsDownloadReport(false);
              setShowDownloadReportModal(false);
            })
            .catch((err) => {
              setIsDownloadReport(false);
            });
        }
      });
      return reader.result;
    };
  });
};

export const captureMapViewImage = async (setAddressMapUrl, address) => {
  return new Promise(
    function (resolve, reject) {
      let location = encodeURIComponent(address);
      let canvasHeight = 640;
      let canvasWidth = 640;
      let imgurl =
        "https://maps.googleapis.com/maps/api/streetview?location=" +
        location +
        "&size=" +
        canvasWidth +
        "x" +
        canvasHeight +
        "&key=" +
        process.env.REACT_APP_GOOGLE_MAP_API_KEY;
      let xhr = new XMLHttpRequest();
      xhr.open("GET", imgurl, true);
      xhr.responseType = "blob";
      xhr.send(null);
      xhr.onload = function (response) {
        let blob = xhr.response;
        let reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onload = function () {
          let base64data = reader.result;
          setAddressMapUrl(base64data);
          resolve(true);
        }.bind(this);
      }.bind(this);
    }.bind(this)
  );
};
export const calculateRoomArea = (roomArray, setRoomArray) => {
  const newRoomArray = _.cloneDeep(roomArray);
  newRoomArray.forEach((roomArrEl, i) => {
    let COARRAY = roomArrEl.data;
    let cordinateArray = [];
    COARRAY?.forEach((element, i) => {
      if (i > 0) {
        let x1 = COARRAY[i - 1][0];
        let y1 = COARRAY[i - 1][1];
        let x2 = COARRAY[i][0];
        let y2 = COARRAY[i][1];
        cordinateArray.push(x1 * 3.28084);
        cordinateArray.push(y1 * 3.28084);
        cordinateArray.push(x2 * 3.28084);
        cordinateArray.push(y2 * 3.28084);
      }
      if (i === COARRAY.length - 1) {
        let x1 = COARRAY[i][0];
        let y1 = COARRAY[i][1];
        let x2 = COARRAY[0][0];
        let y2 = COARRAY[0][1];
        cordinateArray.push(x1 * 3.28084);
        cordinateArray.push(y1 * 3.28084);
        cordinateArray.push(x2 * 3.28084);
        cordinateArray.push(y2 * 3.28084);
      }
    });
    let areaSum = 0;
    for (
      let i = 0, cordinateArrayIndex = cordinateArray.length - 2;
      i < cordinateArrayIndex;
      i += 2
    ) {
      areaSum +=
        cordinateArray[i] * cordinateArray[i + 3] -
        cordinateArray[i + 2] * cordinateArray[i + 1];
    }
    newRoomArray[i].totalAreaOfRoom = Math.abs(areaSum / 2).toFixed(1);
    setRoomArray(newRoomArray);
  });
};

export const findCenterPoint = (pts) => {
  if (pts?.length === 3) {
    let first = pts[0],
      last = pts[pts.length - 1];
    if (first[0] !== last[0] || first[1] !== last[1]) {
      pts.push(first);
    }
    let twicearea = 0,
      x = 0,
      y = 0,
      nPts = pts.length,
      p1,
      p2,
      f;
    for (let i = 0, j = nPts - 1; i < nPts; j = i++) {
      p1 = pts[i];
      p2 = pts[j];
      f = p1[0] * p2[1] - p2[0] * p1[1];
      twicearea += f;
      x += (p1[0] + p2[0]) * f;
      y += (p1[1] + p2[1]) * f;
    }
    f = twicearea * 3;
    return [x / f, y / f, pts[0][2]];
  } else {
    let areaLabelCoords = [
      (Math.min(...pts.map((val) => val[0])) +
        Math.max(...pts.map((val) => val[0]))) /
        2,
      (Math.min(...pts.map((val) => val[1])) +
        Math.max(...pts.map((val) => val[1]))) /
        2,
      (Math.min(...pts.map((val) => val[2])) +
        Math.max(...pts.map((val) => val[2]))) /
        2,
    ];

    return areaLabelCoords;
  }
};
