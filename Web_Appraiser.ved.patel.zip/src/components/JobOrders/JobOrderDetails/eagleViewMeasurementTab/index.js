import React, { Component } from "react";
import _ from "lodash";
import NoDataEagleView from "./NoDataEagleView";
import FloorPlan from "../FloorPlan";
import ImageView from "./imageView";
import eagleViewService from "./../../../../services/eagleViewService";
import { connect, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { StartLoading, StopLoading } from "./../../../../actions/UIAction";
import EagleView2D from "./eagleView2D";
import PDFView from "./../Common/PDFView";
class EagleViewMeasurementTab extends Component {
  canvas = null;

  constructor(props) {
    super(props);
    const { dispatch } = props;
    this.startLoading = bindActionCreators(StartLoading, dispatch);
    this.stopLoading = bindActionCreators(StopLoading, dispatch);
    this.state = {
      eagleViewImages: [],
      loading: false,
      loadFixedEagleView: true,
      statusMessage: "",
    };
  }
  async componentDidMount() {
    if (!this.state.loadFixedEagleView) {
      this.setState({ loading: true });
      this.startLoading();
      eagleViewService.getImages(this.props.jobOrderId).then((res) => {
        if (res) {
          this.setState({
            eagleViewImages: _.get(res, ["data", "data"], []),
          });
          this.setState({ loading: false });
          this.stopLoading();
        }
      });
    }
  }

  render() {
    return (
      <div>
        {this.props.mesurementData &&
        !this.props.isSwitchAndLoadingTab &&
        (this.props.mesurementData.eagleViewJsonData ||
          this.props.mesurementData.eagleViewReportFileData) ? (
          <div className="imageView">
            {this.props.mesurementData.eagleViewJsonData && (
              <EagleView2D
                eagleViewJsonData={this.props.mesurementData.eagleViewJsonData}
              />
            )}
            {this.props.mesurementData.eagleViewReportFileData && (
              <PDFView
                pdfData={this.props.mesurementData.eagleViewReportFileData}
              />
            )}
          </div>
        ) : (
          <div className="imageView">
            <div className="no-data-found">
              <div className="box">
                {this.props.isSwitchAndLoadingTab ? (
                  <div className="loader-spin"></div>
                ) : (
                  <NoDataEagleView
                    createOrder={this.props.createOrder}
                    jobOrderId={this.props.jobOrderId}
                    eagleView={this.props.eagleView}
                    toggleRefreshMeasurementJson={
                      this.props.toggleRefreshMeasurementJson
                    }
                    jsondata={{}}
                  ></NoDataEagleView>
                )}
              </div>
            </div>
          </div>
        )}

        {_.size(this.state.eagleViewImages) > 0 && (
          <ImageView eagleViewImages={this.state.eagleViewImages}></ImageView>
        )}
      </div>
    );
  }
}

export default connect()(EagleViewMeasurementTab);
