import * as actionTypes from "../actions/actionTypes";

const notesState = {
  fetchNotesStart: false,
  fetchNotesSuccess: [],
  fetchNotesError: null,
};

const defaultStates = {
  ...notesState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_NOTES_START:
      return {
        ...state,
        fetchNotesStart: true,
        fetchNotesSuccess: [],
        fetchNotesError: null,
      };
    case actionTypes.FETCH_NOTES_SUCCESS:
      return {
        ...state,
        fetchNotesStart: false,
        fetchNotesSuccess: action.payload,
        fetchNotesError: null,
      };
    case actionTypes.FETCH_NOTES_ERROR:
      return {
        ...state,
        fetchNotesStart: false,
        fetchNotesSuccess: [],
        fetchNotesError: action.payload,
      };
    default:
      return state;
  }
};
