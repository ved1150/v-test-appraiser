import React, { useEffect, useState } from "react";
import _ from "lodash";

import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import NoDataView from "./../Common/noDataView";
import { RECORDINGS, RECORDINGS_ICON } from "./../Common/commonText";
import { customToast } from "./../../../../helpers/customToast";
import { RECORDING_DOWNLOAD_MESSSAGE } from "./../../../../constants/commonMessages";
import { useTranslation } from "react-i18next";
import "./recordingTab.scss";
import { useSelector } from "react-redux";

const RecordingsTab = (props) => {
  const { t } = useTranslation();
  const tableHead = [
    { key: "fileName", label: t("WEB_LABELS.File_Name") },
    {
      key: "createdOn",
      label: t("WEB_LABELS.Created_On"),
    },
    { key: "size", label: t("WEB_LABELS.File_Size") },
    { key: "action", label: "", disableSorting: true },
  ];

  const [sortBy, setSortBy] = useState("createdOn");
  const [direction, setDirection] = useState("desc");
  const [recordingsList, setRecordingsList] = useState([]);

  useEffect(() => {
    const filter = {
      direction,
      sortBy,
      jobOrderId: props.jobOrderId,
    };
    props
      .fetchRecordings(filter)
      .then((data) => {
        setRecordingsList(data);
      })
      .catch((err) => setRecordingsList([]));
  }, [direction, sortBy]);

  const handleSorting = (cellId) => {
    const isAsc = sortBy === cellId && direction === "desc";
    setDirection(isAsc ? "asc" : "desc");
    setSortBy(cellId);
  };

  const downloadRecording = (rec) => {
    window.open(rec.downloadLink, "_blank");
  };

  const fetchRecordingsStart = useSelector(
    (state) => state?.recordings?.fetchRecordingsStart
  );

  return (
    <div>
      {fetchRecordingsStart || _.size(recordingsList) === 0 ? (
        <div className="no-data-found-container">
          {fetchRecordingsStart ? (
            <div className="no-data-found">
              <div className="box">
                <div className="loader-spin"></div>
              </div>
            </div>
          ) : (
            <NoDataView
              text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.RECORDINGS")}
              icon={RECORDINGS_ICON}
            />
          )}
        </div>
      ) : (
        <div class="instruction-note">
          <b>{t("COMMON_MESSAGES.Note")}</b>
          {t("COMMON_MESSAGES.Instruction_Note")}
          <div className="racording scroll-bar-style">
            {/* <div className="download-btn text-right"><button className="blue-btn">Download All</button></div> */}
            <TableContainer>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    {tableHead.map((head, key) => (
                      <TableCell
                        key={key}
                        sortDirection={sortBy === head.key ? direction : false}
                      >
                        {head.disableSorting ? (
                          head.label
                        ) : (
                          <TableSortLabel
                            active={sortBy === head.key}
                            direction={sortBy === head.key ? direction : "asc"}
                            onClick={() => {
                              handleSorting(head.key);
                            }}
                          >
                            {head.label}
                          </TableSortLabel>
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {recordingsList?.map((d, id) => (
                    <TableRow key={id}>
                      <TableCell>{d.fileName}</TableCell>
                      <TableCell>{d.createdOn}</TableCell>
                      <TableCell>{d.fileSize}</TableCell>
                      <TableCell>
                        {d.status !== "COMPLETED" &&
                          t("BUTTONS.Available_Soon")}
                        {d.status === "COMPLETED" && (
                          <button
                            className={`download ${
                              _.get(
                                props,
                                ["recordings", "downloadRecordingStart"],
                                false
                              )
                                ? "disable-download"
                                : ""
                            }`}
                            onClick={() => downloadRecording(d)}
                            disabled={_.get(
                              props,
                              ["recordings", "downloadRecordingStart"],
                              false
                            )}
                          >
                            <i className="icon-download"></i>
                            <span>{t("BUTTONS.Download")}</span>
                          </button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </div>
      )}
    </div>
  );
};

export default RecordingsTab;
