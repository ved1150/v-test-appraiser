import bgimg from "../../../../../src/images/box-pattern.png";
import { useEffect } from "react";
import { fabric } from "fabric";
let canvas;

function EagleView2D(props) {
  useEffect(() => {
    canvas = new fabric.Canvas("measurementcanvas", {
      height: 500,
      width: 500,
      selection: false,
    });
    canvas.setBackgroundColor(
      {
        source: bgimg,
      },
      canvas.renderAll.bind(canvas)
    );
    drawPlan(props.eagleViewJsonData);
    // var xhr = new XMLHttpRequest();
    // xhr.open("GET", "/eagleView.json", true);
    // xhr.responseType = "json";
    // xhr.send(null);
    // xhr.onload = function (response) {
    //   drawPlan(response.target.response);
    // };
  }, []);
  const drawPlan = (data) => {
    let separateLines = [],
      poly = [];
    const faces = data.ThisStructure.Facets;
    const sagements = data.ThisStructure.Segments;
    const points = data.ThisStructure.Points;
    let polypointsx = [],
      polypointsy = [];
    for (let faceIndex = 0; faceIndex < faces.length; faceIndex++) {
      if (faces[faceIndex].Type == 512) {
        let ContainsSegments = [].concat(...faces[faceIndex].Contains);
        for (
          let sagementIndex = 0;
          sagementIndex < sagements.length;
          sagementIndex++
        ) {
          if (ContainsSegments.includes(sagementIndex + 1)) {
            for (let pointIndex = 0; pointIndex < points.length; pointIndex++) {
              if (sagements[sagementIndex].Contains.includes(pointIndex + 1)) {
                polypointsx.push(points[pointIndex].x);
                polypointsy.push(points[pointIndex].y);
              }
            }
          }
        }
      }
    }
    let maxX = Math.max(...polypointsx);
    let maxY = Math.max(...polypointsy);
    let minX = Math.min(...polypointsx);
    let minY = Math.min(...polypointsy);
    const mainline = new fabric.Line([minX, minY, maxX, maxY], {});
    var hRatio = canvas.width / mainline.width;
    var vRatio = canvas.height / mainline.height;

    let ratio = Math.min(hRatio, vRatio);
    for (let faceIndex = 0; faceIndex < faces.length; faceIndex++) {
      if (faces[faceIndex].Type == 512) {
        let polypoints = [];
        let ContainsSegments = [].concat(...faces[faceIndex].Contains);
        for (
          let sagementIndex = 0;
          sagementIndex < sagements.length;
          sagementIndex++
        ) {
          if (ContainsSegments.includes(sagementIndex + 1)) {
            let linepoints = [],
              pointx = [],
              pointy = [];
            for (let pointIndex = 0; pointIndex < points.length; pointIndex++) {
              if (sagements[sagementIndex].Contains.includes(pointIndex + 1)) {
                let Xnew =
                  points[pointIndex].x *
                    data.CalculatedValues.GlobalRotationMatrix[0][0] -
                  points[pointIndex].y *
                    data.CalculatedValues.GlobalRotationMatrix[1][0];
                let Ynew =
                  points[pointIndex].x *
                    data.CalculatedValues.GlobalRotationMatrix[1][0] +
                  points[pointIndex].y *
                    data.CalculatedValues.GlobalRotationMatrix[0][0];
                linepoints.push((Xnew - minX) * ratio);
                linepoints.push((Ynew - minY) * ratio);
                pointx.push((Xnew - minX) * ratio);
                pointy.push((Ynew - minY) * ratio);
                polypoints.push({
                  x: Xnew,
                  y: Ynew,
                });
              }
            }
            const line = new fabric.Line(linepoints, {
              stroke:
                sagements[sagementIndex].LineType == 3 ||
                sagements[sagementIndex].LineType == 2
                  ? "red"
                  : sagements[sagementIndex].LineType == 4
                  ? "blue"
                  : sagements[sagementIndex].LineType == 6
                  ? "green"
                  : sagements[sagementIndex].LineType == 8 ||
                    sagements[sagementIndex].LineType == 7
                  ? "orange"
                  : sagements[sagementIndex].LineType == 9
                  ? "gray"
                  : "black",
              strokeWidth:
                sagements[sagementIndex].LineType == 2 ||
                sagements[sagementIndex].LineType == 4 ||
                sagements[sagementIndex].LineType == 8 ||
                sagements[sagementIndex].LineType == 7 ||
                sagements[sagementIndex].LineType == 9
                  ? 0.5
                  : 2,
              strokeDashArray:
                sagements[sagementIndex].LineType == 4 ? [2, 2] : [],
            });
            separateLines.push(line);
            // const tempPoly = new fabric.Polygon(...polypoints);
            // let polygonCenter = tempPoly.getCenterPoint();
            let coordinateForLable = coordinateForlable(
              Math.min(...pointx),
              Math.max(...pointx),
              Math.min(...pointy),
              Math.max(...pointy),
              (Math.max(...pointx) + Math.min(...pointx)) / 2,
              (Math.max(...pointy) + Math.min(...pointy)) / 2
            );
            let width2 = Math.round(
              sagements[sagementIndex].Length * data.CalculatedValues.FtPerPixel
            );
            let text = new fabric.Text(
              width2 == 6 || width2 == 9
                ? "+" + width2.toString()
                : width2.toString(),
              {
                fontFamily: '"Roboto", sans-serif',
                fontSize: 11,
                fill:
                  sagements[sagementIndex].LineType == 3 ||
                  sagements[sagementIndex].LineType == 2
                    ? "red"
                    : sagements[sagementIndex].LineType == 4
                    ? "blue"
                    : sagements[sagementIndex].LineType == 6
                    ? "green"
                    : sagements[sagementIndex].LineType == 8 ||
                      sagements[sagementIndex].LineType == 7
                    ? "orange"
                    : sagements[sagementIndex].LineType == 9
                    ? "gray"
                    : "black",
                left: coordinateForLable.x,
                top: coordinateForLable.y,
                angle: coordinateForLable.orientation,
                objectCaching: false,
                selectable: false,
                originX: "center",
                originY: "center",
                textAlign: "center",
              }
            );
            if (width2 > 8) {
              text = getLabelPosition(
                text,
                (Math.max(...pointx) + Math.min(...pointx)) / 2,
                (Math.max(...pointy) + Math.min(...pointy)) / 2,
                coordinateForLable.orientation
              );
              text.set("flipY", true);
              poly.push(text);
            }
          }
        }
      }
    }
    let group = new fabric.Group([...separateLines, ...poly], {
      centeredRotation: true,
      hasBorders: true,
      hasControls: false,
      objectCaching: false,
      flipY: true,
    });
    canvas.setHeight(canvas.height + 50);
    canvas.setWidth(canvas.width + 50);
    group.top = canvas.height / 2 - group.height / 2;
    group.left = canvas.width / 2 - group.width / 2;
    canvas.add(group);
  };
  const getLabelPosition = (text, midPointX, midPointY, angleDeg) => {
    text.set("flipY", false);
    text.set("flipX", false);
    if (angleDeg >= -45 && angleDeg < 45) {
      text.set("left", midPointX);
      text.set("top", midPointY - 10);
    } else if (angleDeg >= 45 && angleDeg < 135) {
      text.set("left", midPointX + 10);
      text.set("top", midPointY);
    } else if (angleDeg >= 135 || angleDeg < -135) {
      text.set("left", midPointX);
      text.set("top", midPointY + 10);
      text.set("flipX", true);
    } else if (angleDeg >= -135 && angleDeg < -45) {
      text.set("left", midPointX - 10);
      text.set("top", midPointY);
    }
    return text;
  };
  const coordinateForlable = (x0, x1, y0, y1, centreX, centreY, length) => {
    let midPointX = (x0 + x1) / 2; //mid-point of line
    let midPointY = (y0 + y1) / 2;
    let distanceFromMidpoint = Math.sqrt(
      Math.pow(centreX - midPointX, 2) + Math.pow(centreY - midPointY, 2)
    );
    let lambda = 0.1;
    // let lambda = this.approximateDistanceFromLine /(distanceFromMidpoint - this.approximateDistanceFromLine);
    let lablePointX = (lambda * centreX + midPointX) / (lambda + 1);
    let lablePointY = (lambda * centreY + midPointY) / (lambda + 1);
    let orientation = Math.atan2(y1 - y0, x1 - x0) * (180.0 / Math.PI);

    return {
      x: lablePointX,
      y: lablePointY,
      orientation,
    };
  };
  return (
    <div className="inner-measurement">
      <canvas id="measurementcanvas" />
    </div>
  );
}

export default EagleView2D;
