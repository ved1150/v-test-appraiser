import _ from "lodash";
import api from "./api";
import {
  hydrateTechnicianJobOrders,
  hydrateFloorscanList,
  hydrateFloorscanDetail,
} from "../transformers/technicianJobTransformer";

export default class JobAPI {
  getTechnicianJobOrders(data) {
    const queryParams = {
      isFullRecord: false,
      pagination: {
        direction: _.isEmpty(data.direction) ? "ASC" : data.direction,
        page: data.page,
        size: data.size,
        sortBy: _.isEmpty(data.sortBy) ? "name" : data.sortBy,
      },
    };

    if (data.searchText) {
      queryParams.searchText = data.searchText;
    }

    return api.post("/joborders/floor-status", queryParams).then((res) => {
      return hydrateTechnicianJobOrders(res.data.data);
    });
  }

  getFloorScanList(data) {
    return api
      .get(`floorscan/${data.id}?direction=${data.direction}`)
      .then((res) => {
        return hydrateFloorscanList(res.data.data);
      });
  }

  updateFloorScanStatus(data) {
    return api
      .putMultipartFormData("floorscan/update-status", data)
      .then((res) => {
        return res.data;
      });
  }
  getFloorScanDetail(data) {
    return api.get(`floorscan/details/${data.id}`).then((res) => {
      return hydrateFloorscanDetail(res.data.data);
    });
  }

  updateFloorScanImageAPI(id, data) {
    return api
      .putMultipartFormData(`/floorscan/floorplan-upload/${id}`, data)
      .then((res) => {
        return res.data;
      });
  }

  plyRetry(data) {
    return api.put(`/floorscan/ply-retry/${data.floorScanID}`);
  }

  PlyRetryAfterSuccess(data) {
    return api.put(`/floorscan/ply-retry-dev/${data.floorScanID}`);
  }

  fetchFloorScanReportList(data) {
    return api.get(`/floor-scan/report-list/${data}`);
  }

  scanIsOkay(data) {
    return api.put(`/floor-scan/verify?floorScanId=${data}`);
  }

  getRequestRescanHistory(data) {
    return api.get(`/floorscan/rescan-history/${data}`);
  }
}
