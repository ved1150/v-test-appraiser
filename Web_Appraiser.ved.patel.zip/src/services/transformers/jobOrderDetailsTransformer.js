import moment from "moment";
import _ from "lodash";
import { DATE_FORMAT } from "../../constants/appConstant";
import { hydratePagination } from "./paginationTransformer";

const hydrateImage = (data) => {
  return {
    bookmarkLabel: data.bookmarkLabel,
    original: data.original,
    originalName: data.originalName,
    thumb: data.thumb,
    thumbName: data.thumbName,
    capturedImageTime: data.capturedImageTime,
    checked: false,
    callPicturesId: data.id,
    primaryPicture: data.primaryPicture,
  };
};

export const hydrateImages = (data) => data.data.map((d) => hydrateImage(d));

export const dyHydrateImageList = (data) => {
  return {
    joborder_id: data.joborder_id,
    selected_images: data.selected_images,
  };
};

export const dyHydrateImageListForDelete = (data) => {
  return {
    callPictures: [...data],
  };
};

const hydrateRecording = (data) => {
  return {
    createdOn: moment.utc(data.createdOn).local().format(DATE_FORMAT),
    downloadLink: data.downloadLink,
    fileName: data.fileName,
    fileSize: (data.fileSize / 1024).toFixed(2),
    status: data.status,
  };
};

export const hydrateRecordings = (data) =>
  data.data.map((d) => hydrateRecording(d));

export const hydrateDownloadRecording = (data) => {
  return {
    url: window.URL.createObjectURL(new Blob([data.data])),
  };
};

export const deHydrateRecordings = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    direction: data.direction.toUpperCase(),
    sortBy: data.sortBy,
  };
};

const hydrateFloorPlan = (data) => {
  return {
    floorScanId: data.floorScanId,
    zipPath: data.zipPath,
    videoPath: data.videoPath,
    plyPath: data.plyPath,
    pdfPath: data.pdfPath,
    floorPlanPath: data.floorPlanPath,
    floorPlanViewPath: data.floorPlanViewPath,
    floorIndex: data.floorIndex,
    status: data.status,
    createdAt: moment.utc(data.createdAt).local().format(DATE_FORMAT),
    technicianName: data.technicianName,
    wallThickness: data.wallThickness,
    floorScanNumber: data.floorScanNumber,
    floorPlanFailedReason: data.floorPlanFailedReason,
  };
};

export const hydrateFloorPlans = (data) => {
  const list = _.get(data, ["data", "data", "floorScanList"], []);
  return list.map((d) => hydrateFloorPlan(d));
};

export const deHydrateFloorPlans = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    direction: data.direction.toUpperCase(),
    sortBy: data.sortBy,
  };
};

const hydrateRelar = (data) => {
  return {
    apn: data.apn,
    address: data.address,
    city: data.city,
    state: data.state,
    zip: data.zip,
    beds: data.beds,
    baths: data.baths,
    size: data.size,
    price: data.price,
    distance: data.distance,
    statusDate: moment.utc(data.statusDate).local().format(DATE_FORMAT),
  };
};

export const hydrateRelars = (data) => {
  return {
    data: data.data.data.list.map((d) => hydrateRelar(d)),
    pagination: hydratePagination(_.get(data.data.data, ["page"], {})),
    status: data?.data?.data?.status,
  };
};

export const deHydrateRelars = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    direction: data.direction.toUpperCase(),
    sortBy: data.sortBy,
    relarCompsType: data.relarCompsType,
    pageNo: data.pageNo - 1,
    size: data.pageSize,
  };
};

export const deHydrateFilterRelars = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    direction: data.direction.toUpperCase(),
    sortBy: data.sortBy,
    relarCompsType: data.relarCompsType,
    pageNo: data.pageNo - 1,
    size: data.pageSize,
  };
};
const noteIcon = (name) => {
  if (name) {
    const nameArr = name.split(" ");
    const firstChar = nameArr[0].charAt(0);
    const secondChar = nameArr[1] ? nameArr[1].charAt(0) : "";
    return `${firstChar}${secondChar}`;
  } else {
    return "--";
  }
};

const hydrateNote = (data) => {
  return {
    createdAt: data.createdAt,
    formatedCreatedAT: moment.utc(data.createdAt).local().format(DATE_FORMAT),
    createdBy: data.createdBy,
    createdByName: data.createdByName,
    description: data.description,
    id: data.id,
    joborderId: data.joborderId,
    status: data.status,
    title: data.title,
    updatedAt: data.updatedAt,
    updatedBy: data.updatedBy,
    noteIcon: noteIcon(data.createdByName),
  };
};

export const hydrateNotes = (data) => data.data.data.map((d) => hydrateNote(d));

const hydrateCallparticipant = (data) => {
  return {
    email: _.get(data, "email", "") || "--",
    id: data.id,
    mobile: _.get(data, "mobile", "") || "--",
    name: _.get(data, "name", "") || "--",
  };
};
const hydrateCallparticipants = (data) =>
  data.map((d) => hydrateCallparticipant(d));

const hydrateCallDetail = (data) => {
  return {
    callEnd: data.callEnd,
    callStart: data.callStart,
    formatedCallStart: moment(data.callStart).isValid()
      ? moment.utc(data.callStart).local().format(DATE_FORMAT)
      : "--",
    formatedCallEnd: moment(data.callEnd).isValid()
      ? moment.utc(data.callEnd).local().format(DATE_FORMAT)
      : "--",
    id: data.id,
    isRecording: data.isRecording === 0 ? "No" : "Yes",
    duration:
      moment(data.callStart).isValid() && moment(data.callEnd).isValid()
        ? duration(data.callEnd, data.callStart)
        : "--",
    participants: hydrateCallparticipants(_.get(data, "participants", [])),
    collapseIn: true,
  };
};

const duration = (end, start) => {
  let endD = moment(end);
  let startD = moment(start);
  let temp = endD.diff(startD);
  return moment.utc(temp).format("HH:mm:ss");
};

export const hydrateCallDetails = (data) => {
  const list = _.get(data, ["data", "data", "list"], []);
  return list.map((d) => hydrateCallDetail(d));
};

export const hydrateDetails = (data) => {
  const res = data.data && data.data.data && data.data.data;
  return {
    assignedDate: res.assignedDate,
    formatedAssignedDate: moment
      .utc(res.assignedDate)
      .local()
      .format(DATE_FORMAT),
    assignee: res.assignee,
    assigneeEmail: res.assigneeEmail,
    inspectorName: res.inspectorName,
    inspectorEmail: res.inspectorEmail,
    id: res.id,
    orderNo: res.orderNumber || "--",
    jobOrderStatus: res.jobOrderStatus,
    propertyType: res.propertyType,
    address1: res.address1,
    address2: res.address2,
    city: res.city,
    country: res.country,
    email: res.email,
    name: res.name,
    phone: res.phone,
    state: res.state,
    address: `${res.address1}${
      !_.isEmpty(res.address2) ? `, ${res.address2}` : ""
    }, ${res.city}, ${res.state}, ${res.country}.`,
    propertyZip: res.propertyZip,
    jobOrderType: res.jobOrderType,
    jobOrderSource: res.jobOrderSource,
    isDemoJobOrder: res.demoJobOrder,
    paymentStatus: res.paymentStatus,
    latestScanCreatedDate: res.latestScanCreatedDate
      ? moment.utc(res.latestScanCreatedDate).local().format(DATE_FORMAT)
      : null,
    primaryPictures: res.primaryPictures,
    latitude: res.latitude?.trim() || null,
    longitude: res.longitude?.trim() || null,
  };
};

const hydrateDownloadFloorPlanZip = (data) => {
  return {
    data: data.data,
  };
};

export const hydrateDownloadZip = (data) =>
  hydrateDownloadFloorPlanZip(data.data);

export const deHydrateZips = (data) => {
  return {
    jobOrderId: data.jobOrderId,
    direction: data.direction.toUpperCase(),
    sortBy: data.sortBy,
  };
};

const hydrateDownloadFloorPlanImage = (data) => {
  return {
    data: data.data,
  };
};

export const hydrateDownloadFloorPlanImages = (data) =>
  hydrateDownloadFloorPlanImage(data.data);

export const hydratePDRDetails = (data) => {
  return {
    pdrReportFileData: _.get(data, ["data", "data", "pdrReportFileData"], {}),
    pdrFileName: _.get(data, ["data", "data", "pdrFileName"], {}),
  };
};
