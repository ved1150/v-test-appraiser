import api from "./apis/api";
import {
  hydrateRelars,
  deHydrateRelars,
} from "./transformers/jobOrderDetailsTransformer";

class RelarService {
  getRelars(data) {
    return api.relars.getRelars(deHydrateRelars(data)).then(hydrateRelars);
  }
  filterRelars(data) {
    return api.relars.filterRelars(data).then(hydrateRelars);
  }
  requestRelar(data) {
    return api.relars.requestRelar(data);
  }
}

export default new RelarService();
