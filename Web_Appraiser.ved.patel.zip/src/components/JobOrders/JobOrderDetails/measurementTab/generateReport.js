import { fabric } from "fabric";
import "fabric-history";
import _ from "lodash";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import bgimg from "./../../../../images/box-pattern.png";
import { customToast } from "../../../../helpers/customToast";
import { ERROR_IN_PDF } from "../../../../constants/commonMessages";
import i18n from "i18next";
import SentryUtils from "../../../../errors/SentryUtils";
import {
  getLabelPositionOuter,
  getRoomData,
  coordinateForlable,
  insidePoly,
} from "./Intersection";
import { createTextGroup, getLocation } from "./addLineArrow";
import { robotoFont } from "../../../../styles/customFontJSPDF";
import { doorDirectionEnum } from "../../../../constants/enums";
import { AREA_TYPES } from "../../../../constants/appConstant";
import {
  calculateWallThicknessForRoom,
  EXTERIOR_BORDER_COLOR,
  GLA_BORDER_COLOR,
  lineStokeWidth,
  NON_ADDITIONAL_BORDER_COLOR,
  NON_GLA_BORDER_COLOR,
  partitionLineStokeWidth,
  PARTITION_COLOR,
  PARTITION_DOOR_COLOR,
  PARTITION_INSIDE_DOOR_COLOR,
  PARTITION_WINDOW_COLOR,
  ROOM_WALL_DOOR_COLOR,
  PARTITION_WINDOW_COLOR_BORDER,
} from "./utilityTwoD";

let jobOrderId = 0,
  designatorWiseObjectArray = {},
  roomWiseLineAndTextObjects = {},
  roomLinesGroup = [],
  roomTextGroup = [],
  ratio = 1,
  ratioX = 1,
  ratioY = 1,
  zoomlevel = 100, // this is 1 meter = 100 pixels , based on ios auto conversation.
  originalFloorPlan = null,
  updatedFloorPlan = null,
  roomArray = [],
  roomWiseFontSize = {},
  canvas = null,
  maxX = 0,
  maxY = 0,
  minX = null,
  minY = null,
  canvasWidth = 600,
  canvasHeight = 578,
  selectedFloor = 0,
  baseFontSize = 14,
  wallThickness = 6,
  canvasCursorLayer = null,
  jobDetails = null,
  tenantLogo = null,
  mapImage = null,
  tenantDetails = null,
  appraiserDetails = null;
const stairCasePath =
  "M0 0 50 0 50 100 0 100ZM0 10 50 10M0 20 50 20M0 30 50 30M0 40 50 40M0 50 50 50M0 60 50 60M0 70 50 70M0 80 50 80M0 90 50 90";
export async function generateReport(
  json,
  details,
  _tenantLogo,
  _jobOrderId,
  _mapImage,
  remoteValJson,
  selectedFloors2D,
  _tenantDetails,
  _appraiserDetails
) {
  jobDetails = details;
  jobOrderId = _jobOrderId;
  tenantLogo = _tenantLogo;
  mapImage = _mapImage;
  tenantDetails = _tenantDetails;
  appraiserDetails = _appraiserDetails;
  canvasCursorLayer = document.createElement("canvas");
  canvasCursorLayer.id = "CursorLayer";
  canvas = new fabric.Canvas("CursorLayer", {
    selection: false,
  });
  fabric.Canvas.prototype.getItemByAttr = function (attr, name) {
    let object = null,
      objects = this.getObjects();
    for (let i = 0, len = this.size(); i < len; i++) {
      if (objects[i][attr] && objects[i][attr] === name) {
        object = objects[i];
        break;
      }
    }
    return object;
  };

  let htmlData = [];
  for (let i = 0; i < selectedFloors2D.length; i++) {
    maxX = 0;
    maxY = 0;
    minX = null;
    minY = null;
    originalFloorPlan = _.cloneDeep(remoteValJson);
    updatedFloorPlan = _.cloneDeep(remoteValJson);
    const data = await showTheListFromJsonRoomWise(
      updatedFloorPlan,
      selectedFloors2D[i].floorName,
      selectedFloors2D[i].floorId
    );
    if (data.imgDetails.length > 0 && !_.isEmpty(data.areaDetails)) {
      htmlData.push(data);
    }
  }
  for (let i = 0; i < json?.length; i++) {
    for (let j = 0; j < json[i].floorScanJsonList.length; j++) {
      maxX = 0;
      maxY = 0;
      minX = null;
      minY = null;
      originalFloorPlan = _.cloneDeep(
        json[i].floorScanJsonList[j].floorJsonData
      );
      updatedFloorPlan = _.cloneDeep(
        json[i].floorScanJsonList[j].floorJsonData
      );
      const data = await showTheListFromJsonRoomWise(
        updatedFloorPlan,
        json[i].floorScanJsonList[j].tagName
      );
      if (data.imgDetails.length > 0 && !_.isEmpty(data.areaDetails)) {
        htmlData.push(data);
      }
    }
  }
  let totalAreaDetails = getTotalAreaDetailsOfRooms(htmlData);
  return await prepareHTML(htmlData, totalAreaDetails);
}
function getTotalAreaDetailsOfRooms(htmlData) {
  let areaObject = {};
  for (let i = 0; i < htmlData.length; i++) {
    if (!_.isEmpty(htmlData[i].areaDetails)) {
      areaObject.totalGLA = (
        parseFloat(areaObject.totalGLA || 0) +
        parseFloat(htmlData[i].areaDetails.totalGLA)
      ).toFixed(2);
      areaObject.totalNonGLA = (
        parseFloat(areaObject.totalNonGLA || 0) +
        parseFloat(htmlData[i].areaDetails.totalNonGLA)
      ).toFixed(2);
      areaObject.totalArea = (
        parseFloat(areaObject.totalArea || 0) +
        parseFloat(htmlData[i].areaDetails.totalArea)
      ).toFixed(2);
      areaObject.totalWallsThickness = (
        parseFloat(areaObject.totalWallsThickness || 0) +
        parseFloat(htmlData[i].areaDetails.totalWallsThickness)
      ).toFixed(2);
      areaObject.totalRoomsArea = (
        parseFloat(areaObject.totalRoomsArea || 0) +
        parseFloat(htmlData[i].areaDetails.totalRoomsArea)
      ).toFixed(2);
      areaObject.totalHeight = (
        parseFloat(areaObject.totalHeight || 0) +
        parseFloat(htmlData[i].areaDetails.totalHeight)
      ).toFixed(2);
    }
  }
  return areaObject;
}
async function showTheListFromJsonRoomWise(
  json,
  tagName,
  selectedFloor2D = null
) {
  let jsonObject = json;
  let floorArray = [];
  try {
    if (jsonObject && jsonObject.EAGLEVIEW_EXPORT.STRUCTURES != null) {
      var roofPoints = jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
      if (!roofPoints[0] || !roofPoints[0]["@autoSnappedXY"]) {
        return { imgDetails: [], areaDetails: {} };
      } else {
        var dataStructure = _.get(
          jsonObject,
          ["EAGLEVIEW_EXPORT", "STRUCTURES"],
          {}
        );
        wallThickness = _.get(dataStructure, ["@exteriorWallThickness"], 6);
        var roofObject = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
        var roofPoints = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];

        var roofPointsArray = roofPoints[0]["POINT"];

        var lines = [jsonObject.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
        var linesArray = lines[0].LINE;

        var faceArray = roofObject[0]["FACES"]["FACE"];

        designatorWiseObjectArray = {};

        let roomChildrenArray = [];

        for (
          let faceArrayIndex = 0;
          faceArrayIndex < faceArray.length;
          faceArrayIndex++
        ) {
          let roomFaceObject = faceArray[faceArrayIndex];
          if (
            designatorWiseObjectArray[roomFaceObject["@id"]] == null &&
            roomFaceObject["@type"] == "ROOM" &&
            (roomFaceObject["@floorindex"] == selectedFloor2D ||
              !selectedFloor2D)
          ) {
            roomChildrenArray = [];
            designatorWiseObjectArray[roomFaceObject["@id"]] = [];
            designatorWiseObjectArray[roomFaceObject["@id"]].push(
              roomFaceObject
            );
            let children = roomFaceObject["@children"];
            roomChildrenArray = children.split(",");
            for (
              let roomChildrenIndex = 0;
              roomChildrenIndex < roomChildrenArray.length;
              roomChildrenIndex++
            ) {
              let roomId = roomChildrenArray[roomChildrenIndex];
              for (
                let wallFaceObjectIndex = 0;
                wallFaceObjectIndex < faceArray.length;
                wallFaceObjectIndex++
              ) {
                let faceObject = faceArray[wallFaceObjectIndex];
                if (
                  faceObject["POLYGON"]["@path"].trim().length > 0 &&
                  roomId == faceObject["@id"]
                ) {
                  var lineId = faceObject["POLYGON"]["@path"];
                  for (
                    let lineArrayIndex = 0;
                    lineArrayIndex < linesArray.length;
                    lineArrayIndex++
                  ) {
                    let lineObject = linesArray[lineArrayIndex];
                    if (lineObject["@id"] == lineId) {
                      let linePointObjectArray = [];
                      var linePoints = lineObject["@path"].split(",");
                      for (
                        var linePointsIndex = 0;
                        linePointsIndex < linePoints.length;
                        linePointsIndex++
                      ) {
                        for (
                          let roofPointsArrayIndex = 0;
                          roofPointsArrayIndex < roofPointsArray.length;
                          roofPointsArrayIndex++
                        ) {
                          let roofPointObject =
                            roofPointsArray[roofPointsArrayIndex];
                          if (
                            roofPointObject["@id"] ==
                            linePoints[linePointsIndex]
                          ) {
                            linePointObjectArray.push(roofPointObject);

                            break;
                          }
                        }
                      }
                      lineObject["linePointObjectArray"] = linePointObjectArray;
                      linesArray[lineArrayIndex] = lineObject;
                      faceObject["LINE"] = lineObject;
                      faceArray[wallFaceObjectIndex] = faceObject;
                    }
                  }
                  designatorWiseObjectArray[roomFaceObject["@id"]].push(
                    faceObject
                  );
                }
              }
            }
          } else {
            //TBD. NOT IN USE.
          }
        }
        canvas.viewportTransform[4] = 0;
        canvas.viewportTransform[5] = 0;
        canvas.isDrawingMode = false;
        canvas.freeDrawingBrush.width = 5;
        canvas.freeDrawingBrush.color = "red";
        roomArray = Object.keys(designatorWiseObjectArray);
        for (
          let roomArrayIndex = 0;
          roomArrayIndex < roomArray.length;
          roomArrayIndex++
        ) {
          let roomObjectArray =
            designatorWiseObjectArray[roomArray[roomArrayIndex]];
          roomWiseFontSize[roomArray[roomArrayIndex]] = baseFontSize;

          for (
            let roomObjectArrayIndex = 0;
            roomObjectArrayIndex < roomObjectArray.length;
            roomObjectArrayIndex++
          ) {
            let wallObject = roomObjectArray[roomObjectArrayIndex];
            if (wallObject.LINE == null) {
              floorArray.push({
                floorId: parseInt(wallObject["@floorindex"]),
                floorName: wallObject["@floor"],
                tagName: tagName,
              });
              continue;
            }

            let linePointObjectArray = wallObject.LINE.linePointObjectArray;

            for (
              let linePointObjectArrayInedex = 0;
              linePointObjectArrayInedex < linePointObjectArray.length;
              linePointObjectArrayInedex++
            ) {
              let value1 =
                linePointObjectArray[linePointObjectArrayInedex]["@editedXY"];
              if (value1 == null) {
                break;
              }
              var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
              var v1 = value1.split(",");
              var fval = { id: id, x: v1[0], y: v1[1], z: 0 };

              if (parseFloat(v1[0]) > maxX) {
                maxX = parseFloat(v1[0]);
              }

              if (parseFloat(v1[1]) > maxY) {
                maxY = parseFloat(v1[1]);
              }

              if (minX == null) {
                minX = maxX;
              }
              if (minY == null) {
                minY = maxY;
              }

              if (parseFloat(v1[0]) < minX) {
                minX = parseFloat(v1[0]);
              }

              if (parseFloat(v1[1]) < minY) {
                minY = parseFloat(v1[1]);
              }
            }
          }
        }

        minX = minX - 120;
        minY = minY - 120;
        canvas.setHeight(canvasHeight + 50);
        canvas.setWidth(canvasWidth + 50);

        ratioX = 1;
        ratioY = 1;

        let multiplierX = 1;
        if (maxX - minX < canvasWidth) {
          ratioX = (canvasWidth / (maxX - minX)) * multiplierX;
        } else {
          ratioX = ((maxX - minX) / canvasWidth) * multiplierX;
        }

        if (maxY - minY < canvasHeight) {
          ratioY = (canvasHeight / (maxY - this, minY)) * multiplierX;
        } else {
          ratioY = ((maxY - minY) / canvasHeight) * multiplierX;
        }

        ratioX = Math.ceil(ratioX);
        ratioY = Math.ceil(ratioY);

        let maxRatio = ratioX > ratioY ? ratioX : ratioY;

        ratio = 1 / maxRatio;
        // ratio = 1 ;
        const mainline = new fabric.Line([minX, minY, maxX, maxY], {});
        let hRatio = canvas.width / mainline.width;
        let vRatio = canvas.height / mainline.height;
        ratio = Math.min(hRatio, vRatio);
        zoomlevel =
          _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"]) &&
          !_.isNaN(
            _.parseInt(
              _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"])
            )
          )
            ? _.get(json, ["EAGLEVIEW_EXPORT", "STRUCTURES", "zoomFactor"])
            : zoomlevel;

        floorArray = _.uniq(floorArray);
        floorArray = _.uniqBy(floorArray, "floorId");

        floorArray = _.sortBy(floorArray, ["floorId"]);
        canvas.setHeight(canvasHeight);
        canvas.setWidth(canvasWidth);
        let imgDetails = [];
        let areaDetails = {};
        for (let i = 0; i < floorArray.length; i++) {
          selectedFloor = floorArray[i]["floorId"];
          drawFloorPlan(tagName);
          canvas.renderAll();
          await timer(200);
          imgDetails.push({
            image: downloadImage(),
            area: getAreaDetails(
              selectedFloor,
              floorArray[i]["tagName"],
              faceArray
            ),
          });
          areaDetails = getAreaDetails(undefined, undefined, faceArray);
          canvas.clear();
        }
        return { imgDetails, areaDetails };
      }
    } else {
      return { imgDetails: [], areaDetails: {} };
    }
  } catch (e) {
    SentryUtils.captureException(e);
    customToast.error(ERROR_IN_PDF);
    return false;
  }
}
const timer = (ms) => new Promise((res) => setTimeout(res, ms));
function downloadImage() {
  const dataURL = canvas.toDataURL({
    width: canvas.width,
    height: canvas.height,
    left: 0,
    top: 0,
    format: "png",
    multiplier: 2,
  });
  return dataURL;
}
function getAreaDetails(selectedFloor, floorName, faceArray) {
  let roomObjectArray = [];
  let totalGLA = 0;
  let totalHeight = 0;
  let totalNonGLA = 0;
  let totalWallsThickness = 0;
  let totalRoomsArea = 0;
  let areaObject = {};
  let totalAreaCalc = [];
  let totalGLACalc = [];
  let totalNonGLACalc = [];
  let totalRoomsAreaCalc = [];
  let totalWallsThicknessCalc = [];
  var roomArray = Object.keys(designatorWiseObjectArray);
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < roomArray.length;
    roomArrayIndex++
  ) {
    roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];
    if (
      selectedFloor &&
      roomObjectArray.filter((el) => el["@type"] == "ROOM")[0]["@floorindex"] !=
        selectedFloor
    ) {
      continue;
    }
    let doorArr = _.filter(roomObjectArray, function (n) {
      return n["@type"] == "WALLPENETRATION" && n["@mode"] == "DOOR";
    });
    roomObjectArray.doorCount = _.size(doorArr);
    let windowArr = _.filter(roomObjectArray, function (n) {
      return n["@type"] == "WALLPENETRATION" && n["@mode"] == "WINDOW";
    });
    roomObjectArray.windowCount = _.size(windowArr);
    let roomObject = _.find(roomObjectArray, (room) => room["@type"] == "ROOM");
    if (roomObject && roomObject["@additionalType"] != 1) {
      let walls = roomObject["@children"].split(",");
      const totalWallThickness = calculateWallThicknessForRoom(
        roomObject,
        faceArray,
        wallThickness
      );
      // let totalWallThickness = _.size(walls) * wallThickness;
      // totalWallThickness = totalWallThickness / 12;
      totalWallsThicknessCalc.push(totalWallThickness.toFixed(2));
      //  totalWallThickness = totalWallThickness;
      let roomArea = Number(roomObject["@editedArea"]);
      let totalMeasurement = parseFloat(
        (roomArea + totalWallThickness).toFixed(2)
      );
      totalAreaCalc.push(totalMeasurement);
      if (roomObject["@measuretype"] == "GLA") {
        totalGLA = totalGLA + totalMeasurement;
        totalGLACalc.push(totalMeasurement);
      } else if (roomObject["@measuretype"] == "Non-GLA") {
        totalNonGLA = totalNonGLA + totalMeasurement;
        totalNonGLACalc.push(totalMeasurement);
      } else {
      }
      let cheight = roomObject["@height"]
        ? parseFloat(roomObject["@height"])
        : 0;
      totalWallsThickness = totalWallsThickness + totalWallThickness;
      totalRoomsArea = totalRoomsArea + roomArea;
      totalRoomsAreaCalc.push(roomArea.toFixed(2));
      totalHeight = cheight > totalHeight ? cheight : totalHeight;
      roomObjectArray.wallCount = _.size(walls);
      roomObjectArray.totalWallThickness = totalWallThickness.toFixed(2);
      roomObjectArray.roomArea = roomArea.toFixed(2);
    }
  }
  areaObject = {
    floorName,
    totalGLA: totalGLA > 0 ? totalGLA.toFixed(2) : totalGLA.toFixed(2),
    totalNonGLA:
      totalNonGLA > 0 ? totalNonGLA.toFixed(2) : totalNonGLA.toFixed(2),
    totalArea: (totalGLA + totalNonGLA).toFixed(2),
    totalAreaCalc:
      totalGLA + totalNonGLA > 0 ? "(" + totalAreaCalc.join(" + ") + ")" : "",
    totalWallsThickness: totalWallsThickness.toFixed(2),
    totalWallsThicknessCalc:
      totalWallsThickness > 0
        ? "(" + totalWallsThicknessCalc.join(" + ") + ")"
        : "",
    totalRoomsArea: totalRoomsArea.toFixed(2),
    totalRoomsAreaCalc:
      totalRoomsArea > 0 ? "(" + totalRoomsAreaCalc.join(" + ") + ")" : "",
    totalNonGLACalc: totalNonGLACalc.join(" + "),
    totalGLACalc: totalGLA > 0 ? "(" + totalGLACalc.join(" + ") + ")" : "",
    totalNonGLACalc:
      totalNonGLA > 0 ? "(" + totalNonGLACalc.join(" + ") + ")" : "",
    totalHeight: totalHeight.toFixed(2),
  };
  return areaObject;
}

function drawFloorPlan(tagName) {
  setTimeout(() => {
    canvas.setBackgroundColor("white", canvas.renderAll.bind(canvas));
  }, 10);

  roomArray = Object.keys(designatorWiseObjectArray);

  let roomWiseLineAndTextObjectsRef = getRoomData(
    designatorWiseObjectArray,
    selectedFloor,
    minX,
    minY,
    ratio
  );
  let selectedFloorRooms = [];
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < roomArray.length;
    roomArrayIndex++
  ) {
    let roomObjectArray = designatorWiseObjectArray[roomArray[roomArrayIndex]];
    if (roomObjectArray[0]["@floorindex"] == selectedFloor) {
      selectedFloorRooms.push(roomArray[roomArrayIndex]);
    }
  }

  //Now start drawing
  let groupArray = [];
  for (
    let roomArrayIndex = 0;
    roomArrayIndex < selectedFloorRooms.length;
    roomArrayIndex++
  ) {
    var areaName = "";
    var roomArea = "";
    var roomID = "";
    var measureType = "";
    var roomFontSize = 0;
    var additionalType = "";
    let roomAreaLabelLeft = 0;
    let roomAreaLabelTop = 0;
    let roomLabelAngle = 0;

    let roomObjectArray =
      designatorWiseObjectArray[selectedFloorRooms[roomArrayIndex]];

    //if(roomLinesGroup[""])

    roomLinesGroup = [];
    roomTextGroup = [];
    let polygonpoints = [];
    var wallNo = 0;
    for (
      let roomObjectArrayIndex = 0;
      roomObjectArrayIndex < roomObjectArray.length;
      roomObjectArrayIndex++
    ) {
      let wallObject = roomObjectArray[roomObjectArrayIndex];
      let wallID = wallObject["@id"];
      if (wallObject.LINE == null) {
        additionalType = wallObject["@additionalType"];
        areaName = wallObject["@areaname"];
        roomArea = wallObject["@editedArea"];
        roomID = wallObject["@id"];
        measureType = wallObject["@measuretype"];
        roomAreaLabelLeft = wallObject["@areaLabelLeft"]
          ? (parseFloat(wallObject["@areaLabelLeft"]) - minX) * ratio
          : 0;
        roomAreaLabelTop = wallObject["@areaLabelTop"]
          ? (parseFloat(wallObject["@areaLabelTop"]) - minY) * ratio
          : 0;
        roomLabelAngle = wallObject["@labelAngle"];

        roomFontSize = roomWiseFontSize[roomID];

        roomWiseLineAndTextObjects[roomID] = {};
        roomWiseLineAndTextObjects[roomID]["roomLinesGroup"] = [];
        roomWiseLineAndTextObjects[roomID]["roomTextGroup"] = [];
        roomWiseLineAndTextObjects[roomID]["roomCircleGroup"] = [];
        roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = {};
        roomWiseLineAndTextObjects[roomID]["roomArea"] = roomArea;

        continue;
      }

      let isWallPenetration =
        wallObject["@type"] == "WALLPENETRATION" ? true : false;
      if (isWallPenetration == false) {
        //TBD
      } else {
        continue;
      }

      var linePointObjectArray = wallObject.LINE.linePointObjectArray;
      var poligonObject = wallObject.POLYGON;

      let points = [];

      for (
        let linePointObjectArrayInedex = 0;
        linePointObjectArrayInedex < linePointObjectArray.length;
        linePointObjectArrayInedex++
      ) {
        let value1 =
          linePointObjectArray[linePointObjectArrayInedex]["@autoSnappedXY"];

        if (value1 == null) {
          break;
        }
        var id = linePointObjectArray[linePointObjectArrayInedex]["@id"];
        var v1 = value1.split(",");
        var fval = { id: id, x: v1[0], y: v1[1], z: 0 };
        points.push(fval);
      }
      if (points.length < 2) {
        break;
      }

      var line = null;

      //var color = wallNo % 2 == 0 ? "#fe741f" : "black";
      var color = "black";

      polygonpoints.push({
        x: (points[0].x - minX) * ratio,
        y: (points[0].y - minY) * ratio,
      });
      polygonpoints.push({
        x: (points[1].x - minX) * ratio,
        y: (points[1].y - minY) * ratio,
      });

      line = new fabric.Line(
        [
          (points[0].x - minX) * ratio,
          (points[0].y - minY) * ratio,
          (points[1].x - minX) * ratio,
          (points[1].y - minY) * ratio,
        ],
        {
          stroke: color,
          strokeWidth: lineStokeWidth,
          selectable: false,
          evented: false,
          id: wallID,
          roomID: roomID,
          type: "WALL-LINE",
          linePointObjectArray: linePointObjectArray,
          unroundedsize: wallObject["POLYGON"]["@editedUnroundedsize"],
          size: wallObject["POLYGON"]["@editedSize"],
          areaName: areaName,
          roomArea: roomArrayIndex,
        }
      );

      roomWiseLineAndTextObjects[roomID]["roomLinesGroup"].push(line);
      roomLinesGroup.push(line);

      if (isWallPenetration == false) {
        wallNo++;
      } else {
      }
    }

    let roomCenterPointX = 0;
    let roomCenterPointY = 0;

    for (
      var roomLinesGroupArrayIndex = 0;
      roomLinesGroupArrayIndex < roomLinesGroup.length;
      roomLinesGroupArrayIndex++
    ) {
      //var color = roomLinesGroupArrayIndex % 2 == 0 ? "#fe741f" : "black";
      var color = "black";

      // Connectors

      var circle = null;
      if (roomLinesGroupArrayIndex == 0) {
        circle = makeCircle(
          roomLinesGroup[0].get("x1"),
          roomLinesGroup[0].get("y1"),
          roomLinesGroup[roomLinesGroup.length - 1],
          roomLinesGroup[0],
          color
        );

        // canvas.add(circle);
      } else {
        if (roomLinesGroupArrayIndex < roomLinesGroup.length - 1) {
          circle = makeCircle(
            roomLinesGroup[roomLinesGroupArrayIndex - 1].get("x2"),
            roomLinesGroup[roomLinesGroupArrayIndex - 1].get("y2"),
            roomLinesGroup[roomLinesGroupArrayIndex - 1],
            roomLinesGroup[roomLinesGroupArrayIndex],
            color
          );
        } else {
          circle = makeCircle(
            roomLinesGroup[roomLinesGroupArrayIndex].get("x1"),
            roomLinesGroup[roomLinesGroupArrayIndex].get("y1"),
            roomLinesGroup[roomLinesGroupArrayIndex - 1],
            roomLinesGroup[roomLinesGroupArrayIndex],
            color
          );
        }
      }
      roomCenterPointX +=
        (roomLinesGroup[roomLinesGroupArrayIndex].x1 +
          roomLinesGroup[roomLinesGroupArrayIndex].x2) /
        2;
      roomCenterPointY +=
        (roomLinesGroup[roomLinesGroupArrayIndex].y1 +
          roomLinesGroup[roomLinesGroupArrayIndex].y2) /
        2;
    }

    let totalPoints = roomLinesGroup.length;

    let areaLabelLeft = roomCenterPointX / totalPoints;
    let areaLabelTop = roomCenterPointY / totalPoints;

    var centreTextObject = null;
    if (canvas.getItemByAttr("id", roomID) != null) {
      centreTextObject = canvas.getItemByAttr("id", roomID);
      centreTextObject.set(
        "left",
        areaLabelLeft - centreTextObject.getBoundingRect().width / 2
      );

      centreTextObject.set(
        "top",
        areaLabelTop - centreTextObject.getBoundingRect().height / 2
      );
    } else {
      let displayRoomArea = "";
      if (roomArea.trim().length == 0) {
        roomArea = ".";
      } else {
        displayRoomArea = roomArea;
      }

      let roomAreaSpilts = roomArea.split(".");
      let tempCalculatedAreaInFoot =
        roomAreaSpilts && roomAreaSpilts.length > 0 ? roomAreaSpilts[0] : "";
      let tempCalculatedAreaPoints =
        roomAreaSpilts && roomAreaSpilts.length > 1 ? roomAreaSpilts[1] : "";
      let calculatedArea =
        tempCalculatedAreaInFoot != ""
          ? tempCalculatedAreaInFoot + "' " + tempCalculatedAreaPoints + "''"
          : "";

      let AreaNameLabel = "\n" + areaName;
      let centerBoxText =
        (displayRoomArea.length > 0 && !isNaN(displayRoomArea)
          ? parseFloat(displayRoomArea).toFixed(1)
          : displayRoomArea) + AreaNameLabel;
      centreTextObject = new fabric.Text(centerBoxText, {
        fontFamily: '"Roboto", sans-serif',
        fontSize: roomFontSize + 1,
        left: roomAreaLabelLeft || areaLabelLeft,
        top: roomAreaLabelTop || areaLabelTop,
        angle: roomLabelAngle || 0,
        fill: "#555555",
        id: roomID,
        objectCaching: false,
        textAlign: "center",
        selectable: false,
        textAlign: "center",
        type: "CENTRE-BOX-TEXT",
        // backgroundColor:"red",
      });

      if (!roomAreaLabelLeft) {
        centreTextObject.set(
          "left",
          areaLabelLeft - centreTextObject.getBoundingRect().width / 2
        );

        centreTextObject.set(
          "top",
          areaLabelTop - centreTextObject.getBoundingRect().height / 2
        );
      }
      roomTextGroup.push(centreTextObject);
      roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(
        centreTextObject
      );
    }
    polygonpoints = _.uniqWith(polygonpoints, _.isEqual);
    const poly = new fabric.Polygon(polygonpoints, {
      fill: "transparent",
      strokeWidth: lineStokeWidth,
      stroke:
        additionalType != "1"
          ? measureType == "GLA"
            ? GLA_BORDER_COLOR
            : NON_GLA_BORDER_COLOR
          : NON_ADDITIONAL_BORDER_COLOR,
      cornerColor: "black",
      roomID: roomID,
      ID: "POLY-" + roomID,
    });
    if (!roomAreaLabelLeft) {
      var polygonCenter = poly.getCenterPoint();
      centreTextObject.set(
        "left",
        polygonCenter.x - centreTextObject.getBoundingRect().width / 2
      );
      centreTextObject.set(
        "top",
        polygonCenter.y - centreTextObject.getBoundingRect().height / 2
      );
    }
    roomWiseLineAndTextObjects[roomID]["roomPolyGroup"] = poly;
    for (
      var roomLinesGroupArrayIndex = 0;
      roomLinesGroupArrayIndex < roomLinesGroup.length;
      roomLinesGroupArrayIndex++
    ) {
      let indexedLine = roomLinesGroup[roomLinesGroupArrayIndex];
      let wallID = indexedLine.get("id");
      let sizes = indexedLine.get("unroundedsize").split(".");
      let tempFoot = sizes && sizes.length > 0 ? sizes[0] : "";
      let tempPoints = sizes && sizes.length > 1 ? sizes[1] : "";
      let unRoundedSizeFeetLabel = tempFoot + "' " + tempPoints + "''";
      let polygonpointsclone =
        roomWiseLineAndTextObjects[indexedLine.roomID]["roomPolyGroup"];
      var coordinateForLable = coordinateForlable(
        indexedLine.x1,
        indexedLine.x2,
        indexedLine.y1,
        indexedLine.y2,
        areaLabelLeft,
        areaLabelTop
      );

      var text = new fabric.Text(unRoundedSizeFeetLabel, {
        fontFamily: '"Roboto", sans-serif',
        fontSize: 12,
        left: coordinateForLable.x,
        top: coordinateForLable.y,
        angle: coordinateForLable.orientation,
        fill: color,
        id: wallID,
        roomID: roomID,
        objectCaching: false,
        type: "LABEL",
        selectable: false,
        originX: "center",
        originY: "center",
      });
      let midPointX = (indexedLine.x1 + indexedLine.x2) / 2; //mid-point of line
      let midPointY = (indexedLine.y1 + indexedLine.y2) / 2;
      text = getLabelPositionOuter(
        text,
        midPointX,
        midPointY,
        coordinateForLable.orientation,
        polygonpointsclone,
        roomWiseLineAndTextObjectsRef,
        indexedLine
      );
      if (text) {
        if (parseFloat(indexedLine.get("unroundedsize")) > 2.5) {
          const locations = getLocation(
            text,
            indexedLine,
            midPointX,
            midPointY
          );
          const lineZ = new fabric.Line(
            [locations.x1, locations.y1, locations.x2, locations.y2],
            {
              strokeWidth: 1,
              fill: "black",
              stroke: "black",
              originX: "center",
              originY: "center",
            }
          );
          text = createTextGroup(
            lineZ,
            unRoundedSizeFeetLabel,
            text.angle,
            coordinateForLable.orientation
          );
          roomWiseLineAndTextObjects[roomID]["roomTextGroup"].push(text);
          roomTextGroup.push(text);
        }
      }
    }

    var roomDrawingObjectArray = [poly].concat(roomTextGroup);

    var group = new fabric.Group(roomDrawingObjectArray, {
      id: "GROUP-" + roomID,
      roomID: roomID,
      lockScalingX: true,
      lockScalingY: true,
      objectCaching: false,
      selectable: true,
      type: "GROUP",
      subTargetCheck: true,
      backgroundColor: "red",
      fill: "blue",
    });

    group.setControlsVisibility({
      mt: false,
      mb: false,
      ml: false,
      mr: false,
    });
    // canvas.add(group);
    // group.initialLeft = group.left;
    // group.initialTop = group.top;
    groupArray.push(group);
  }
  let lineGroupArray = createDoorsAndWindows();
  let labelGroupArray = createLableForExterior();
  let lineExteriorGroupArray = createLineForExterior();
  let partitionDoorGroupArray = createPartitionDoor();
  let partitionWindowGroupArray = createPartitionWindow();
  let stairCaseGroupArray = createStaircase();
  if (lineGroupArray.length > 0) {
    groupArray.push(...lineGroupArray);
  }
  if (labelGroupArray.length > 0) {
    groupArray.push(...labelGroupArray);
  }
  if (lineExteriorGroupArray.length > 0) {
    groupArray.push(...lineExteriorGroupArray);
  }
  if (partitionDoorGroupArray.length > 0) {
    groupArray.push(...partitionDoorGroupArray);
  }
  if (partitionWindowGroupArray.length > 0) {
    groupArray.push(...partitionWindowGroupArray);
  }
  if (stairCaseGroupArray.length > 0) {
    groupArray.push(...stairCaseGroupArray);
  }
  let groupCanvas = new fabric.Group(groupArray, {});
  canvas.setHeight(canvas.height + 100);
  canvas.setWidth(canvas.width + 100);
  groupCanvas.top = canvas.height / 2 - groupCanvas.height / 2;
  groupCanvas.left = canvas.width / 2 - groupCanvas.width / 2;
  canvas.add(groupCanvas);
  canvas.renderAll();
}
function createLineForExterior() {
  let lineExteriorGroupArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let linesViaAddLine = faceArray.filter((el) => el["@type"] == "LINE");
  for (let i = 0; i < linesViaAddLine.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@childrenLine"] &&
        el["@childrenLine"].split(",").includes(linesViaAddLine[i]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == linesViaAddLine[i].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray.filter((el) => el["@id"] == pointpath[0]);
        point1 = !_.isEmpty(point1[0]["@editedXY"])
          ? point1[0]["@editedXY"].split(",")
          : point1[0]["@dataXY"]?.split(",");

        let point2 = roofPointsArray.filter((el) => el["@id"] == pointpath[1]);
        point2 = !_.isEmpty(point2[0]["@editedXY"])
          ? point2[0]["@editedXY"].split(",")
          : point2[0]["@dataXY"]?.split(",");

        const _fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - minX) * ratio,
            (parseFloat(point1[1]) - minY) * ratio,
            (parseFloat(point2[0]) - minX) * ratio,
            (parseFloat(point2[1]) - minY) * ratio,
          ],
          {
            id: linesViaAddLine[i]["@id"],
            visible: true,
            roomID: parentroom[0]["@id"],
            objectCaching: false,
            type: "LINE",
            stroke: PARTITION_COLOR,
            originX: "center",
            originY: "center",
            selectable: true,
            strokeUniform: true,
            strokeWidth: partitionLineStokeWidth,
            padding: 4,
          }
        );
        lineExteriorGroupArray.push(_fabricLine);
      }
    }
  }
  return lineExteriorGroupArray;
}
function createPartitionDoor() {
  let lineExteriorGroupArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let linesViaAddLine = faceArray.filter(
    (el) => el["@type"] == "PARTITION_DOOR"
  );
  for (let i = 0; i < linesViaAddLine.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@partitionDoor"] &&
        el["@partitionDoor"].split(",").includes(linesViaAddLine[i]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == linesViaAddLine[i].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray.filter((el) => el["@id"] == pointpath[0]);
        point1 = !_.isEmpty(point1[0]["@editedXY"])
          ? point1[0]["@editedXY"].split(",")
          : point1[0]["@dataXY"]?.split(",");

        let point2 = roofPointsArray.filter((el) => el["@id"] == pointpath[1]);
        point2 = !_.isEmpty(point2[0]["@editedXY"])
          ? point2[0]["@editedXY"].split(",")
          : point2[0]["@dataXY"]?.split(",");

        const line = new fabric.Line(
          [
            (parseFloat(point1[0]) - minX) * ratio,
            (parseFloat(point1[1]) - minY) * ratio,
            (parseFloat(point2[0]) - minX) * ratio,
            (parseFloat(point2[1]) - minY) * ratio,
          ],
          {
            id: linesViaAddLine[i]["@id"],
            visible: true,
            roomID: parentroom[0]["@id"],
            objectCaching: false,
            type: "PARTITION_DOOR",
            stroke: PARTITION_DOOR_COLOR,
            originX: "center",
            originY: "center",
            selectable: true,
            strokeUniform: true,
            strokeWidth: partitionLineStokeWidth,
            padding: 4,
            doorDirection: linesViaAddLine[i]["@doorDirection"]
              ? linesViaAddLine[i]["@doorDirection"]
              : doorDirectionEnum.inside,
          }
        );
        let centerOrigin = new fabric.Point(line.x1, line.y1);
        let radians = fabric.util.degreesToRadians(90);
        // console.log(x,y,this.ratio,this.minX,this.minY);
        let objectOrigin = new fabric.Point(line.x2, line.y2);
        let new_loc = fabric.util.rotatePoint(
          objectOrigin,
          centerOrigin,
          radians
        );
        let x1 = line.x1,
          y1 = line.y1,
          x2 = line.x2,
          y2 = line.y2;
        let polygonpointsclone =
          roomWiseLineAndTextObjects[line.roomID]["roomPolyGroup"];
        if (
          line.doorDirection &&
          line.doorDirection == doorDirectionEnum.inside
        ) {
          if (
            !insidePoly(
              new fabric.Point(new_loc.x, new_loc.y),
              polygonpointsclone.points
            )
          ) {
            x1 = line.x2;
            y1 = line.y2;
            x2 = line.x1;
            y2 = line.y1;
            centerOrigin = new fabric.Point(x1, y1);
            radians = fabric.util.degreesToRadians(90);
            objectOrigin = new fabric.Point(x2, y2);
            new_loc = fabric.util.rotatePoint(
              objectOrigin,
              centerOrigin,
              radians
            );
          }
        } else {
          if (
            insidePoly(
              new fabric.Point(new_loc.x, new_loc.y),
              polygonpointsclone.points
            )
          ) {
            x1 = line.x2;
            y1 = line.y2;
            x2 = line.x1;
            y2 = line.y1;
            centerOrigin = new fabric.Point(x1, y1);
            radians = fabric.util.degreesToRadians(90);
            objectOrigin = new fabric.Point(x2, y2);
            new_loc = fabric.util.rotatePoint(
              objectOrigin,
              centerOrigin,
              radians
            );
          }
        }
        let doorArc = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        let doorShape = new fabric.Path(
          `M ${x1} ${y1} L ${x2} ${y2} M ${x1} ${y1} L ${new_loc.x} ${new_loc.y} M ${x2} ${y2}, A ${doorArc}, ${doorArc}, 0 0 1 ${new_loc.x}, ${new_loc.y}`,
          {
            stroke: "black",
            strokeWidth: 1,
            fill: "transparent",
            originX: "center",
            type: "doorobject",
            selectable: false,
            id: "doorobject_" + line.id,
          }
        );
        lineExteriorGroupArray.push(doorShape);
        lineExteriorGroupArray.push(line);
      }
    }
  }
  return lineExteriorGroupArray;
}

const createPartitionWindow = () => {
  let partitionWindowGroupArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let linesObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = linesObject[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let lines = faceArray.filter((el) => el["@type"] == "PARTITION_WINDOW");
  for (let i = 0; i < lines.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@partitionWindow"] &&
        el["@partitionWindow"].split(",").includes(lines[i]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let linePath = linesArray.filter(
        (el) => el["@id"] == lines[i].POLYGON["@path"]
      );
      let pointpath = linePath[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray.filter((el) => el["@id"] == pointpath[0]);
        point1 = !_.isEmpty(point1[0]["@editedXY"])
          ? point1[0]["@editedXY"].split(",")
          : point1[0]["@dataXY"]?.split(",");

        let point2 = roofPointsArray.filter((el) => el["@id"] == pointpath[1]);
        point2 = !_.isEmpty(point2[0]["@editedXY"])
          ? point2[0]["@editedXY"].split(",")
          : point2[0]["@dataXY"]?.split(",");
        const fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - minX) * ratio,
            (parseFloat(point1[1]) - minY) * ratio,
            (parseFloat(point2[0]) - minX) * ratio,
            (parseFloat(point2[1]) - minY) * ratio,
          ],
          {
            id: lines[i]["@id"],
            roomID: parentroom[0]["@id"],
            objectCaching: false,
            type: "PARTITION_WINDOW",
            stroke: PARTITION_WINDOW_COLOR,
            originX: "center",
            originY: "center",
            strokeUniform: true,
            strokeWidth: partitionLineStokeWidth,
            padding: 4,
            parentPartitionId: lines[i]["@parentPartition"],
            lockScalingX: true,
            lockScalingY: true,
            lockRotation: false,
            hasControls: false,
            lockMovementX: true,
            lockMovementY: true,
          }
        );
        partitionWindowGroupArray.push(fabricLine);
      }
    }
  }
  return partitionWindowGroupArray;
};

function createLableForExterior() {
  let labelGroupArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let labels = faceArray.filter((el) => el["@type"] == "LABEL");
  for (let labelindex = 0; labelindex < labels.length; labelindex++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@childrenLabel"] &&
        el["@childrenLabel"].split(",").includes(labels[labelindex]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == labels[labelindex].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      let point = roofPointsArray.filter((el) => el["@id"] == pointpath[0]);
      point = !_.isEmpty(point[0]["@editedXY"])
        ? point[0]["@editedXY"].split(",")
        : point[0]["@dataXY"]?.split(",");
      let RectX = (parseFloat(point[0]) - minX) * ratio;
      let RectY = (parseFloat(point[1]) - minY) * ratio;
      const textLabel = new fabric.IText(labels[labelindex]["@text"], {
        fontFamily: '"Roboto", sans-serif',
        fill: "black",
        id: labels[labelindex]["@id"],
        roomID: parentroom[0]["@id"],
        type: "textLabel",
        fontSize: baseFontSize,
        left: RectX,
        top: RectY,
        padding: 5,
        textAlign: "center",
        visible: true,
        hasControls: false,
        lockScalingX: true,
        lockScalingY: true,
      });
      // canvas.add(textLabel);
      labelGroupArray.push(textLabel);
    }
  }
  return labelGroupArray;
}
function createDoorsAndWindows() {
  let lineGroupArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  // Added condition && el["@mode"] != "WINDOW" for not displaying windows
  // In future remove this && el["@mode"] != "WINDOW" condition to display windows
  let doors = faceArray.filter((el) => el["@type"] == "WALLPENETRATION");
  for (let doorindex = 0; doorindex < doors.length; doorindex++) {
    const parentwall = faceArray.filter((el) =>
      el["@children"].split(",").includes(doors[doorindex]["@id"])
    );
    const parentroom = faceArray.filter((el) =>
      el["@children"].split(",").includes(parentwall[0]["@id"])
    );
    if (parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == doors[doorindex].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      let point1 = roofPointsArray
        .filter((el) => el["@id"] == pointpath[0])[0]
        ["@autoSnappedXY"].split(",");
      let point2 = roofPointsArray
        .filter((el) => el["@id"] == pointpath[1])[0]
        ["@autoSnappedXY"].split(",");
      let pointspos = [
        (point1[0] - minX) * ratio,
        (point1[1] - minY) * ratio,
        (point2[0] - minX) * ratio,
        (point2[1] - minY) * ratio,
      ];
      var anglePipePoints = [];
      var circlePoint = new fabric.Circle({
        radius: 2,
        fill: "rgba(0,0,0,0)",
        //fill: 'white',
        left: pointspos[0],
        top: pointspos[1],
        selectable: false,
        originX: "center",
        originY: "center",
        hoverCursor: "auto",
      });

      // canvas.add(circlePoint);
      lineGroupArray.push(circlePoint);
      var circlePoint1 = new fabric.Circle({
        radius: 2,
        fill: "rgba(0,0,0,0)",
        //fill: 'white',
        left: pointspos[2],
        top: pointspos[3],
        selectable: false,
        originX: "center",
        originY: "center",
        hoverCursor: "auto",
      });

      // canvas.add(circlePoint1);
      lineGroupArray.push(circlePoint1);

      anglePipePoints.push(circlePoint);
      anglePipePoints.push(circlePoint1);
      if (anglePipePoints.length > 1) {
        let startPoint = anglePipePoints[anglePipePoints.length - 2];
        let endPoint = anglePipePoints[anglePipePoints.length - 1];

        let line = new fabric.Line(
          [
            startPoint.get("left"),
            startPoint.get("top"),
            endPoint.get("left"),
            endPoint.get("top"),
          ],
          {
            stroke: ROOM_WALL_DOOR_COLOR,
            strokeWidth: lineStokeWidth - 2,
            hasControls: false,
            hasBorders: false,
            selectable: false,
            type: "DW",
            isDoor: doors[doorindex]["@mode"] == "DOOR",
            linePointObjectArray: doorline[0]["@path"],
            wallID: parentwall[0]["@id"],
            originX: "center",
            originY: "center",
            roomID: parentroom[0]["@id"],
            id: doors[doorindex]["@id"],
            unroundedsize: doors[doorindex]["POLYGON"]["@editedUnroundedsize"],
            size: doors[doorindex]["POLYGON"]["@editedSize"],
            doorDirection:
              doors[doorindex]["@mode"] == "DOOR" &&
              doors[doorindex]["@doorDirection"]
                ? doors[doorindex]["@doorDirection"]
                : doors[doorindex]["@mode"] == "DOOR" &&
                  doorDirectionEnum.inside,
          }
        );
        if (doors[doorindex]["@mode"] !== "DOOR") {
          const wline = _.cloneDeep(line);
          wline.type = "Clone-DW";
          wline.stroke = PARTITION_WINDOW_COLOR_BORDER;
          wline.strokeWidth = lineStokeWidth;
          wline.id = "wclone-" + doors[doorindex]["@id"];
          lineGroupArray.push(wline);
        }
        if (doors[doorindex]["@mode"] == "DOOR") {
          let centerOrigin = new fabric.Point(line.x1, line.y1);
          let radians = fabric.util.degreesToRadians(90);
          // console.log(x,y,this.ratio,this.minX,this.minY);
          let objectOrigin = new fabric.Point(line.x2, line.y2);
          let new_loc = fabric.util.rotatePoint(
            objectOrigin,
            centerOrigin,
            radians
          );
          let x1 = line.x1,
            y1 = line.y1,
            x2 = line.x2,
            y2 = line.y2;
          let polygonpointsclone =
            roomWiseLineAndTextObjects[line.roomID]["roomPolyGroup"];
          if (
            line.doorDirection &&
            line.doorDirection == doorDirectionEnum.inside
          ) {
            if (
              !insidePoly(
                new fabric.Point(new_loc.x, new_loc.y),
                polygonpointsclone.points
              )
            ) {
              x1 = line.x2;
              y1 = line.y2;
              x2 = line.x1;
              y2 = line.y1;
              centerOrigin = new fabric.Point(x1, y1);
              radians = fabric.util.degreesToRadians(90);
              objectOrigin = new fabric.Point(x2, y2);
              new_loc = fabric.util.rotatePoint(
                objectOrigin,
                centerOrigin,
                radians
              );
            }
          } else {
            if (
              insidePoly(
                new fabric.Point(new_loc.x, new_loc.y),
                polygonpointsclone.points
              )
            ) {
              x1 = line.x2;
              y1 = line.y2;
              x2 = line.x1;
              y2 = line.y1;
              centerOrigin = new fabric.Point(x1, y1);
              radians = fabric.util.degreesToRadians(90);
              objectOrigin = new fabric.Point(x2, y2);
              new_loc = fabric.util.rotatePoint(
                objectOrigin,
                centerOrigin,
                radians
              );
            }
          }
          let doorArc = Math.sqrt(
            (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)
          );
          let doorShape = new fabric.Path(
            `M ${x1} ${y1} L ${x2} ${y2} M ${x1} ${y1} L ${new_loc.x} ${new_loc.y} M ${x2} ${y2}, A ${doorArc}, ${doorArc}, 0 0 1 ${new_loc.x}, ${new_loc.y}`,
            {
              stroke: "black",
              strokeWidth: 1,
              fill: "transparent",
              originX: "center",
              type: "doorobject",
              selectable: false,
              id: "doorobject_" + line.id,
            }
          );
          lineGroupArray.push(doorShape);
        }
        lineGroupArray.push(line);
      }
    }
  }
  return lineGroupArray;
}
const createStaircase = () => {
  let stairCaseArray = [];
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let lines = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = lines[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let labels = faceArray.filter((el) => el["@type"] == "STAIR_CASE");
  for (let labelindex = 0; labelindex < labels.length; labelindex++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@childrenStairCase"] &&
        el["@childrenStairCase"].split(",").includes(labels[labelindex]["@id"])
    );
    if (parentroom[0] && parentroom[0]["@floorindex"] == selectedFloor) {
      let doorline = linesArray.filter(
        (el) => el["@id"] == labels[labelindex].POLYGON["@path"]
      );
      let pointpath = doorline[0]["@path"].split(",");
      let point = roofPointsArray.filter((el) => el["@id"] == pointpath[0])[0];
      let scaleXY = roofPointsArray.filter(
        (el) => el["@id"] == pointpath[0]
      )[0];
      point = point["@editedXY"].split(",");
      let RectX = (parseFloat(point[0]) - minX) * ratio;
      let RectY = (parseFloat(point[1]) - minY) * ratio;
      const stairCase = new fabric.Path(stairCasePath, {
        fill: false,
        id: labels[labelindex]["@id"],
        roomID: parentroom[0]["@id"],
        type: "stair-case",
        left: RectX,
        top: RectY,
        stroke: "black",
        angle: labels[labelindex]["@angle"] ? labels[labelindex]["@angle"] : 0,
        scaleX: scaleXY["@scaleX"] * ratio,
        scaleY: scaleXY["@scaleY"] * ratio,
      });
      stairCaseArray.push(stairCase);
    }
  }
  return stairCaseArray;
};
function makeCircle(
  left,
  top,
  line1,
  line2,
  color = "red",
  editedRoomAngle = 0
) {
  let c = new fabric.Circle({
    left: left,
    top: top,
    strokeWidth: 7,
    radius: 4,
    fill: "#fff",
    stroke: color,
    type: "connector",
    angle: editedRoomAngle,
    originX: "center",
    originY: "center",
  });
  c.hasControls = c.hasBorders = false;

  c.line1 = line1;
  c.line2 = line2;

  return c;
}

async function prepareHTML(imgDetails, areaObject = {}) {
  const doc = new jsPDF("p", "px", [640, 850], true);
  doc.internal.scaleFactor = 2;
  const pageWidth =
    doc.internal.pageSize.width || doc.internal.pageSize.getWidth();
  const pageHeight =
    doc.internal.pageSize.height || doc.internal.pageSize.getHeight();

  doc.addFileToVFS("Roboto-Medium-normal.ttf", robotoFont);
  doc.addFont("Roboto-Medium-normal.ttf", "Roboto-Medium", "normal");

  let Body = `<html>
	<head>
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

	<style>
  .print-foot:after {content: counter(page);counter-increment: page}div.footer-left{display:block;text-align:left;font-size:12px;padding-left:15px;position:running(footer-left)}div.footer-right{display:block;text-align:right;font-size:12px;padding-right:15px;position:running(footer-right)}div.content{page-break-after:always}@page{@bottom-left{content:element(footer-left)}}@page{@bottom-right{content:element(footer-right)}}
		@media print {
     *{
        -webkit-print-color-adjust: exact; 
    }
}
*{font-family: 'Roboto', sans-serif;
box-sizing: border-box
}
@page {size: Wpx 0px; margin-top:0px;margin-left:10px;margin-right:10px;}
	</style>
	</head><body id='bodyContent' style="height:0px;overflow:auto;">
  <div class="footer-left">Job Order ID: ${_.get(
    jobDetails,
    ["orderNo"],
    "--"
  )}</div> <div class="footer-right">  <div class="print-foot"> </div></div>
  <div class="content">
  <table id="firstPage" style="width:100%;vertical-align:top;margin: 0 auto">
			<tbody>
				<tr>
        <td style="padding:10px 10px 10px 50px;text-align:left" colspan="2">
        <div style="padding:0 0 30px 0">  <img src=${tenantLogo} height="60px" alt=""></img></div>
					</td>
			  </tr>
				<tr>
					<td style="padding:25px 25px 0 50px;text-align:left" colspan="2">
						<div style="padding:0 0 0 0">
						<h1 style="font-size: 50px; font-weight:500; color:${_.get(
              tenantDetails,
              ["buttonBackgroundColor"],
              ""
            )}"> Floor Plan <br/> Report Output </h1>
						</div>
					
					</td>
				</tr>
				<tr>
					<td style="padding:25px 25px 40px 50px;text-align:left" >
						<div style="padding:0 0 0 0">
						<p style="margin-bottom:15px;">Property Owner Name:  <br/> <b>${_.get(
              jobDetails,
              ["name"],
              "--"
            )}</b></p>
						<p style="">Subject Property Address: <br/> <b>${_.get(
              jobDetails,
              ["address"],
              "--"
            )}</b></p>
						</div>
					
					</td>
          <td style="padding:25px 50px 40px 0;text-align:right">
						<div style="padding:0 0 0 0">
						<p style="margin-bottom:15px;">Job Order ID  <br/> <b>${_.get(
              jobDetails,
              ["orderNo"],
              "--"
            )}</b></p>
						</div>
					
					</td>
				</tr>
        <tr style="width:100%;margin:0 auto;text-align:center">
					<td style="text-align:center;background:#F2F2F2;" colspan="2">
						<div style="background:#F2F2F2;text-align:center;width:100%;padding:10px">
							<img src="${mapImage}" style="height:450px;display:inline-block" alt="MapView"></img>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
    </div>`;
  Body += `<div id="jodetails" style="width:100%;page-break-after : always;margin: 0 auto;padding-top:80px;position:relative">
  <div style="position:absolute;width:100%; top:0;   box-sizing: border-box; display:flex; justify-content: space-between; align-items:center;padding:10px;border-bottom: 1px solid #bdbdbd">
	<table style="width:100%;border-spacing: 0;">		
  <tbody>
  <tr>
  <td style="width:70%">
  <div>
  <img src=${tenantLogo} height="30px" alt=""></img>
  </div>
  </td>
  <td style="width:30%;text-align:right">
  <div>
      <p style="font-size:12px"> ${_.get(jobDetails, ["address"], "--")}</p>
			</div>
  </td>
    </tr>
    </tbody>
    </table>
    </div>

    <div style="width:100%;border-spacing: 0;margin-top:15px;">
  <table  style="width:100%;border-spacing: 0;border:1px solid #D1D1D1;">
  <tbody>
  <tr>
  <td colspan="2" style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 14px;">
  <div><p style="margin:0; padding:0;color:${_.get(
    tenantDetails,
    ["buttonBackgroundColor"],
    ""
  )}"><b>${i18n.t("WEB_LABELS.Job_Order_Details")}</b></p></div>
		
  </td>
  </tr>
  <tr>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Job_Order_ID"
    )}:</b> ${_.get(jobDetails, ["orderNo"], "--")}</p></div>
  </td>`;
  if (
    _.get(jobDetails, ["jobOrderSource"], "")?.trim().toLowerCase() == "vsi"
  ) {
    Body += `<td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Inspector_Name"
    )}:</b> ${
      !_.isNil(_.get(jobDetails, ["inspectorName"]))
        ? _.get(jobDetails, ["inspectorName"])
        : "Jane Doe"
    }</p></div>
  </td>
  </tr>
  <tr>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Inspector_Email"
    )}:</b> ${
      !_.isNil(_.get(jobDetails, ["inspectorEmail"]))
        ? _.get(jobDetails, ["inspectorEmail"])
        : "jane@virtualsiteinspections.com"
    }</p></div>
  </td>`;
  } else {
    Body += `<td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Appraiser_Name"
    )}:</b> ${
      !_.isNil(_.get(jobDetails, ["assignee"]))
        ? _.get(jobDetails, ["assignee"])
        : "Jane Doe"
    }</p></div>
  </td>
  </tr>
  <tr>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Appraiser_Email"
    )}:</b> ${
      !_.isNil(_.get(jobDetails, ["assigneeEmail"]))
        ? _.get(jobDetails, ["assigneeEmail"])
        : "jane@remoteval.com"
    }</p></div>
  </td>`;
  }
  Body += `<td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Property_Type"
    )}:</b> ${_.get(jobDetails, ["propertyType"], "--")}</p></div>
  </td>
  </tr>
  <tr>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Job_Order_Source"
    )}:</b> ${_.get(jobDetails, ["jobOrderSource"], "--")}</p></div>
  </td>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
  <div><p style="margin:0; padding:0;"><b>${i18n.t(
    "WEB_LABELS.Assigned_Date"
  )}:</b> ${_.get(jobDetails, ["formatedAssignedDate"], "--")}</p></div>
</td>
  
  </tr>

  <tr>
  <td style="width: 50%;padding: 10px 15px; border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1; font-size: 12px;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Is_Demo_Job_Order"
    )}:</b> ${
    _.get(jobDetails, ["isDemoJobOrder"], false) ? "Yes" : "No"
  }</p></div>
  </td>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
  <div><p style="margin:0; padding:0;"><b>${i18n.t(
    "WEB_LABELS.Job_Order_Type"
  )}:</b> ${
    _.isEmpty(_.get(jobDetails, ["jobOrderType"], "--"))
      ? "--"
      : _.get(jobDetails, ["jobOrderType"], "--")
  }</p></div>
</td>
    </tr>
    <tr>

  <td style="width: 50%;padding: 10px 15px;font-size: 12px;border-right:1px solid #D1D1D1;">
    <div><p style="margin:0; padding:0;"><b>${i18n.t(
      "WEB_LABELS.Job_Order_Status"
    )}:</b> ${_.get(jobDetails, ["jobOrderStatus"], "--")}</p></div>
  </td>

    </tr>
    </tbody>
    </table>
</div>

<div style="width:100%;border-spacing: 0;margin-top:15px;">
  <table  style="width:100%;border-spacing: 0;border:1px solid #D1D1D1;">
  <tbody>
  <tr>
  <td colspan="2" style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 14px;">
  <div><p style="margin:0; padding:0;color:${_.get(
    tenantDetails,
    ["buttonBackgroundColor"],
    ""
  )}"><b>${i18n.t("WEB_LABELS.Customer_Details")}</b></p></div>
		
  </td>
  </tr>

  <tr>
  <td style="width: 50%;padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
          <div><p style="margin:0; padding:0;"><b>${i18n.t(
            "WEB_LABELS.Name"
          )}:</b> ${_.get(jobDetails, ["name"], "--")}</p></div>
    </td>
    <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
          <div><p style="margin:0; padding:0;"><b>${i18n.t(
            "WEB_LABELS.Address"
          )}:</b>  ${_.get(jobDetails, ["address"], "--")}</p></div>
    </td>
    </tr>

    <tr>
    <td style="width: 50%;padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
          <div><p style="margin:0; padding:0;"><b>${i18n.t(
            "WEB_LABELS.Cell_Phone"
          )}:</b> ${_.get(jobDetails, ["phone"], "--")}</p></div>
    </td>
    <td style="width: 50%;padding: 10px 15px;border-bottom:1px solid #D1D1D1;font-size: 12px;">
          <div><p style="margin:0; padding:0;"><b>${i18n.t(
            "WEB_LABELS.Email"
          )}:</b> ${_.get(jobDetails, ["email"], "--")}</p></div>
    </td>
    </tr>`;
  if (jobDetails?.latitude && jobDetails?.longitude) {
    Body += `<tr>
      <td style="width: 50%;padding: 10px 15px;border-right:1px solid #D1D1D1;font-size: 12px;">
            <div><p style="margin:0; padding:0;"><b>Latitude:</b> ${_.get(
              jobDetails,
              ["latitude"],
              "--"
            )}</p></div>
      </td>
      <td style="width: 50%;padding: 10px 15px;font-size: 12px;">
            <div><p style="margin:0; padding:0;"><b>Longitude:</b> ${_.get(
              jobDetails,
              ["longitude"],
              "--"
            )}</p></div>
      </td>
      </tr>`;
  }
  Body += `</tbody>
  </table>
  </div>`;
  if (areaObject.totalRoomsArea) {
    Body += ` 
    <div style="width:100%;border-spacing: 0;margin-top:15px;">
  <table  style="width:100%;border-spacing: 0;border:1px solid #D1D1D1;">
  <tbody>
	<tr>
  <td colspan="2" style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 14px;">
  <div><p style="margin:0; padding:0;color:${_.get(
    tenantDetails,
    ["buttonBackgroundColor"],
    ""
  )}"><b>${i18n.t("WEB_LABELS.Property_Measurement_Information")}</b></p></div>
  </td>
		</tr>

	<tr>
  <td style="width: 50%;padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
							<div><p style="margin:0; padding:0;"><b>${i18n.t(
                "WEB_LABELS.Total_Room_Units_Square_Feet"
              )}:</b> ${areaObject.totalRoomsArea}</p></div>
              </td>
  <td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
							<div><p style="margin:0; padding:0;"><b>${i18n.t(
                "WEB_LABELS.Total_Walls_Square_Feet"
              )}:</b> ${areaObject.totalWallsThickness}</p></div>
  </td>
  </tr>
  <tr>
  <td style="width: 50%;padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;font-size: 12px;">
							<div><p style="margin:0; padding:0;"><b>${i18n.t(
                "WEB_LABELS.Total_GLA_Square_Feet"
              )}:</b> ${areaObject.totalGLA}</p></div>
</td>
<td style="width: 50%;padding: 10px 15px;  border-bottom:1px solid #D1D1D1;font-size: 12px;">
							<div><p style="margin:0; padding:0;"><b>${i18n.t(
                "WEB_LABELS.Total_Non_GLA_Square_Feet"
              )}:</b> ${areaObject.totalNonGLA}</p></div>
</td>
</tr>
<tr>
<td style="width: 50%;padding: 10px 15px;border-right:1px solid #D1D1D1;font-size: 12px;">
							<div><p style="margin:0; padding:0;"><b>${i18n.t(
                "WEB_LABELS.Total_Square_Feet"
              )}:</b> ${areaObject.totalArea}</p></div>
  </td>
  <td style="width: 50%;padding: 10px 15px;">
		</td>
	</tr></tbody>
  </table>
  </div>`;
  }
  Body += `</div>`;

  for (let i = 0; i < imgDetails.length; i++) {
    for (let j = 0; j < imgDetails[i].imgDetails.length; j++) {
      Body += `<div id="measurementdetails${
        i + "" + j
      }" style="width:100%;page-break-after : always;margin: 0 auto;padding-top:80px;position:relative">
      <div style="position:absolute;width:100%; top:0;   box-sizing: border-box; display:flex; justify-content: space-between; align-items:center;padding:10px;border-bottom: 1px solid #bdbdbd">
			<table style="width:100%;border-spacing: 0;">		
  <tbody>
  <tr>
  <td style="width:70%">
  <div>
  <img src=${tenantLogo} height="30px" alt=""></img>
  </div>
  </td>
  <td style="width:30%;text-align:right">
  <div>
      <p style="font-size:12px"> ${_.get(jobDetails, ["address"], "--")}</p>
			</div>
  </td>
    </tr>
    </tbody>
    </table>
    </div>

    <table  style="width:100%;padding:0;">
    <tbody>
      <tr>
        <td colspan="8">    
          <div style="width: 100%;padding:0;color:${_.get(
            tenantDetails,
            ["buttonBackgroundColor"],
            ""
          )};font-size: 16px;"> <p style="padding:0;padding-bottom:10px;padding-top:10px;margin:0;"><b>${
        imgDetails[i].imgDetails[j].area.floorName
      }</b></p><p style="width:100%;height:3px; margin-top: 3px;margin-bottom:0;padding:0;background: ${_.get(
        tenantDetails,
        ["buttonBackgroundColor"],
        ""
      )};"></p> </div>
        </td>
      </tr>
      <tr style="font-size:12px">
      <td style="vertical-align:center;padding:10px 0;width:60px">
      <div class="" style="float:left;display:inline;width:100%;">	
        <div style="width:20px;float:left;height:20px;margin-right:5px;border:4px solid ${GLA_BORDER_COLOR};display:inline-block">
            </div> <span style="display:inline-block; padding-top:3px;">GLA</span>
         </div>
      </td>
      <td style="vertical-align:center;padding:10px 0;width:90px">
        <div class="" style="float:left;display:inline;width:100%;">	
          <div style="width:20px;float:left;height:20px;margin-right:5px;border:4px solid ${NON_GLA_BORDER_COLOR};display:inline-block">
          </div> <span style="display:inline-block; padding-top:3px;">NON-GLA</span>
        </div>   
      </td>
      <td style="vertical-align:center;padding:10px 0;width:75px">
        <div class="" style="float:left;display:inline;width:100%;">	
          <div style="width:20px;float:left;height:20px;margin-right:5px;border:4px solid #000;display:inline-block">
          </div> <span style="display:inline-block; padding-top:3px;">Partition</span>
        </div>
      </td>
      <td style="vertical-align:center;padding:10px 0;width:130px">
        <div class="" style="float:left;display:inline;width:100%;">	
            <div style="width:20px;float:left;height:20px;margin-right:5px;border:4px solid ${NON_ADDITIONAL_BORDER_COLOR};display:inline-block">
            </div> <span style="display:inline-block; padding-top:3px;">NON-ADDITIONAL</span>
        </div>
      </td>
     `;
      Body += `
      </tr>
      <tr>
        <td  colspan="8" style="text-align:center;padding-left:0;">    
          <div style="width:100%;margin: 0 auto; border: 1px solid #bdbdbd; padding: 0;background: #fff;">
            <img src="${
              imgDetails[i].imgDetails[j].image
            }" style="height:700px" alt=""></img>
          </div>
        </td>
      </tr>
      <tr>
        <td colspan="8" style="text-align:left;padding:10px 0;">    
            <div style="width:100%;margin: 0 auto;">
              <span style="font-weight:300;font-size:12px;">ANSI Aligned Floor Plan and Measurements generated by ${_.get(
                tenantDetails,
                ["tenantName"],
                ""
              )} scan created on ${_.get(
        jobDetails,
        ["latestScanCreatedDate"],
        ""
      )}.</span>
            </div>
          </td>
      </tr>
    </tbody>
  </table></div>`;

      Body += `<div id="measurementdetailsCalculations${
        i + "" + j
      }" style="width:100%;page-break-after : always;margin: 0 auto;padding-top:80px;position:relative">
  <div style="position:absolute;width:100%; top:0;   box-sizing: border-box; display:flex; justify-content: space-between; align-items:center;padding:10px;border-bottom: 1px solid #bdbdbd">
  <table style="width:100%;border-spacing: 0;">		
  <tbody>
  <tr>
  <td style="width:70%">
  <div>
  <img src=${tenantLogo} height="30px" alt=""></img>
  </div>
  </td>
  <td style="width:30%;text-align:right">
  <div>
      <p style="font-size:12px"> ${_.get(jobDetails, ["address"], "--")}</p>
			</div>
  </td>
    </tr>
    </tbody>
    </table>
    </div>
<div style="margin-top:15px;">
<table  style="width:100%;font-size:12px; border:1px solid #D1D1D1;">
<tbody>
<tr>
<td style="padding: 10px 15px;width:30%;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
  <div ><p style="margin:0; padding:0;"><b>Structure</b></p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:20%;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;text-align:left">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
  <div ><p style="margin:0; padding:0;"><b> Area</b></p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;border-bottom:1px solid #D1D1D1;text-align:left">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
  <div ><p style="margin:0; padding:0;"><b> Calculations</b></p></div>
  
  </div>
</td>
</tr>
<tr>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
    <div ><p style="margin:0; padding:0;">${i18n.t(
      "WEB_LABELS.Total_Room_Units_Square_Feet"
    )}</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;text-align:left;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
    <div ><p style="margin:0; padding:0;"> ${
      imgDetails[i].imgDetails[j].area.totalRoomsArea
    }</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;border-bottom:1px solid #D1D1D1;text-align:left">  
      <div style="width: 100%;margin: 0 auto; padding: 0;">
        <div ><p style="margin:0; padding:0;"> ${
          imgDetails[i].imgDetails[j].area.totalRoomsAreaCalc != ""
            ? imgDetails[i].imgDetails[j].area.totalRoomsAreaCalc
            : "--"
        }</p></div>
      
      </div>
    </td>
</tr>
<tr>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
    <div ><p style="margin:0; padding:0;">${i18n.t(
      "WEB_LABELS.Total_Walls_Square_Feet"
    )}</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;text-align:left;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
    <div ><p style="margin:0; padding:0;"> ${
      imgDetails[i].imgDetails[j].area.totalWallsThickness
    }</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;border-bottom:1px solid #D1D1D1;text-align:left">  
      <div style="width: 100%;margin: 0 auto; padding: 0;">
        <div ><p style="margin:0; padding:0;"> ${
          imgDetails[i].imgDetails[j].area.totalWallsThicknessCalc != ""
            ? imgDetails[i].imgDetails[j].area.totalWallsThicknessCalc
            : "--"
        }</p></div>
      
      </div>
    </td>
</tr>  
</tr>
<tr>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
    <div ><p style="margin:0; padding:0;">${i18n.t(
      "WEB_LABELS.Total_GLA_Square_Feet"
    )}</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;text-align:left;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
    <div ><p style="margin:0; padding:0;"> ${
      imgDetails[i].imgDetails[j].area.totalGLA
    }</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;border-bottom:1px solid #D1D1D1;text-align:left">  
      <div style="width: 100%;margin: 0 auto; padding: 0;">
        <div ><p style="margin:0; padding:0;"> ${
          imgDetails[i].imgDetails[j].area.totalGLACalc != ""
            ? imgDetails[i].imgDetails[j].area.totalGLACalc
            : "--"
        }</p></div>
      
      </div>
    </td>
</tr>  
<tr>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
    <div ><p style="margin:0; padding:0;">${i18n.t(
      "WEB_LABELS.Total_Non_GLA_Square_Feet"
    )}</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;text-align:left;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
    <div ><p style="margin:0; padding:0;"> ${
      imgDetails[i].imgDetails[j].area.totalNonGLA
    }</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;border-bottom:1px solid #D1D1D1;text-align:left">  
      <div style="width: 100%;margin: 0 auto; padding: 0;">
        <div ><p style="margin:0; padding:0;"> ${
          imgDetails[i].imgDetails[j].area.totalNonGLACalc != ""
            ? imgDetails[i].imgDetails[j].area.totalNonGLACalc
            : "--"
        }</p></div>
      
      </div>
    </td>
</tr> 
<tr>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
    <div ><p style="margin:0; padding:0;">${i18n.t(
      "WEB_LABELS.Total_Square_Feet"
    )}</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;border-bottom:1px solid #D1D1D1;text-align:left;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
    <div ><p style="margin:0; padding:0;"> ${
      imgDetails[i].imgDetails[j].area.totalArea
    }</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;border-bottom:1px solid #D1D1D1;text-align:left">  
      <div style="width: 100%;margin: 0 auto; padding: 0;">
        <div ><p style="margin:0; padding:0;"> ${
          imgDetails[i].imgDetails[j].area.totalAreaCalc != ""
            ? imgDetails[i].imgDetails[j].area.totalAreaCalc
            : "--"
        }</p></div>
      
      </div>
    </td>
</tr>  
<tr>
<td style="padding: 10px 15px;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;text-align:left">
    <div ><p style="margin:0; padding:0;">${i18n.t(
      "WEB_LABELS.Height_Feet"
    )}</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;text-align:left;border-right:1px solid #D1D1D1;">  
  <div style="width: 100%;margin: 0 auto; padding: 0;">
    <div ><p style="margin:0; padding:0;"> ${
      imgDetails[i].imgDetails[j].area.totalHeight
    }</p></div>
  
  </div>
</td>
<td style="padding: 10px 15px;width:50%;text-align:left">  
      <div style="width: 100%;margin: 0 auto; padding: 0;">
        <div ><p style="margin:0; padding:0;"> -- </p></div>
      
      </div>
    </td>
</tr>  
</tbody>
</table></div></div>`;
    }
  }
  Body += "</body></html>";
  let htmlel = document.createElement("html");
  htmlel.innerHTML = Body;
  document.body.appendChild(htmlel);
  document.body.removeChild(htmlel);
  let formdata = new FormData();
  formdata.append("file", doc.output("blob"), jobOrderId + ".pdf");
  formdata.append("jobOrderId", jobOrderId);
  formdata.append(
    "glaSquareFootage",
    areaObject.totalGLA ? areaObject.totalGLA : 0.0
  );
  return Body;
}
