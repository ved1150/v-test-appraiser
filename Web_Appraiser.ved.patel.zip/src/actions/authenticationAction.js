import * as actionTypes from "./actionTypes";
import authenticationService from "./../services/authenticationService";
import { customToast } from "./../helpers/customToast";
import {
  UNEXPECTED_ERROR_MESSAGE,
  FORGET_PASSWORD_SUCCESS_MESSAGE,
  RESET_PASSWORD_SUCCESS_MESSAGE,
} from "./../constants/commonMessages";
import localStorage from "./../services/storage";
import sessionStorage from "./../services/sessionStorage";
import { StartLoading, StopLoading } from "./UIAction";
import { ROLE, storageTypes } from "../constants/appConstant";
import i18n from "../translations/i18n";
import { getSubDomainFromURL } from "../helpers";
import { profileUpdate } from "./profileAction";
import authService from "../services/authService";
import { getTenantTheme } from "./whiteLabelAction";

const fetchTokenStart = () => {
  return {
    type: actionTypes.FETCH_TOKEN_START,
  };
};

const fetchTokenSuccess = (data) => {
  return {
    type: actionTypes.FETCH_TOKEN_SUCCESS,
    payload: data,
  };
};

const fetchTokenError = (error) => {
  return {
    type: actionTypes.FETCH_TOKEN_ERROR,
    payload: error,
  };
};

export const fetchToken = (accessCode, history) => {
  return (dispatch) => {
    dispatch(fetchTokenStart());
    return authenticationService
      .fetchToken(accessCode)
      .then(async (data) => {
        await Promise.all([
          authenticationService.setToken(data.token),
          authenticationService.setUserRole(data.userRole),
          authenticationService.setTenantDetails(
            JSON.stringify({
              tenantId: data.tenantList[0].id,
              tenantSubDomain: data.tenantList[0].tenantSubDomain,
            })
          ),
        ]);
        if (data.userRole === ROLE.TECHNICIAN) {
          i18n.changeLanguage("en");
          sessionStorage.set("selectedLanguage", "english");
        }
        dispatch(successLogin(data));
        dispatch(fetchTokenSuccess(data));
        if (data.userRole === ROLE.SWITCH_MULTITENANT_TECHNICIAN) {
          history.push("/tenants");
        } else {
          history.push("/");
        }
        return data;
      })
      .catch((err) => {
        dispatch(fetchTokenError(err));
      });
  };
};

const startLogin = () => {
  return {
    type: actionTypes.LOGIN_START,
  };
};

const successLogin = (data) => {
  return {
    type: actionTypes.LOGIN_SUCCESS,
    payload: data,
  };
};

const loginError = (error) => {
  return {
    type: actionTypes.LOGIN_ERROR,
    payload: error,
  };
};

const startResetPassword = () => {
  return {
    type: actionTypes.RESET_PASSWORD_START,
  };
};

const successResetPassword = () => {
  return {
    type: actionTypes.RESET_PASSWORD_SUCCESS,
  };
};

const resetPasswordError = () => {
  return {
    type: actionTypes.RESET_PASSWORD_ERROR,
  };
};

export const logIn =
  (formProps, history, fromWorkspace = false) =>
  async (dispatch) => {
    dispatch(startLogin());
    const headerData = formProps.tenant && {
      headers: {
        "X-Tenant": formProps.tenant,
      },
    };
    return authenticationService
      .logIn(formProps, headerData)
      .then(async (res) => {
        const query = new URLSearchParams(history.location.search);
        const redirectPathFromURL = query.get("redirect");
        const subdomain = getSubDomainFromURL();
        const tenantData = authenticationService.getTenantDetails();
        if (!subdomain) {
          let authData = JSON.stringify(formProps);
          if (tenantData) {
            authenticationService.removeAuthData();
          } else {
            authenticationService.setAuthData(authData);
          }
        }
        await Promise.all([
          authenticationService.setToken(res.token),
          authenticationService.setUserRole(res.userRole),
          authenticationService.setTenantDetails(
            JSON.stringify({
              tenantId: res.tenantList[0].id,
              tenantSubDomain: res.tenantList[0].tenantSubDomain,
            })
          ),
        ]);
        if (window.location.host.includes("localhost")) {
          // Execute theme-API if localhost is present so we can see the theme while developing.
          await Promise.all([dispatch(getTenantTheme())]);
        }
        if (
          res.userRole === ROLE.TECHNICIAN ||
          res.userRole === ROLE.SWITCH_MULTITENANT_TECHNICIAN
        ) {
          i18n.changeLanguage("en");
          sessionStorage.set("selectedLanguage", "english");
        }
        let redirectPath = fromWorkspace
          ? redirectPathFromURL || "/"
          : "/tenants";
        history.push(redirectPath);
        dispatch(successLogin(res));
        return res;
      })
      .catch((err) => {
        dispatch(loginError(err));
        throw err;
      });
  };

export const forgotPassword = (formProps) => async (dispatch) => {
  return authenticationService
    .forgotPassword(formProps)
    .then((res) => {
      customToast.success(FORGET_PASSWORD_SUCCESS_MESSAGE);
      return res;
    })
    .catch((e) => {
      throw e;
    });
};

export const resetPassword = (formProps, history) => async (dispatch) => {
  dispatch(startResetPassword());
  return authenticationService
    .resetPassword(formProps)
    .then((res) => {
      dispatch(successResetPassword());
      customToast.success(RESET_PASSWORD_SUCCESS_MESSAGE);
      history.push("/sign-in");
      return res;
    })
    .catch((err) => {
      dispatch(resetPasswordError());
      throw err;
    });
};

const startSignOut = () => {
  return {
    type: actionTypes.SIGN_OUT_START,
  };
};

const successSignOut = () => {
  return {
    type: actionTypes.SIGN_OUT_SUCCESS,
  };
};

const signOutError = () => {
  return {
    type: actionTypes.SIGN_OUT_ERROR,
  };
};

export const signOut = () => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(startSignOut());
  return authenticationService
    .signOut()
    .then((res) => {
      dispatch(successSignOut());
      localStorage.clearAll();
      sessionStorage.clearAll();
      dispatch(StopLoading());
      return res;
    })
    .catch((err) => {
      dispatch(signOutError());
      dispatch(StopLoading());
      throw err;
    });
};

const fetchLinkStart = () => {
  return {
    type: actionTypes.FETCH_LINK_START,
  };
};

const fetchLinkSuccess = (data) => {
  return {
    type: actionTypes.FETCH_LINK_SUCCESS,
    payload: data,
  };
};

const fetchLinkError = (error) => {
  return {
    type: actionTypes.FETCH_LINK_ERROR,
    payload: error,
  };
};

export const fetchLink = (payload, history) => {
  return (dispatch) => {
    dispatch(fetchLinkStart());
    return authenticationService
      .fetchLink(payload)
      .then((res) => {
        dispatch(fetchLinkSuccess(res.data.data));
        return res.data.data;
      })
      .catch((err) => {
        dispatch(fetchLinkError(err));
        history.push("/");
      });
  };
};

export const switchTenant = (
  tenantSubdomain,
  headerData,
  storageType,
  history
) => {
  storageType == storageTypes.sessionStorage &&
    authenticationService.setStorageType(storageType);
  return (dispatch) => {
    return authenticationService
      .switchTenant(tenantSubdomain, headerData)
      .then(async (res) => {
        if (Array.isArray(res.tenantList)) {
          dispatch(profileUpdate({ selectedTenant: res.tenantList[0] }));
        }
        await Promise.all([
          authenticationService.setToken(res.token),
          authenticationService.setUserRole(res.userRole),
          authenticationService.setTenantDetails(
            JSON.stringify({
              tenantId: res.tenantList[0].id,
              tenantSubDomain: res.tenantList[0].tenantSubDomain,
            })
          ),
        ]);
        if (window.location.host.includes("localhost")) {
          // Execute theme-API if localhost is present so we can see the theme while developing.
          await Promise.all([dispatch(getTenantTheme())]);
        }
        if (res.userRole === ROLE.TECHNICIAN) {
          i18n.changeLanguage("en");
          sessionStorage.set("selectedLanguage", "english");
        }
        history.push("/");
        return res;
      })
      .catch((err) => {
        throw err;
      });
  };
};

const switchTechnicianStart = () => {
  return {
    type: actionTypes.SWITCH_TECHNICIAN_START,
  };
};

const switchTechnicianSuccess = (data) => {
  return {
    type: actionTypes.SWITCH_TECHNICIAN_SUCCESS,
    payload: data,
  };
};

const switchTechnicianError = (error) => {
  return {
    type: actionTypes.SWITCH_TECHNICIAN_ERROR,
    payload: error,
  };
};

export const switchTechnician = (
  headerData,
  subDomain,
  storageType,
  history
) => {
  return (dispatch) => {
    dispatch(switchTechnicianStart());
    return authenticationService
      .switchTechnician(headerData, subDomain)
      .then(async (res) => {
        if (Array.isArray(res.tenantList)) {
          dispatch(profileUpdate({ selectedTenant: res.tenantList[0] }));
        }
        await Promise.all([
          authenticationService.setStorageType(storageTypes.sessionStorage),
          authenticationService.setToken(res.jwtToken),
          authenticationService.setUserRole(res.userRole),
          authenticationService.setTenantDetails(
            JSON.stringify({
              tenantId: res.tenantList[0].id,
              tenantSubDomain: res.tenantList[0].tenantSubDomain,
            })
          ),
        ]);
        if (window.location.host.includes("localhost")) {
          await Promise.all([dispatch(getTenantTheme())]);
        }
        if (res.userRole === ROLE.TECHNICIAN) {
          i18n.changeLanguage("en");
          sessionStorage.set("selectedLanguage", "english");
        }
        dispatch(switchTechnicianSuccess(res));
        history.push("/");
        return res;
      })
      .catch((err) => {
        dispatch(switchTechnicianError(err));
      });
  };
};

export const fetchStates = () => {
  return (dispatch) => {
    return authenticationService
      .getStates()
      .then((data) => {
        return data;
      })
      .catch((err) => {
        throw err;
      });
  };
};
