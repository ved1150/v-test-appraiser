import React, { useEffect, useRef, useState } from "react";
import _ from "lodash";
import { useTranslation } from "react-i18next";
import { useDispatch, connect, useSelector } from "react-redux";
import { Link, useParams, useHistory } from "react-router-dom";
import {
  getFloorScanDetail,
  unmountFloorScanDetail,
  updateFloorScan,
  updateFloorScanStatus,
  markScanIsOkay,
  getRequestRescanHistory,
} from "../../../actions/technicianJobAction";
import ViewImage from "../../JobOrders/JobOrderDetails/Models/viewImage";
import { downloadZip } from "../../../actions/floorPlansAction";
import { customToast } from "../../../helpers/customToast";
import AsyncImage from "../../common/AsyncImage";
import "./Index.scss";
import {
  CHAR_LIMIT,
  STATUS,
  SHAPE_TYPE,
  SHAPE_STATUS,
  ANNOTATION_ACK,
} from "../../../constants/appConstant";
import NoDataView from "../../JobOrders/JobOrderDetails/Common/noDataView";
import { FLOORPLANS_ICON } from "../../JobOrders/JobOrderDetails/Common/commonText";
import { Button } from "@mui/material";
import { useFormik } from "formik";
import View3DFloorPlan from "../View3DFloorPlan";
import * as Yup from "yup";
import InstructionModal from "../View3DFloorPlan/InstructionModal";
import MarkupView from "../View3DFloorPlan/MarkupView";
import { floorScanStatusEnum, floorScanType } from "../../../constants/enums";
import objFileIcon from "../../../images/obj-file-icon.png";
import ConfirmationModal from "../../common/confirmationModal";
import { MARK_SCAN_AS_OKAY } from "../../../constants/commonMessages";
import RequestRescanHistory from "../RequestRescanHistory/RequestRescanHistory";
import RequestRescanHistoryImages from "../RequestRescanHistory/RequestRescanHistoryImages";

function View2DFloorPlan(props) {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const floorDetail = useSelector((state) => state.technicianJob.floorDetail);
  const fileRef = useRef(null);
  const pdfFileRef = useRef(null);
  const [zoomLevel, setZoomLevel] = useState("1");
  const [showRescanSidebar, setShowRescanSidebar] = useState(false);
  const [submitloading, setSubmitLoading] = useState(false);
  const [explorePlanInstruction, setExplorePlanInstruction] = useState(false);
  const [measurementInstruction, setMeasurementInstruction] = useState(false);
  const history = useHistory();
  const [toggle, setToggle] = useState(true);
  const [scanIsOkay, setScanIsOkay] = useState(false);
  const [showPopUp, setShowPopUp] = useState(false);
  const [showRequestRescanHistoryModal, setShowRequestRescanHistoryModal] =
    useState(false);
  const [
    showRequestRescanHistoryImagesModal,
    setShowRequestRescanHistoryImagesModal,
  ] = useState(false);
  const [
    requestRescanHistoryImagesModalData,
    setRequestRescanHistoryImagesModalData,
  ] = useState(null);
  const [showAddMarkupImgModal, setShowAddMarkupImgModal] = useState(false);
  const [images, setImages] = useState([]);
  const [imagesURLs, setImagesURLs] = useState([]);
  const [markupImageCount, setMarkupImageCount] = useState(0);
  const [enableImageView, setEnableImageView] = useState(false);
  const [selectedImageIndexForView, setSelectedImageIndexForView] =
    useState("");
  //markup state start
  const [isCapturedPopUp, setIsCapturedPopUp] = useState(false);
  const [incomingMarkupAnnotationObject, setIncomingMarkupAnnotationObject] =
    useState({});
  const [markupImageURL, setMarkupImageURL] = useState("");
  const [userMarkupObjectArray, setUserMarkupObjectArray] = useState([]);
  const [globalMarkupObjectArray, setGlobalMarkupObjectArray] = useState([]);
  const [userUndoObjectArray, setUserUndoObjectArray] = useState([]);
  const [markupViewStartedBy, setMarkupViewStartedBy] = useState("");
  //markup state end

  const markupPathCreated = (annotationPoint, objectId) => {
    //For test, send event to start the markup view
    const changesObject = {
      data: {
        participantIdentity: "",
        participantSid: "",
        borderWidth: "" + annotationPoint[0].borderWidth,
        deviceType: "",
        annotationPoint: JSON.stringify(annotationPoint),
        objectId: "" + objectId,
        sessionid: "",
        shapeType: "" + SHAPE_TYPE.PENCIL_DRAW,
        statusShape: "" + SHAPE_STATUS.DRAW,
        text_str: "",
      },
    };
    setUserMarkupObjectArray([...userMarkupObjectArray, changesObject]);
  };

  const markupShapeAdded = (annotationPoint, objectId, shapeType) => {
    //For test, send event to start the markup view
    const changesObject = {
      data: {
        participantIdentity: "",
        participantSid: "",
        borderWidth: "",
        deviceType: "",
        annotationPoint: JSON.stringify(annotationPoint),
        objectId: "" + objectId,
        sessionid: "",
        shapeType: "" + shapeType,
        statusShape: "" + SHAPE_STATUS.DRAW,
        text_str: "",
      },
    };
    setUserMarkupObjectArray([...userMarkupObjectArray, changesObject]);
  };

  const markupShapeMoved = (annotationPoint, objectId) => {
    //For test, send event to start the markup view
    const changesObject = {
      data: {
        participantIdentity: "",
        participantSid: "",
        borderWidth: "",
        deviceType: "",
        annotationPoint: JSON.stringify(annotationPoint),
        objectId: "" + objectId,
        sessionid: "",
        shapeType: "",
        statusShape: "" + SHAPE_STATUS.MOVE,
        text_str: "",
      },
    };
    setUserMarkupObjectArray([...userMarkupObjectArray, changesObject]);
  };

  const markupUndo = (changesObject) => {
    let matchIndex = -1;
    let _userMarkupObjectArray = userMarkupObjectArray;
    _userMarkupObjectArray.splice(-1, 1);

    setUserMarkupObjectArray([..._userMarkupObjectArray]);
    setUserUndoObjectArray([...userUndoObjectArray, changesObject]);
    for (let index = userMarkupObjectArray.length - 1; index >= 0; index--) {
      if (
        userMarkupObjectArray[index].data.objectId ==
        changesObject.data.objectId
      ) {
        matchIndex = index;
        break;
      }
    }
    if (matchIndex != -1) {
      let copyOfUserMarkupObject = _.cloneDeep(
        userMarkupObjectArray[matchIndex]
      );
      copyOfUserMarkupObject = {
        data: {
          ...copyOfUserMarkupObject.data,
          statusShape: SHAPE_STATUS.MOVE,
          timestamp: new Date().getTime(),
        },
      };
      setIncomingMarkupAnnotationObject({ ...copyOfUserMarkupObject.data });
    } else {
      let copyOfUserMarkupObject = {
        data: {
          ...changesObject.data,
          statusShape: SHAPE_STATUS.UNDO,
          timestamp: new Date().getTime(),
        },
      };
      setIncomingMarkupAnnotationObject({ ...copyOfUserMarkupObject.data });
    }
  };

  const markupRedo = (changesObject) => {
    let _userUndoObjectArray = userUndoObjectArray;
    _userUndoObjectArray.splice(-1, 1);
    let copyOfUserUndoObject = _.cloneDeep(changesObject);
    copyOfUserUndoObject = {
      data: {
        ...changesObject.data,
        timestamp: new Date().getTime(),
      },
    };
    setIncomingMarkupAnnotationObject({ ...copyOfUserUndoObject.data });

    setUserMarkupObjectArray([...userMarkupObjectArray, changesObject]);
    setUserUndoObjectArray([..._userUndoObjectArray]);
  };

  const markupClear = () => {
    const changesObject = {
      data: {
        participantIdentity: "",
        rticipantSid: "",
        deviceType: "",
        objectId: "" + new Date().getTime(),
        sessionid: "",
        shapeType: "" + SHAPE_TYPE.PENCIL_DRAW,
        status: "" + ANNOTATION_ACK.CLEAR,
        text_str: "",
      },
    };
    setUserMarkupObjectArray([]);
    setUserUndoObjectArray([]);
    setGlobalMarkupObjectArray([]);
  };

  const markupClose = () => {
    const changesObject = {
      data: {
        participantIdentity: "",
        participantSid: "",
        deviceType: "",
        objectId: "" + new Date().getTime(),
        sessionid: "",
        shapeType: "",
        status: "" + ANNOTATION_ACK.STOPPED,
        text_str: "",
      },
    };
    setUserMarkupObjectArray([]);
    setUserUndoObjectArray([]);
    setGlobalMarkupObjectArray([]);
  };

  const downloadBase64File = (linkSource, fileName) => {
    const downloadLink = document.createElement("a");
    downloadLink.href = linkSource;
    downloadLink.download = fileName;
    downloadLink.click();
  };
  const saveMarkupImage = async (dataURL) => {
    const fileName = `${floorDetail.floorScanNumber}_${floorDetail.orderNumber}.png`;
    downloadBase64File(dataURL, fileName);
  };
  const scanIsOkayInProgress = useSelector(
    (state) => state?.technicianJob?.scanIsOkayStart
  );
  const vsiScanIsOkay = floorDetail?.status === floorScanStatusEnum?.[8]?.id;
  const handleRequestRescan = (floorPlanFailedReason) => {
    setSubmitLoading(true);
    dispatch(
      updateFloorScanStatus({
        id: scanId,
        status: STATUS.FLOORPLAN_FAILED,
        floorPlanFailedReason,
        files: imagesURLs?.map((img) => img.key),
      })
    )
      .then(() => {
        setSubmitLoading(false);
        setShowRescanSidebar(false);
        getFSDetail();
        setImages([]);
        setImagesURLs([]);
        setMarkupImageCount(0);
      })
      .catch(() => {
        setSubmitLoading(false);
        setShowRescanSidebar(false);
        getFSDetail();
        setImages([]);
        setImagesURLs([]);
        setMarkupImageCount(0);
      });
  };

  const {
    handleChange,
    handleBlur,
    handleSubmit,
    errors,
    touched,
    isValid,
    dirty,
    values,
    handleReset,
  } = useFormik({
    initialValues: {
      floorPlanFailedReason: "",
    },
    validateOnChange: true,
    validationSchema: Yup.object().shape({
      floorPlanFailedReason: Yup.string()
        .required("Please enter reason.")
        .max(CHAR_LIMIT, `You can add upto ${CHAR_LIMIT} character only`),
    }),

    onSubmit: (values) => {
      handleRequestRescan(values.floorPlanFailedReason);
      handleReset();
    },
  });

  const downloadFile = (zipPath) => {
    props.downloadZip(zipPath).then((data) => {
      window.open(data.data, "_blank");
    });
  };

  const { scanId } = useParams();

  const onFileUpload = () => {
    // `current` points to the mounted file input element
    fileRef.current.click();
  };
  const onPDFFileUpload = () => {
    // `current` points to the mounted file input element
    pdfFileRef.current.click();
  };
  const getFSDetail = () => dispatch(getFloorScanDetail(scanId));
  const [refresh, setRefresh] = useState(false);
  useEffect(() => {
    if (scanId) {
      getFSDetail();
    }
    return () => dispatch(unmountFloorScanDetail());
  }, [dispatch, scanId, refresh]);
  const validateAttachImageType = (file) => {
    return (
      ["image/jpeg", "image/png"].includes(file.type) &&
      (file.name.endsWith(".jpg") ||
        file.name.endsWith(".JPG") ||
        file.name.endsWith(".jpeg") ||
        file.name.endsWith(".JPEG") ||
        file.name.endsWith(".png") ||
        file.name.endsWith(".PNG"))
    );
  };
  const validateAttachPDFType = (file) => {
    return (
      ["application/pdf"].includes(file.type) && file.name.endsWith(".pdf")
    );
  };
  const handleFileUpload = (e, validateFunc) => {
    e.preventDefault();
    const file = e.target.files[0];
    if (file) {
      if (!validateFunc(file)) {
        return customToast.error(
          t("COMMON_MESSAGES.ATTACHMENT_UPLOAD_UNSUPPORTED_FORMAT")
        );
      }
      if (file.size / (1024 * 1024) >= 10) {
        return customToast.error(
          t("COMMON_MESSAGES.ATTACHMENT_UPLOAD_SIZE_EXCEEDED")
        );
      }
      uploadFile(file);
    }
  };
  const uploadFile = (file) => {
    const uploadedFileName = file.name;
    const data = {
      floorScanId: scanId,
      file,
      fileName: uploadedFileName,
    };

    dispatch(updateFloorScan(data)).then((res) => {
      dispatch(getFloorScanDetail(scanId));
    });
  };
  const handleComplete = () => {
    dispatch(
      updateFloorScanStatus({
        id: scanId,
        status: STATUS.COMPLETED,
      })
    )
      .then(() => {
        getFSDetail();
      })
      .catch(() => {
        getFSDetail();
      });
  };

  const floorPlanBtn = (btnData, icon, btnText) =>
    floorDetail?.status && !floorDetail.plyPath ? (
      <button disabled>
        <i className={icon}></i>
        <div className="switch-group">{btnText}</div>
      </button>
    ) : (
      <button {...btnData}>
        <i className={icon}></i>
        <div className="switch-group">{btnText}</div>
      </button>
    );

  const isScanOkay = () => {
    const isDisable =
      floorDetail?.status === floorScanStatusEnum?.[8]?.id ||
      isScanStatusCompleted ||
      isJobOrderStatusCompleted ||
      scanIsOkayInProgress
        ? true
        : null;
    return (
      <li
        style={{ padding: "12px" }}
        className={`wall-thinkness ${isDisable ? "disable" : ""}`}
      >
        <div className="check-btn">
          <label>
            <input
              disabled={isDisable ? true : null}
              type="checkbox"
              onClick={() => {
                setScanIsOkay(!scanIsOkay);
                setShowPopUp(true);
              }}
              name="check"
              checked={scanIsOkay}
            />
            <span>&emsp; Scan is okay?</span>
          </label>
        </div>
      </li>
    );
  };

  const markScanIsOkayFn = (isOkay) => {
    if (isOkay) {
      dispatch(markScanIsOkay(floorDetail?.floorScanId))
        .then((response) => {
          customToast.success("Floor scan verification submitted successfully");
        })
        .finally(() => {
          setShowPopUp(false);
          setRefresh(!refresh);
        });
    } else {
      setScanIsOkay(isOkay);
    }
  };

  useEffect(() => {
    setScanIsOkay(vsiScanIsOkay);
  }, [vsiScanIsOkay]);

  useEffect(() => {
    if (
      !_.isEmpty(scanId) &&
      (showRescanSidebar || showRequestRescanHistoryModal)
    ) {
      dispatch(getRequestRescanHistory(scanId));
    }
  }, [showRescanSidebar, showRequestRescanHistoryModal]);

  useEffect(() => {
    if (images.length < 1) {
      return;
    }
    const newImageURL = [];
    images.forEach((image) => {
      const obj = {};
      obj.original = URL.createObjectURL(image);
      obj.key = image;
      newImageURL.push(obj);
    });
    setImagesURLs([...imagesURLs, ...newImageURL]);
  }, [images]);

  useEffect(() => {
    setMarkupImageCount(imagesURLs?.length);
  }, [imagesURLs]);

  const [invalidFileVisualAidMessage, setInvalidFileVisualAidMessage] =
    useState(false);
  const onImageChange = (e) => {
    setInvalidFileVisualAidMessage(false);
    const file = e?.target?.files[0];
    if (file) {
      if (!validateAttachImageType(file)) {
        if (e != null) {
          e.target.value = null;
        }
        setInvalidFileVisualAidMessage(true);
        return;
      }
    }
    setImages([...e.target.files]);
    if (e != null) {
      e.target.value = null;
    }
  };
  const onSaveMarkUpImages = () => {
    setShowAddMarkupImgModal(false);
  };
  const closeSideReqRescanModal = () => {
    setImages([]);
    setImagesURLs([]);
    setMarkupImageCount(0);
    setShowRescanSidebar(false);
  };
  const closeCenterReqScanModal = () => {
    setShowAddMarkupImgModal(false);
  };
  const viewImage = (imgIndex) => {
    toggleViewImage();
    setSelectedImageIndexForView(imgIndex);
  };
  const deleteImage = (imgSrc) => {
    const filteredDeleteImg = imagesURLs.filter(
      (img) => img.original !== imgSrc.original
    );
    setImagesURLs([...filteredDeleteImg]);
  };
  const toggleViewImage = () => {
    setEnableImageView(!enableImageView);
  };
  const isScanStatusCompleted =
    floorDetail?.status?.toLowerCase()?.trim() === "completed";

  const isJobOrderStatusCompleted =
    floorDetail?.jobOrderStatus?.toLowerCase()?.trim() === "completed";

  return (
    <>
      <section className="content-wapper">
        <div className="breadcrumb">
          <ul>
            <li>
              <Link to="/">
                <button>Job Orders</button>
              </Link>
            </li>
            {!!floorDetail.orderNumber && (
              <li>
                <Link to={`/my-job-orders/${floorDetail.jobOrderId}`}>
                  <button>{floorDetail.orderNumber}</button>
                </Link>
              </li>
            )}
            {!!floorDetail.floorScanNumber && (
              <li>{floorDetail.floorScanNumber}</li>
            )}
          </ul>
        </div>
        {showAddMarkupImgModal && (
          <div className="center-modal open">
            {enableImageView && (
              <ViewImage
                selectedImageIndexForView={selectedImageIndexForView}
                imageList={imagesURLs}
                toggleViewImage={toggleViewImage}
              ></ViewImage>
            )}
            <div className="inner-modal big-area">
              <div className="comman-modal-main">
                <div className="side-head">
                  Request Rescan
                  <button
                    className="close-modal"
                    onClick={closeCenterReqScanModal}
                  >
                    <i className="icon-close-image"></i>
                  </button>
                </div>
                <div className="modal-body">
                  <div>
                    <b>Note:</b> File extension must be jpg, JPG, jpeg, JPEG,
                    png, PNG
                  </div>
                  <div className="captured-images">
                    <ul className="list scroll-bar-style">
                      {imagesURLs &&
                        _.map(imagesURLs, (imgSrc, id) => (
                          <li key={id}>
                            <div className="saved-images-box">
                              <div className="images-box">
                                <div className="viewbtn">
                                  <button onClick={() => viewImage(id)}>
                                    <i className="icon-eye"></i>
                                  </button>
                                  <button
                                    className="btndelete"
                                    onClick={() => deleteImage(imgSrc)}
                                  >
                                    <i className="icon-delete"></i>
                                  </button>
                                </div>
                                <img src={imgSrc.original} />
                              </div>
                            </div>
                          </li>
                        ))}
                      <li>
                        <label className="attachfiles">
                          <input
                            className="fileinput"
                            type="file"
                            multiple
                            accept="image/jpeg, image/png"
                            onChange={onImageChange}
                          />
                          <i className="app-icon-plus-attachment"></i>
                        </label>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="model-footer ">
                  {invalidFileVisualAidMessage && (
                    <div className="danger-visual-aid-message">
                      Please select a valid file
                    </div>
                  )}
                  <button className="blue-btn" onClick={onSaveMarkUpImages}>
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        <div
          className={
            showRescanSidebar
              ? "comman-modal right-side open"
              : "comman-modal right-side "
          }
        >
          <div className="comman-modal-main">
            <div className="side-head">
              Request Rescan
              <button
                className="close-modal"
                onClick={() => closeSideReqRescanModal()}
              >
                <i className="icon-close-image"></i>
              </button>
            </div>
            <div className="comman-modal-body attach-document-modal scroll-bar-style">
              <form className="">
                <div className="form-group markup-group-form ">
                  <label className="markup-group">
                    <span>Reason</span>
                    <span
                      className="markup-link"
                      onClick={() => {
                        setShowAddMarkupImgModal(true);
                        setInvalidFileVisualAidMessage(false);
                      }}
                    >
                      Add Visual Aids
                    </span>
                  </label>
                  <div className="markup-main-grp">
                    <textarea
                      name="floorPlanFailedReason"
                      className="form-control"
                      rows="5"
                      placeholder="Reason"
                      value={values.floorPlanFailedReason}
                      onChange={handleChange}
                      onBlur={handleBlur}
                    ></textarea>
                    <label className="markup-group">
                      <span className="markup-color">
                        {`${markupImageCount} Attached Visual Aids`}
                      </span>{" "}
                      <span className="number">
                        {values?.floorPlanFailedReason?.length ?? 0}/
                        {CHAR_LIMIT}
                      </span>
                    </label>
                  </div>
                  {(errors.floorPlanFailedReason ||
                    (errors.floorPlanFailedReason &&
                      touched.floorPlanFailedReason)) && (
                    <div className="form-error">
                      {errors.floorPlanFailedReason}
                    </div>
                  )}
                </div>
              </form>
              <div className="button-group text-center">
                <Button
                  disabled={!dirty || !isValid}
                  type="submit"
                  className="blue-btn"
                  onClick={handleSubmit}
                >
                  {t("BUTTONS.Submit")}
                  {submitloading && <div className="loader-spin"></div>}
                </Button>
              </div>
              <RequestRescanHistory
                setRequestRescanHistoryImagesModalData={
                  setRequestRescanHistoryImagesModalData
                }
                setShowRequestRescanHistoryImagesModal={
                  setShowRequestRescanHistoryImagesModal
                }
              />
            </div>
          </div>
        </div>
        {showRequestRescanHistoryImagesModal && (
          <RequestRescanHistoryImages
            requestRescanHistoryImagesModalData={
              requestRescanHistoryImagesModalData
            }
            setRequestRescanHistoryImagesModalData={
              setRequestRescanHistoryImagesModalData
            }
            setShowRequestRescanHistoryImagesModal={
              setShowRequestRescanHistoryImagesModal
            }
          />
        )}
        <div
          className={
            showRequestRescanHistoryModal
              ? "comman-modal right-side open"
              : "comman-modal right-side "
          }
        >
          <div className="comman-modal-main">
            <div className="side-head">
              {t("Request_Rescan_History")}
              <button
                className="close-modal"
                onClick={() => {
                  setShowRequestRescanHistoryModal(false);
                  setRequestRescanHistoryImagesModalData(null);
                }}
              >
                <i className="icon-close-image"></i>
              </button>
            </div>
            <RequestRescanHistory
              setRequestRescanHistoryImagesModalData={
                setRequestRescanHistoryImagesModalData
              }
              setShowRequestRescanHistoryImagesModal={
                setShowRequestRescanHistoryImagesModal
              }
            />
          </div>
        </div>
        <div className="common-panel measurement-segment">
          <div className="panel-body job-details-wapper">
            <div className="custom-tab">
              <div className="right-side right-side-buttons">
                <ul className="dropdown-menu-btn">
                  <li className="menu-more">
                    <button className="blue-btn">
                      <div className="switch-group">Complete floor plan</div>
                      <i className="icon-drop-bottom drop-button-aero-white"></i>
                    </button>
                    <ul>
                      {toggle ? (
                        !!floorDetail.status &&
                        floorDetail.status !== STATUS.FLOORPLAN_FAILED ? (
                          floorDetail.floorPlanViewPath ? (
                            <>
                              <li className="wall-thinkness">
                                <button onClick={handleComplete}>
                                  <i className="icon-Floor-plan-success green-icon"></i>
                                  <div className="switch-group">
                                    Floor Plan Success
                                  </div>
                                </button>
                              </li>
                              <li className="wall-thinkness">
                                <button
                                  onClick={() => setShowRescanSidebar(true)}
                                >
                                  <i className="icon-Floor-plan-failed red-icon"></i>
                                  <div className="switch-group">
                                    Request Rescan
                                  </div>
                                </button>
                              </li>
                            </>
                          ) : (
                            <>
                              <li className="wall-thinkness">
                                <button disabled onClick={handleComplete}>
                                  <i className="icon-Floor-plan-success green-icon"></i>
                                  <div className="switch-group">
                                    Floor Plan Success
                                  </div>
                                </button>
                              </li>
                              <li className="wall-thinkness">
                                <button
                                  onClick={() => setShowRescanSidebar(true)}
                                >
                                  <i className="icon-Floor-plan-failed red-icon"></i>
                                  <div className="switch-group">
                                    Request Rescan
                                  </div>
                                </button>
                              </li>
                            </>
                          )
                        ) : (
                          <>
                            <li className="wall-thinkness">
                              <button disabled onClick={handleComplete}>
                                <i className="icon-Floor-plan-success green-icon"></i>
                                <div className="switch-group">
                                  Floor Plan Success
                                </div>
                              </button>
                            </li>
                            <li className="wall-thinkness">
                              <button
                                onClick={() => setShowRescanSidebar(true)}
                              >
                                <i className="icon-Floor-plan-failed red-icon"></i>
                                <div className="switch-group">
                                  Request Rescan
                                </div>
                              </button>
                            </li>
                          </>
                        )
                      ) : (
                        <>
                          <li className="wall-thinkness">
                            <button onClick={handleComplete}>
                              <i className="icon-Floor-plan-success green-icon"></i>
                              <div className="switch-group">
                                Floor Plan Success
                              </div>
                            </button>
                          </li>
                          <li className="wall-thinkness">
                            <button onClick={() => setShowRescanSidebar(true)}>
                              <i className="icon-Floor-plan-failed red-icon"></i>
                              <div className="switch-group">Request Rescan</div>
                            </button>
                          </li>
                        </>
                      )}
                      {(floorDetail?.jobOrderSource?.trim()?.toLowerCase() ===
                        "vsi" ||
                        floorDetail?.jobOrderSource?.trim()?.toLowerCase() ===
                          "virtual_appraisal") &&
                        isScanOkay()}
                      <li className="wall-thinkness">
                        <button
                          onClick={() => {
                            setShowRequestRescanHistoryModal(true);
                          }}
                        >
                          <i className="icon-Time"></i>
                          <div className="switch-group">
                            {t("Rescan_History")}
                          </div>
                        </button>
                      </li>
                    </ul>
                  </li>
                  <li className="menu-more">
                    <button className="blue-btn">
                      <div className="switch-group">Download Files</div>
                      <i className="icon-drop-bottom drop-button-aero-white"></i>
                    </button>
                    <ul>
                      <li className="wall-thinkness">
                        <button
                          className={`${!floorDetail.plyPath ? "disable" : ""}`}
                          disabled={!floorDetail.plyPath}
                          onClick={() => downloadFile(floorDetail.plyPath)}
                        >
                          <i className="icon-Download-ply-file"></i>
                          Download .ply
                        </button>
                      </li>
                      <li className="wall-thinkness">
                        <button
                          className={`${!floorDetail.zipPath ? "disable" : ""}`}
                          disabled={!floorDetail.zipPath}
                          onClick={() => downloadFile(floorDetail.zipPath)}
                        >
                          {floorDetail.floorScanType ==
                          floorScanType[0].value ? (
                            <>
                              <img
                                src={objFileIcon}
                                alt="ObjFile"
                                style={{ width: "12px", marginRight: "5px" }}
                              />
                              Download OBJ
                            </>
                          ) : (
                            <>
                              <i className="icon-Download-Video"></i>
                              Download Video
                            </>
                          )}
                        </button>
                      </li>
                      <li className="wall-thinkness">
                        <button
                          className={`${!floorDetail.pdfPath ? "disable" : ""}`}
                          disabled={!floorDetail.pdfPath}
                          onClick={() => downloadFile(floorDetail.pdfPath)}
                        >
                          <i className="icon-Download-PDF"></i>
                          Download PDF
                        </button>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>

              <ul className="tab-list">
                <li className={toggle ? "active" : ""}>
                  <button
                    onClick={() => {
                      setToggle(true);
                    }}
                  >
                    View 2D Floor Plan
                  </button>
                </li>
                <li className={toggle ? "" : "active"}>
                  <button
                    onClick={() => {
                      setToggle(false);
                    }}
                  >
                    Explore 3D Space
                  </button>
                </li>
              </ul>
              {toggle ? (
                <div className="tab-content open">
                  <div className="measurement-document">
                    <div className="measurement-head">
                      <div className="menu-list">
                        <div className="menu-items">
                          <ul className="menu-list-plan">
                            <li>
                              {floorPlanBtn(
                                {
                                  onClick: onFileUpload,
                                },
                                "icon-Floor-Plan",
                                "Upload Floor Plan"
                              )}
                            </li>
                            <li>
                              <input
                                type="file"
                                ref={pdfFileRef}
                                hidden
                                accept=".pdf"
                                onChange={(e) =>
                                  handleFileUpload(e, validateAttachPDFType)
                                }
                              />
                              {floorPlanBtn(
                                {
                                  onClick: onPDFFileUpload,
                                },
                                "icon-Upload-PDF",
                                "Upload PDF"
                              )}
                            </li>
                          </ul>
                        </div>
                        <div className="select-floor">
                          <div className="button-view text-right">
                            <input
                              type="file"
                              ref={fileRef}
                              hidden
                              accept="image/*"
                              onChange={(e) =>
                                handleFileUpload(e, validateAttachImageType)
                              }
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="measurement-view">
                      {floorDetail.floorPlanViewPath ? (
                        <div
                          style={{ width: "90%" }}
                          className="image_content zoom-level-image"
                        >
                          <AsyncImage
                            zoomLevel={zoomLevel}
                            imageUrl={floorDetail.floorPlanViewPath}
                          />
                          <div
                            className="zoom_outer theme_white"
                            style={{ display: "block" }}
                          >
                            <span className="zoom-level">Zoom Level</span>
                            <div className="zoom_main">
                              <div className="level">
                                <label>
                                  <input
                                    type="radio"
                                    name="zoomlevel"
                                    value="3(3x)"
                                    onClick={() => setZoomLevel("3")}
                                  />
                                  <span>3X</span>
                                </label>
                              </div>
                              <div className="level">
                                <label>
                                  <input
                                    type="radio"
                                    name="zoomlevel"
                                    value="2(2x)"
                                    onClick={() => setZoomLevel("2")}
                                  />
                                  <span>2X</span>
                                </label>
                              </div>
                              <div className="level">
                                <label>
                                  <input
                                    type="radio"
                                    name="zoomlevel"
                                    className="checked"
                                    value="1(1x)"
                                    onClick={() => setZoomLevel("1")}
                                    checked={zoomLevel === "1" ?? "checked"}
                                  />
                                  <span>1X</span>
                                </label>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="no-data-found-container">
                          <NoDataView
                            text={t(
                              "COMMON_MESSAGES.JOB_ORDER_DETAILS.TWO_D_FLOOR_PLAN"
                            )}
                            icon={FLOORPLANS_ICON}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <View3DFloorPlan
                  id={scanId}
                  floorDetail={floorDetail}
                  setExplorePlanInstruction={setExplorePlanInstruction}
                  setMeasurementInstruction={setMeasurementInstruction}
                  screenCapturedPopupShow={isCapturedPopUp}
                  setScreenCapturedPopup={setIsCapturedPopUp}
                  setMarkupImageURL={setMarkupImageURL}
                />
              )}
            </div>
          </div>
        </div>
        <InstructionModal
          explorePlanInstruction={explorePlanInstruction}
          setExplorePlanInstruction={setExplorePlanInstruction}
          measurementInstruction={measurementInstruction}
          setMeasurementInstruction={setMeasurementInstruction}
        />
        {isCapturedPopUp && (
          <MarkupView
            screenCapturedPopupShow={isCapturedPopUp}
            setScreenCapturedPopup={setIsCapturedPopUp}
            markupImageURL={markupImageURL}
            incomingMarkupAnnotationObject={incomingMarkupAnnotationObject}
            setIncomingMarkupAnnotationObject={
              setIncomingMarkupAnnotationObject
            }
            markupPathCreated={markupPathCreated}
            markupShapeAdded={markupShapeAdded}
            markupShapeMoved={markupShapeMoved}
            markupUndo={markupUndo}
            markupRedo={markupRedo}
            markupClear={markupClear}
            markupClose={markupClose}
            userMarkupObjectArray={userMarkupObjectArray}
            globalMarkupObjectArray={globalMarkupObjectArray}
            userUndoObjectArray={userUndoObjectArray}
            markupViewStartedBy={markupViewStartedBy}
            saveMarkupImage={saveMarkupImage}
          />
        )}
        {showPopUp && scanIsOkay && (
          <ConfirmationModal
            cancelEvent={() => {
              markScanIsOkayFn(false);
            }}
            title={t(MARK_SCAN_AS_OKAY)}
            cancelText={t("COMMON_MESSAGES.No")}
            confirmText={t("COMMON_MESSAGES.Yes")}
            confirmEvent={() => {
              markScanIsOkayFn(true);
            }}
          ></ConfirmationModal>
        )}
      </section>
    </>
  );
}

const mapStateToProps = (state) => {
  return {
    downloadZip: state.downloadZip,
  };
};

export default connect(mapStateToProps, {
  downloadZip,
})(View2DFloorPlan);
