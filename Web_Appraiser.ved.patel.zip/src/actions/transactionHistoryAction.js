import * as actionTypes from "../actions/actionTypes";
import transactionHistoryService from "../services/transactionHistoryService";
import { StartLoading, StopLoading } from "./UIAction";

const fetchTransactionHistoryStart = () => {
  return {
    type: actionTypes.FETCH_TRANSACTION_HISTORY_START,
  };
};

const fetchTransactionHistorySuccess = (data) => {
  return {
    type: actionTypes.FETCH_TRANSACTION_HISTORY_SUCCESS,
    payload: data,
  };
};

const fetchTransactionHistoryError = (error) => {
  return {
    type: actionTypes.FETCH_TRANSACTION_HISTORY_ERROR,
    payload: error,
  };
};

export const fetchTransactionHistory = (data) => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(fetchTransactionHistoryStart());
  return transactionHistoryService
    .fetchTransactionHistory(data)
    .then((response) => {
      dispatch(StopLoading());
      return dispatch(fetchTransactionHistorySuccess(response));
    })
    .catch((error) => {
      dispatch(StopLoading());
      dispatch(fetchTransactionHistoryError(error));
      throw error;
    });
};

const fetchTransactionStatusStart = () => {
  return {
    type: actionTypes.FETCH_TRANSACTION_STATUS_START,
  };
};

const fetchTransactionStatusSuccess = (data) => {
  return {
    type: actionTypes.FETCH_TRANSACTION_STATUS_SUCCESS,
    payload: data,
  };
};

const fetchTransactionStatusError = (error) => {
  return {
    type: actionTypes.FETCH_TRANSACTION_STATUS_ERROR,
    payload: error,
  };
};

export const fetchTransactionStatus = (data) => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(fetchTransactionStatusStart());
  return transactionHistoryService
    .fetchTransactionStatus(data)
    .then((response) => {
      dispatch(StopLoading());
      return dispatch(fetchTransactionStatusSuccess(response));
    })
    .catch((error) => {
      dispatch(StopLoading());
      dispatch(fetchTransactionStatusError(error));
      throw error;
    });
};

const exportTransactionHistoryStart = () => {
  return {
    type: actionTypes.EXPORT_TRANSACTION_HISTORY_START,
  };
};

const exportTransactionHistorySuccess = (data) => {
  return {
    type: actionTypes.EXPORT_TRANSACTION_HISTORY_SUCCESS,
    payload: data,
  };
};

const exportTransactionHistoryError = (error) => {
  return {
    type: actionTypes.EXPORT_TRANSACTION_HISTORY_ERROR,
    payload: error,
  };
};

export const exportTransactionHistory = (data) => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(exportTransactionHistoryStart());
  return transactionHistoryService
    .exportTransactionHistory(data)
    .then((response) => {
      dispatch(StopLoading());
      dispatch(exportTransactionHistorySuccess());
      return response;
    })
    .catch((error) => {
      dispatch(StopLoading());
      dispatch(exportTransactionHistoryError(error));
      throw error;
    });
};
