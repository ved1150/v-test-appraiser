import React, { useEffect, useState } from "react";
import _ from "lodash";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import NoDataView from "../Common/noDataView";
import { ATTACHMENTS, ATTACHMENTS_ICON } from "./../Common/commonText";
import { getUTCToLocalDateTimeWithFormat } from "../../../../helpers";
import {
  DATE_FORMAT,
  DATE_TIME_API_FORMAT,
} from "./../../../../constants/appConstant";
import Button from "./../../../common/Button";
import { customToast } from "./../../../../helpers/customToast";
import { ATTACHMENT_DOWNLOAD_MESSSAGE } from "./../../../../constants/commonMessages";
import "./attachmentTab.scss";
import { useTranslation } from "react-i18next";

const AttachmentTab = (props) => {
  const { t } = useTranslation();
  const tableHead = [
    { key: "checkbox", label: "", checkAll: true },
    { key: "fileName", label: t("WEB_LABELS.Document_Name") },
    {
      key: "updatedBy",
      label: t("WEB_LABELS.Uploaded_By"),
    },
    { key: "updatedAt", label: t("WEB_LABELS.Uploaded_On") },
    { key: "size", label: t("WEB_LABELS.File_Size_Attachment") },
    { key: "action", label: "", disableSorting: true },
  ];

  const [sortBy, setSortBy] = useState("updatedAt");
  const [direction, setDirection] = useState("desc");
  const [attachmentList, setAttachmentList] = useState([]);
  const [downloadList, setDownloadList] = useState([]);
  const [checkAll, setCheckAll] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [fetchDone, setFetchDone] = useState(false);

  useEffect(() => {
    let isSubscribed = true;
    const filter = {
      direction,
      sortBy,
      jobOrderId: props.jobOrderId,
    };
    setFetchDone(false);
    props
      .loadAttachments(filter)
      .then((data) => isSubscribed && setAttachmentList(data))
      .catch((err) => isSubscribed && setAttachmentList([]))
      .finally(() => {
        setFetchDone(true);
      });
    return () => (isSubscribed = false);
  }, [sortBy, direction, props.isRefreshAttachments]);

  const handleSorting = (cellId) => {
    const isAsc = sortBy === cellId && direction === "desc";
    setDirection(isAsc ? "asc" : "desc");
    setSortBy(cellId);
  };

  const downloadAttachment = ({ fileName, attachmentId }) => {
    props.downloadAttachment(attachmentId).then((data) => {
      const blob = new Blob([data.data], {
        type: data.headers["content-type"],
      });
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob);
        return;
      }
      const url = URL.createObjectURL(blob);
      let link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
    deselectAllAttachments();
  };

  const formatTime = (date) => {
    return getUTCToLocalDateTimeWithFormat(
      date,
      DATE_TIME_API_FORMAT,
      DATE_FORMAT
    );
  };

  const deselectAllAttachments = () => {
    const items = [...attachmentList.map((i) => ({ ...i, checked: false }))];
    setAttachmentList(items);
    setCheckAll(false);
  };

  const selectAllAttachments = (e) => {
    const { checked } = e.target;
    setCheckAll(checked);
    const items = [...attachmentList.map((i) => ({ ...i, checked }))];
    setAttachmentList(items);
    !!checked ? setDownloadList(items) : setDownloadList([]);
  };

  const selectOneAttachment = (item, id, e) => {
    const { checked } = e.target;
    if (!!!checked) {
      setDownloadList([
        ...downloadList.filter((i) => i.attachmentId != item.attachmentId),
      ]);
      const items = [...attachmentList];
      items.splice(id, 1, { ...item, checked: false });
      setAttachmentList(items);
    } else {
      setDownloadList([...downloadList, item]);
      const items = [...attachmentList];
      items.splice(id, 1, { ...item, checked: true });
      setAttachmentList(items);
    }
  };

  useEffect(() => {
    const lengthCheck = attachmentList.length === downloadList.length;
    const downCheck = downloadList.length > 0;
    setCheckAll(lengthCheck && downCheck);
  }, [downloadList]);

  const onDownloadAll = () => {
    const selectedForDownload = attachmentList.filter((i) => !!i.checked);
    const attachmentIds = selectedForDownload.map((i) => i.attachmentId);
    if (selectedForDownload.length !== 0) {
      setSubmitting(true);
      props
        .downloadAttachments({
          joborder_id: props.jobOrderId,
          selected_file_uuid: attachmentIds,
        })
        .then((res) => {
          setSubmitting(false);
          const disposition = res.request.getResponseHeader(
            "Content-Disposition"
          );
          let fileName = "";
          let filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
          let matches = filenameRegex.exec(disposition);
          if (matches != null && matches[1]) {
            fileName = matches[1].replace(/['"]/g, "");
          }

          const contentType = _.get(res, ["headers", "content-type"]);
          const blob = new Blob([res.data], { type: contentType });
          if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob);
            return;
          }
          const url = window.URL.createObjectURL(blob);
          let link = document.createElement("a");
          link.href = url;
          link.setAttribute("download", fileName);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          deselectAllAttachments();
          setDownloadList([]);

          customToast.success(ATTACHMENT_DOWNLOAD_MESSSAGE);
        });
    }
  };

  return (
    <>
      <div className="attach-document">
        <div className="button-view text-right">
          <Button
            className="blue-btn"
            onClick={() => props.setAttachmentDocumentModalVisible(true)}
          >
            <i className="icon-Attach-Document"></i>
            {t("BUTTONS.Attach_Document")}
          </Button>
          <Button
            className="blue-btn"
            disabled={downloadList.length === 0 || submitting}
            onClick={() => onDownloadAll()}
          >
            {!!!checkAll ? t("BUTTONS.Download") : t("BUTTONS.Download_All")}{" "}
            {submitting && <div className="loader-spin"></div>}
          </Button>
        </div>
        {!fetchDone || _.size(attachmentList) === 0 ? (
          <div className="no-data-found-container">
            {!fetchDone ? (
              <div className="no-data-found">
                <div className="box">
                  <div className="loader-spin"></div>
                </div>
              </div>
            ) : (
              <NoDataView
                text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.ATTACHMENTS")}
                icon={ATTACHMENTS_ICON}
              />
            )}
          </div>
        ) : (
          <div className="scroll-bar-style">
            <TableContainer>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    {tableHead.map((head, key) => (
                      <TableCell
                        key={key}
                        sortDirection={sortBy === head.key ? direction : false}
                      >
                        {head.checkAll ? (
                          <div className="check-btn">
                            <label>
                              <input
                                type="checkbox"
                                onChange={(e) => selectAllAttachments(e)}
                                id={"checkAll"}
                                name="checkAll"
                                checked={checkAll}
                              />
                              <span></span>
                            </label>
                          </div>
                        ) : head.disableSorting ? (
                          head.label
                        ) : (
                          <TableSortLabel
                            active={sortBy === head.key}
                            direction={sortBy === head.key ? direction : "asc"}
                            onClick={() => {
                              handleSorting(head.key);
                            }}
                          >
                            {head.label}
                          </TableSortLabel>
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {attachmentList.map((d, id) => (
                    <TableRow key={id}>
                      <TableCell>
                        <div className="check-btn">
                          <label>
                            <input
                              type="checkbox"
                              onChange={(e) => selectOneAttachment(d, id, e)}
                              id={id}
                              name="check"
                              checked={d.checked || false}
                            />
                            <span></span>
                          </label>
                        </div>
                      </TableCell>
                      <TableCell>{d.fileName}</TableCell>
                      <TableCell>{d.updatedBy}</TableCell>
                      <TableCell>{formatTime(d.updatedAt)}</TableCell>
                      <TableCell>
                        {(d.fileSize / (1024 * 1024)).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <button
                          className="download"
                          disabled={submitting && d.checked}
                          onClick={() => downloadAttachment(d)}
                        >
                          <i className="icon-download"></i>
                          <span>{t("BUTTONS.Download")}</span>
                        </button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        )}
      </div>
    </>
  );
};
export default AttachmentTab;
