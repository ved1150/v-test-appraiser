import * as actionTypes from "../actions/actionTypes";

const defaultState = { downloadFilePercentage: 0 };

export default (state = defaultState, action = {}) => {
  switch (action.type) {
    case actionTypes.DOWNLOAD_FILE_START:
      return {
        ...state,
        downloadFilePercentage: action.payload,
        fileDownloaded: false,
      };
    case actionTypes.DOWNLOAD_FILE_STOP:
      return {
        ...state,
        downloadFilePercentage: 0,
        fileDownloaded: true,
      };
    default:
      return state;
  }
};
