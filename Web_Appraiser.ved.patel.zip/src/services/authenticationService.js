import api from "./apis/api";
import sessionStorage from "./sessionStorage";
import localStorage from "./storage";
import {
  dehydrateSignIn,
  hydratePostLogin,
  hydrateLogin,
  dehydrateForgotPassword,
  dehydrateResetPassword,
  hydrateSwitchTechnician,
  hydrateStates,
} from "./transformers/authenticationTransformer";
import { storageTypes } from "./../constants/appConstant";

const TOKEN = "token";
const USERID = "userId";
const STORAGETYPE = "storageType";
const LOGINTYPE = "loginType";
const USER_ROLE = "role";
const AUTH_DATA = "auth";
const TENANT = "tenant";
const IS_TOKEN_EXPIRED = "isTokenExpired";
class AuthenticationService {
  setToken(value) {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      sessionStorage.set(TOKEN, value);
    } else {
      localStorage.set(TOKEN, value);
    }
  }
  encryptData(data) {
    if (data) {
      return Buffer.from(data).toString("base64");
    }
  }
  decryptData(data) {
    if (data) {
      return Buffer.from(data, "base64").toString("ascii");
    }
  }
  getToken() {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      return sessionStorage.get(TOKEN);
    } else {
      return localStorage.get(TOKEN);
    }
  }

  setUserId(value) {
    return sessionStorage.set(USERID, value);
  }

  getUserId() {
    return sessionStorage.get(USERID);
  }

  setStorageType(value) {
    sessionStorage.set(STORAGETYPE, value);
  }

  getStorageType() {
    return sessionStorage.get(STORAGETYPE);
  }

  getStates() {
    return api.authentication.fetchStates().then(hydrateStates);
  }

  setLoginType(value) {
    localStorage.set(LOGINTYPE, value);
  }

  getLoginType() {
    return localStorage.get(LOGINTYPE);
  }
  setUserRole(value) {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      sessionStorage.set(USER_ROLE, this.encryptData(value));
    } else {
      localStorage.set(USER_ROLE, this.encryptData(value));
    }
  }
  getUserRole() {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      return this.decryptData(sessionStorage.get(USER_ROLE));
    } else {
      return this.decryptData(localStorage.get(USER_ROLE));
    }
  }
  setAuthData(value) {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      sessionStorage.set(AUTH_DATA, this.encryptData(value));
    } else {
      localStorage.set(AUTH_DATA, this.encryptData(value));
    }
  }
  getEncAuthData() {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      return sessionStorage.get(AUTH_DATA);
    } else {
      return localStorage.get(AUTH_DATA);
    }
  }
  getDecAuthData(enc) {
    return this.decryptData(enc);
  }
  removeAuthData() {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      return sessionStorage.remove(AUTH_DATA);
    } else {
      return localStorage.remove(AUTH_DATA);
    }
  }
  fetchToken(data) {
    return api.authentication.fetchToken(data).then(hydratePostLogin);
  }

  logIn(formData, headerData) {
    return api.authentication
      .logIn(dehydrateSignIn(formData), headerData)
      .then(hydrateLogin);
  }

  forgotPassword(formData) {
    return api.authentication.forgotPassword(dehydrateForgotPassword(formData));
  }
  resetPassword(formData) {
    return api.authentication.resetPassword(dehydrateResetPassword(formData));
  }

  signOut() {
    return api.authentication.signOut();
  }

  fetchLink(payload) {
    return api.authentication.fetchLink(payload);
  }

  switchTenant(tenantSubdomain, headerData) {
    return api.authentication
      .switchTenant(tenantSubdomain, headerData)
      .then(hydrateLogin);
  }
  setTenantDetails(value) {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      sessionStorage.set(TENANT, this.encryptData(value));
    } else {
      localStorage.set(TENANT, this.encryptData(value));
    }
  }
  getTenantDetails() {
    if (sessionStorage.get(STORAGETYPE) == storageTypes.sessionStorage) {
      return this.decryptData(sessionStorage.get(TENANT));
    } else {
      return this.decryptData(localStorage.get(TENANT));
    }
  }
  switchTechnician(headerData, subDomain) {
    return api.authentication
      .switchTechnician(headerData, subDomain)
      .then(hydrateSwitchTechnician);
  }
}

export default new AuthenticationService();
