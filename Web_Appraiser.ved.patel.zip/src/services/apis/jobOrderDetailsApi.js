import api from "./api";

export default class JobOrderDetailsApi {
  completeJO(jobOrderData, joborderId) {
    return api.putMultipartFormData(`/joborder/complete`, jobOrderData);
  }

  setPrimaryPictureForReportPDF(data) {
    return api.put("/joborder/primary-picture", data);
  }
}
