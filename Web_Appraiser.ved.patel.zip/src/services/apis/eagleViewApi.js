import api from "./api";

export default class EagleViewAPI {
  createOrder(data) {
    return api.get(`/joborders/${data}/process`);
  }

  getImages(data) {
    return api.get(`/eagleview/${data}`);
  }
}
