/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect, useCallback, useRef } from "react";
import { connect } from "react-redux";
import _ from "lodash";
import Tooltip from "@mui/material/Tooltip";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Pagination from "@mui/material/Pagination";
import { useTranslation } from "react-i18next";
import { getTechnicianJobOrders } from "../../../actions/technicianJobAction";
import "./index.scss";
import { jobOrdersPerPage } from "../../../constants/appConstant";
import Button from "../../common/Button";
import NoDataView from "../../JobOrders/JobOrderDetails/Common/noDataView";
import { JOB_ORDERS_ICON } from "../../JobOrders/JobOrderDetails/Common/commonText";
import TextInput from "../../common/TextInput";
import { floorScanStatusEnum } from "../../../constants/enums";
import { TableSortLabel } from "@mui/material";
import store from "../../../store";
import { StoreActions } from "../../../actions/jobAction";
import { scrollIntoView } from "../../../helpers";
import CustomPagination from "../../common/CustomPagination";

const TechnicianJobOrders = (props) => {
  const { t } = useTranslation();
  const tableHead = [
    {
      key: "orderNumber",
      label: t("WEB_LABELS.Job_Order_ID"),
      disableSorting: true,
      width: "10%",
    },
    {
      key: "customerName",
      label: t("WEB_LABELS.Customer_Name") + "\n" + t("WEB_LABELS.Address"),
      disableSorting: true,
    },
    {
      key: "jobOrderType",
      label: t("WEB_LABELS.Job_Order_Type"),
      disableSorting: true,
    },
    {
      key: "assignDate",
      label: t("WEB_LABELS.Assigned_Date"),
    },
    {
      key: "latestScanCreatedDate",
      label: t("WEB_LABELS.Last_Scan_Date"),
    },
    {
      key: "floorScanStatusList",
      label: t("WEB_LABELS.Floor_Scan_Status"),
      disableSorting: true,
    },
    {
      key: "jobOrderStatus",
      label: t("WEB_LABELS.Job_Order_Status"),
      disableSorting: true,
    },
    {
      key: "action",
      label: t("WEB_LABELS.Action"),
      disableSorting: true,
    },
  ];
  const [pageNo, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [startPoint, setStartPoint] = useState(1);
  const [endPoint, setEndPoint] = useState(pageSize);
  const [offset, setOffset] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [refreshJobOrder, setRefreshJoborder] = useState(false);
  const [jobOrderList, setJobOrderList] = useState([]);
  const [searchInpValue, setSearchInpValue] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("latestScanCreatedDate");
  const [direction, setDirection] = useState("desc");
  const [fetchDone, setFetchDone] = useState(false);
  const scrollableListRef = useRef();

  useEffect(() => {
    const filter = {
      pageNo,
      pageSize,
      sortBy,
      direction,
    };

    if (searchTerm) {
      filter.searchText = searchTerm;
    }

    const actionFilter = _.get(
      props,
      ["job", "storeActionsData", "jobOrders"],
      {}
    );
    if (actionFilter?.jobOrderId) {
      if (actionFilter?.searchText) {
        setSearchInpValue(actionFilter?.searchText);
        setSearchTerm(actionFilter?.searchText);
        filter.searchText = actionFilter?.searchText;
      }
      setOffset(actionFilter?.offset);
      setCurrentPage(actionFilter?.pageNo);
      setSortBy(actionFilter?.sortBy);
      setDirection(actionFilter?.direction);
      setStartPoint(actionFilter?.startPoint);
      setEndPoint(actionFilter?.endPoint);
      setPageSize(actionFilter?.pageSize);
      filter.pageNo = actionFilter?.pageNo;
      filter.pageSize = actionFilter?.pageSize;
      filter.sortBy = actionFilter?.sortBy;
      filter.direction = actionFilter?.direction;
    }

    setFetchDone(false);
    if (
      filter.pageNo == pageNo &&
      filter.pageSize == pageSize &&
      (filter.searchText ? filter.searchText == searchInpValue : true)
    ) {
      props
        .getTechnicianJobOrders(filter)
        .then((res) => {
          if (res) {
            setJobOrderList(res.data);
            const count = _.get(res, ["pagination", "totalCount"], 0);
            setTotalCount(count);
            setStartPoint(parseInt(pageSize * (pageNo - 1) + 1));
            if (pageSize * pageNo > count) {
              setEndPoint(count);
            } else {
              setEndPoint(pageSize * pageNo);
            }
            const totalPage = _.get(res, ["pagination", "totalPage"], 0);
            if (pageNo > totalPage) {
              setCurrentPage(1);
              setOffset(0);
              setStartPoint(1);
            }
          }
        })
        .finally(() => {
          setFetchDone(true);
          setTimeout(() => {
            scrollIntoView(scrollableListRef);
            storeDataInRedux(
              filter,
              actionFilter?.jobOrderId,
              _.get(props, ["job", "storeActionsData", "floorScans"], {})
            );
          }, 10);
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageNo, pageSize, sortBy, direction, refreshJobOrder, searchTerm]);

  const handlePageSize = (e) => {
    storeDataInRedux({});
    setOffset(0);
    setCurrentPage(1);
    setPageSize(e.target.value);
  };

  const handleSorting = (cellId) => {
    const isAsc = sortBy === cellId && direction === "desc";
    storeDataInRedux({});
    setDirection(isAsc ? "asc" : "desc");
    setSortBy(cellId);
  };

  const handlePagination = (event, value) => {
    if (!_.isEqual(value, pageNo)) {
      storeDataInRedux({});
      setOffset(value);
      setCurrentPage(value);
    }
  };

  if (!props.technicianJob.jobOrders) {
    return <section className="content-wapper"></section>;
  }

  const handleJobOrderDetails = (jobOrderId) => {
    storeDataInRedux(
      _.get(props, ["job", "storeActionsData", "jobOrders"], {}),
      jobOrderId,
      true
    );
    props.history.push(`/my-job-orders/${jobOrderId}`);
  };

  // Search Start

  const handleSearchChange = (value) => {
    storeDataInRedux({});
    setSearchTerm(value);
  };

  const debounceSearchFn = useCallback(
    _.debounce((value) => handleSearchChange(value), 500),
    []
  );

  const debouncedSearchChange = (event) => {
    const {
      target: { value },
    } = event;
    setSearchInpValue(value);
    debounceSearchFn(value);
  };

  const storeDataInRedux = (data, jobOrderId = null, floorScans) => {
    store.dispatch(
      StoreActions({
        jobOrders: {
          pageNo: data.pageNo,
          pageSize: data.pageSize,
          sortBy: data.sortBy,
          direction: data.direction,
          searchText: data.searchText,
          jobOrderId: jobOrderId,
          startPoint: startPoint,
          endPoint: endPoint,
          offset: offset,
        },
        floorScans: floorScans,
      })
    );
  };

  // Search End

  return (
    <section className="content-wapper">
      <h1>{t("WEB_LABELS.My_Job_Orders")}</h1>
      <div className="common-panel panel-table-height">
        <div className="panel-body">
          <div className="filter-box">
            <div className="show-entries">
              {t("COMMON_MESSAGES.Show")}
              <select onChange={handlePageSize} value={pageSize}>
                {jobOrdersPerPage.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.displayName}
                  </option>
                ))}
              </select>
              {t("COMMON_MESSAGES.entries")}
            </div>
            <div className="filter-segment">
              <div className="search-box">
                <TextInput
                  className="form-control"
                  type="text"
                  name="search"
                  value={searchInpValue}
                  onChange={debouncedSearchChange}
                  placeholder={t("WEB_LABELS.Search")}
                  icon={
                    <div className="search-icon">
                      <i className="icon-search"></i>
                    </div>
                  }
                />
              </div>
              <div className="filter-button"></div>
            </div>
          </div>
          {fetchDone && totalCount !== 0 ? (
            <TableContainer>
              <Table aria-label="simple table">
                <TableHead>
                  <TableRow>
                    {tableHead.map((head, key) =>
                      head.key === "customerName" ? (
                        <TableCell style={{ width: head.width }} key={key}>
                          <TableSortLabel
                            active={sortBy === head.key}
                            direction={sortBy === head.key ? direction : "asc"}
                            onClick={() => {
                              handleSorting(head.key);
                            }}
                          >
                            <div>
                              <div>{head.label.split("\n")[0]}</div>
                              <div style={{ fontWeight: "normal" }}>
                                {head.label.split("\n")[1]}
                              </div>
                            </div>
                          </TableSortLabel>
                        </TableCell>
                      ) : (
                        <TableCell
                          key={key}
                          sortDirection={
                            sortBy === head.key ? direction : false
                          }
                        >
                          {head.disableSorting ? (
                            head.label
                          ) : (
                            <TableSortLabel
                              active={sortBy === head.key}
                              direction={
                                sortBy === head.key ? direction : "asc"
                              }
                              onClick={() => {
                                handleSorting(head.key);
                              }}
                            >
                              {head.label}
                            </TableSortLabel>
                          )}
                        </TableCell>
                      )
                    )}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {jobOrderList &&
                    jobOrderList.map((d, id) => {
                      const actionJOId = _.get(
                        props,
                        ["job", "storeActionsData", "jobOrders", "jobOrderId"],
                        ""
                      );
                      return (
                        <TableRow
                          ref={
                            d.jobOrderId === actionJOId
                              ? scrollableListRef
                              : null
                          }
                          className={`${
                            d.jobOrderId === actionJOId ? "selected-item" : ""
                          }`}
                          key={d.id}
                        >
                          <TableCell style={{ width: "10%" }} scope="row">
                            {d.orderNumber}
                            <div
                              className={`${
                                d.isDemoJobOrder ? "demo-blue" : "live-green"
                              }`}
                            >
                              {`${d.isDemoJobOrder ? "Demo" : "Live"}`}
                            </div>
                          </TableCell>
                          <TableCell style={{ width: "15%" }}>
                            <div>
                              <b>{d.customerName}</b>
                            </div>
                            <div>{d.address}</div>
                          </TableCell>
                          <TableCell style={{ width: "10%" }}>
                            {d.jobOrderType}
                          </TableCell>
                          <TableCell style={{ width: "15%" }}>
                            {d.technicianAssignDate}
                          </TableCell>
                          <TableCell style={{ width: "15%" }}>
                            {d.latestScanCreatedDate}
                          </TableCell>
                          <TableCell style={{ width: "25%" }}>
                            {d.floorScanStatusList.length ? (
                              <>
                                {d.floorScanStatusList.map(
                                  ({ floorScanStatus, floorScanStatusCount }) =>
                                    floorScanStatus ? (
                                      floorScanStatusEnum?.map(
                                        ({ id, valTechnician, color }, index) =>
                                          floorScanStatus === id && (
                                            <div
                                              className={`card-chips ${color}`}
                                            >
                                              {valTechnician}
                                              <span className="counter">
                                                {floorScanStatusCount}
                                              </span>
                                            </div>
                                          )
                                      )
                                    ) : (
                                      <>--</>
                                    )
                                )}
                              </>
                            ) : (
                              <>--</>
                            )}
                          </TableCell>
                          <TableCell style={{ width: "10%" }}>
                            {d.jobOrderStatus ? d.jobOrderStatus : "-"}
                          </TableCell>
                          <TableCell>
                            <div className="action-wrapper">
                              <ul className="btn-list">
                                <li>
                                  <Tooltip title={t("WEB_TOOLTIPS.Edit")} arrow>
                                    <Button
                                      disabled={
                                        d.jobOrderStatus === "Cancel"
                                          ? true
                                          : null
                                      }
                                      onClick={() =>
                                        handleJobOrderDetails(d.jobOrderId)
                                      }
                                    >
                                      <i className="icon-edit-appraiser"></i>
                                    </Button>
                                  </Tooltip>
                                </li>
                              </ul>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <div className="no-data-found-container">
              {!fetchDone ? (
                <div className="no-data-found">
                  <div className="box">
                    <div className="loader-spin"></div>
                  </div>
                </div>
              ) : (
                <NoDataView
                  text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.JOB_ORDERS")}
                  icon={JOB_ORDERS_ICON}
                />
              )}
            </div>
          )}

          <div className="pagination-wrapper">
            {totalCount !== 0 && (
              <span className="show-results">
                {t("COMMON_MESSAGES.Showing")} {startPoint}{" "}
                {t("COMMON_MESSAGES.to")} {endPoint} {t("COMMON_MESSAGES.of")}{" "}
                {totalCount} {t("COMMON_MESSAGES.entries")}
              </span>
            )}

            <CustomPagination
              shape="rounded"
              count={_.get(
                props,
                ["technicianJob", "jobOrders", "pagination", "totalPage"],
                0
              )}
              limit={pageSize}
              page={pageNo}
              total={_.get(
                props,
                ["technicianJob", "jobOrders", "pagination", "totalCount"],
                0
              )}
              onChange={handlePagination}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

const mapStateToProps = (state) => {
  return {
    technicianJob: state.technicianJob,
    profile: state.profile,
    job: state.job,
  };
};

export default connect(mapStateToProps, {
  getTechnicianJobOrders,
})(TechnicianJobOrders);
