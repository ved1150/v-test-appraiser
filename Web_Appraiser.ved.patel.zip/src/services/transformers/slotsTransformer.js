import moment from "moment";

export function hydrateAvailabilities(data) {
  return data && data.map((d) => hydrateAvailability(d));
}

export function hydrateAvailability(data) {
  return {
    slotDate: data.slotDate,
    slotDetail:
      data &&
      data.slotDetail &&
      data.slotDetail.map((d) => hydrateSlotDetail(d)),
  };
}

export function hydrateSlotDetail(data) {
  const currentDate = moment.utc().format("YYYY-MM-DD HH:mm:ss");
  const momentCurrentDate = moment(currentDate, "YYYY-MM-DD HH:mm:ss").utc();
  const momnetStartDate = moment(
    data.slotDateStartTime,
    "YYYY-MM-DD HH:mm:ss"
  ).utc();
  return {
    appointmentId: data.appointmentId,
    slotId: data.slotId,
    status: data.status,
    slotDateEndTime: data.slotDateEndTime,
    slotDateStartTime: data.slotDateStartTime,
    slotStartDate: moment
      .utc(data.slotDateStartTime)
      .local()
      .format("YYYY-MM-DD"),
    slotEndDate: moment.utc(data.slotDateEndTime).local().format("YYYY-MM-DD"),
    formatedStartTime: moment
      .utc(data.slotDateStartTime)
      .local()
      .format("hh:mm A"),
    formatedEndTime: moment.utc(data.slotDateEndTime).local().format("hh:mm A"),
    isPast: momnetStartDate.isBefore(momentCurrentDate),
    appointmentDetails: data.appointmentDetails,
    callStartTime: moment(data.slotDateStartTime).isValid()
      ? moment.utc(data.slotDateStartTime).local().format("MM/DD/YYYY hh:mm A")
      : "--",
  };
}
