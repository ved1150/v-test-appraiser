import api from "./apis/api";

class EagldeViewService {
  createOrder(data) {
    return api.eagleView.createOrder(data);
  }

  getImages(data) {
    return api.eagleView.getImages(data);
  }
}

export default new EagldeViewService();
