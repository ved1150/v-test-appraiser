import React, { useEffect, useState } from "react";
import _ from "lodash";
import { useTranslation } from "react-i18next";
import Button from "../../../common/Button";
import { Slider } from "@mui/material";
import moment from "moment";
import "@hassanmojab/react-modern-calendar-datepicker/lib/DatePicker.css";
import DatePicker from "@hassanmojab/react-modern-calendar-datepicker";
import { utils } from "react-modern-calendar-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import CustomSlider from "../../../common/CustomSlider";

const RelarFilterBox = (props) => {
  const { t } = useTranslation();
  const [priceValue, setPriceValue] = React.useState([1000, 1000]);
  const [houseValue, setHouseValue] = React.useState([0, 0]);
  const [distanceValue, setDistanceValue] = React.useState([0, 0]);
  const [city, SetCity] = useState("");
  const [beds, SetBeds] = useState(0);
  const [baths, SetBaths] = useState(0);
  const [zip, Setzip] = useState("");
  var today = new Date();
  var selectedDate = {
    day: today.getDate(),
    month: today.getMonth() + 1,
    year: today.getFullYear(),
  };
  const [selectedDayString, setSelectedDayString] = useState(
    "mm-dd-yyyy - mm-dd-yyyy"
  );
  const [selectedDay, setSelectedDay] = useState({
    from: selectedDate,
    to: selectedDate,
  });

  const [filterData, SetFilterData] = useState({
    baths: 0,
    beds: 0,
    city: "",
    endDistance: 0,
    endPrice: 0,
    endSize: 0,
    endStatusDate: "",
    jobOrderId: "",
    relarCompsType: "",
    startDistance: 0,
    startPrice: 0,
    startSize: 0,
    startStatusDate: "",
    state: "",
    zip: "",
    pagination: {
      direction: "",
      page: 0,
      size: 0,
      sortBy: "",
    },
  });

  useEffect(() => {
    if (props.filterOldData) {
      if (props.filterOldData?.city) {
        SetCity(props.filterOldData.city);
        SetFilterData({
          ...props.filterOldData,
          city: props.filterOldData.city,
        });
      }
      if (props.filterOldData.beds && props.filterOldData?.beds != 0) {
        SetBeds(Number(props.filterOldData.beds));
        SetFilterData({
          ...props.filterOldData,
          beds: props.filterOldData.beds,
        });
      }
      if (props.filterOldData.baths && props.filterOldData?.baths != 0) {
        SetBaths(Number(props.filterOldData.baths));
        SetFilterData({
          ...props.filterOldData,
          baths: props.filterOldData.baths,
        });
      }
      if (props.filterOldData?.zip?.length > 0) {
        Setzip(Number(props.filterOldData.zip));
        SetFilterData({ ...props.filterOldData, zip: props.filterOldData.zip });
      }
      if (props.filterOldData?.endPrice > 1000) {
        setPriceValue([
          props.filterOldData.startPrice,
          props.filterOldData.endPrice,
        ]);
        SetFilterData({
          ...props.filterOldData,
          startPrice: props.filterOldData.startPrice,
          endPrice: props.filterOldData.endPrice,
        });
      }
      if (
        props.filterOldData?.endHouseSize &&
        props.filterOldData?.endHouseSize != 0
      ) {
        setHouseValue([
          props.filterOldData.startHouseSize,
          props.filterOldData.endHouseSize,
        ]);
        SetFilterData({
          ...props.filterOldData,
          startHouseSize: props.filterOldData.startHouseSize,
          endHouseSize: props.filterOldData.endHouseSize,
        });
      }
      if (
        props.filterOldData?.endDistance &&
        props.filterOldData?.endDistance != 0
      ) {
        setDistanceValue([
          props.filterOldData.startDistance,
          props.filterOldData.endDistance,
        ]);
        SetFilterData({
          ...props.filterOldData,
          startDistance: props.filterOldData.startDistance,
          endDistance: props.filterOldData.endDistance,
        });
      }

      if (
        props.filterOldData?.startStatusDate &&
        props.filterOldData?.endStatusDate
      ) {
        const startDate = moment(props.filterOldData.startStatusDate).format(
          "MM/DD/YYYY"
        );
        const endDate = moment(props.filterOldData.endStatusDate).format(
          "MM/DD/YYYY"
        );
        SetFilterData({
          ...props.filterOldData,
          startStatusDate: startDate,
          endStatusDate: endDate,
        });
      }
      // SetFilterData(props.oldFilterData);
    }
  }, []);
  useEffect(() => {}, [filterData]);
  function valuetext(value) {
    return `${value}`;
  }

  const handleChangePrice = (event, newValue) => {
    setPriceValue(newValue);
    SetFilterData({
      ...filterData,
      startPrice: newValue[0],
      endPrice: newValue[1],
    });
  };
  const handleChangeHouse = (event, newValue) => {
    setHouseValue(newValue);
    SetFilterData({
      ...filterData,
      startHouseSize: newValue[0],
      endHouseSize: newValue[1],
    });
  };
  const handleChangeDistance = (event, newValue) => {
    setDistanceValue(newValue);
    SetFilterData({
      ...filterData,
      startDistance: newValue[0],
      endDistance: newValue[1],
    });
  };

  const checkFilterValidation = () => {
    if (
      filterData.city ||
      filterData.zip ||
      filterData.beds != 0 ||
      filterData.baths != 0 ||
      filterData.startPrice != 0 ||
      filterData.endPrice != 0 ||
      filterData.startStatusDate ||
      filterData.endStatusDate ||
      filterData.startSize != 0 ||
      filterData.endSize != 0 ||
      filterData.startDistance != 0 ||
      filterData.endDistance != 0
    ) {
      return false;
    } else {
      return true;
    }
  };

  const handleOnDateChange = (date) => {
    setSelectedDay(date);
    if (date.from !== null && date.to !== null) {
      const fromDay =
        date.from.day < 10 ? `0${date.from.day}` : `${date.from.day}`;
      const toDay = date.to.day < 10 ? `0${date.to.day}` : `${date.to.day}`;
      const fromMonth =
        date.from.month < 10 ? `0${date.from.month}` : `${date.from.month}`;
      const toMonth =
        date.to.month < 10 ? `0${date.to.month}` : `${date.to.month}`;
      const dateStr = `${fromMonth}/${fromDay}/${date.from.year} - ${toMonth}/${toDay}/${date.to.year}`;
      let startDate = `${fromMonth}/${fromDay}/${date.from.year}`;
      let endDate = `${toMonth}/${toDay}/${date.to.year}`;
      setSelectedDayString(dateStr);
      SetFilterData({
        ...filterData,
        startStatusDate: startDate,
        endStatusDate: endDate,
      });
    }
  };

  const renderCustomInput = ({ ref }) => (
    <div className="form-group">
      <label>{t("WEB_LABELS.Date")} </label>
      <div className="date-formate">
        <span className="icon-date-picker"></span>
        <input
          readOnly
          ref={ref}
          placeholder="08/03/2021 - 10/03/2021"
          value={selectedDayString}
          className="form-control"
        />
      </div>
    </div>
  );

  return (
    <>
      <div className="comman-modal complete-job-order right-side open">
        <div className="comman-modal-main">
          <div className="side-head">
            <span className="icon">
              <i className="icon-filter"></i>
            </span>
            {t("COMMON_MESSAGES.Filter")}
            <button
              className="close-modal"
              onClick={() => props.SetFilterOpen((prev) => !prev)}
            >
              <i className="icon-close-image"></i>
            </button>
          </div>
          <div className="comman-modal-body scroll-bar-style">
            <div className="form-group">
              <label> {t("WEB_LABELS.City")}</label>
              {/* <select
                className="form-control"
                name="city"
                value={city}
                onChange={(e) => {
                  SetCity(e.target.value);
                  SetFilterData({ ...filterData, city: e.target.value });
                }}
              >
                <option selected value="">
                  {" "}
                  {t("WEB_LABELS.Select_City")}
                </option>
                <option value="Glendale"> Glendale</option>
                <option value="Phoenix"> Phoenix</option>
                <option value="Peoria"> Peoria </option>
              </select> */}
              <input
                className="form-control"
                name="city"
                value={city}
                onChange={(e) => {
                  SetCity(e.target.value);
                  SetFilterData({ ...filterData, city: e.target.value });
                }}
              ></input>
            </div>
            <div className="form-group">
              <label>{t("WEB_LABELS.Zip_Code")}</label>
              <input
                className="form-control"
                type="number"
                value={zip}
                onChange={(e) => {
                  SetFilterData({ ...filterData, zip: e.target.value });
                  Setzip(e.target.value);
                }}
              ></input>
            </div>
            <div className="form-group">
              <label>{t("WEB_LABELS.Price")}</label>
              <CustomSlider
                className="form-control"
                style={{ border: "none", marginLeft: "0.5rem", width: "98%" }}
                getAriaLabel={() => "Price"}
                value={priceValue}
                onChange={handleChangePrice}
                valueLabelDisplay="auto"
                getAriaValueText={valuetext}
                min={1000}
                max={500000}
                step={1000}
              />
            </div>
            <div className="form-group">
              <label>{t("WEB_LABELS.Beds")}</label>
              <input
                className="form-control"
                type="number"
                value={beds}
                onChange={(e) => {
                  SetBeds(e.target.value);
                  SetFilterData({
                    ...filterData,
                    beds: Number(e.target.value),
                  });
                }}
              ></input>
            </div>
            <div className="form-group">
              <label>{t("WEB_LABELS.Bath")}</label>
              <input
                className="form-control"
                type="number"
                value={baths}
                onChange={(e) => {
                  SetBaths(e.target.value);
                  SetFilterData({
                    ...filterData,
                    baths: Number(e.target.value),
                  });
                }}
              ></input>
            </div>

            <div className="date-range-picker form-group">
              <DatePicker
                value={selectedDay}
                colorPrimary="#334aa6"
                colorPrimaryLight="rgba(51,74,166,0.4)"
                onChange={handleOnDateChange}
                renderInput={renderCustomInput}
                shouldHighlightWeekends
                style={{ width: "100%" }}
                calendarClassName="custom-calendar"
              />
            </div>

            <div className="form-group">
              <label>{t("WEB_LABELS.House_Size")}</label>
              <CustomSlider
                className="form-control"
                style={{ border: "none", marginLeft: "0.5rem", width: "98%" }}
                getAriaLabel={() => "House Size"}
                value={houseValue}
                onChange={handleChangeHouse}
                valueLabelDisplay="auto"
                start={0}
                end={3000}
                step={50}
                getAriaValueText={valuetext}
              />
            </div>
            <div className="form-group">
              <label>{t("WEB_LABELS.Distance")}</label>

              <CustomSlider
                className="form-control"
                style={{ border: "none", marginLeft: "0.5rem", width: "98%" }}
                getAriaLabel={() => "Distance"}
                value={distanceValue}
                onChange={handleChangeDistance}
                valueLabelDisplay="auto"
                start={0}
                end={50}
                step={0.1}
                getAriaValueText={valuetext}
              />
            </div>

            <div className="text-center">
              <Button
                className="blue-btn"
                disabled={checkFilterValidation()}
                onClick={() => {
                  props.getFilterAttrib(filterData);
                }}
              >
                {t("BUTTONS.Filter")}{" "}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default RelarFilterBox;
