import React, { useEffect } from "react";
import { useSelector, connect } from "react-redux";
import { useHistory } from "react-router-dom";
import { ROLE, storageTypes } from "../../constants/appConstant";
import { redirectToUnAuthPage } from "../../helpers";
import authenticationService from "../../services/authenticationService";
import LanguageSwitcher from "../Authentication/LanguageSwitcher";
import AsyncImage from "../common/AsyncImage";
import "./index.scss";
import { switchTechnician } from "./../../actions/authenticationAction";
import localStorage from "../../services/storage";
import sessionStorage from "../../services/sessionStorage";

const Workspace = () => {
  const userRole = authenticationService.getUserRole();

  const tenantList = useSelector(
    ({ profile: { fetchProfileDetailsSuccess } }) =>
      fetchProfileDetailsSuccess.tenantList
  );
  const history = useHistory();
  useEffect(() => {
    if (!tenantList.length) {
      redirectToUnAuthPage(history);
    }
  }, [tenantList]);

  const handleSwitch = (tenant) => {
    if (
      userRole === ROLE.SWITCH_MULTITENANT_TECHNICIAN &&
      authenticationService.getStorageType() == storageTypes.sessionStorage
    ) {
      const authToken = authenticationService.getToken();
      if (window.location.host.includes("localhost")) {
        window.location.href = `/switch-tenant/${tenant.tenantSubDomain}?switch-technician=${authToken}&subDomain=${tenant.tenantSubDomain}&type=${storageTypes.sessionStorage}&userRole=${userRole}`;
      } else {
        if (
          authenticationService.getStorageType() == storageTypes.sessionStorage
        ) {
          sessionStorage.clearAll();
        } else {
          localStorage.clearAll();
          sessionStorage.clearAll();
        }
        window.location.href = `https://${tenant.tenantSubDomain}.${process.env.REACT_APP_DOMAIN_URL}/switch-tenant/${tenant.tenantSubDomain}?switch-technician=${authToken}&subDomain=${tenant.tenantSubDomain}&type=${storageTypes.sessionStorage}&userRole=${userRole}`;
      }
    } else {
      const encAuthData = authenticationService.getEncAuthData();
      if (window.location.host.includes("localhost")) {
        window.location.href = `/switch-tenant/${tenant.tenantSubDomain}?auth=${encAuthData}`;
      } else {
        if (
          authenticationService.getStorageType() == storageTypes.sessionStorage
        ) {
          sessionStorage.clearAll();
        } else {
          localStorage.clearAll();
          sessionStorage.clearAll();
        }
        window.location.href = `https://${tenant.tenantSubDomain}.${
          process.env.REACT_APP_DOMAIN_URL
        }/switch-tenant/${
          tenant.tenantSubDomain
        }?auth=${encAuthData}&userRole=${Buffer.from(userRole).toString(
          "base64"
        )}`;
      }
    }
  };
  return (
    <section className="work-shop-wraper">
      <div className="work-shop-center-segment">
        <div className="work-shop-text-top">
          Please Select and Switch Workspace
        </div>
        <div className="work-shop-field-section">
          <div className="inner-work-shop">
            <ul className="work-shop-list">
              {tenantList.map((tenant) => (
                <li key={tenant.id}>
                  <button type="button" onClick={() => handleSwitch(tenant)}>
                    <div className="work-shop-row">
                      <div className="work-shop-img">
                        <AsyncImage
                          imageUrl={tenant.logoPath}
                          tenantSubDomain={tenant.tenantSubDomain}
                        />
                      </div>
                      <div className="work-shop-text">
                        <div className="work-shop-name">
                          {tenant.tenantName}
                        </div>
                        <div className="work-shop-icon">
                          <i className="icon-side-right"></i>
                        </div>
                      </div>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
        {(userRole === ROLE.APPRAISER ||
          userRole === ROLE.SWITCH_MULTITENANT_APPRAISER) && (
          <LanguageSwitcher />
        )}
      </div>
    </section>
  );
};

const mapStateToProps = (state) => {
  return {
    authentication: state.authentication,
  };
};

export default connect(mapStateToProps, {
  switchTechnician,
})(Workspace);
