export const DETAILS = "Details";
export const NOTES = "Notes";
export const CAPTURED_IMAGES = "Captured Images";
export const RECORDINGS = "Recordings";
export const ATTACHMENTS = "Attachments";
export const JOB_ORDERS = "Job Orders";
export const QUESTIONNAIRE = "Questionnaire";

export const DETAILS_ICON = "icon-inspection-form";
export const NOTES_ICON = "icon-created-by";
export const CAPTURED_IMAGES_ICON = "icon-images";
export const RECORDINGS_ICON = "icon-call-recording";
export const ATTACHMENTS_ICON = "icon-Attach-Document";
export const MEASUREMENTS_ICON = "icon-Measurement-Details";
export const JOB_ORDERS_ICON = "icon-no-bookmark";
export const QUESTIONNAIRE_ICON = "icon-Questionnaire-Form";
export const FLOORPLANS_ICON = "icon-Floor-Plan";
