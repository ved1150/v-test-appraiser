import api from "./api";

export default class RecordingsAPI {
  getRecordings(data) {
    return api.get(
      `/joborder/${data.jobOrderId}/recordings?direction=${data.direction}&sortBy=${data.sortBy}`
    );
  }

  downloadRecording(data) {
    return api.get(`/joborder/recording/${data.callId}/${data.compositionId}`);
  }
}
