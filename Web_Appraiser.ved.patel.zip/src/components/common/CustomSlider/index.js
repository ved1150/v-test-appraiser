import Slider from "@mui/material/Slider";

export default function CustomSlider({
  className,
  style,
  getAriaLabel,
  value,
  onChange,
  valueLabelDisplay,
  getAriaValueText,
  min,
  max,
  step,
}) {
  return (
    <Slider
      sx={{
        color: getComputedStyle(
          document.querySelector(":root")
        ).getPropertyValue("--button_bg_color"),
      }}
      className={className}
      style={style}
      getAriaLabel={getAriaLabel}
      value={value}
      onChange={onChange}
      valueLabelDisplay={valueLabelDisplay}
      getAriaValueText={getAriaValueText}
      min={min}
      max={max}
      step={step}
    />
  );
}
