import api from "./api";

export default class ManageCardsAPI {
  getManageCardList(data) {
    return api.post("/manageCards", data);
  }

  deleteManageCard(data) {
    return api.delete("/deleteCard", { data: data });
  }

  setDefaultCard(data) {
    return api.post("/setDefaultCard", data);
  }

  getHostedProfilePageRequestToken(data) {
    return api.post("/getToken", data);
  }
}
