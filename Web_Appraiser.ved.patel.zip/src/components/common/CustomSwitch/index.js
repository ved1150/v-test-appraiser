import Switch from "@mui/material/Switch";

export default function CustomSwitch({ checked, onChange }) {
  return (
    <Switch
      sx={[
        {
          width: "40px",
          height: "20px",
          padding: "0px",
          display: "flex",
        },
        {
          ".MuiSwitch-switchBase": {
            padding: "2px",
            color: "#ffffff",
          },
        },
        {
          ".MuiSwitch-switchBase.Mui-checked": {
            transform: "translateX(20px)",
            color: "#FFFFFF",
          },
          ".MuiSwitch-switchBase.Mui-checked+.MuiSwitch-track": {
            backgroundColor: `${getComputedStyle(
              document.querySelector(":root")
            ).getPropertyValue("--button_bg_color")}`,
            borderColor: `${getComputedStyle(
              document.querySelector(":root")
            ).getPropertyValue("--button_bg_color")}`,
            opacity: 1,
          },
        },
        {
          ".MuiSwitch-thumb": {
            width: "16px",
            height: "16px",
            boxShadow: "none",
            color: "#ffffff",
          },
        },
        {
          ".MuiSwitch-track": {
            border: `1px solid #ffffff`,
            backgroundColor: "#cecece",
            borderRadius: "50px",
            opacity: 1,
          },
        },
      ]}
      checked={checked}
      onChange={onChange}
    />
  );
}
