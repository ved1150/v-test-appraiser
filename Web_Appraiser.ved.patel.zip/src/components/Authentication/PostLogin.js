import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { useLocation } from "react-router-dom";
import authenticationService from "../../services/authenticationService";
import { fetchToken } from "./../../actions/authenticationAction";
import { fetchProfileDetails } from "./../../actions/profileAction";
import { storageTypes, loginType } from "./../../constants/appConstant";

const PostLogin = (props) => {
  let params = new URLSearchParams(useLocation().search);
  const accessCode = params.get("access");
  const type = params.get("type");
  type == storageTypes.sessionStorage &&
    authenticationService.setStorageType(storageTypes.sessionStorage);
  const token = authenticationService.getToken();

  useEffect(() => {
    if (!token) {
      !type && authenticationService.setLoginType(loginType.valueConnect);
      props.fetchToken(accessCode, props.history).then((res) => {
        if (!res && !res?.token) {
          props.history.push("/unauthorized");
        }
      });
    }
  }, []);

  return <div></div>;
};

const mapStateToProps = (state) => {
  return {
    authentication: state.authentication,
  };
};

export default connect(mapStateToProps, {
  fetchToken,
  fetchProfileDetails,
})(PostLogin);
