import * as actionTypes from "./actionTypes";
import recordingsService from "./../services/recordingsService";
import { StartLoading, StopLoading } from "./UIAction";
import { customToast } from "../helpers/customToast";
import { UNEXPECTED_ERROR_MESSAGE } from "../constants/commonMessages";

const startFetchRecordings = () => {
  return {
    type: actionTypes.FETCH_RECORDINGS_START,
  };
};

const successFetchRecordings = (data) => {
  return {
    type: actionTypes.FETCH_RECORDINGS_SUCCESS,
    payload: data,
  };
};

const errorFetchRecordings = (error) => {
  return {
    type: actionTypes.FETCH_RECORDINGS_ERROR,
    payload: error,
  };
};

export const fetchRecordings = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startFetchRecordings());
    return recordingsService
      .getRecordings(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successFetchRecordings(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorFetchRecordings(err));
      });
  };
};

const startDownloadRecording = () => {
  return {
    type: actionTypes.DOWNLOAD_RECORDING_START,
  };
};

const successDownloadRecording = (data) => {
  return {
    type: actionTypes.DOWNLOAD_RECORDING_SUCCESS,
    payload: data,
  };
};

const errorDownloadRecording = (error) => {
  return {
    type: actionTypes.DOWNLOAD_RECORDING_ERROR,
    payload: error,
  };
};

export const downloadRecording = (data) => {
  return (dispatch) => {
    dispatch(StartLoading());
    dispatch(startDownloadRecording());
    return recordingsService
      .downloadRecording(data)
      .then((data) => {
        dispatch(StopLoading());
        dispatch(successDownloadRecording(data));
        return data;
      })
      .catch((err) => {
        dispatch(StopLoading());
        dispatch(errorDownloadRecording(data));
        throw err;
      });
  };
};
