import * as actionTypes from "../actions/actionTypes";

const recordingsState = {
  fetchRecordingsStart: false,
  fetchRecordingsSuccess: [],
  fetchRecordingsError: null,
  downloadRecordingStart: false,
  downloadRecordingSuccess: {},
  downloadRecordingError: null,
};

const defaultStates = {
  ...recordingsState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_RECORDINGS_START:
      return {
        ...state,
        fetchRecordingsStart: true,
        fetchRecordingsSuccess: [],
        fetchRecordingsError: null,
      };
    case actionTypes.FETCH_RECORDINGS_SUCCESS:
      return {
        ...state,
        fetchRecordingsStart: false,
        fetchRecordingsSuccess: action.payload,
        fetchRecordingsError: null,
      };
    case actionTypes.FETCH_RECORDINGS_ERROR:
      return {
        ...state,
        fetchRecordingsStart: false,
        fetchRecordingsSuccess: [],
        fetchRecordingsError: action.payload,
      };
    case actionTypes.DOWNLOAD_RECORDING_START:
      return {
        ...state,
        downloadRecordingStart: true,
        downloadRecordingSuccess: {},
        downloadRecordingError: null,
      };
    case actionTypes.DOWNLOAD_RECORDING_SUCCESS:
      return {
        ...state,
        downloadRecordingStart: false,
        downloadRecordingSuccess: action.payload,
        downloadRecordingError: null,
      };
    case actionTypes.DOWNLOAD_RECORDING_ERROR:
      return {
        ...state,
        downloadRecordingStart: false,
        downloadRecordingSuccess: {},
        downloadRecordingError: action.payload,
      };
    default:
      return state;
  }
};
