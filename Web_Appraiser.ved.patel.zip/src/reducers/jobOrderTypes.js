import * as actionTypes from "../actions/actionTypes";

const jobOrderTypeState = {
  listJobOrderTypeStart: false,
  listJobOrderTypeSuccess: [],
  listJobOrderTypeError: null,
};

export const defaultState = {
  ...jobOrderTypeState,
};

const jobOrderTypesReducer = (state = defaultState, action = {}) => {
  switch (action.type) {
    // ----------------------------
    // Start of List Job Order Type
    // ----------------------------
    case actionTypes.LIST_JOB_ORDER_TYPE_START:
      return {
        ...state,
        listJobOrderTypeStart: true,
        listJobOrderTypeSuccess: [],
        listJobOrderTypeError: null,
      };
    case actionTypes.LIST_JOB_ORDER_TYPE_SUCCESS:
      return {
        ...state,
        listJobOrderTypeStart: false,
        listJobOrderTypeSuccess: action.payload,
        listJobOrderTypeError: null,
      };
    case actionTypes.LIST_JOB_ORDER_TYPE_ERROR:
      return {
        ...state,
        listJobOrderTypeStart: false,
        listJobOrderTypeSuccess: [],
        listJobOrderTypeError: action.payload,
      };
    // --------------------------
    // End of List Job Order Type
    // --------------------------

    default:
      return state;
  }
};

export default jobOrderTypesReducer;
