import React, { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import "./index.scss";
import { getManageCardToken } from "../../actions/manageCardsAction";
import { connect, useSelector } from "react-redux";
import { getSelfServeIframeUrl } from "../../helpers";
import { customToast } from "../../helpers/customToast";

// For Add-Card or Edit-Card
const ManageCard = (props) => {
  const { t } = useTranslation();
  const [token, setToken] = useState(null);
  const [addCardUrl, setAddCardUrl] = useState("");
  const [editCardUrl, setEditCardUrl] = useState("");
  const [initialResizeNotification, setInitialResizeNotification] =
    useState(false);
  const addPaymentForm = useRef();
  const editPaymentForm = useRef();

  const _customerProfileId = useSelector(
    (state) => state?.manageCards?.listCardsData?.customerProfileId
  );

  window.CommunicationHandler = {
    onReceiveCommunication: (event) => {
      const { qstr } = event;
      if (!initialResizeNotification && qstr?.includes("resize")) {
        setInitialResizeNotification(true);
      }
      if (qstr?.includes("cancel") || qstr?.includes("successfulSave")) {
        if (qstr?.includes("successfulSave")) {
          if (props?.location?.state?.isAddCard) {
            customToast.success(t("Card_Add_Success"));
          } else if (props?.location?.state?.isEditCard) {
            customToast.success(t("Card_Edit_Success"));
          }
          setTimeout(() => {
            props.history.replace("/cards");
          }, 1000);
        } else if (qstr?.includes("cancel")) {
          props.history.replace("/cards");
        }
      }
    },
  };

  useEffect(() => {
    if (token && addCardUrl && props.location.state.isAddCard) {
      addPaymentForm.current.submit();
    }
    if (token && editCardUrl && props.location.state.isEditCard) {
      editPaymentForm.current.submit();
    }
  }, [token, addCardUrl, editCardUrl]);

  useEffect(() => {
    if (
      _customerProfileId &&
      (props?.location?.state?.isAddCard ||
        (props?.location?.state?.isEditCard &&
          props?.location?.state?.paymentProfileId))
    ) {
      props
        .getManageCardToken({
          customerProfileId: _customerProfileId,
          settingTypeJson: {
            // hostedProfileCardCodeRequired: true,
            hostedProfilePaymentOptions: "showCreditCard",
            hostedProfileHeadingBgColor: getComputedStyle(
              document.querySelector(":root")
            ).getPropertyValue("--button_bg_color"),
            hostedProfileIFrameCommunicatorUrl: getSelfServeIframeUrl(),
          },
        })
        .then((data) => {
          if (
            data?.data?.data?.token &&
            data?.data?.data?.addCardUrl &&
            data?.data?.data?.editCardUrl
          ) {
            setToken(data.data.data.token);
            setAddCardUrl(data.data.data.addCardUrl);
            setEditCardUrl(data.data.data.editCardUrl);
          }
        });
    } else {
      props.history.replace("/cards");
    }
  }, []);

  return (
    <>
      <section className="content-wapper">
        <div className="breadcrumb">
          <ul>
            <li>
              <button
                onClick={() => {
                  props.history.replace("/cards");
                }}
              >
                {t("WEB_LABELS.Manage_Cards")}
              </button>
            </li>
            {props?.location?.state?.isAddCard && (
              <li>{t("BUTTONS.Add_Card")}</li>
            )}
            {props?.location?.state?.isEditCard && (
              <li>{t("BUTTONS.Edit_Card")}</li>
            )}
          </ul>
        </div>
        <div className="iframe-wrapper common-panel lander-magement relative-panel">
          {!initialResizeNotification && (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                background: "white",
                height: "100%",
              }}
            >
              <div className="loader-spin"></div>
            </div>
          )}
          <div
            style={{
              height: initialResizeNotification ? "100%" : "0%",
              visibility: initialResizeNotification ? "visible" : "hidden",
            }}
            className="panel-body"
          >
            {props.location.state.isAddCard && (
              <>
                <iframe
                  style={{ height: "100%" }}
                  title="add payment"
                  id="add_payment"
                  className="embed-responsive-item panel"
                  name="add_payment"
                  width="100%"
                ></iframe>
                <form
                  ref={addPaymentForm}
                  id="add_payment_form"
                  method="post"
                  action={addCardUrl}
                  target="add_payment"
                >
                  <input type="hidden" name="token" value={token} />
                </form>
              </>
            )}
            {props.location.state.isEditCard && (
              <>
                <iframe
                  style={{ height: "100%" }}
                  title="edit payment"
                  id="edit_payment"
                  className="embed-responsive-item panel"
                  name="edit_payment"
                  width="100%"
                ></iframe>
                <form
                  ref={editPaymentForm}
                  id="edit_payment_form"
                  method="post"
                  action={editCardUrl}
                  target="edit_payment"
                >
                  <input type="hidden" name="token" value={token} />
                  <input
                    type="hidden"
                    name="paymentProfileId"
                    value={`${props.location.state.paymentProfileId}`}
                  />
                </form>
              </>
            )}
          </div>
        </div>
      </section>
    </>
  );
};

const mapStateToProps = (state) => {
  return {};
};

const mapDispatchToProps = (dispatch) => {
  return {
    getManageCardToken: (data) => dispatch(getManageCardToken(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ManageCard);
