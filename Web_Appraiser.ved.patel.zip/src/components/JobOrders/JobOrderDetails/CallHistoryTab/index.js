import React, { useEffect, useState } from "react";

const CallHistoryTab = (props) => {
  return (
    <div className="call-history">
      <ul>
        <li>
          <div className="box">
            <div className="head">
              Schedule Appointment: Sent Request{" "}
              <span className="time">Apr 1, 2021 12:00AM</span>
            </div>
            <div className="body">
              <span>Alex Pike</span> has sent a request to{" "}
              <span>John Smith </span> to schedule an appointment.
            </div>
          </div>
        </li>
        <li>
          <div className="box">
            <div className="head">
              Schedule Appointment: Confirm Request{" "}
              <span className="time">Mar 30, 2021 02:00AM</span>
            </div>
            <div className="body">
              <span>John Smith</span> has confirmed the request of{" "}
              <span>Alex Pike</span> to schedule an appointment.
            </div>
          </div>
        </li>
        <li>
          <div className="box">
            <div className="head">
              Schedule Appointment: Reschedule{" "}
              <span className="time">Mar 27, 2021 04:00AM</span>
            </div>
            <div className="body">
              <span>John Smith</span> has rescheduled the appointment of{" "}
              <span>Alex Pike.</span>
            </div>
          </div>
        </li>
        <li>
          <div className="box">
            <div className="head">
              Schedule Appointment: Cancel Appointment{" "}
              <span className="time">Mar 26, 2021 05:00AM</span>
            </div>
            <div className="body">
              <span>John Smith</span> has canceled the appointment of{" "}
              <span>Alex Pike.</span>
            </div>
          </div>
        </li>
        <li>
          <div className="box">
            <div className="head">
              Quick Call: Sent Quick Call
              <span className="time">Mar 25, 2021 06:00AM</span>
            </div>
            <div className="body">
              <span>Alex Pike</span> has sent quick call to{" "}
              <span>John Smith.</span>
            </div>
          </div>
        </li>
        <li>
          <div className="box">
            <div className="head">
              Measurment Link: Sent Measurement Link
              <span className="time">Mar 24, 2021 07:00AM</span>
            </div>
            <div className="body">
              <span>Alex Pike</span> has sent measurement link to itself.
            </div>
          </div>
        </li>
      </ul>
    </div>
  );
};

export default CallHistoryTab;
