import React, { useEffect } from "react";
import _ from "lodash";
import NoDataView from "./../Common/noDataView";
import { NOTES, NOTES_ICON } from "./../Common/commonText";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
const NotesTab = (props) => {
  const { t } = useTranslation();
  useEffect(() => {
    props.fetchNotes(props.jobOrderId);
  }, []);

  const fetchNotesStart = useSelector((state) => state?.notes?.fetchNotesStart);

  return (
    <div className="note-list scroll-bar-style">
      <ul>
        {fetchNotesStart || _.size(props.notes.fetchNotesSuccess) === 0 ? (
          <div className="no-data-found-container">
            {fetchNotesStart ? (
              <div className="no-data-found">
                <div className="box">
                  <div className="loader-spin"></div>
                </div>
              </div>
            ) : (
              <NoDataView
                text={t("COMMON_MESSAGES.JOB_ORDER_DETAILS.NOTES")}
                icon={NOTES_ICON}
              />
            )}
          </div>
        ) : (
          _.get(props, ["notes", "fetchNotesSuccess"], []).map((d, id) => (
            <li key={id}>
              <div className="profile-pic">
                <span>{d.noteIcon}</span>
              </div>
              <div className="details">
                <h4>{d.title}</h4>
                <p>{d.description}</p>
                <div className="create">
                  <div className="box">
                    <button>
                      <i className="icon-created-by"></i>
                    </button>
                    <strong>{t("WEB_LABELS.Created_By")}: </strong>
                    {d.createdByName}
                  </div>
                  <div className="box">
                    <i className="icon-Time"></i>
                    <strong>{t("WEB_LABELS.Created_On")}: </strong>
                    {d.formatedCreatedAT}
                  </div>
                </div>
              </div>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};

export default NotesTab;
