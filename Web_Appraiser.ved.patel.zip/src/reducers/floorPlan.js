import * as actionTypes from "../actions/actionTypes";

const floorState = {
  fetchFloorStart: false,
  fetchFloorSuccess: [],
  fetchFloorError: null,
};

const defaultStates = {
  ...floorState,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.FETCH_FLOOR_START:
      return {
        ...state,
        fetchFloorStart: true,
        fetchFloorSuccess: [],
        fetchFloorError: null,
      };
    case actionTypes.FETCH_FLOOR_SUCCESS:
      return {
        ...state,
        fetchFloorStart: false,
        fetchFloorSuccess: action.payload,
        fetchFloorError: null,
      };
    case actionTypes.FETCH_FLOOR_ERROR:
      return {
        ...state,
        fetchFloorStart: false,
        fetchFloorSuccess: [],
        fetchFloorError: action.payload,
      };
    default:
      return state;
  }
};
