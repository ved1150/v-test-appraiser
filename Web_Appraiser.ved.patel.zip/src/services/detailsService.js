import api from "./apis/api";
import {
  hydrateCallDetails,
  hydrateDetails,
} from "./transformers/jobOrderDetailsTransformer";

class DetailsService {
  getDetails(data) {
    return api.details.getDetails(data).then(hydrateDetails);
  }

  getCallDetails(data) {
    return api.details.getCallDetails(data).then(hydrateCallDetails);
  }
}

export default new DetailsService();
