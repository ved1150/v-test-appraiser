import _ from "lodash";

export function hydratePostLogin(data) {
  return {
    userId: _.get(data, ["data", "data", "userId"], ""),
    token: _.get(data, ["data", "data", "jwtToken"], ""),
    userRole: _.get(data, ["data", "data", "userRole"], ""),
    tenantList: _.get(data, ["data", "data", "tenantList"], []),
  };
}

export function dehydrateSignIn(params) {
  return {
    userName: params.email,
    password: params.password,
    // role: params.role,
  };
}

export function hydrateLogin(data) {
  return {
    userId: _.get(data, ["data", "data", "userId"], ""),
    token: _.get(data, ["data", "data", "jwtToken"], ""),
    userRole: _.get(data, ["data", "data", "userRole"], ""),
    tenantList: _.get(data, ["data", "data", "tenantList"], []),
  };
}

export function dehydrateForgotPassword(params) {
  return {
    emailId: params.email,
  };
}

export function dehydrateResetPassword(params) {
  return {
    newPassword: params.newPassword,
    userId: params.userId,
  };
}

export function hydrateSwitchTechnician(data) {
  return {
    userId: _.get(data, ["data", "data", "userId"], ""),
    jwtToken: _.get(data, ["data", "data", "jwtToken"], ""),
    userRole: _.get(data, ["data", "data", "userRole"], ""),
    tenantList: _.get(data, ["data", "data", "tenantList"], []),
  };
}

export function hydrateStates(data) {
  return {
    states: _.get(data, ["data", "data"], []),
  };
}
