import React, { useRef, useState, Suspense, useEffect } from "react";
import { Canvas, useThree, extend } from "@react-three/fiber";
import {
  Line,
  OrbitControls,
  TransformControls,
  Bounds,
  useBounds,
  Html,
  Box,
  Torus,
} from "@react-three/drei";
import CameraControls from "camera-controls";
import Tooltip from "@mui/material/Tooltip";
import { connect, useSelector } from "react-redux";
import { customToast } from "../../../helpers/customToast";
import { useTranslation } from "react-i18next";
import ConfirmationModal from "../../common/confirmationModal";
import { PLYLoader } from "three/examples/jsm/loaders/PLYLoader";
import { MTLLoader } from "three/examples/jsm/loaders/MTLLoader";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader";

import {
  fetchFloor,
  fetchFloorContent,
  publishJson,
  fetchZipFile,
  autoSaveThreeDJson,
} from "../../../actions/floorAction";
import localStorage from "../../../services/storage";
import * as THREE from "three";
import {
  StartLoading,
  StopLoading,
  updateHeader,
  updateNavBar,
} from "../../../actions/UIAction";
import _ from "lodash";
import "./Index.scss";
import {
  screenModeTypes,
  STATUS,
  storageTypes,
  threeDFloorScan,
} from "../../../constants/appConstant";
import sessionStorage from "../../../services/sessionStorage";
import {
  floorName,
  areaLabel,
  floorScanType,
  undoLineFor3D,
  additionalType3D,
  doorDirectionEnum,
} from "../../../constants/enums";
import { FLOORPLANS_ICON } from "../../JobOrders/JobOrderDetails/Common/commonText";
import NoDataView from "../../JobOrders/JobOrderDetails/Common/noDataView";
import { UNEXPECTED_ERROR_MESSAGE } from "../../../constants/commonMessages";
import PublishFormSidebar from "./PublishFormSidebar";
import JSZip from "jszip";

import { Button } from "@mui/material";
import authenticationService from "../../../services/authenticationService";
import {
  DeleteRoom,
  deselectSelectedRoom,
  PointerUp,
  findMaxRoom,
  ShowFabNew,
  AddPartition,
  FindParentRoomOfPoint,
  findMaxLabelId,
  PointerDown,
  MarkerPointSphere,
  changeAreaDetails,
  resetAreaDetails,
  isIntersectDoor,
  pinPoint,
  deleteDoor,
  onMeshPointerMove,
  DoorWindowStartPoint,
  CreateLabel,
  calculateRoomArea,
  findCenterPoint,
  CreateStairCase,
  findMaxStairCaseId,
  PointerMove,
  THREED_INSIDE_DOOR_COLOR,
  THREED_DOOR_COLOR,
  THREED_WINDOW_COLOR,
} from "./UtilityThreejs";
import MeasurementTab from "../../JobOrders/JobOrderDetails/measurementTab";
import { fetchProfileDetails } from "../../../actions/profileAction";

let lineArrayFab = [],
  doorwindowArray = [],
  polypointsx = [],
  polypointsy = [],
  lineArrayFabstr = [],
  textArrayFabstr = [],
  meshExist = [],
  meshLoaded = [],
  state = null,
  maxZ = null,
  isloaded = false,
  draggingLine = false,
  changesStack = [],
  boundsRef = null,
  oldOrbitPointerDownDistance = null,
  screenSize = { mode: 0, navOpen: true },
  defaultObjectZoomLevel = null,
  stairCaseArrayFabstr = [],
  lastChangedName = null,
  autoSaveSuccess = true;

const meshName = "meshName",
  Select_Area_Type = "Select Area Type",
  canvasSelector = "#zoom-canvas > div > canvas",
  Axis_Length = 200;

CameraControls.install({ THREE });
extend({ CameraControls, Text });

function worldPointFromScreenPoint(screenPoint, camera) {
  let worldPoint = new THREE.Vector3();
  worldPoint.x = screenPoint.x;
  worldPoint.y = screenPoint.y;
  worldPoint.z = 0;
  worldPoint.unproject(camera);
  return worldPoint;
}

const onStairDrag = (
  event,
  stairCaseArray,
  i,
  setStairCaseArray,
  start,
  addChangesToStack,
  removeMagnifier
) => {
  event.stopPropagation();
  if (start) {
    addChangesToStack({ stairCaseArray: _.cloneDeep(stairCaseArray) });
    removeMagnifier();
  }
  const rect = state.size;
  let viewportDown = new THREE.Vector2();
  viewportDown.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  viewportDown.y = -(((event.clientY - rect.top) / rect.height) * 2) + 1;
  let my3dPosition = worldPointFromScreenPoint(viewportDown, state.camera);
  stairCaseArray[i].points = [
    my3dPosition?.x,
    my3dPosition?.y,
    my3dPosition?.z,
  ];
  setStairCaseArray([...stairCaseArray]);
};

const onScaleX = (
  event,
  stairCaseArray,
  i,
  setStairCaseArray,
  setSelectedStairObject,
  selectedStairObject
) => {
  stairCaseArray[i].scaleX = event.target.value;
  selectedStairObject.scaleX = event.target.value;
  selectedStairObject.scaled = true;
  setSelectedStairObject(selectedStairObject);
  setStairCaseArray([...stairCaseArray]);
};

const onScaleY = (
  event,
  stairCaseArray,
  i,
  setStairCaseArray,
  setSelectedStairObject,
  selectedStairObject
) => {
  stairCaseArray[i].scaleY = event.target.value;
  selectedStairObject.scaleY = event.target.value;
  selectedStairObject.scaled = true;
  setSelectedStairObject(selectedStairObject);
  setStairCaseArray([...stairCaseArray]);
};

const TextObj = ({
  position,
  name,
  textid,
  setSelectedTextId,
  setSelectedLabelId,
  id,
  setText,
  index,
  text,
  deleteLabel,
  pointerDown,
  pointerUp,
  isDragLine,
  labelId,
  selectedLabelId,
  selectedTextId,
  deleteRoom,
  setDeleteRoom,
  isSelectItem,
  setSelectedRoom,
  areaLabelTextArray,
  roomId,
  isTotalAreaLabel = false,
  addChangesToStack,
  textArray,
}) => {
  return (
    <>
      <mesh position={position} name={name} meshid={id} text={text}>
        <Html>
          <span
            id="labelOuterDiv"
            textid={textid}
            labelid={labelId}
            style={{
              pointerEvents: isTotalAreaLabel || isDragLine ? "none" : "",
              cursor: isTotalAreaLabel || isDragLine ? "none" : "",
            }}
            className={`measure-anchor-area-label ${
              selectedLabelId === labelId?.toString() &&
              selectedTextId !== null &&
              isSelectItem &&
              !isTotalAreaLabel
                ? "border"
                : ""
            }`}
            onPointerUp={(e) => {
              pointerUp(e);
              if (e.target.id.includes("custom-text")) {
                setSelectedTextId(e.target.id);
              }
            }}
            onPointerDown={(e) => {
              if (lastChangedName != e.target.innerText?.trim()) {
                lastChangedName = e.target.innerText?.trim();
              }
              pointerDown(e);
              if (e.target.id.includes("custom-text")) {
                setText(e.target.innerText, index);
              }
            }}
            readOnly={isTotalAreaLabel}
          >
            <div className={`measure-anchor__label-area-label`}>
              <div
                id={textid}
                labelid={labelId}
                contentEditable={!isDragLine}
                suppressContentEditableWarning={true}
                onBlur={(e) => {
                  if (e.target.innerText?.trim() === "") {
                    deleteLabel();
                  } else {
                    let textArrayClone = textArray.map((textEl) => {
                      if (textEl.labelId == labelId) {
                        return {
                          ...textEl,
                          text: lastChangedName,
                        };
                      } else {
                        return { ...textEl };
                      }
                    });
                    addChangesToStack({
                      textArray: [...textArrayClone],
                    });
                    pointerDown(e);
                    setText(e.target.innerText, index);
                  }
                }}
                onSelect={(e) => {
                  if (!isTotalAreaLabel) {
                    if (e.target.innerText?.trim() === "Tap and Type") {
                      e.target.innerText = "";
                    }
                    if (e.target.id?.indexOf("custom-text") > -1) {
                      setDeleteRoom({
                        ...deleteRoom,
                        roomId: null,
                      });
                    }
                    deselectSelectedRoom(deleteRoom, setDeleteRoom);
                    setSelectedRoom(areaLabel?.[0]?.value);
                    if (e.target.id.indexOf("arealabel") > -1 && isSelectItem) {
                      let roomId = e.target.attributes?.roomid
                        ? e.target.attributes?.roomid.value
                        : "";
                      if (roomId != "") {
                        areaLabelTextArray.map((val) => {
                          if (val.roomID == roomId) {
                            setSelectedRoom(val.text);
                          }
                        });
                        setDeleteRoom({
                          roomId: parseInt(roomId.split(":")[1]),
                          isDelete: false,
                        });
                      }
                    }
                    setSelectedLabelId(
                      e.target.attributes?.labelid?.textContent
                    );
                    setSelectedTextId(e.target.id);
                  }
                }}
                onKeyDown={(e) => {
                  if (e?.target?.id.indexOf("arealabel") > -1) {
                    e.preventDefault();
                  }
                  if (
                    e.key == "Escape" &&
                    e?.target?.innerText?.trim() === ""
                  ) {
                    deleteLabel();
                  }
                  if (
                    !(
                      e.key == "Backspace" ||
                      e.key == "Delete" ||
                      e.key == "ArrowLeft" ||
                      e.key == "ArrowRight" ||
                      e.key == "ArrowUp" ||
                      e.key == "ArrowDown"
                    )
                  ) {
                    if (e.target.innerText.length >= 20) e.preventDefault();
                  }
                }}
                className={`measure-anchor__value-area-label ${
                  isTotalAreaLabel ? " read-only" : ""
                }`}
              >
                {text}
              </div>
            </div>
          </span>
        </Html>
      </mesh>
    </>
  );
};

const ScenePLY = ({
  isloaded,
  setLine,
  pointerUp,
  plyFilePath,
  setLoader,
  setLoadingPer,
  loadingPer,
  setContentAvailable,
  index,
  floorScanTypeVar,
  pinLocation,
  drawLine,
  isAddDoor,
  isAddWindow,
  isDragLine,
  isAddLabel,
  isAddPartition,
  setAxisCords,
  isAddStairCase,
  selectedRoomStairCase,
}) => {
  state = useThree();
  let scene = state.scene;
  if (!isloaded && plyFilePath && !meshExist.includes(`${meshName + index}`)) {
    setLoader(true);
    meshExist.push(`${meshName + index}`);
    if (_.isEmpty(plyFilePath?.image)) {
      const loader = new PLYLoader();
      let token;
      if (sessionStorage.get("storageType") == storageTypes.sessionStorage) {
        token = sessionStorage.get("token");
      } else {
        token = localStorage.get("token");
      }
      const currentTenantSubDomain =
        authenticationService.getTenantDetails() &&
        _.get(
          JSON.parse(authenticationService.getTenantDetails()),
          ["tenantSubDomain"],
          ""
        );
      loader.setRequestHeader({
        authorization: `Bearer ${token}`,
        "X-Tenant": currentTenantSubDomain,
      });
      loader.load(
        plyFilePath,
        function (geometry) {
          if (!isloaded) {
            const light = new THREE.AmbientLight(0x404040, 1);
            scene.add(light);
            AddSoftWhiteLight(new THREE.Vector3(10, 20, 10));
            AddSoftWhiteLight(new THREE.Vector3(-10, 20, 10));
            AddSoftWhiteLight(new THREE.Vector3(-10, 20, -10));
            AddSoftWhiteLight(new THREE.Vector3(10, 20, -10));
            const material = new THREE.MeshStandardMaterial({
              side: THREE.DoubleSide,
              depthWrite: true,
              depthTest: true,
              color: "#ffffff",
              defines: { STANDARD: "" },
            });
            geometry.computeVertexNormals();
            const mesh = new THREE.Mesh(geometry, material);
            mesh.name = `${meshName + index}`;
            scene.add(mesh);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            isloaded = true;
            meshLoaded.push(`${meshName + index}`);
            if (meshLoaded.length === meshExist.length) {
              setLoader(false);
            }
            geometry.computeBoundingBox();
            let bBox = geometry.boundingBox;
            maxZ = bBox?.max?.z;
            maxZ = maxZ + maxZ;
            let pinCoords = pinLocation ? JSON.parse(pinLocation) : null;
            if (floorScanTypeVar == floorScanType[1].value && pinCoords) {
              pinPoint(scene, pinCoords?.data);
            }
          }
        },
        (onProgress) => {
          setLoadingPer(
            Math.floor((onProgress.loaded / onProgress.total) * 100)
          );
        },
        (error) => {
          setContentAvailable(false);
        }
      );
    } else if (!_.isEmpty(plyFilePath?.image)) {
      new MTLLoader().load(
        plyFilePath.material,
        function (materials) {
          materials.preload();
          new OBJLoader()
            .setMaterials(materials)
            .load(plyFilePath.obj, function (object) {
              const texture = new THREE.TextureLoader().load(plyFilePath.image);
              const ambientLight = new THREE.AmbientLight("#FFFFFF");

              object.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                  child.material.map = texture;
                  child.geometry.computeBoundingBox();
                  child.name = `${meshName + index}`;
                  let bBox = child.geometry.boundingBox;
                  maxZ = bBox?.max?.z;
                  maxZ = maxZ + maxZ;
                }
              });
              object.name = `${meshName + index}`;
              const group = new THREE.Group();
              group.name = `${meshName} colouredObjGrp`;
              group.add(ambientLight);
              group.add(object);
              scene.add(group);
              meshLoaded.push(`${meshName + index}`);
              setTimeout(() => {
                isloaded = true;
                setLoader(false);
              }, 1000);
            });
        },
        (onProgress) => {
          setLoadingPer(
            Math.floor((onProgress.loaded / onProgress.total) * 100)
          );
        },
        (error) => {
          setContentAvailable(false);
        }
      );
    }
  }
  return <primitive object={scene} />;
};

function AddSoftWhiteLight(inPosition) {
  const intensity = 0.02;
  const light = new THREE.PointLight(0xffffff, intensity);
  light.position.set(inPosition.x, inPosition.y, inPosition.z);
  state.scene.add(light);
}

function View3DFloorPlan(props) {
  const [popUp, setPopUp] = useState({
    show: false,
    override: false,
    overridePrevented: false,
  });
  const { t } = useTranslation();
  const [tab, setTab] = useState({
    currentTab: "",
    nextTab: "",
  });
  const [zoom, setZoom] = useState("");
  const [focus, setFocus] = useState({});
  const [ZoomChange, setZoomChange] = useState(false);
  const [lockModel, SetLockModel] = useState(true);
  const [lineArray, setLineArray] = useState([]);
  const [suggestlineArray, setSuggestLineArray] = useState([]);
  const [showScatch, setShowScatch] = useState(false);
  const [fileType, setFileType] = useState("");
  const [popUpMsg, SetPopUpMsg] = useState("");
  const [clickOn, setClickOn] = useState("");
  const [drawLine, setDrawLine] = useState(false);
  const [hidePly, setHidePly] = useState(false);
  const [JsonObject, setJsonObject] = useState({});
  const [drawFloorPlan, setDrawFloorPlan] = useState(false);
  const [floorScanId, setFloorScanId] = useState("");
  const [plyFilePath, setPlyFilePath] = useState([]);
  const [pinLocation, setPinLocation] = useState(null);
  const [floorScanTypeDetail, setFloorScanTypeDetail] = useState(null);
  const [loader, setLoader] = useState(false);
  const [publish, setPublish] = useState({
    show: false,
    name: "",
  });
  const [showPublishSidebar, setShowPublishSidebar] = useState(false);
  const [loadingPer, setLoadingPer] = useState(0);
  const [floorIndex, setFloorIndex] = useState("");
  const [contentAvailable, setContentAvailable] = useState(true);
  const [connectFinish, setConnectFinish] = useState(false);
  const downloadFile = useSelector(
    (state) => state.downloadFilePercentageReducer
  );
  const isNavOpen = useSelector((state) => state.ui.isNavOpen);
  const [downloadFilePercentage, setDownloadFilePercentage] = useState(0);
  const [isZipDownloaded, setIsZipDownloaded] = useState(false);
  const clickExplore = useRef();
  const [selectedRoom, setSelectedRoom] = useState(areaLabel?.[0]?.value);
  const [selectedRoomType, setSelectedRoomType] = useState(Select_Area_Type);
  const [roomArray, setRoomArray] = useState([]);
  const [doorArray, setDoorArray] = useState([]);
  const [windowArray, setWindowArray] = useState([]);
  const [textArray, setTextArray] = useState([]);
  const [liveLineMoveData, setLiveLineMoveData] = useState([]);
  const [areaLabelTextArray, setAreaLabelTextArray] = useState([]);
  const [isAddDoor, setIsAddDoor] = useState(false);
  const [isAddWindow, setIsAddWindow] = useState(false);
  const [isDragLine, setIsDragLine] = useState(false);
  const [isAddLabel, setIsAddLabel] = useState(false);
  const [doorWindowCircleArray, setDoorWindowCircleArray] = useState([]);
  const [selectedAdditionalType, setSelectedAdditionalType] = useState(null);
  const [nameOfMesh, setNameOfMesh] = useState(null);
  const [selectedPoint, setSelectedPoint] = useState("");
  const [selectedRoomId, setSelectedRoomId] = useState(null);
  const [parentRoomId, setParentRoomId] = useState(null);
  const [selectedLineId, setSelectedLineId] = useState(null);

  const [selectedRoomForLable, setSelectedRoomForLable] = useState("");
  const [isZipFile, setIsZipFile] = useState(false);
  const [isSelectItem, setIsSelectItem] = useState(false);
  const [screenMode, setScreenMode] = useState(screenModeTypes.minimize);
  const [isSelectDoorItem, setIsSelectDoorItem] = useState(false);
  const [draggedLines, setDraggedLines] = useState([]);
  const [isDownAt, setIsDownAt] = useState({
    label: 0,
    room: 0,
    partition: 0,
    staircase: 0,
  });
  const [selectedTextId, setSelectedTextId] = useState(null);
  const [selectedLabelId, setSelectedLabelId] = useState(null);
  const [deletedLabelHistory, setDeletedLabelHistory] = useState([]);
  const [addDoorDirection, setAddDoorDirection] = useState(
    doorDirectionEnum.inside
  );
  const [deleteSelectedDoorWin, setDeleteSelectedDoorWin] = useState({
    isDelete: false,
    isDeleteWindow: false,
    name: "",
  });
  const [hideLabels, setHideLabels] = useState(true);
  const [deleteRoom, setDeleteRoom] = useState({
    roomId: null,
    isDelete: false,
  });
  const [deletedRoom, setDeletedRoom] = useState([]);
  const [basePoints, setBasePoints] = useState([]);
  const [isAddPartition, setIsAddPartition] = useState();
  const [partitionArray, setPartitionArray] = useState([]);
  const [partitionFirstArray, setPartitionFirstArray] = useState([]);
  const [isDragPartitionWall, setIsDragPartitionWall] = useState(false);
  const [markerPointArray, setMarkerPointArray] = useState({
    points: null,
    isMesh: 0,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [wallThickness, setWallThickness] = useState(9);
  const [navOpenBeforeMaximize, setnavOpenBeforeMaximize] = useState(false);
  const [oldRoomArray, setOldRoomArray] = useState([]);
  const [isSideView, setIsSideView] = useState(true);
  const orbitCtrl = useRef();
  const [floorDetails, setFloorDetails] = useState(null);
  const [isAutoDetect, setIsAutoDetect] = useState(false);
  const [refresh, setRefresh] = useState(false);

  const [axisCords, setAxisCords] = useState([]);
  const [highlighterCords, setHighlighterCords] = useState([]);
  const [isAddStairCase, setIsAddStairCase] = useState(false);
  const [stairCaseArray, setStairCaseArray] = useState([]);
  const [selectedRoomStairCase, setSelectedRoomStairCase] = useState(null);
  const [selectedStairObject, setSelectedStairObject] = useState(null);
  const [prevselectedStairObject, setPrevSelectedStairObject] = useState(null);

  const [selectedTorusDetails, setSelectedTorusDetails] = useState(null);

  useEffect(() => {
    if (
      drawLine ||
      isAddDoor ||
      isAddLabel ||
      isAddPartition ||
      isAddStairCase ||
      isAddWindow
    )
      setHideLabels(true);
  }, [
    isAddDoor,
    isAddLabel,
    isAddPartition,
    isAddStairCase,
    isAddWindow,
    drawLine,
  ]);

  useEffect(() => {
    screenSize = {
      mode: screenMode,
      navOpen: isNavOpen,
    };
  }, [isNavOpen, screenMode]);

  useEffect(() => {
    setLoader(loader);
  }, [loader]);
  useEffect(() => {
    setDownloadFilePercentage(downloadFile.downloadFilePercentage);
    setIsZipDownloaded(downloadFile.fileDownloaded);
  }, [downloadFile]);
  useEffect(() => {
    if (plyFilePath.length > 0) {
      setCameraView("SIDE");
    }
  }, [plyFilePath]);
  useEffect(() => {
    maxZ = null;
    setDownloadFilePercentage(0);
    setIsZipDownloaded(false);
    meshExist = [];
    meshLoaded = [];
    state?.scene?.clear();
    state = null;
    autoSaveSuccess = true;
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    if (props.id) {
      setFloorScanId(props.id);
    }
    if (plyFilePath?.length === 0) {
      props
        .fetchFloor({ floorScanId: props.id })
        .then((data) => {
          setFloorDetails(data?.data);
          let payloadForZip = {
            floorScanId: data?.data?.floorScanId,
            fileName: data?.data?.plyViewPath?.substring(
              data?.data?.plyViewPath?.lastIndexOf("/") + 1
            ),
          };
          setPinLocation(data?.data?.pinLocation);
          setFloorScanTypeDetail(data?.data?.floorScanType);
          setFloorIndex(data?.data?.floorIndex);
          setWallThickness(
            data?.data?.wallThickness >= 0 ? data.data.wallThickness : 9
          );
          let isZip = payloadForZip?.fileName?.split(".").pop();
          if (isZip === "zip") {
            setIsZipFile(true);
            setLoader(true);
            props
              .fetchZipFile(payloadForZip)
              .then(function (response) {
                setLoader(false);
                if (response.status === 200 || response.status === 0) {
                  return Promise.resolve(response.data);
                } else {
                  return Promise.reject(new Error(response.statusText));
                }
              })
              .then(JSZip.loadAsync)
              .then(function (zip) {
                let extractedFiles = Object.values(zip.files);
                if (extractedFiles.length > 0) {
                  let plysPath = [];
                  let materialObj = null;
                  extractedFiles?.map((element, index) => {
                    element
                      .async("blob")
                      .then((res) => {
                        let plyName = new File([res], element.name);
                        plysPath.push(URL.createObjectURL(plyName));

                        if (plyName?.name?.split(".")?.pop() == "mtl") {
                          materialObj = {
                            ...materialObj,
                            material: URL.createObjectURL(plyName),
                          };
                        } else if (plyName.name?.split(".")?.pop() == "obj") {
                          materialObj = {
                            ...materialObj,
                            obj: URL.createObjectURL(plyName),
                          };
                        } else if (plyName.name?.split(".")?.pop() == "jpg") {
                          materialObj = {
                            ...materialObj,
                            image: URL.createObjectURL(plyName),
                          };
                        }
                        if (
                          extractedFiles?.length === plysPath?.length &&
                          !materialObj
                        ) {
                          setPlyFilePath(plysPath);
                        } else if (
                          !_.isEmpty(materialObj?.image) &&
                          !_.isEmpty(materialObj?.material) &&
                          !_.isEmpty(materialObj?.obj)
                        ) {
                          setPlyFilePath([materialObj]);
                        }
                      })
                      .catch((err) => {
                        if (
                          err?.response &&
                          err?.response?.data &&
                          err?.response?.data?.message
                        ) {
                          const {
                            response: { data },
                          } = err;
                          customToast.error(data?.message);
                          throw err;
                        }
                        customToast.error(UNEXPECTED_ERROR_MESSAGE);
                        throw err;
                      });
                  });
                } else {
                  setContentAvailable(false);
                  setLoader(true);
                }
              })
              .catch((err) => {
                if (
                  err?.response &&
                  err?.response?.data &&
                  err?.response?.data?.message
                ) {
                  const {
                    response: { data },
                  } = err;
                  customToast.error(data?.message);
                  throw err;
                }
                customToast.error(UNEXPECTED_ERROR_MESSAGE);
                throw err;
              });
          } else {
            setPlyFilePath([data?.data?.plyViewPath]);
          }
        })
        .catch((err) => {
          throw err;
        });
    }
    clickExplore.current.click();
    return () => {
      if (screenSize.mode === screenModeTypes.minimize && !screenSize.navOpen) {
        props.updateNavBar();
      }
      if (screenSize.mode === screenModeTypes.maximize) {
        props.updateHeader();
        props.updateNavBar();
      }
    };
  }, []);

  useEffect(() => {
    if (!_.isEqual(roomArray, oldRoomArray)) {
      setOldRoomArray(roomArray);
      calculateRoomArea(roomArray, setRoomArray);
    }
  }, [roomArray, oldRoomArray]);

  useEffect(() => {
    if (!_.isNil(selectedRoomStairCase)) {
      if (!_.isNil(selectedTextId)) {
        setSelectedTextId(null);
      }
      if (!_.isNil(selectedLabelId)) {
        setSelectedLabelId(null);
      }
      if (
        deleteSelectedDoorWin?.isDelete ||
        deleteSelectedDoorWin?.isDeleteWindow
      ) {
        setDeleteSelectedDoorWin({
          isDelete: false,
          isDeleteWindow: false,
          name: "",
        });
      }
    }
  }, [selectedLabelId, selectedRoomStairCase, selectedTextId]);

  useEffect(() => {
    if (!_.isNil(selectedRoomStairCase) && !_.isNil(selectedTextId)) {
      setSelectedRoomStairCase(null);
    }
    if (
      !_.isNil(selectedTextId) &&
      (deleteSelectedDoorWin?.isDelete || deleteSelectedDoorWin?.isDeleteWindow)
    ) {
      setDeleteSelectedDoorWin({
        isDelete: false,
        isDeleteWindow: false,
        name: "",
      });
    }
  }, [selectedTextId]);

  useEffect(() => {
    if (!_.isNil(selectedRoomStairCase) && !_.isNil(selectedLabelId)) {
      setSelectedRoomStairCase(null);
    }
  }, [selectedLabelId]);

  useEffect(() => {
    if (!_.isNil(selectedRoomStairCase)) {
      removeMagnifier();
    }
  }, [selectedRoomStairCase]);

  useEffect(() => {
    if (
      deleteSelectedDoorWin?.isDelete ||
      deleteSelectedDoorWin?.isDeleteWindow
    ) {
      if (!_.isNil(selectedTextId)) {
        setSelectedTextId(null);
      }
      if (!_.isNil(selectedLabelId)) {
        setSelectedLabelId(null);
      }
      if (!_.isNil(selectedRoomStairCase) && !_.isNil(selectedLabelId)) {
        setSelectedRoomStairCase(null);
      }
    }
  }, [deleteSelectedDoorWin]);

  const getUpdatedValue = () => {
    return {
      doorArray: _.cloneDeep(doorArray),
      windowArray: _.cloneDeep(windowArray),
      textArray: _.cloneDeep(textArray),
      lineArray: _.cloneDeep(lineArray),
      roomArray: _.cloneDeep(roomArray),
      lineArrayFab: _.cloneDeep(lineArrayFab),
      lineArrayFabstr: _.cloneDeep(lineArrayFabstr),
      suggestlineArray: _.cloneDeep(suggestlineArray),
      textArrayFabstr: _.cloneDeep(textArrayFabstr),
      partitionArray: _.cloneDeep(partitionArray),
      areaLabelTextArray: _.cloneDeep(areaLabelTextArray),
      stairCaseArray: _.cloneDeep(stairCaseArray),
      stairCaseArrayFabstr: _.cloneDeep(stairCaseArrayFabstr),
      changesStack: _.cloneDeep(changesStack),
    };
  };

  useEffect(() => {
    if (
      !isDragLine &&
      !_.isEmpty(floorScanId) &&
      tab.currentTab === "Measurement" &&
      JSON.stringify(getUpdatedValue()) !==
        floorDetails?.floorScan3dAutoSaveJson &&
      autoSaveSuccess
    ) {
      autoSaveSuccess = false;
      props
        .autoSaveThreeDJson({
          floorScan3dAutoSaveJson: JSON.stringify(getUpdatedValue()),
          floorScanId: floorScanId,
        })
        .then((_) => (autoSaveSuccess = true))
        .catch((_) => (autoSaveSuccess = true));
    }
  }, [
    doorArray,
    windowArray,
    textArray,
    lineArray,
    roomArray,
    suggestlineArray,
    partitionArray,
    areaLabelTextArray,
    floorScanId,
    stairCaseArray,
  ]);

  const pointerDown = (e) => {
    oldOrbitPointerDownDistance = e.distance ? e.distance.toFixed(2) : null;
    PointerDown(
      e,
      drawLine,
      draggingLine,
      setIsDragLine,
      setSelectedPoint,
      setSelectedRoomId,
      setSelectedLineId,
      setIsDownAt,
      setBasePoints,
      addChangesToStack,
      _.cloneDeep(roomArray),
      _.cloneDeep(doorArray),
      _.cloneDeep(windowArray),
      setSelectedLabelId,
      setSelectedTextId,
      _.cloneDeep(textArray),
      _.cloneDeep(partitionArray),
      setIsDragPartitionWall,
      isSelectItem,
      setParentRoomId,
      isAddPartition,
      _.cloneDeep(stairCaseArray),
      selectedRoomStairCase
    );
  };

  const pointerUp = (e) => {
    setSelectedTorusDetails(null);
    PointerUp(
      e,
      drawLine,
      selectedRoomId,
      selectedLineId,
      isDownAt,
      roomArray,
      selectedPoint,
      setSelectedPoint,
      setRoomArray,
      setIsDownAt,
      setDraggedLines,
      draggedLines,
      setSelectedRoomId,
      setSelectedLineId,
      draggingLine,
      setIsDragLine,
      doorArray,
      setDoorArray,
      windowArray,
      setWindowArray,
      basePoints,
      setBasePoints,
      isDragPartitionWall,
      setIsDragPartitionWall,
      partitionArray,
      setPartitionArray,
      setSelectedTextId,
      setSelectedLabelId,
      selectedTextId,
      selectedLabelId,
      isDragLine,
      selectedRoomStairCase,
      setSelectedRoomStairCase
    );
  };

  function FakeSphere(props) {
    return (
      <>
        <Torus
          name={`roomArrayIndex${props?.roomArrayIndex}${props?.roomWallIndex}`}
          position={props.args}
          args={[0.15, 0.04, 2, 200]}
        >
          <meshBasicMaterial color={"red"} attach="material" />
        </Torus>
        {(!isDragLine || isAddDoor) && (
          <mesh
            name={`circle${props?.args?.toString()}`}
            roomid={props.roomId}
            parentroomid={props?.parentroomid}
            lineid={props.lineId}
            basePoints={props.basePoints}
            isPartition={props.isPartition ? props.isPartition : false}
            position={props.args}
            partitionArrayIndex={props?.partitionArrayIndex}
            partitionWallIndex={props?.partitionWallIndex}
            roomArrayIndex={props?.roomArrayIndex}
            roomWallIndex={props?.roomWallIndex}
            onPointerDown={(e) => {
              if (!isAddDoor && e.which == 1) {
                PointerDown(
                  e,
                  drawLine,
                  draggingLine,
                  setIsDragLine,
                  setSelectedPoint,
                  setSelectedRoomId,
                  setSelectedLineId,
                  setIsDownAt,
                  setBasePoints,
                  addChangesToStack,
                  _.cloneDeep(roomArray),
                  _.cloneDeep(doorArray),
                  _.cloneDeep(windowArray),
                  setSelectedLabelId,
                  setSelectedTextId,
                  _.cloneDeep(textArray),
                  _.cloneDeep(partitionArray),
                  setIsDragPartitionWall,
                  false,
                  setParentRoomId,
                  isAddPartition,
                  _.cloneDeep(stairCaseArray),
                  selectedRoomStairCase
                );
                if (e.eventObject) {
                  setSelectedTorusDetails({
                    selectedTorusType: e.eventObject?.isPartition
                      ? true
                      : false,
                    partitionArrayIndex: e.eventObject?.partitionArrayIndex,
                    partitionWallIndex: e.eventObject?.partitionWallIndex,
                    roomArrayIndex: e.eventObject?.roomArrayIndex,
                    roomWallIndex: e.eventObject?.roomWallIndex,
                  });
                }
              }
            }}
            onPointerUp={(e) => {
              if (isAddDoor) {
                setDoorWindow(e, {
                  partitionwall: null,
                  areatype: null,
                  arealabel: null,
                  additionaltype: null,
                });
              } else {
                pointerUp(e);
              }
            }}
          >
            <sphereGeometry args={[0.15, 64, 32]} attach="geometry" />
            <meshBasicMaterial attach="material" transparent opacity={0} />
          </mesh>
        )}
      </>
    );
  }

  const setLine = (e, setAxisCords) => {
    e.stopPropagation();
    setSelectedTextId(null);
    setSelectedLabelId(null);
    setSelectedRoomStairCase(null);
    if (tab.currentTab == "Measurement") {
      if (
        (oldOrbitPointerDownDistance === null ||
          oldOrbitPointerDownDistance === (e.clientX, e.clientY).toString()) &&
        drawLine &&
        !lockModel &&
        !showScatch &&
        !lineArrayFabstr.includes(e.x + "," + e.y)
      ) {
        addChangesToStack({
          isAddDoor: false,
          isAddWindow: false,
        });
        if (lineArray.length === 0) {
        }
        setAxisCords([
          [e.point.x + Axis_Length, e.point.y, e.point.z + 0.1],
          [e.point.x - Axis_Length, e.point.y, e.point.z + 0.1],
          [e.point.x, e.point.y + Axis_Length, e.point.z + 0.1],
          [e.point.x, e.point.y - Axis_Length, e.point.z + 0.1],
        ]);
        setLineArray([...lineArray, [e.point.x, e.point.y, e.point.z]]);
        lineArrayFab.push({ x: e.point.x, y: e.point.y, z: e.point.z });
        lineArrayFabstr.push(e.x + "," + e.y);
        if (lineArray.length >= 2) {
          setSuggestLineArray([
            [e.point.x, e.point.y, e.point.z],
            [lineArray[0][0], lineArray[0][1], lineArray[0][2]],
          ]);
        } else {
          setSuggestLineArray([]);
        }
        setIsAddDoor(false);
        setIsAddWindow(false);
      } else if (isAddLabel) {
        addChangesToStack({
          isAddLabel: false,
        });
        let selectedRoomForLable = FindParentRoomOfPoint(e.point, roomArray);
        if (
          selectedRoomForLable !== "" &&
          !textArrayFabstr.includes(e.x + "," + e.y)
        ) {
          textArrayFabstr.push(e.x + "," + e.y);
          setTextArray([
            ...textArray,
            {
              points: [e.point.x, e.point.y, e.point.z],
              roomID: `room:${selectedRoomForLable}`,
              labelId:
                textArray && textArray.length > 0
                  ? findMaxLabelId(textArray) + 1
                  : 0,
              text:
                selectedRoom == areaLabel?.[0]?.value
                  ? "Tap and Type"
                  : selectedRoom,
            },
          ]);
          setSelectedRoomForLable("");
          setIsAddLabel(false);
        } else {
          customToast.error("Oops! please try to add label inside room area.");
        }
      } else if (isAddStairCase) {
        addChangesToStack({
          isAddStairCase: false,
        });
        let selectedRoomForStairCase = FindParentRoomOfPoint(
          e.point,
          roomArray
        );
        if (
          selectedRoomForStairCase !== "" &&
          !stairCaseArrayFabstr.includes(e.x + "," + e.y)
        ) {
          stairCaseArrayFabstr.push(e.x + "," + e.y);
          setStairCaseArray([
            ...stairCaseArray,
            {
              points: [e.point.x, e.point.y, e.point.z],
              roomID: `room:${selectedRoomForStairCase}`,
              angle: state.controls.getAzimuthalAngle(),
              stairCaseId:
                stairCaseArray && stairCaseArray.length > 0
                  ? findMaxStairCaseId(stairCaseArray) + 1
                  : 0,
            },
          ]);

          setSelectedRoomStairCase(null);
          setIsAddStairCase(false);
          removeMagnifier();
        } else {
          customToast.error(threeDFloorScan.add_staircase);
        }
      }
    } else {
      if (
        plyFilePath.length > 1 &&
        e?.object?.name?.substring(0, 8) === meshName
      ) {
        setNameOfMesh(e?.object?.name);
      } else if (plyFilePath.length > 1) {
        setNameOfMesh(null);
      }
    }
  };

  const setDoorWindow = (e, areaDetails) => {
    e.stopPropagation();
    setSelectedTextId(null);
    setSelectedLabelId(null);
    if (!areaDetails.partitionwall && (isAddDoor || isAddWindow)) {
      if (e?.object?.name?.includes("circle")) {
        if (
          doorwindowArray.length &&
          doorwindowArray[0].roomId === e.eventObject.roomid
        ) {
          customToast.error(threeDFloorScan.Add_Door_Window_On_Same_Wall);
          return;
        }
        let isIntersectDoors = null;
        doorArray.forEach((doorEl) => {
          if (
            doorwindowArray.length &&
            ((doorEl[0].points.toString() ===
              doorwindowArray[0].points.toString() &&
              doorEl[1].points.toString() ===
                e.eventObject.position.toArray().toString()) ||
              (doorEl[1].points.toString() ===
                doorwindowArray[0].points.toString() &&
                doorEl[0].points.toString() ===
                  e.eventObject.position.toArray().toString())) &&
            !isIntersectDoors
          ) {
            isIntersectDoors = true;
            customToast.error(threeDFloorScan.Add_Door_Window_On_Same_Wall);
          }
        });
        if (!isIntersectDoors) {
          if (
            doorwindowArray.length === 1 &&
            doorwindowArray[0].parentRoomId !== e.eventObject.parentroomid
          ) {
            customToast.error(threeDFloorScan.Add_Partition_Door_In_Same_Room);
            return;
          } else {
            let doorWindowObject = {
              points: [
                e.eventObject.position.x,
                e.eventObject.position.y,
                e.eventObject.position.z,
              ],
              type: isAddDoor ? "Door" : "Window",
              lineId: `isPartitionDoor::${e.eventObject.lineId}`,
              roomId: e.eventObject.roomid,
              parentRoomId: e.eventObject.parentroomid,
            };
            doorwindowArray.push(doorWindowObject);
            if (isAddDoor) {
              doorWindowObject.doorDirection = addDoorDirection;
            }
            setDoorWindowCircleArray(doorwindowArray);
            if (doorwindowArray.length === 2) {
              addChangesToStack({
                isAddDoor: false,
                isAddLabel: false,
                isAddWindow: false,
                isAddStairCase: false,
              });
              if (isAddDoor) {
                setDoorArray([...doorArray, doorwindowArray]);
                doorwindowArray = [];
              } else {
                setWindowArray([...windowArray, doorwindowArray]);
                doorwindowArray = [];
              }
              setIsAddWindow(false);
              setIsAddDoor(false);
              removeMagnifier();
              setDoorWindowCircleArray([]);
            }
          }
        }
      } else {
        if (
          doorwindowArray.length > 0 &&
          doorwindowArray[0].lineId != e.object.lineid
        ) {
          customToast.error(threeDFloorScan.Add_Door_Window_On_Same_Wall);
          return;
        }
        let mainRoomId = FindParentRoomOfPoint(e.point, roomArray);
        let isIntersectDoors = null;
        roomArray.forEach((roomEl) => {
          if (!isIntersectDoors) {
            doorArray.forEach((doorEl) => {
              if (
                roomEl.roomId === e.object.roomid &&
                doorEl[0].lineId === e.object.lineid &&
                !isIntersectDoors
              ) {
                isIntersectDoors = isIntersectDoor(
                  doorwindowArray.length === 0
                    ? null
                    : doorwindowArray[0].points,
                  e.pointOnLine,
                  doorEl[0].points,
                  doorEl[1].points
                );
              }
            });
            windowArray.forEach((winEl) => {
              if (
                roomEl.roomId === e.object.roomid &&
                winEl[0].lineId === e.object.lineid &&
                !isIntersectDoors
              ) {
                isIntersectDoors = isIntersectDoor(
                  doorwindowArray.length === 0
                    ? null
                    : doorwindowArray[0].points,
                  e.pointOnLine,
                  winEl[0].points,
                  winEl[1].points
                );
              }
            });
          }
        });

        if (!isIntersectDoors) {
          let doorWindowObject = {
            points: [e.pointOnLine.x, e.pointOnLine.y, e.pointOnLine.z],
            type: isAddDoor ? "Door" : "Window",
            lineId: e.object.lineid,
            lineid: e.object.lineid,
            roomId: e.object.roomid,
            parentRoomId:
              e.eventObject.name === "partitionwall"
                ? mainRoomId
                : e.object.roomid,
          };
          doorwindowArray.push(doorWindowObject);
          if (isAddDoor) {
            doorWindowObject.doorDirection = addDoorDirection;
          }
          setDoorWindowCircleArray(doorwindowArray);
          if (doorwindowArray.length === 2) {
            addChangesToStack({
              isAddDoor: false,
              isAddLabel: false,
              isAddWindow: false,
              isAddStairCase: false,
            });
            if (isAddDoor) {
              setDoorArray([...doorArray, doorwindowArray]);
              doorwindowArray = [];
            } else {
              setWindowArray([...windowArray, doorwindowArray]);
              doorwindowArray = [];
            }
            setIsAddWindow(false);
            setIsAddDoor(false);
            removeMagnifier();
            setDoorWindowCircleArray([]);
            setMarkerPointArray({ points: null, isMesh: 0 });
          }
        } else if (isIntersectDoors) {
          if (isAddDoor) {
            customToast.error(threeDFloorScan.door_override);
          } else {
            customToast.error(threeDFloorScan.window_override);
          }
        }
      }
    } else if (areaDetails.partitionwall && isAddWindow) {
      if (
        doorwindowArray.length > 0 &&
        doorwindowArray[0].lineId != e.object.lineid
      ) {
        customToast.error(threeDFloorScan.Add_Door_Window_On_Same_Wall);
        return;
      }
      let mainRoomId = FindParentRoomOfPoint(e.point, roomArray);
      let isIntersectDoors = null;
      partitionArray.forEach((roomEl) => {
        if (!isIntersectDoors) {
          doorArray.forEach((doorEl) => {
            if (
              roomEl.roomId === e.object.roomid &&
              doorEl[0].lineId === e.object.lineid &&
              !isIntersectDoors
            ) {
              isIntersectDoors = isIntersectDoor(
                doorwindowArray.length === 0 ? null : doorwindowArray[0].points,
                e.pointOnLine,
                doorEl[0].points,
                doorEl[1].points
              );
            }
          });
          windowArray.forEach((winEl) => {
            if (
              roomEl.roomId === e.object.roomid &&
              winEl[0].lineId === e.object.lineid &&
              !isIntersectDoors
            ) {
              isIntersectDoors = isIntersectDoor(
                doorwindowArray.length === 0 ? null : doorwindowArray[0].points,
                e.pointOnLine,
                winEl[0].points,
                winEl[1].points
              );
            }
          });
        }
      });

      if (!isIntersectDoors) {
        let doorWindowObject = {
          points: [e.pointOnLine.x, e.pointOnLine.y, e.pointOnLine.z],
          type: "partitionWindow",
          lineId: e.object.lineid,
          lineid: `partitionWindow::${e.eventObject.lineId}`,
          roomId: e.object.roomid,
          parentRoomId:
            e.eventObject.name === "partitionwall"
              ? mainRoomId
              : e.object.roomid,
        };
        doorwindowArray.push(doorWindowObject);
        if (isAddDoor) {
          doorWindowObject.doorDirection = addDoorDirection;
        }
        setDoorWindowCircleArray(doorwindowArray);
        if (doorwindowArray.length === 2) {
          addChangesToStack({
            isAddDoor: false,
            isAddLabel: false,
            isAddWindow: false,
            isAddStairCase: false,
          });
          if (isAddDoor) {
            setDoorArray([...doorArray, doorwindowArray]);
            doorwindowArray = [];
          } else {
            setWindowArray([...windowArray, doorwindowArray]);
            doorwindowArray = [];
          }
          setIsAddWindow(false);
          setIsAddDoor(false);
          removeMagnifier();
          setDoorWindowCircleArray([]);
          setMarkerPointArray({ points: null, isMesh: 0 });
        }
      } else if (isIntersectDoors) {
        if (isAddDoor) {
          customToast.error(threeDFloorScan.door_override);
        } else {
          customToast.error(threeDFloorScan.window_override);
        }
      }
    } else if (
      isSelectItem &&
      !isSelectDoorItem &&
      !drawLine &&
      !isDragPartitionWall &&
      !isAddPartition &&
      !isAddDoor &&
      !isAddWindow &&
      e?.eventObject?.roomid?.toString()
    ) {
      setDeleteSelectedDoorWin({
        name: "",
        isDelete: false,
        isDeleteWindow: false,
      });
      const isSelectedRoom =
        e.eventObject.roomid === deleteRoom.roomId || deleteRoom.roomId === null
          ? !deleteRoom.isDelete
          : true;
      setDeleteRoom({
        isDelete: isSelectedRoom,
        roomId: isSelectedRoom ? e.eventObject.roomid : null,
        isAdditional: isSelectedRoom ? areaDetails.additionaltype : null,
        roomName: isSelectedRoom ? e.eventObject?.name : null,
      });
      areaDetails.areatype && isSelectedRoom
        ? setSelectedRoomType(areaDetails.areatype)
        : setSelectedRoomType(Select_Area_Type);
      areaDetails.arealabel && isSelectedRoom
        ? setSelectedRoom(areaDetails.arealabel)
        : setSelectedRoom(areaLabel?.[0]?.value);
    } else if (!isAddDoor && !isAddWindow) {
      setLine(e, setAxisCords);
    }
  };

  function SelectToZoom({ children, ...props }) {
    const api = useBounds();
    boundsRef = api;
    // return (
    //   <group {...props} onClick={(e) => (e.stopPropagation(), e.delta <= 2 && api.refresh(e.object).fit())} onPointerMissed={(e) => e.button === 0 && api.refresh().fit()}>
    //     {children}
    //   </group>
    // )
    return null;
  }

  const showPopUp = (tab, eventButton, override) => {
    if (eventButton == "yes") {
      if (publish.show && clickOn == "Preview") {
        props
          .publishJson({
            floorScanId: props.id,
            floorScanJson: JsonObject,
            floorTagName: publish.name,
            isOverrideFloorTagName: !!override,
          })
          .then((data) => {
            if (data.status == 200) {
              if (data.data.status === STATUS.STATUS_TAG_ALREADY_EXIST) {
                SetPopUpMsg(threeDFloorScan.msgForSameFloorPublish);
                setPopUp({
                  show: true,
                  override: true,
                  overridePrevented: false,
                });
              } else if (
                data.data.status === STATUS.STATUS_OVERRIDE_PREVENTED
              ) {
                SetPopUpMsg(threeDFloorScan.msgForFloorplanPrevented);
                setPopUp({
                  show: true,
                  override: false,
                  overridePrevented: true,
                });
              } else {
                props.autoSaveThreeDJson({
                  floorScan3dAutoSaveJson: null,
                  floorScanId: floorScanId,
                });
                setIsAutoDetect(true);
                customToast.success("Floor Plan Published Successfully!!");
                setPublish({
                  show: false,
                  name: "",
                });
                setShowPublishSidebar(false);
              }
            }
          })
          .catch((err) => {
            if (
              err?.response &&
              err?.response?.data &&
              err?.response?.data?.message
            ) {
              const {
                response: { data },
              } = err;
              customToast.error(data?.message);
              throw err;
            }
            customToast.error(UNEXPECTED_ERROR_MESSAGE);
            throw err;
          });
      } else {
        setTab({ currentTab: clickOn, nextTab: "" });
        if (tab.nextTab == "Preview") {
          setShowScatch(true);
          setDrawLine(false);
          setIsSelectItem(false);
          setIsSelectDoorItem(false);
          ShowFabNew(
            roomArray,
            state,
            floorIndex,
            floorName,
            setJsonObject,
            setDrawFloorPlan,
            wallThickness,
            textArray,
            stairCaseArray
          );
        } else if (tab.nextTab == "Explore") {
          isloaded = false;
          setLineArray([]);
          setRoomArray([]);
          setSuggestLineArray([]);
          lineArrayFab = [];
          lineArrayFabstr = [];
          textArrayFabstr = [];
          setConnectFinish(false);
          setShowScatch(false);
          setPartitionArray([]);
          setPartitionFirstArray([]);
          setIsDragPartitionWall(false);
          setMarkerPointArray({ points: null, isMesh: 0 });
          deselectSelectedRoom(deleteRoom, setDeleteRoom);
          resetAreaDetails(
            Select_Area_Type,
            setSelectedRoomType,
            setSelectedRoom
          );
          doorwindowArray = [];
          setIsAddDoor(false);
          removeMagnifier();
          setIsAddWindow(false);
          setHideLabels(false);
          stairCaseArrayFabstr = [];
        } else if (tab.nextTab == "Measurement") {
        }
      }
      setTextArray([]);
      setAreaLabelTextArray([]);
      setDoorArray([]);
      setWindowArray([]);
      setStairCaseArray([]);
    } else {
      setClickOn(tab.currentTab);
    }
  };

  const checkPopUpMsg = (temptab) => {
    if (temptab.nextTab == "Measurement" && temptab.currentTab == "Explore") {
      // SetPopUpMsg(msgForLock);
    } else if (
      temptab.nextTab == "Explore" &&
      temptab.currentTab == "Preview"
    ) {
      SetPopUpMsg(threeDFloorScan.msgForPreview);
    } else if (
      temptab.nextTab == "Preview" &&
      temptab.currentTab == "Measurement"
    ) {
      SetPopUpMsg(threeDFloorScan.msgForPreview);
    }
  };

  const addChangesToStack = (paramLatestChanges = {}) => {
    const latestChanges = {
      isAddWindow,
      isAddDoor,
      isAddLabel,
      isDragLine,
      drawLine,
      showScatch,
      doorArray: _.cloneDeep(doorArray),
      selectedTextId,
      windowArray: _.cloneDeep(windowArray),
      textArray: _.cloneDeep(textArray),
      lineArray: _.cloneDeep(lineArray),
      roomArray: _.cloneDeep(roomArray),
      selectedRoomType: _.cloneDeep(selectedRoomType),
      selectedRoom: _.cloneDeep(selectedRoom),
      lineArrayFab,
      selectedRoomForLable,
      lineArrayFabstr,
      polypointsx,
      polypointsy,
      suggestlineArray: _.cloneDeep(suggestlineArray),
      textArrayFabstr,
      partitionArray: _.cloneDeep(partitionArray),
      areaLabelTextArray: _.cloneDeep(areaLabelTextArray),
      isAddStairCase,
      stairCaseArray,
      selectedRoomStairCase,
      stairCaseArrayFabstr,
      ...paramLatestChanges,
    };
    if (
      changesStack.length == 0 ||
      !_.isEqual(changesStack[changesStack.length - 1], latestChanges)
    ) {
      changesStack.push(latestChanges);
      setRefresh(!refresh);
    }
  };

  const undoChangesToStack = () => {
    const lastChanges = changesStack.pop();
    setDoorArray([...lastChanges.doorArray]);
    setWindowArray([...lastChanges.windowArray]);
    setTextArray([...lastChanges.textArray]);
    setLineArray([...lastChanges.lineArray]);
    setRoomArray([...lastChanges.roomArray]);
    lineArrayFab = [...lastChanges.lineArrayFab];
    lineArrayFabstr = [...lastChanges.lineArrayFabstr];
    polypointsx = [...lastChanges.polypointsx];
    polypointsy = [...lastChanges.polypointsy];
    setSuggestLineArray([...lastChanges.suggestlineArray]);
    textArrayFabstr = [...lastChanges.textArrayFabstr];
    setPartitionArray([...lastChanges.partitionArray]);
    setAreaLabelTextArray([...lastChanges.areaLabelTextArray]);
    setStairCaseArray([...lastChanges.stairCaseArray]);
    stairCaseArrayFabstr = [...lastChanges.stairCaseArrayFabstr];
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    UpdateAxisCords(lastChanges);
    setHighlighterCords([]);
    setSelectedStairObject(null);
    setPrevSelectedStairObject(null);
    setSelectedRoomStairCase(null);
    removeMagnifier();
  };

  const UpdateAxisCords = (lastChanges) => {
    let lastpoint = lastChanges?.lineArray[lastChanges?.lineArray?.length - 1];
    if (lastpoint == undefined || !drawLine) setAxisCords([]);
    else
      setAxisCords([
        [lastpoint[0] + Axis_Length, lastpoint[1], lastpoint[2] + 0.1],
        [lastpoint[0] - Axis_Length, lastpoint[1], lastpoint[2] + 0.1],
        [lastpoint[0], lastpoint[1] + Axis_Length, lastpoint[2] + 0.1],
        [lastpoint[0], lastpoint[1] - Axis_Length, lastpoint[2] + 0.1],
      ]);
  };

  const ConnectAndAddRoom = () => {
    if (selectedRoomType === Select_Area_Type) {
      customToast.error(threeDFloorScan.Please_Select_Area_Type);
      return;
    }
    addChangesToStack();
    let connectRoom = [
      ...roomArray,
      {
        roomname: selectedRoom !== areaLabel?.[0]?.value ? selectedRoom : "",
        areatype: selectedRoomType,
        additionaltype: selectedAdditionalType,
        data: lineArray,
        totalAreaOfRoom: null,
        roomId:
          roomArray && roomArray.length > 0
            ? findMaxRoom(roomArray, partitionArray) + 1
            : 0,
      },
    ];
    if (selectedRoom !== areaLabel?.[0]?.value) {
      let updateAreaLabel = Object.assign(areaLabelTextArray, []);
      let areaLabelCoords = {
        x:
          (Math.min(...lineArray.map((val) => val[0])) +
            Math.max(...lineArray.map((val) => val[0]))) /
          2,
        y:
          (Math.min(...lineArray.map((val) => val[1])) +
            Math.max(...lineArray.map((val) => val[1]))) /
          2,
        z:
          (Math.min(...lineArray.map((val) => val[2])) +
            Math.max(...lineArray.map((val) => val[2]))) /
          2,
      };
      setAreaLabelTextArray([
        ...updateAreaLabel,
        {
          points: [areaLabelCoords.x, areaLabelCoords.y, areaLabelCoords.z],
          roomID: `room:${
            roomArray && roomArray.length > 0
              ? findMaxRoom(roomArray, partitionArray) + 1
              : 0
          }`,
          labelId:
            areaLabelTextArray && areaLabelTextArray.length > 0
              ? findMaxLabelId(areaLabelTextArray) + 1
              : 0,
          text: selectedRoom,
        },
      ]);
    }
    setRoomArray([...connectRoom]);
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    setDrawLine(false);
    removeMagnifier();
    setLineArray([]);
    lineArrayFab = [];
    lineArrayFabstr = [];
    textArrayFabstr = [];
    setSuggestLineArray([]);
    setAxisCords([]);
    setHighlighterCords([]);
    stairCaseArrayFabstr = [];
  };

  const toggleAddLine = (isDrawLine, selectedAdditionalType) => {
    if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (partitionFirstArray.length) {
      customToast.error(
        threeDFloorScan.Please_complete_the_partition_first_before_moving_ahead
      );
      return;
    }
    if (isDrawLine) {
      setTimeout(() => {
        magnify(canvasSelector, 2);
      }, 1000);
    } else {
      removeMagnifier();
    }
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setSelectedAdditionalType(selectedAdditionalType);
    setDrawLine(isDrawLine);
    !isDrawLine && setSelectedRoomType(Select_Area_Type);
    setIsAddWindow(false);
    setIsAddDoor(false);
    setIsAddLabel(false);
    setIsAddPartition(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setSelectedRoom(areaLabel?.[0]?.value);
    isDrawLine && lineArray?.length > 0
      ? setAxisCords([
          [
            lineArray[lineArray?.length - 1][0] + Axis_Length,
            lineArray[lineArray?.length - 1][1],
            lineArray[lineArray?.length - 1][2] + 0.1,
          ],
          [
            lineArray[lineArray?.length - 1][0] - Axis_Length,
            lineArray[lineArray?.length - 1][1],
            lineArray[lineArray?.length - 1][2] + 0.1,
          ],
          [
            lineArray[lineArray?.length - 1][0],
            lineArray[lineArray?.length - 1][1] + Axis_Length,
            lineArray[lineArray?.length - 1][2] + 0.1,
          ],
          [
            lineArray[lineArray?.length - 1][0],
            lineArray[lineArray?.length - 1][1] - Axis_Length,
            lineArray[lineArray?.length - 1][2] + 0.1,
          ],
        ])
      : setAxisCords([]);
    setHighlighterCords([]);
    setIsAddStairCase(false);
    setSelectedRoomStairCase(null);
  };

  const toggleAddDoor = () => {
    if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Add_Door
      );
      return;
    } else if (!roomArray.length) {
      customToast.error(threeDFloorScan.Please_Add_At_Least_One_Room);
      return;
    } else if (partitionFirstArray.length) {
      customToast.error(
        threeDFloorScan.Please_complete_the_partition_first_before_moving_ahead
      );
      return;
    }
    if (isAddDoor) {
      removeMagnifier();
    } else {
      setTimeout(() => {
        magnify(canvasSelector, 2);
      }, 1000);
    }
    setIsAddDoor(!isAddDoor);
    setDoorWindowCircleArray([]);
    doorwindowArray = [];
    setIsAddWindow(false);
    setDrawLine(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setIsAddLabel(false);
    setIsAddPartition(false);
    setMarkerPointArray({ points: null, isMesh: 0 });
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setIsAddStairCase(false);
    setSelectedRoomStairCase(null);
  };

  const toggleAddWindow = () => {
    if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Add_Window
      );
      return;
    } else if (!roomArray.length) {
      customToast.error(threeDFloorScan.Please_Add_At_Least_One_Room);
      return;
    } else if (partitionFirstArray.length) {
      customToast.error(
        threeDFloorScan.Please_complete_the_partition_first_before_moving_ahead
      );
      return;
    }
    if (isAddWindow) {
      removeMagnifier();
    } else {
      setTimeout(() => {
        magnify(canvasSelector, 2);
      }, 1000);
    }
    setIsAddWindow(!isAddWindow);
    setDoorWindowCircleArray([]);
    doorwindowArray = [];
    setIsAddDoor(false);
    setDrawLine(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setIsAddLabel(false);
    setIsAddPartition(false);
    setMarkerPointArray({ points: null, isMesh: 0 });
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setIsAddStairCase(false);
    setSelectedRoomStairCase(null);
  };

  const toggleAddLabel = () => {
    if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Add_Label
      );
      return;
    } else if (!roomArray.length) {
      customToast.error(threeDFloorScan.Please_Add_At_Least_One_Room);
      return;
    } else if (partitionFirstArray.length) {
      customToast.error(
        threeDFloorScan.Please_complete_the_partition_first_before_moving_ahead
      );
      return;
    }
    setSelectedTextId(null);
    setIsAddLabel(!isAddLabel);
    setIsAddWindow(false);
    setIsAddDoor(false);
    removeMagnifier();
    setDrawLine(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setSelectedRoomForLable("");
    setIsAddPartition(false);
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setIsAddStairCase(false);
    setSelectedRoomStairCase(null);
  };

  const toggleAddPartition = () => {
    if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Add_Partition
      );
      return;
    } else if (!roomArray.length) {
      customToast.error(threeDFloorScan.Please_Add_At_Least_One_Room);
      return;
    }
    if (isAddPartition) {
      removeMagnifier();
    } else {
      setTimeout(() => {
        magnify(canvasSelector, 2);
      }, 1000);
    }
    setIsAddPartition(!isAddPartition);
    setPartitionFirstArray([]);
    setDrawLine(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setIsAddDoor(false);
    setIsAddWindow(false);
    setIsAddLabel(false);
    setSelectedRoomForLable("");
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setIsAddStairCase(false);
    setSelectedRoomStairCase(null);
  };

  const toggleHidePLY = (val) => {
    if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Hide_PLY
      );
      return;
    } else {
      if (!val) {
        state.scene.children.forEach((child) => {
          if (child.name.includes(meshName)) {
            child.visible = false;
          }
        });
      } else {
        state.scene.children.forEach((child) => {
          child.visible = true;
        });
      }
    }
    setHidePly(!hidePly);
    setDrawLine(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setIsAddPartition(false);
    setIsAddDoor(false);
    removeMagnifier();
    setIsAddWindow(false);
    setIsAddLabel(false);
    setSelectedRoomForLable("");
    setSelectedRoomStairCase(null);
  };
  const toggleScreen = () => {
    let screen =
      screenMode == screenModeTypes.minimize
        ? screenModeTypes.maximize
        : screenModeTypes.minimize;
    setScreenMode(screen);
    props.updateHeader();
    if (screen === 1) {
      setnavOpenBeforeMaximize(isNavOpen);
      if (isNavOpen) {
        props.updateNavBar();
      }
    } else if (navOpenBeforeMaximize) {
      props.updateNavBar();
    }
  };
  const toggleAddStairCase = () => {
    if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Add_Label
      );
      return;
    } else if (!roomArray.length) {
      customToast.error(threeDFloorScan.Please_Add_At_Least_One_Room);
      return;
    } else if (partitionFirstArray.length) {
      customToast.error(
        threeDFloorScan.Please_complete_the_partition_first_before_moving_ahead
      );
      return;
    }
    if (isAddStairCase) {
      removeMagnifier();
    } else {
      setTimeout(() => {
        magnify(canvasSelector, 2);
      }, 1000);
    }
    setIsAddStairCase(!isAddStairCase);
    setSelectedTextId(null);
    setIsAddLabel(false);
    setIsAddWindow(false);
    setIsAddDoor(false);
    setDrawLine(false);
    setIsSelectItem(false);
    setIsSelectDoorItem(false);
    setSelectedRoomForLable("");
    setIsAddPartition(false);
    resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setSelectedRoomStairCase(null);
  };

  const captureScreenShot = () => {
    props.setMarkupImageURL(state.gl.domElement.toDataURL("image/png"));
    props.setScreenCapturedPopup(true);
  };
  const setCameraView = (view) => {
    orbitCtrl?.current?.reset();
    let orthographicCamera = orbitCtrl?.current?.object;
    if (orthographicCamera) {
      if (defaultObjectZoomLevel == null) {
        defaultObjectZoomLevel = orthographicCamera.zoom;
      } else {
        orthographicCamera.zoom = defaultObjectZoomLevel;
        orthographicCamera.updateProjectionMatrix();
      }
    }
    if (view == "TOP") {
      setIsSideView(false);
    } else if (view == "SIDE") {
      setIsSideView(true);
      orbitCtrl?.current?.setPolarAngle(Math.PI / 4);
    }
  };
  const toggleSelectItem = () => {
    if (doorwindowArray.length > 0 && isAddDoor) {
      customToast.error(threeDFloorScan.Complete_Door_Selection);
      return;
    } else if (doorwindowArray.length > 0 && isAddWindow) {
      customToast.error(threeDFloorScan.Please_Complete_Window_Selection);
      return;
    } else if (suggestlineArray.length > 0 || lineArray.length > 0) {
      customToast.error(
        threeDFloorScan.Please_Connect_Room_And_Try_To_Select_Item
      );
      return;
    }
    if (isSelectItem) {
      deselectSelectedRoom(deleteRoom, setDeleteRoom);
      resetAreaDetails(Select_Area_Type, setSelectedRoomType, setSelectedRoom);
      removeMagnifier();
    } else {
      setTimeout(() => {
        magnify(canvasSelector, 2);
      }, 1000);
    }
    setIsSelectItem(!isSelectItem);
    setIsSelectDoorItem(false);
    setHidePly(false);
    setDrawLine(false);
    setIsAddPartition(false);
    setIsAddDoor(false);
    removeMagnifier();
    setIsAddWindow(false);
    setIsAddLabel(false);
    setSelectedRoomForLable("");
    setDeleteSelectedDoorWin({
      name: "",
      isDelete: false,
      isDeleteWindow: false,
    });
    setIsAddStairCase(false);
    setSelectedRoomStairCase(null);
  };
  const autoDetectedCorner = () => {
    changesStack = [];
    setDrawFloorPlan(false);
    if (
      floorDetails &&
      (isAutoDetect || _.isEmpty(floorDetails?.floorScan3dAutoSaveJson)) &&
      (process.env.REACT_APP_APP_ENV === "dev" ||
        floorDetails?.floorScanType === floorScanType[0].value) &&
      floorDetails?.floorScanObjPoints
    ) {
      let floorScanObjPoints = [],
        objectKey = [];
      floorScanObjPoints = floorDetails?.floorScanObjPoints;
      const stringToFloorScanPointsObj = JSON.parse(floorScanObjPoints);
      floorScanObjPoints = stringToFloorScanPointsObj?.data;
      if (floorDetails?.floorScanType === floorScanType[0].value) {
        floorScanObjPoints = floorScanObjPoints?.filter(function (el) {
          return el.length > 2;
        });
        autoDetectedCornerView(floorScanObjPoints);
      } else if (
        floorDetails?.floorScanType === floorScanType[1].value &&
        floorScanObjPoints &&
        process.env.REACT_APP_APP_ENV === "dev"
      ) {
        objectKey = Object.keys(floorScanObjPoints);
        objectKey.forEach((element) => {
          if (floorScanObjPoints?.[element]?.length > 0) {
            const stringToArray = JSON.parse(floorScanObjPoints?.[element]);
            if (stringToArray?.length > 2) {
              autoDetectedCornerView([stringToArray]);
            }
          }
        });
      }
    } else if (
      !isAutoDetect &&
      !_.isEmpty(floorDetails?.floorScan3dAutoSaveJson)
    ) {
      const setAutoSavedJson = JSON.parse(
        floorDetails?.floorScan3dAutoSaveJson
      );
      setDoorArray(
        setAutoSavedJson?.doorArray?.length > 0
          ? setAutoSavedJson?.doorArray
          : []
      );
      setWindowArray(
        setAutoSavedJson?.windowArray?.length > 0
          ? setAutoSavedJson?.windowArray
          : []
      );
      setTextArray(
        setAutoSavedJson?.textArray?.length > 0
          ? setAutoSavedJson?.textArray
          : []
      );
      setLineArray(
        setAutoSavedJson?.lineArray?.length > 0
          ? setAutoSavedJson?.lineArray
          : []
      );
      setRoomArray(
        setAutoSavedJson?.roomArray?.length > 0
          ? setAutoSavedJson?.roomArray
          : []
      );
      setSuggestLineArray(
        setAutoSavedJson?.suggestlineArray?.length > 0
          ? setAutoSavedJson?.suggestlineArray
          : []
      );
      setPartitionArray(
        setAutoSavedJson?.partitionArray?.length > 0
          ? setAutoSavedJson?.partitionArray
          : []
      );
      setAreaLabelTextArray(
        setAutoSavedJson?.areaLabelTextArray?.length > 0
          ? setAutoSavedJson?.areaLabelTextArray
          : []
      );
      lineArrayFabstr =
        setAutoSavedJson?.lineArrayFabstr?.length > 0
          ? setAutoSavedJson?.lineArrayFabstr
          : [];
      lineArrayFab =
        setAutoSavedJson?.lineArrayFab?.length > 0
          ? setAutoSavedJson?.lineArrayFab
          : [];
      changesStack =
        setAutoSavedJson?.changesStack?.length > 0
          ? setAutoSavedJson?.changesStack
          : [];
      textArrayFabstr =
        setAutoSavedJson?.textArrayFabstr?.length > 0
          ? setAutoSavedJson?.textArrayFabstr
          : [];
      setStairCaseArray(
        setAutoSavedJson?.stairCaseArray?.length > 0
          ? setAutoSavedJson?.stairCaseArray
          : []
      );
      stairCaseArrayFabstr =
        setAutoSavedJson?.stairCaseArrayFabstr?.length > 0
          ? setAutoSavedJson?.stairCaseArrayFabstr
          : [];
      setConnectFinish(true);
    }
    state?.scene?.children?.forEach((element, index) => {
      if (element.name != `pinPoint`) {
        state.scene.children[index].position.x = 0;
        state.scene.children[index].position.y = 0;
        state.scene.children[index].position.z = 0;
      }
    });
  };

  function autoDetectedCornerView(floorScanObjPoints) {
    let setRoomArrayAutoDetected = [];
    let lastAddedItemAutoDetected = [];
    floorScanObjPoints?.forEach((element, index) => {
      lastAddedItemAutoDetected.push(undoLineFor3D[2].id);
      setConnectFinish(true);
      let loopLineArray = [];
      let loopSuggestedLineArray = [];
      element.forEach((points, pointIndex) => {
        addChangesToStack({
          lineArray: loopLineArray,
          suggestlineArray: loopSuggestedLineArray,
          roomArray: _.cloneDeep(setRoomArrayAutoDetected),
        });
        lineArrayFab.push({ x: points[0], y: points[1], z: points[2] });
        lineArrayFabstr.push(points[0] + "," + points[1]);
        loopLineArray = [...loopLineArray, [points[0], points[1], points[2]]];
        if (loopLineArray.length > 2) {
          loopSuggestedLineArray = [
            [points[0], points[1], points[2]],
            [loopLineArray[0][0], loopLineArray[0][1], loopLineArray[0][2]],
          ];
        } else {
          loopSuggestedLineArray = [];
        }
        if (element.length - 1 === pointIndex) {
          addChangesToStack({
            lineArray: loopLineArray,
            suggestlineArray: loopSuggestedLineArray,
            roomArray: _.cloneDeep(setRoomArrayAutoDetected),
          });
        }
      });
      setRoomArrayAutoDetected.push({
        roomname: "",
        roomid: index,
        areatype: "GLA",
        additionaltype: additionalType3D[0].id,
        data: element,
        roomId: index,
      });
    });
    setRoomArray(setRoomArrayAutoDetected);
    setLineArray([]);
    setSuggestLineArray([]);
  }

  const floorNameJson = floorName?.find((el) => el.id == floorIndex) || {};

  const downloadPercentage = (text) => {
    return (
      <div className="no-data-found">
        <div className="box">
          <div className="loader-spin"></div>
          <p className="blue-text">{text}</p>
        </div>
      </div>
    );
  };

  const confirmEventOnClick = () => {
    if (
      state?.scene?.position?.x &&
      state?.scene?.position?.y &&
      state?.scene?.position?.z
    ) {
      state.scene.position.x = 0;
      state.scene.position.y = 0;
      state.scene.position.z = 0;
    }
    isloaded = false;
    maxZ = null;
    meshExist = [];
    meshLoaded = [];
    state?.scene?.clear();
    state = null;
    autoSaveSuccess = true;
    setDoorArray([]);
    setWindowArray([]);
    setDrawLine(false);
    setHidePly(false);
    setPopUp(false);
    showPopUp(tab, "yes", popUp.override);
    setSelectedRoom(areaLabel?.[0]?.value);
    setSelectedAdditionalType(null);
    deselectSelectedRoom(deleteRoom, setDeleteRoom);
    setIsAddPartition(false);
    setIsSelectItem(false);
    setIsAutoDetect(true);
    setHideLabels(true);
    props.autoSaveThreeDJson({
      floorScan3dAutoSaveJson: null,
      floorScanId: floorScanId,
    });
    props
      .fetchFloor({ floorScanId: props.id })
      .then((data) => {
        setFloorDetails(data?.data);
      })
      .catch((err) => {
        throw err;
      });
  };

  const explorePlanClick = () => {
    changesStack = [];
    setClickOn("Explore");
    setLoadingPer(0);
    setFileType("PLY");
    if (tab.nextTab == "" && tab.currentTab == "") {
      isloaded = false;
      lineArrayFab = [];
      setTab({
        nextTab: "Explore",
        currentTab: "Explore",
      });
      checkPopUpMsg({
        nextTab: "Explore",
        currentTab: "Explore",
      });
    } else if (tab.currentTab == "Preview") {
      setTab({ ...tab, nextTab: "Explore" });
      SetPopUpMsg(threeDFloorScan.msgForPreview);
      setPopUp({
        show: true,
        override: false,
        overridePrevented: false,
      });
    } else if (tab.currentTab == "Measurement") {
      setTab({ ...tab, nextTab: "Explore" });
      SetPopUpMsg(threeDFloorScan.msgForBack);
      setPopUp({
        show: true,
        override: false,
        overridePrevented: false,
      });
    } else if (tab.nextTab == "Explore" || tab.currentTab == "Explore") {
      isloaded = false;
      maxZ = null;
      meshExist = [];
      meshLoaded = [];
      state?.scene?.clear();
      lineArrayFab = [];
      setTab({
        nextTab: "Explore",
        currentTab: "Explore",
      });
      checkPopUpMsg({
        nextTab: "Explore",
        currentTab: "Explore",
      });
    }
  };

  const deleteLabel = (isAreaLabel = false) => {
    // this function will find the selected textId only for specific label and reset the array
    // also it will save the history of the deleted label so while performing undo it can be helpfull
    addChangesToStack({
      selectedTextId: null,
    });
    let objTextArray = [];
    if (!isAreaLabel) {
      setTextArray([]);
      let deletedLabel = textArray.filter(
        (val, index) => index == selectedTextId.split(":")[1].trim()
      );
      setDeletedLabelHistory([...deletedLabelHistory, deletedLabel[0]]);
      objTextArray = textArray.filter(
        (val, index) => index != selectedTextId.split(":")[1].trim()
      );
    } else {
      setAreaLabelTextArray([]);
      let deletedAreaLabel = areaLabelTextArray.filter(
        (val, index) => index == selectedTextId.split(":")[1].trim()
      );
      setDeletedLabelHistory([...deletedLabelHistory, deletedAreaLabel[0]]);
      roomArray.forEach((element) => {
        if (element.roomId == deletedAreaLabel[0].roomID.split(":")[1]) {
          element.roomname = "";
        }
      });
      objTextArray = areaLabelTextArray.filter(
        (val, index) => index != selectedTextId.split(":")[1].trim()
      );
    }
    //settimeout is neccessary because we want to reset every label and then add new ids to the same
    // if we dont put time out it will refer to old ids and the delete wont work properly
    setTimeout(() => {
      if (!isAreaLabel) {
        setTextArray([...objTextArray]);
      } else {
        setRoomArray([...roomArray]);
        setAreaLabelTextArray([...objTextArray]);
      }
      setSelectedTextId(null);
      setSelectedLabelId(null);
    }, 100);
  };

  function getCursorPos(e) {
    const x = window.Event
      ? e.pageX
      : window.Event.clientX +
        (document.documentElement.scrollLeft
          ? document.documentElement.scrollLeft
          : document.body.scrollLeft);
    const y = window.Event
      ? e.pageY
      : window.Event.clientY +
        (document.documentElement.scrollTop
          ? document.documentElement.scrollTop
          : document.body.scrollTop);
    return { x: x, y: y };
  }
  function cloneCanvas(oldCanvas) {
    const newCanvas = oldCanvas.cloneNode(true);
    const context = newCanvas.getContext("2d");
    newCanvas.width = oldCanvas.width;
    newCanvas.height = oldCanvas.height;
    context.drawImage(oldCanvas, 0, 0);
    return newCanvas;
  }
  const removeMagnifier = () => {
    if (document.getElementById("lens")) {
      document.getElementById("lens").remove();
    }
  };
  const magnify = (id, zoom) => {
    removeMagnifier();
    const lensSize = 200;
    const el = document.getElementById("zoom-canvas");
    const el1 = document.querySelector(id);
    if (el1 instanceof HTMLCanvasElement) {
      const copy = cloneCanvas(el1);
      const lens = document.createElement("div");
      lens.setAttribute("id", "lens");
      lens.style.width = lensSize + "px";
      lens.style.height = lensSize + "px";
      el.appendChild(lens);
      el1.getBoundingClientRect();
      copy.style.zoom = zoom;
      lens.appendChild(copy);
      copy.style.position = "absolute";
      const lensCursor = document.createElement("div");
      lensCursor.innerHTML = `<div class="vl"></div><div class="hl"></div>`;

      el1.addEventListener(
        "mousemove",
        _.debounce((ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          const el = document.getElementById("zoom-canvas");
          const el1 = document.querySelector(id);
          const copy = cloneCanvas(el1);
          lens.innerHTML = "";
          copy.style.zoom = zoom;
          lens.appendChild(copy);
          copy.style.position = "absolute";
          const pos = getCursorPos(ev);
          lens.style.left = -(lensSize / 2) + pos.x - lensSize + "px";
          lens.style.top = -(lensSize / 2) + pos.y - lensSize + "px";

          if (screenSize.mode === screenModeTypes.maximize) {
            copy.style.left =
              -(pos.x + el.offsetLeft) +
              (lensSize / zoom) * 0.5 +
              lensSize -
              50 +
              "px";
            copy.style.top =
              -(pos.y + el.offsetTop) +
              (lensSize / zoom) * 0.5 +
              lensSize -
              135 +
              "px";
          } else {
            copy.style.left =
              -(pos.x + el.offsetLeft) +
              (lensSize / zoom) * 0.5 +
              lensSize +
              145 +
              "px";
            copy.style.top =
              -(pos.y + el.offsetTop) +
              (lensSize / zoom) * 0.5 +
              lensSize +
              5 +
              "px";
          }
          lensCursor.style.top = "45%";
          lensCursor.style.position = "absolute";
          lensCursor.style.left = "45%";
          lens.appendChild(lensCursor);
        }),
        500
      );
    }
  };
  const deleteStairCase = () => {
    // this function will find the selected textId only for specific label and reset the array
    // also it will save the history of the deleted label so while performing undo it can be helpfull
    addChangesToStack({
      selectedRoomStairCase: null,
    });

    // Delete Label Start
    let objStairCaseArray = stairCaseArray.filter(
      (val) => `stairCase-${val.stairCaseId}` !== selectedRoomStairCase
    );
    setTimeout(() => {
      setStairCaseArray([...objStairCaseArray]);
      setSelectedRoomStairCase(null);
    }, 100);
    // Delete Label End
  };

  const LayerOfPLY = React.memo((props) => {
    return (
      <Box
        {...props}
        args={[props.state?.size?.height, props.state?.size?.width, props.maxZ]}
        premultipliedAlpha={true}
        metalness={0}
        attach="material"
        material={{ color: "#ffffff" }}
        visible={false}
        onPointerDown={(e) => {
          if (!isDragLine && drawLine) {
            setLine(e, setAxisCords);
          } else if (!isDragLine && isAddPartition) {
            AddPartition(
              e,
              partitionArray,
              setPartitionArray,
              partitionFirstArray,
              setPartitionFirstArray,
              roomArray,
              addChangesToStack
            );
          } else if (!isDragLine && isAddLabel) {
            setLine(e, setAxisCords);
          } else if (!isDragLine && isAddStairCase) {
            setLine(e, setAxisCords);
          }
        }}
        onPointerMove={(e) => {
          PointerMove(
            e,
            props.drawLine,
            props.selectedRoomId,
            props.isDownAt,
            props.roomArray,
            props.selectedPoint,
            props.setSelectedPoint,
            props.setRoomArray,
            props.doorArray,
            props.windowArray,
            props.selectedLineId,
            props.setDoorArray,
            props.setWindowArray,
            props.basePoints,
            props.isDragPartitionWall,
            props.partitionArray,
            props.setPartitionArray,
            props.selectedTextId,
            props.textArray,
            props.setTextArray,
            props.selectedLabelId,
            props.setIsDownAt,
            props.isDragLine,
            props.areaLabelTextArray,
            props.setAreaLabelTextArray,
            props.setLiveLineMoveData,
            props.stairCaseArray,
            props.setStairCaseArray,
            props.selectedRoomStairCase
          );
        }}
        onPointerUp={(e) => {
          pointerUp(e);
        }}
      />
    );
  });

  function PointLight() {
    const pointLightRef = useRef();
    if (_.isNil(pointLightRef?.current)) {
      return (
        <pointLight
          ref={pointLightRef}
          position={[0, 0, 10]}
          intensity={0.6}
          color={0xffffff}
        />
      );
    } else {
      return null;
    }
  }

  return (
    <>
      <section>
        <div className="tab-content open">
          <div className="measurement-document">
            <div className="measurement-head display-flex">
              <div className="menu-list">
                <div className="menu-items">
                  <div className="button-view">
                    <ul className="menu-list-plan left-menu-view">
                      <li
                        className={
                          clickOn == "Explore" && tab.currentTab == "Explore"
                            ? "active"
                            : ""
                        }
                      >
                        <button
                          ref={clickExplore}
                          onClick={() => explorePlanClick()}
                        >
                          <i className="icon-explore"></i>
                          <div className="">Explore Plan</div>
                        </button>
                      </li>
                      <li
                        className={
                          clickOn == "Measurement" &&
                          tab.currentTab == "Measurement"
                            ? "active"
                            : ""
                        }
                        onClick={() => {
                          isloaded = true;
                          tab.currentTab === "Explore" && autoDetectedCorner();
                        }}
                      >
                        <button
                          disabled={
                            loadingPer < 100 && tab.currentTab != "Measurement"
                              ? true
                              : false
                          }
                          onClick={() => {
                            setClickOn("Measurement");
                            if (tab.currentTab != "Measurement") {
                              setDrawLine(false);
                              setCameraView("TOP");
                            }
                            setTab({ currentTab: "Measurement", nextTab: "" });
                            SetLockModel(false);
                          }}
                        >
                          <i
                            className="icon-Measurement-Details"
                            style={{
                              opacity:
                                tab.currentTab == "Explore" ||
                                tab.currentTab == "Measurement"
                                  ? "1"
                                  : "0.6",
                            }}
                          ></i>
                          <div className="">Create Floorplan</div>
                        </button>
                      </li>
                      <li
                        className={
                          clickOn == "Preview" && tab.currentTab == "Preview"
                            ? "active"
                            : ""
                        }
                      >
                        <button
                          disabled={
                            (tab.currentTab == "Measurement" ||
                              tab.currentTab == "Preview") &&
                            roomArray.length > 0 &&
                            suggestlineArray.length == 0 &&
                            lineArray.length === 0 &&
                            connectFinish
                              ? false
                              : true
                          }
                          onClick={(e) => {
                            setClickOn("Preview");
                            setLoadingPer(0);
                            if (tab.currentTab != "Preview") {
                              setShowScatch(true);
                              setDrawLine(false);
                              ShowFabNew(
                                roomArray,
                                state,
                                floorIndex,
                                floorName,
                                setJsonObject,
                                setDrawFloorPlan,
                                wallThickness,
                                textArray,
                                stairCaseArray
                              );
                              setTab({
                                currentTab: "Preview",
                                nextTab: "Preview",
                              });
                              checkPopUpMsg({
                                currentTab: "Preview",
                                nextTab: "Preview",
                              });
                            }
                          }}
                        >
                          <i
                            className="icon-Floor-Plan"
                            style={{
                              opacity:
                                (tab.currentTab == "Measurement" ||
                                  tab.currentTab == "Preview") &&
                                roomArray.length > 0 &&
                                suggestlineArray.length == 0
                                  ? "1"
                                  : "0.6",
                            }}
                          ></i>
                          <div className="">Preview</div>
                        </button>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="menu-list">
                <div className="menu-items">
                  <div className="button-view">
                    <ul className="menu-list-plan right-menu-list">
                      {tab.currentTab == "Measurement" && (
                        <li>
                          <select
                            className="form-control sm-hight"
                            name="areaType"
                            value={selectedRoomType}
                            onChange={(e) => {
                              changeAreaDetails(
                                e.target.value,
                                selectedRoom,
                                setSelectedRoomType,
                                setSelectedRoom,
                                _.cloneDeep(roomArray),
                                setRoomArray,
                                deleteRoom,
                                addChangesToStack,
                                areaLabelTextArray,
                                setAreaLabelTextArray,
                                isSelectItem,
                                textArray,
                                setTextArray,
                                selectedTextId
                              );
                            }}
                          >
                            <option>Select Area Type</option>
                            <option>GLA</option>
                            <option>Non-GLA</option>
                          </select>
                        </li>
                      )}
                      {tab.currentTab == "Measurement" && (
                        <li>
                          <select
                            className="form-control sm-hight"
                            name="areaLabel"
                            value={selectedRoom}
                            onChange={(e) => {
                              changeAreaDetails(
                                selectedRoomType,
                                e.target.value,
                                setSelectedRoomType,
                                setSelectedRoom,
                                _.cloneDeep(roomArray),
                                setRoomArray,
                                deleteRoom,
                                addChangesToStack,
                                areaLabelTextArray,
                                setAreaLabelTextArray,
                                isSelectItem,
                                textArray,
                                setTextArray,
                                selectedTextId
                              );
                            }}
                          >
                            {areaLabel.map((item) => (
                              <option key={item.id} value={item.value}>
                                {item.value}
                              </option>
                            ))}
                          </select>
                        </li>
                      )}
                      <li>
                        {tab.currentTab == "Measurement" && (
                          <button
                            disabled={
                              isAddDoor ||
                              isAddWindow ||
                              partitionFirstArray?.length > 0 ||
                              !changesStack.length
                            }
                            onClick={(e) => {
                              undoChangesToStack();
                            }}
                          >
                            <i className="icon-undo"></i>
                            <div className="">Undo</div>
                          </button>
                        )}

                        {tab.currentTab == "Preview" ? (
                          <button
                            disabled={isLoading ? isLoading : false}
                            className="green-btn"
                            onClick={(e) => {
                              setIsLoading(true);
                              document.getElementById("saveArea")?.click();
                            }}
                          >
                            <i className="icon-publish"></i>
                            <div className="switch-group">
                              Publish
                              {isLoading && <div className="loader-spin"></div>}
                            </div>
                          </button>
                        ) : null}
                      </li>
                      {tab.currentTab == "Measurement" && (
                        <li>
                          {suggestlineArray.length ? (
                            <Tooltip title={"Connect & Finish"} arrow>
                              <button
                                className="snap-true"
                                onClick={() => {
                                  ConnectAndAddRoom();
                                  setConnectFinish(true);
                                }}
                              >
                                <i className="icon-Floor-plan-success"></i>
                              </button>
                            </Tooltip>
                          ) : (
                            <button disabled={true} className="snap-true">
                              <i className="icon-Floor-plan-success"></i>
                            </button>
                          )}
                        </li>
                      )}
                      {(props?.floorDetail?.plyPath &&
                        contentAvailable &&
                        tab.currentTab == "Explore") ||
                      tab.currentTab == "" ? (
                        <li
                          onClick={() => props.setExplorePlanInstruction(true)}
                        >
                          <button className="snap-true">
                            <Tooltip title={"Instructions"} arrow>
                              <i className="icon-information mr-0"></i>
                            </Tooltip>
                          </button>
                        </li>
                      ) : null}
                      {tab.currentTab == "Measurement" ? (
                        <li
                          onClick={() => props.setMeasurementInstruction(true)}
                        >
                          <button className="snap-true">
                            <Tooltip title={"Instructions"} arrow>
                              <i className="icon-information mr-0"></i>
                            </Tooltip>
                          </button>
                        </li>
                      ) : null}

                      <li>
                        <button
                          onClick={() => {
                            toggleScreen();
                          }}
                        >
                          {screenMode === screenModeTypes.minimize ? (
                            <Tooltip title={"Fullscreen"} arrow>
                              <i className="app-icon-fullscreen"></i>
                            </Tooltip>
                          ) : (
                            <Tooltip title={"Exit Fullscreen"} arrow>
                              <i className="app-icon-Small-screen"></i>
                            </Tooltip>
                          )}
                        </button>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="measurement-view">
              {/* adding tool in explore tab screenshot of canvas */}
              {loadingPer >= 100 &&
                contentAvailable &&
                !loader &&
                tab.currentTab == "Explore" && (
                  <div className="explore-plan-tool tools-sagament scroll-bar-none">
                    <ul className="tools-list">
                      <li className="inactive">
                        <button>Tools</button>
                      </li>
                      <li className="active">
                        <Tooltip placement="right" title={"Capture Snap"} arrow>
                          <button
                            onClick={() => {
                              captureScreenShot();
                            }}
                            disabled={loader ? true : false}
                            className="active"
                          >
                            <i className="app-icon-markup"></i>
                          </button>
                        </Tooltip>
                      </li>
                    </ul>
                  </div>
                )}
              {tab.currentTab == "Measurement" && (
                <div className="tools-sagament scroll-bar-none">
                  <ul className="tools-list">
                    {drawLine || isAddLabel || isAddPartition || isAddStairCase
                      ? (draggingLine = false)
                      : (draggingLine = true)}
                    <li className="inactive">
                      <button>Tools</button>
                    </li>
                    <li
                      className={
                        (drawLine &&
                          selectedAdditionalType === additionalType3D[0].id) ||
                        deleteRoom.isAdditional === additionalType3D[0].id
                          ? "active"
                          : ""
                      }
                    >
                      <Tooltip
                        placement="right"
                        title={"Add line as additional"}
                        arrow
                      >
                        <button
                          onClick={() =>
                            toggleAddLine(
                              drawLine &&
                                selectedAdditionalType ===
                                  additionalType3D[1].id
                                ? true
                                : !drawLine
                                ? true
                                : false,
                              !drawLine && !selectedAdditionalType
                                ? additionalType3D[0].id
                                : drawLine &&
                                  selectedAdditionalType ===
                                    additionalType3D[0].id
                                ? null
                                : additionalType3D[0].id
                            )
                          }
                          className={
                            drawLine &&
                            selectedAdditionalType === additionalType3D[0].id
                              ? "active"
                              : ""
                          }
                        >
                          <i className="app-icon-Add-additional"></i>
                        </button>
                      </Tooltip>
                    </li>

                    <li
                      className={
                        (drawLine &&
                          selectedAdditionalType === additionalType3D[1].id) ||
                        deleteRoom.isAdditional === additionalType3D[1].id
                          ? "active"
                          : ""
                      }
                    >
                      <Tooltip
                        placement="right"
                        title={"Add line as non additional"}
                        arrow
                      >
                        <button
                          onClick={() =>
                            toggleAddLine(
                              drawLine &&
                                selectedAdditionalType ===
                                  additionalType3D[0].id
                                ? true
                                : !drawLine
                                ? true
                                : false,
                              !drawLine && !selectedAdditionalType
                                ? additionalType3D[1].id
                                : drawLine &&
                                  selectedAdditionalType ===
                                    additionalType3D[1].id
                                ? null
                                : additionalType3D[1].id
                            )
                          }
                          className={
                            drawLine &&
                            selectedAdditionalType === additionalType3D[1].id
                              ? "active"
                              : ""
                          }
                        >
                          <i className="app-icon-Add-non-additional"></i>
                        </button>
                      </Tooltip>
                    </li>

                    <li className={isAddPartition ? "active" : ""}>
                      <Tooltip
                        placement="right"
                        title={"Add Interior Wall Partition"}
                        arrow
                      >
                        <button
                          onClick={() => {
                            toggleAddPartition();
                          }}
                        >
                          <i className="app-icon-Partition"></i>
                        </button>
                      </Tooltip>
                    </li>

                    <li className={isSelectItem ? "active" : ""}>
                      <Tooltip placement="right" title={"Select Item"} arrow>
                        <button
                          onClick={() => {
                            toggleSelectItem();
                          }}
                          className={isSelectItem ? "active" : ""}
                        >
                          <i className="app-icon-room-selection"></i>
                        </button>
                      </Tooltip>
                    </li>

                    <li className={isAddLabel ? "active" : ""}>
                      <Tooltip placement="right" title={"Add Text Label"} arrow>
                        <button onClick={() => toggleAddLabel()}>
                          <i className="icon-build_add_label"></i>
                        </button>
                      </Tooltip>
                    </li>
                    <li>
                      {deleteRoom.isDelete ||
                      selectedTextId ||
                      deleteSelectedDoorWin.isDeleteWindow ||
                      deleteSelectedDoorWin.isDelete ||
                      !_.isNil(selectedRoomStairCase) ? (
                        <Tooltip
                          placement="right"
                          title={`Delete Selected Area `}
                          arrow
                        >
                          <button
                            onClick={(e) => {
                              if (selectedTextId) {
                                if (selectedTextId.indexOf("arealabel") > -1) {
                                  deleteLabel(true);
                                } else {
                                  deleteLabel();
                                }
                              } else if (
                                deleteSelectedDoorWin.isDelete ||
                                deleteSelectedDoorWin.isDeleteWindow
                              ) {
                                setIsSelectDoorItem(false);
                                deleteDoor(
                                  doorArray,
                                  setDoorArray,
                                  windowArray,
                                  setWindowArray,
                                  deleteSelectedDoorWin,
                                  setDeleteSelectedDoorWin,
                                  addChangesToStack,
                                  setMarkerPointArray
                                );
                              } else if (!_.isNil(selectedRoomStairCase)) {
                                deleteStairCase();
                              } else {
                                setIsSelectDoorItem(false);
                                DeleteRoom(
                                  e,
                                  deleteRoom.roomId,
                                  deleteRoom.roomName,
                                  roomArray,
                                  setRoomArray,
                                  deletedRoom,
                                  setDeletedRoom,
                                  textArray,
                                  setTextArray,
                                  windowArray,
                                  setWindowArray,
                                  doorArray,
                                  setDoorArray,
                                  addChangesToStack,
                                  partitionArray,
                                  setPartitionArray,
                                  areaLabelTextArray,
                                  setAreaLabelTextArray,
                                  stairCaseArray,
                                  setStairCaseArray
                                );
                                setDeleteRoom({
                                  roomId: null,
                                  isDelete: false,
                                });
                              }
                              resetAreaDetails(
                                Select_Area_Type,
                                setSelectedRoomType,
                                setSelectedRoom
                              );
                              deselectSelectedRoom(deleteRoom, setDeleteRoom);
                            }}
                          >
                            <i className="app-icon-Delete"></i>
                          </button>
                        </Tooltip>
                      ) : (
                        <button disabled={true}>
                          <i className="app-icon-Delete"></i>
                        </button>
                      )}
                    </li>

                    <li
                      className={
                        isAddDoor &&
                        addDoorDirection == doorDirectionEnum.inside
                          ? "active"
                          : ""
                      }
                    >
                      <Tooltip
                        placement="right"
                        title={"Add Interior Door"}
                        arrow
                      >
                        <button
                          onClick={() => {
                            toggleAddDoor();
                            setAddDoorDirection(doorDirectionEnum.inside);
                          }}
                        >
                          <i className="app-icon-inside-door"></i>
                        </button>
                      </Tooltip>
                    </li>
                    <li
                      className={
                        isAddDoor &&
                        addDoorDirection == doorDirectionEnum.outside
                          ? "active"
                          : ""
                      }
                    >
                      <Tooltip
                        placement="right"
                        title={"Add Exterior Door"}
                        arrow
                      >
                        <button
                          onClick={() => {
                            toggleAddDoor();
                            setAddDoorDirection(doorDirectionEnum.outside);
                          }}
                        >
                          <i className="app-icon-outside-door"></i>
                        </button>
                      </Tooltip>
                    </li>
                    <li className={isAddWindow ? "active" : ""}>
                      <Tooltip placement="right" title={"Add Window"} arrow>
                        <button onClick={() => toggleAddWindow()}>
                          <i className="icon-add-window"></i>
                        </button>
                      </Tooltip>
                    </li>
                    <li className={isAddStairCase ? "active" : ""}>
                      <Tooltip placement="right" title={"Add Staircase"} arrow>
                        <button onClick={() => toggleAddStairCase()}>
                          <i className="app-icon-staircase"></i>
                        </button>
                      </Tooltip>
                    </li>

                    <li className={"hide-ply"}>
                      <button
                        className="hide-ply blue-btn"
                        disabled={
                          lineArray.length
                            ? false
                            : roomArray.length
                            ? false
                            : true
                        }
                        onClick={() => {
                          toggleHidePLY(hidePly);
                        }}
                      >
                        {`${hidePly ? "Show" : "Hide"} PLY`}
                      </button>
                    </li>
                    <li className={"hide-ply"}>
                      <button
                        className="hide-ply blue-btn"
                        disabled={!roomArray.length}
                        onClick={() => {
                          setHideLabels(!hideLabels);
                        }}
                      >
                        {`${hideLabels ? "Show" : "Hide"} Label(s)`}
                      </button>
                    </li>
                  </ul>
                </div>
              )}
              {tab.currentTab == "Measurement" &&
                selectedRoomStairCase &&
                isSelectItem &&
                selectedStairObject && (
                  <div className="scale-box">
                    <div className="scale-box-title">Scale</div>
                    <div className="scale-box-body">
                      <div className="scale-box-list">
                        <div className="box-head">Width</div>
                        <div className="box-runnet">
                          <input
                            type="range"
                            min="0.1"
                            max="5"
                            value={selectedStairObject.scaleX || 1}
                            step="0.1"
                            onChange={() => {
                              addChangesToStack({
                                stairCaseArray: _.cloneDeep(
                                  prevselectedStairObject
                                ),
                              });
                            }}
                            onInput={(e) => {
                              onScaleX(
                                e,
                                stairCaseArray,
                                selectedStairObject.i,
                                setStairCaseArray,
                                setSelectedStairObject,
                                selectedStairObject
                              );
                            }}
                          />
                        </div>
                      </div>
                      <div className="scale-box-list">
                        <div className="box-head">Height</div>
                        <div className="box-runnet">
                          <input
                            type="range"
                            min="0.1"
                            max="5"
                            value={selectedStairObject.scaleY || 1}
                            step="0.1"
                            onChange={() => {
                              addChangesToStack({
                                stairCaseArray: _.cloneDeep(
                                  prevselectedStairObject
                                ),
                              });
                            }}
                            onInput={(e) => {
                              onScaleY(
                                e,
                                stairCaseArray,
                                selectedStairObject.i,
                                setStairCaseArray,
                                setSelectedStairObject,
                                selectedStairObject
                              );
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              {popUp.show ? (
                <>
                  <ConfirmationModal
                    hideButtons={popUp.overridePrevented}
                    cancelEvent={() => {
                      setPopUp({
                        show: false,
                        override: false,
                        overridePrevented: false,
                      });
                      showPopUp(tab, "no");
                    }}
                    title={popUpMsg}
                    cancelText={t("COMMON_MESSAGES.No")}
                    confirmText={t("COMMON_MESSAGES.Yes")}
                    confirmEvent={() => confirmEventOnClick()}
                  >
                    {popUp.overridePrevented && (
                      <div className="conf-footer text-right">
                        <Button
                          className="blue-btn"
                          onClick={() =>
                            setPopUp({
                              show: false,
                              override: false,
                              overridePrevented: false,
                            })
                          }
                        >
                          Ok
                        </Button>
                      </div>
                    )}
                  </ConfirmationModal>
                </>
              ) : null}

              <div className="inner-measurement-ThreeD">
                {((tab.currentTab == "Explore" && loadingPer == 100) ||
                  tab.currentTab == "Measurement") && (
                  <div className="angle-box">
                    <ul>
                      <li className={isSideView ? "active" : ""}>
                        <Tooltip title="Overview" arrow>
                          <button
                            onClick={() => {
                              setCameraView("SIDE");
                            }}
                          >
                            <i className="app-icon-d-vie"></i>
                          </button>
                        </Tooltip>
                      </li>
                      <li className={!isSideView ? "active" : ""}>
                        <Tooltip title="Top-Down" arrow>
                          <button
                            onClick={() => {
                              setCameraView("TOP");
                            }}
                          >
                            <i className="icon-Floor-Plan"></i>
                          </button>
                        </Tooltip>
                      </li>
                    </ul>
                  </div>
                )}
                {loader && !contentAvailable && (
                  <div className="no-data-found">
                    <div className="box">
                      <i className={FLOORPLANS_ICON}></i>
                      <p>{"Oops! PLY file failed to load. Please try again"}</p>
                    </div>
                  </div>
                )}
                {loader &&
                  !isZipFile &&
                  loadingPer > 0 &&
                  downloadPercentage(
                    loadingPer < 100
                      ? loadingPer + "% Loaded..."
                      : "Preparing Sketch..."
                  )}
                {loader &&
                  isZipFile &&
                  (isZipDownloaded
                    ? downloadFilePercentage == 0
                    : downloadFilePercentage > 0) &&
                  downloadPercentage(
                    !isZipDownloaded
                      ? downloadFilePercentage + "% Loaded..."
                      : "Preparing Sketch..."
                  )}
                {loader &&
                  (!isZipFile
                    ? loadingPer == 0
                    : downloadFilePercentage == 0) &&
                  !isZipDownloaded &&
                  contentAvailable && (
                    <div className="no-data-found">
                      <div className="box">
                        <p className="blue-text">
                          {threeDFloorScan.Please_Wait}
                        </p>
                      </div>
                    </div>
                  )}
                {!props.floorDetail.plyPath && (
                  <NoDataView text={"3D Floor Plan"} icon={FLOORPLANS_ICON} />
                )}
                {plyFilePath?.length > 0 &&
                  props?.floorDetail?.plyPath &&
                  contentAvailable &&
                  !showScatch &&
                  fileType == "PLY" && (
                    <>
                      <Suspense fallback={null}>
                        <Canvas
                          id={"zoom-canvas"}
                          gl={{ preserveDrawingBuffer: true }}
                          orthographic={true}
                          camera={{
                            position: [0, 0, 10],
                            zoom: 2,
                            up: [0, 0, 1],
                            far: 10000,
                          }}
                          className={
                            (isSelectItem || isSelectDoorItem) && !isDragLine
                              ? "custom-cursor"
                              : ""
                          }
                          style={{
                            zIndex: 1,
                            display:
                              loader && loadingPer >= 0 ? "none" : "block",
                            backgroundImage: `${
                              !maxZ
                                ? ""
                                : "linear-gradient(rgb(50 50 172 / 92%) ,rgb(109 109 198))"
                            }`,
                            cursor:
                              drawLine ||
                              isAddDoor ||
                              isAddWindow ||
                              isAddPartition ||
                              isAddStairCase
                                ? "crosshair"
                                : isAddLabel
                                ? "text"
                                : isDragLine
                                ? "grabbing"
                                : "move",
                          }}
                        >
                          <Bounds fit clip margin={1.2}>
                            <SelectToZoom />
                          </Bounds>
                          <PointLight />
                          {maxZ &&
                            (isAddLabel ||
                              hidePly ||
                              drawLine ||
                              isDragLine ||
                              isAddPartition ||
                              isAddStairCase) && (
                              <LayerOfPLY
                                drawLine={drawLine}
                                selectedRoomId={selectedRoomId}
                                isDownAt={isDownAt}
                                roomArray={roomArray}
                                selectedPoint={selectedPoint}
                                setSelectedPoint={setSelectedPoint}
                                setRoomArray={setRoomArray}
                                state={state}
                                maxZ={maxZ}
                                doorArray={doorArray}
                                windowArray={windowArray}
                                selectedLineId={selectedLineId}
                                setDoorArray={setDoorArray}
                                setWindowArray={setWindowArray}
                                basePoints={basePoints}
                                isDragPartitionWall={isDragPartitionWall}
                                partitionArray={partitionArray}
                                setPartitionArray={setPartitionArray}
                                selectedTextId={selectedTextId}
                                textArray={textArray}
                                setTextArray={setTextArray}
                                selectedLabelId={selectedLabelId}
                                setIsDownAt={setIsDownAt}
                                isDragLine={isDragLine}
                                areaLabelTextArray={areaLabelTextArray}
                                setAreaLabelTextArray={setAreaLabelTextArray}
                                setLine={setLine}
                                pointerUp={pointerUp}
                                setLiveLineMoveData={setLiveLineMoveData}
                                stairCaseArray={stairCaseArray}
                                setStairCaseArray={setStairCaseArray}
                                selectedRoomStairCase={selectedRoomStairCase}
                              />
                            )}
                          {plyFilePath?.length > 0 &&
                            plyFilePath?.map((element, index) => {
                              return (
                                <ScenePLY
                                  key={element}
                                  setLine={setLine}
                                  pointerUp={pointerUp}
                                  plyFilePath={element}
                                  setLoader={setLoader}
                                  setLoadingPer={setLoadingPer}
                                  loadingPer={loadingPer}
                                  setContentAvailable={setContentAvailable}
                                  index={index}
                                  floorScanTypeVar={floorScanTypeDetail}
                                  pinLocation={pinLocation}
                                  drawLine={drawLine}
                                  isAddDoor={isAddDoor}
                                  isAddWindow={isAddWindow}
                                  isDragLine={isDragLine}
                                  isAddLabel={isAddLabel}
                                  isAddPartition={isAddPartition}
                                  setAxisCords={setAxisCords}
                                  isAddStairCase={isAddStairCase}
                                  selectedRoomStairCase={selectedRoomStairCase}
                                />
                              );
                            })}

                          {markerPointArray.points?.length &&
                            (isAddDoor || isAddWindow) && (
                              <MarkerPointSphere
                                args={markerPointArray}
                                setMarkerPointArray={setMarkerPointArray}
                              />
                            )}

                          {!isAddLabel &&
                            roomArray.map((el, roomIndex) => {
                              let areaName = null;
                              let indexOfAreaLabel = null;
                              areaLabelTextArray.forEach(
                                (labelEl, labelIndex) => {
                                  if (
                                    el.roomId == labelEl.roomID?.split(":")?.[1]
                                  ) {
                                    indexOfAreaLabel = labelIndex;
                                    areaName = labelEl;
                                  }
                                }
                              );
                              return el?.data?.map((elm, i) => {
                                if (i < el.data.length - 1) {
                                  return (
                                    <>
                                      {!isSelectItem &&
                                        !isAddWindow &&
                                        !isAddLabel &&
                                        !isAddDoor &&
                                        !hidePly &&
                                        !drawLine &&
                                        !isAddPartition &&
                                        !suggestlineArray.length > 0 &&
                                        !selectedLabelId &&
                                        !selectedTextId &&
                                        !isAddStairCase &&
                                        (!isDragLine ||
                                          (!selectedTorusDetails?.selectedTorusType &&
                                            selectedTorusDetails?.roomArrayIndex ===
                                              roomIndex &&
                                            selectedTorusDetails?.roomWallIndex ===
                                              i)) && (
                                          <FakeSphere
                                            lineId={i}
                                            roomId={el.roomId}
                                            args={elm}
                                            basePoints={el.data}
                                            roomArrayIndex={roomIndex}
                                            roomWallIndex={i}
                                          />
                                        )}
                                      {!hideLabels && (
                                        <CreateLabel
                                          startingPoint={{
                                            x: el.data[i][0],
                                            y: el.data[i][1],
                                            z: el.data[i][2],
                                          }}
                                          endingPoint={{
                                            x: el.data[i + 1][0],
                                            y: el.data[i + 1][1],
                                            z: el.data[i + 1][2],
                                          }}
                                        />
                                      )}
                                      <Line
                                        points={[el.data[i], el.data[i + 1]]}
                                        distStart={{
                                          x: el.data[i][0],
                                          y: el.data[i][1],
                                          z: el.data[i][2],
                                        }}
                                        distEnd={{
                                          x: el.data[i + 1][0],
                                          y: el.data[i + 1][1],
                                          z: el.data[i + 1][2],
                                        }}
                                        color={
                                          deleteRoom.isDelete
                                            ? deleteRoom.roomId === el.roomId
                                              ? "red"
                                              : "black"
                                            : isDragLine &&
                                              (selectedRoomId === el.roomId ||
                                                parentRoomId === el.roomId)
                                            ? "#008000"
                                            : "black"
                                        }
                                        name={"custom-line:" + el.roomId}
                                        lineid={
                                          "custom-line:" + el.roomId + "" + i
                                        }
                                        roomid={el.roomId}
                                        renderOrder={
                                          selectedRoomId === el.roomId ||
                                          parentRoomId === el.roomId
                                            ? 9999999999999
                                            : 999999999999
                                        }
                                        lineWidth={7}
                                        depthTest={false}
                                        depthWrite={false}
                                        onPointerUp={(e) => {
                                          if (isDragLine) {
                                            pointerUp(e);
                                          } else {
                                            setIsSelectDoorItem(false);
                                            setDoorWindow(e, {
                                              partitionwall: false,
                                              areatype: el.areatype,
                                              arealabel:
                                                el.roomname !== ""
                                                  ? el.roomname
                                                  : null,
                                              additionaltype: el.additionaltype,
                                            });
                                          }
                                        }}
                                        onPointerOver={(e) => {
                                          if (isAddDoor || isAddWindow) {
                                            onMeshPointerMove(
                                              e,
                                              setMarkerPointArray,
                                              markerPointArray,
                                              true
                                            );
                                          }
                                        }}
                                        onPointerMove={(e) => {
                                          if (isAddDoor || isAddWindow) {
                                            onMeshPointerMove(
                                              e,
                                              setMarkerPointArray,
                                              markerPointArray,
                                              true
                                            );
                                          }
                                        }}
                                        onPointerLeave={(e) => {
                                          if (isAddDoor || isAddWindow) {
                                            onMeshPointerMove(
                                              e,
                                              setMarkerPointArray,
                                              markerPointArray,
                                              false
                                            );
                                          }
                                        }}
                                      />
                                    </>
                                  );
                                } else {
                                  return (
                                    <>
                                      {!isSelectItem &&
                                        !isAddWindow &&
                                        !isAddLabel &&
                                        !isAddDoor &&
                                        !hidePly &&
                                        !drawLine &&
                                        !isAddPartition &&
                                        !suggestlineArray.length > 0 &&
                                        !selectedLabelId &&
                                        !selectedTextId &&
                                        !isAddStairCase &&
                                        (!isDragLine ||
                                          (!selectedTorusDetails?.selectedTorusType &&
                                            selectedTorusDetails?.roomArrayIndex ===
                                              roomIndex &&
                                            selectedTorusDetails?.roomWallIndex ===
                                              i)) && (
                                          <FakeSphere
                                            lineId={i}
                                            roomId={el.roomId}
                                            args={elm}
                                            basePoints={el.data}
                                            roomArrayIndex={roomIndex}
                                            roomWallIndex={i}
                                          />
                                        )}
                                      {!hideLabels && (
                                        <CreateLabel
                                          startingPoint={{
                                            x: el.data[i][0],
                                            y: el.data[i][1],
                                            z: el.data[i][2],
                                          }}
                                          endingPoint={{
                                            x: el.data[0][0],
                                            y: el.data[0][1],
                                            z: el.data[0][2],
                                          }}
                                        />
                                      )}
                                      <Line
                                        points={[el.data[i], el.data[0]]}
                                        distStart={{
                                          x: el.data[i][0],
                                          y: el.data[i][1],
                                          z: el.data[i][2],
                                        }}
                                        distEnd={{
                                          x: el.data[0][0],
                                          y: el.data[0][1],
                                          z: el.data[0][2],
                                        }}
                                        color={
                                          deleteRoom.isDelete
                                            ? deleteRoom.roomId === el.roomId
                                              ? "red"
                                              : "black"
                                            : isDragLine &&
                                              (selectedRoomId === el.roomId ||
                                                parentRoomId === el.roomId)
                                            ? "#008000"
                                            : "black"
                                        }
                                        name={"custom-line:" + el.roomId}
                                        lineid={
                                          "custom-line:" + el.roomId + "" + i
                                        }
                                        roomid={el.roomId}
                                        renderOrder={
                                          selectedRoomId === el.roomId ||
                                          parentRoomId === el.roomId
                                            ? 9999999999999
                                            : 999999999999
                                        }
                                        lineWidth={7}
                                        depthTest={false}
                                        depthWrite={false}
                                        onPointerUp={(e) => {
                                          if (isDragLine) {
                                            pointerUp(e);
                                          } else {
                                            setDoorWindow(e, {
                                              partitionwall: false,
                                              areatype: el.areatype,
                                              arealabel:
                                                el.roomname !== ""
                                                  ? el.roomname
                                                  : null,
                                              additionaltype: el.additionaltype,
                                            });
                                          }
                                        }}
                                        onPointerOver={(e) => {
                                          if (isAddDoor || isAddWindow) {
                                            onMeshPointerMove(
                                              e,
                                              setMarkerPointArray,
                                              markerPointArray,
                                              true
                                            );
                                          }
                                        }}
                                        onPointerMove={(e) => {
                                          if (isAddDoor || isAddWindow) {
                                            onMeshPointerMove(
                                              e,
                                              setMarkerPointArray,
                                              markerPointArray,
                                              true
                                            );
                                          }
                                        }}
                                        onPointerLeave={(e) => {
                                          if (isAddDoor || isAddWindow) {
                                            onMeshPointerMove(
                                              e,
                                              setMarkerPointArray,
                                              markerPointArray,
                                              false
                                            );
                                          }
                                        }}
                                      />
                                      {!hideLabels && !_.isEmpty(areaName) ? (
                                        <TextObj
                                          position={findCenterPoint(
                                            _.cloneDeep(el.data)
                                          )}
                                          name={"arealabel::" + areaName.roomID}
                                          id={
                                            "arealabel::" +
                                            areaName.roomID +
                                            "arealabel-text:" +
                                            indexOfAreaLabel
                                          }
                                          labelId={`arealabel${areaName.labelId}`}
                                          textid={
                                            "arealabel:" + indexOfAreaLabel
                                          }
                                          setSelectedTextId={setSelectedTextId}
                                          setSelectedLabelId={
                                            setSelectedLabelId
                                          }
                                          selectedLabelId={selectedLabelId}
                                          selectedTextId={selectedTextId}
                                          deleteLabel={deleteLabel}
                                          pointerDown={pointerDown}
                                          pointerUp={pointerUp}
                                          isDragLine={isDragLine}
                                          deleteRoom={deleteRoom}
                                          setDeleteRoom={setDeleteRoom}
                                          text={`${el.totalAreaOfRoom} Sq ft\n${areaName.text}`}
                                          index={indexOfAreaLabel}
                                          setText={(text, index) => {}}
                                          isSelectItem={isSelectItem}
                                          setSelectedRoom={setSelectedRoom}
                                          areaLabelTextArray={
                                            areaLabelTextArray
                                          }
                                          roomId={areaName.roomID}
                                          isTotalAreaLabel={true}
                                        />
                                      ) : (
                                        !hideLabels && (
                                          <TextObj
                                            position={findCenterPoint(
                                              _.cloneDeep(el.data)
                                            )}
                                            name={
                                              "totalAreaLabel::" + el.roomId
                                            }
                                            id={
                                              "totalAreaLabel::" +
                                              el.roomId +
                                              "totalAreaLabel-text:" +
                                              i
                                            }
                                            labelId={`totalAreaLabel${i}`}
                                            textid={"totalAreaLabel:" + i}
                                            setSelectedTextId={
                                              setSelectedTextId
                                            }
                                            setSelectedLabelId={
                                              setSelectedLabelId
                                            }
                                            selectedLabelId={selectedLabelId}
                                            selectedTextId={selectedTextId}
                                            deleteLabel={deleteLabel}
                                            pointerDown={pointerDown}
                                            pointerUp={pointerUp}
                                            isDragLine={isDragLine}
                                            deleteRoom={deleteRoom}
                                            setDeleteRoom={setDeleteRoom}
                                            text={`${el.totalAreaOfRoom} Sq ft`}
                                            index={i}
                                            setText={(text, index) => {}}
                                            isSelectItem={isSelectItem}
                                            setSelectedRoom={setSelectedRoom}
                                            areaLabelTextArray={
                                              areaLabelTextArray
                                            }
                                            roomId={el.roomId}
                                            isTotalAreaLabel={true}
                                          />
                                        )
                                      )}
                                    </>
                                  );
                                }
                              });
                            })}
                          {isAddLabel &&
                            roomArray.map((el) => {
                              return (
                                <Line
                                  points={[...el.data, el.data[0]]}
                                  color={
                                    selectedRoomForLable == "room:" + el.roomId
                                      ? "red"
                                      : "black"
                                  }
                                  name={"room:" + el.roomId}
                                  renderOrder={999999999999}
                                  lineWidth={7}
                                  depthTest={false}
                                  depthWrite={false}
                                />
                              );
                            })}
                          {drawLine &&
                            lineArray?.length > 0 &&
                            liveLineMoveData?.length > 0 && (
                              <>
                                <CreateLabel
                                  startingPoint={{
                                    x: lineArray[lineArray.length - 1][0],
                                    y: lineArray[lineArray.length - 1][1],
                                    z: lineArray[lineArray.length - 1][2],
                                  }}
                                  endingPoint={{
                                    x: liveLineMoveData[0],
                                    y: liveLineMoveData[1],
                                    z: liveLineMoveData[2],
                                  }}
                                />
                                <Line
                                  points={[
                                    lineArray[lineArray.length - 1],
                                    liveLineMoveData,
                                  ]}
                                  color={"#008000"}
                                  name={"custom-line"}
                                  lineWidth={7}
                                  renderOrder={999999999999}
                                  depthTest={false}
                                  depthWrite={false}
                                />
                              </>
                            )}
                          {lineArray.map((el, i) => {
                            if (i < lineArray.length - 1) {
                              return (
                                <>
                                  {!isDragLine && drawLine && (
                                    <FakeSphere roomId={el.roomId} args={el} />
                                  )}
                                  {!hideLabels && (
                                    <CreateLabel
                                      startingPoint={{
                                        x: lineArray[i][0],
                                        y: lineArray[i][1],
                                        z: lineArray[i][2],
                                      }}
                                      endingPoint={{
                                        x: lineArray[i + 1][0],
                                        y: lineArray[i + 1][1],
                                        z: lineArray[i + 1][2],
                                      }}
                                    />
                                  )}
                                  <Line
                                    points={[lineArray[i], lineArray[i + 1]]}
                                    color={"#008000"}
                                    name={"custom-line"}
                                    lineWidth={7}
                                    renderOrder={999999999999}
                                    depthTest={false}
                                    depthWrite={false}
                                  />
                                </>
                              );
                            } else if (i < lineArray.length) {
                              return (
                                <>
                                  {!isDragLine && drawLine && (
                                    <FakeSphere roomId={el.roomId} args={el} />
                                  )}
                                  <Line
                                    points={[lineArray[i], lineArray[i]]}
                                    color={"black"}
                                    name={"custom-line"}
                                    lineWidth={7}
                                    renderOrder={999999999999}
                                    depthTest={false}
                                    depthWrite={false}
                                  />
                                </>
                              );
                            }
                          })}
                          {suggestlineArray.length > 0 && (
                            <>
                              {!hideLabels && (
                                <CreateLabel
                                  startingPoint={{
                                    x: suggestlineArray[0][0],
                                    y: suggestlineArray[0][1],
                                    z: suggestlineArray[0][2],
                                  }}
                                  endingPoint={{
                                    x: suggestlineArray[1][0],
                                    y: suggestlineArray[1][1],
                                    z: suggestlineArray[1][2],
                                  }}
                                />
                              )}
                              <Line
                                points={suggestlineArray}
                                // lineWidth={7}
                                color={"red"}
                                name={"custom-line"}
                                renderOrder={999999999999}
                                depthTest={false}
                                depthWrite={false}
                                dashed={true}
                                dashSize={0.5}
                                gapSize={0.3}
                              />
                            </>
                          )}

                          {!isDragLine &&
                            !deleteRoom.isDelete &&
                            doorArray.length > 0 &&
                            doorArray.map((el, i) => {
                              return (
                                <Line
                                  points={[el[0].points, el[1].points]}
                                  distStart={{
                                    x: el[0].points[0],
                                    y: el[0].points[1],
                                    z: el[0].points[2],
                                  }}
                                  distEnd={{
                                    x: el[1].points[0],
                                    y: el[1].points[1],
                                    z: el[1].points[2],
                                  }}
                                  doorDirection={el[0].doorDirection}
                                  color={
                                    deleteSelectedDoorWin.isDelete &&
                                    deleteSelectedDoorWin.name ==
                                      "doors::" + el[0].lineId + "::" + i
                                      ? "red"
                                      : el[0].doorDirection ==
                                        doorDirectionEnum.inside
                                      ? THREED_INSIDE_DOOR_COLOR
                                      : THREED_DOOR_COLOR
                                  }
                                  lineWidth={7}
                                  name={"doors::" + el[0].lineId + "::" + i}
                                  renderOrder={99999999999999}
                                  depthTest={false}
                                  depthWrite={false}
                                  parentroomid={el[0].parentRoomId}
                                  onPointerDown={(e) => {
                                    if (isSelectItem) {
                                      setIsSelectDoorItem(true);
                                      if (
                                        isSelectItem &&
                                        deleteSelectedDoorWin.isDelete &&
                                        deleteSelectedDoorWin.name ==
                                          e.eventObject.name
                                      ) {
                                        setDeleteSelectedDoorWin({
                                          name: "",
                                          isDelete: false,
                                          isDeleteWindow: false,
                                        });
                                      } else {
                                        setDeleteSelectedDoorWin({
                                          name: e.eventObject.name,
                                          isDelete: true,
                                          isDeleteWindow: false,
                                        });
                                      }
                                    }
                                  }}
                                />
                              );
                            })}
                          {!isDragLine &&
                            !deleteRoom.isDelete &&
                            windowArray.length > 0 &&
                            windowArray.map((el, i) => {
                              return (
                                <Line
                                  points={[el[0].points, el[1].points]}
                                  distStart={{
                                    x: el[0].points[0],
                                    y: el[0].points[1],
                                    z: el[0].points[2],
                                  }}
                                  distEnd={{
                                    x: el[1].points[0],
                                    y: el[1].points[1],
                                    z: el[1].points[2],
                                  }}
                                  color={
                                    isSelectItem &&
                                    deleteSelectedDoorWin.isDeleteWindow &&
                                    deleteSelectedDoorWin.name ==
                                      "windows::" + el[0].lineid + "::" + i
                                      ? "red"
                                      : THREED_WINDOW_COLOR
                                  }
                                  lineWidth={7}
                                  name={"windows::" + el[0].lineid + "::" + i}
                                  partitionlineid={el[0].roomId}
                                  renderOrder={99999999999999}
                                  depthTest={false}
                                  depthWrite={false}
                                  parentroomid={el[0].parentRoomId}
                                  onPointerDown={(e) => {
                                    if (isSelectItem) {
                                      setIsSelectDoorItem(true);
                                      if (
                                        deleteSelectedDoorWin.isDeleteWindow &&
                                        deleteSelectedDoorWin.name ==
                                          e.eventObject.name
                                      ) {
                                        setDeleteSelectedDoorWin({
                                          name: "",
                                          isDelete: false,
                                          isDeleteWindow: false,
                                        });
                                      } else {
                                        setDeleteSelectedDoorWin({
                                          name: e.eventObject.name,
                                          isDelete: false,
                                          isDeleteWindow: true,
                                        });
                                      }
                                    }
                                  }}
                                />
                              );
                            })}

                          {doorWindowCircleArray?.length > 0 && (
                            <DoorWindowStartPoint
                              args={doorWindowCircleArray[0].points}
                            />
                          )}
                          {!hideLabels &&
                            textArray.map((el, i) => {
                              return (
                                <TextObj
                                  position={el.points}
                                  name={"label::" + el.roomID}
                                  id={
                                    "label::" + el.roomID + "custom-text:" + i
                                  }
                                  labelId={el.labelId}
                                  textid={"custom-text:" + i}
                                  setSelectedTextId={setSelectedTextId}
                                  setSelectedLabelId={setSelectedLabelId}
                                  selectedLabelId={selectedLabelId}
                                  selectedTextId={selectedTextId}
                                  deleteLabel={deleteLabel}
                                  pointerDown={pointerDown}
                                  pointerUp={pointerUp}
                                  isDragLine={isDragLine}
                                  deleteRoom={deleteRoom}
                                  setDeleteRoom={setDeleteRoom}
                                  text={el.text}
                                  index={i}
                                  setText={(text, index) => {
                                    state.scene.children.forEach((child) => {
                                      if (
                                        child.meshid ==
                                        "label::" +
                                          el.roomID +
                                          "custom-text:" +
                                          i
                                      )
                                        child.text = text;
                                    });
                                    let newtextArray = textArray;
                                    newtextArray[index].text = text;
                                    setTextArray(newtextArray);
                                  }}
                                  roomId={el.roomID}
                                  isSelectItem={isSelectItem}
                                  setSelectedRoom={setSelectedRoom}
                                  addChangesToStack={addChangesToStack}
                                  textArray={textArray}
                                />
                              );
                            })}
                          {partitionFirstArray?.length > 0 && (
                            <>
                              {!isDragLine && isAddPartition && (
                                <FakeSphere
                                  roomId={""}
                                  args={partitionFirstArray[0].points}
                                  isPartition={true}
                                />
                              )}
                              <Line
                                points={[
                                  partitionFirstArray[0].points,
                                  partitionFirstArray[0].points,
                                ]}
                                color={"black"}
                                lineWidth={7}
                                renderOrder={999999999999}
                                depthTest={false}
                                depthWrite={false}
                              />
                            </>
                          )}
                          {partitionArray?.length > 0 &&
                            partitionArray.map((el, i) => {
                              return (
                                <>
                                  {!isSelectItem &&
                                    !isAddWindow &&
                                    !isAddLabel &&
                                    !hidePly &&
                                    !drawLine &&
                                    !isAddPartition &&
                                    !suggestlineArray.length > 0 &&
                                    !selectedLabelId &&
                                    !selectedTextId &&
                                    !isAddStairCase &&
                                    (!isDragLine ||
                                      selectedTorusDetails?.selectedTorusType) && (
                                      <>
                                        {!isAddPartition &&
                                          _.isEmpty(selectedTorusDetails) && (
                                            <>
                                              <FakeSphere
                                                lineId={i}
                                                roomId={el.roomId}
                                                parentroomid={el.mainRoomId}
                                                args={el.points[0]}
                                                basePoints={el.points[1]}
                                                isPartition={true}
                                                partitionArrayIndex={i}
                                                partitionWallIndex={0}
                                              />
                                              <FakeSphere
                                                lineId={i}
                                                roomId={el.roomId}
                                                parentroomid={el.mainRoomId}
                                                args={el.points[1]}
                                                basePoints={el.points[0]}
                                                isPartition={true}
                                                partitionArrayIndex={i}
                                                partitionWallIndex={1}
                                              />
                                            </>
                                          )}
                                        {selectedTorusDetails?.selectedTorusType &&
                                        selectedTorusDetails?.partitionArrayIndex ===
                                          i &&
                                        selectedTorusDetails?.partitionWallIndex ===
                                          0 ? (
                                          <FakeSphere
                                            lineId={i}
                                            roomId={el.roomId}
                                            parentroomid={el.mainRoomId}
                                            args={el.points[0]}
                                            basePoints={el.points[1]}
                                            isPartition={true}
                                            partitionArrayIndex={i}
                                            partitionWallIndex={0}
                                          />
                                        ) : (
                                          selectedTorusDetails?.selectedTorusType &&
                                          selectedTorusDetails?.partitionArrayIndex ===
                                            i &&
                                          selectedTorusDetails?.partitionWallIndex ===
                                            1 && (
                                            <FakeSphere
                                              lineId={i}
                                              roomId={el.roomId}
                                              parentroomid={el.mainRoomId}
                                              args={el.points[1]}
                                              basePoints={el.points[0]}
                                              isPartition={true}
                                              partitionArrayIndex={i}
                                              partitionWallIndex={1}
                                            />
                                          )
                                        )}
                                      </>
                                    )}
                                  <Line
                                    points={[el.points[0], el.points[1]]}
                                    distStart={{
                                      x: el.points[0][0],
                                      y: el.points[0][1],
                                      z: el.points[0][2],
                                    }}
                                    distEnd={{
                                      x: el.points[1][0],
                                      y: el.points[1][1],
                                      z: el.points[1][2],
                                    }}
                                    color={
                                      deleteRoom.isDelete &&
                                      (deleteRoom.roomId == el.roomId ||
                                        deleteRoom.roomId == el.mainRoomId)
                                        ? "red"
                                        : "black"
                                    }
                                    name={"partitionwall"}
                                    lineid={`partitionwall:${el.roomId}${i}`}
                                    lineId={i}
                                    roomid={el.roomId}
                                    parentroomid={el.mainRoomId}
                                    renderOrder={999999999999}
                                    lineWidth={7}
                                    depthTest={false}
                                    depthWrite={false}
                                    onPointerUp={(e) => {
                                      isDragLine && pointerUp(e);
                                      setDoorWindow(e, {
                                        partitionwall: true,
                                        areatype: null,
                                        arealabel: null,
                                        additionaltype: null,
                                      });
                                    }}
                                    onPointerOver={(e) => {
                                      if (isAddDoor || isAddWindow) {
                                        onMeshPointerMove(
                                          e,
                                          setMarkerPointArray,
                                          markerPointArray,
                                          true
                                        );
                                      }
                                    }}
                                    onPointerMove={(e) => {
                                      if (isAddDoor || isAddWindow) {
                                        onMeshPointerMove(
                                          e,
                                          setMarkerPointArray,
                                          markerPointArray,
                                          true
                                        );
                                      }
                                    }}
                                    onPointerLeave={(e) => {
                                      if (isAddDoor || isAddWindow) {
                                        onMeshPointerMove(
                                          e,
                                          setMarkerPointArray,
                                          markerPointArray,
                                          false
                                        );
                                      }
                                    }}
                                  />
                                </>
                              );
                            })}
                          {tab.currentTab == "Measurement" &&
                            axisCords.length > 0 && (
                              <>
                                <Line
                                  points={[axisCords[0], axisCords[1]]}
                                  color={"#e7534b"}
                                  name={"XaxisLine"}
                                  renderOrder={999999999999}
                                  lineWidth={1}
                                  onPointerUp={(e) => {}}
                                  onPointerOver={(e) => {
                                    setHighlighterCords([
                                      e?.point?.x,
                                      e?.point?.y,
                                      e?.point?.z,
                                    ]);
                                  }}
                                  onPointerLeave={(e) => {
                                    setHighlighterCords([]);
                                  }}
                                  dashed={true}
                                  dashSize={0.08}
                                  gapSize={0.08}
                                />
                                <Line
                                  points={[axisCords[2], axisCords[3]]}
                                  color={"#62DA7F"}
                                  name={"YaxisLine"}
                                  renderOrder={999999999999}
                                  lineWidth={1}
                                  onPointerOver={(e) => {
                                    setHighlighterCords([
                                      e?.point?.x,
                                      e?.point?.y,
                                      e?.point?.z,
                                    ]);
                                  }}
                                  onPointerLeave={(e) => {
                                    setHighlighterCords([]);
                                  }}
                                  dashed={true}
                                  dashSize={0.08}
                                  gapSize={0.08}
                                />
                              </>
                            )}
                          {highlighterCords?.length > 0 &&
                            lineArray.length > 0 && (
                              <Line
                                points={[
                                  lineArray[lineArray.length - 1],
                                  highlighterCords,
                                ]}
                                color={"#e48e1a"}
                                name={"highlighteraxisLine"}
                                renderOrder={999999999999}
                                lineWidth={2}
                                dashed={false}
                                enableRotate={true}
                              />
                            )}
                          {stairCaseArray?.length > 0 &&
                            stairCaseArray.map((el, i) => {
                              return (
                                <CreateStairCase
                                  key={"stair-case::" + el.roomID}
                                  position={el.points}
                                  scaleX={el.scaleX || 1}
                                  scaleY={el.scaleY || 1}
                                  angle={el.angle || 0}
                                  name={"stair-case::" + el.roomID}
                                  id={"stair-case::" + el.roomID}
                                  stairCaseId={el.stairCaseId}
                                  selectedRoomStairCase={selectedRoomStairCase}
                                  setSelectedRoomStairCase={
                                    setSelectedRoomStairCase
                                  }
                                  selectedStairObject={selectedStairObject}
                                  setSelectedStairObject={() => {
                                    setSelectedStairObject({
                                      i,
                                      scaleX: el.scaleX,
                                      scaleY: el.scaleY,
                                    });
                                    setPrevSelectedStairObject(
                                      _.cloneDeep(stairCaseArray)
                                    );
                                  }}
                                  onDrag={(e, start) =>
                                    isSelectItem &&
                                    e.target?.closest("div")?.id ==
                                      selectedRoomStairCase
                                      ? onStairDrag(
                                          e,
                                          stairCaseArray,
                                          i,
                                          setStairCaseArray,
                                          start,
                                          addChangesToStack,
                                          removeMagnifier
                                        )
                                      : () => {}
                                  }
                                  isSelectItem={isSelectItem}
                                  pointerDown={pointerDown}
                                />
                              );
                            })}

                          {nameOfMesh && !isDragLine && (
                            <TransformControls
                              object={state.scene.getObjectByName(nameOfMesh)}
                              mode={"translate"}
                            />
                          )}
                          {!isDragLine &&
                          !isAddPartition &&
                          !selectedRoomStairCase ? (
                            <OrbitControls
                              ref={orbitCtrl}
                              enableDamping={!drawLine}
                              enableZoom={!drawLine}
                              enableRotate={!drawLine}
                              enablePan={!drawLine}
                              makeDefault
                              minPolarAngle={0}
                              maxPolarAngle={isSideView ? Math.PI : 0}
                            />
                          ) : (
                            <OrbitControls
                              enableDamping={false}
                              enableZoom={false}
                              enableRotate={false}
                              enablePan={false}
                              makeDefault
                              minPolarAngle={0}
                              maxPolarAngle={isSideView ? Math.PI : 0}
                            />
                          )}
                        </Canvas>
                      </Suspense>
                    </>
                  )}

                {contentAvailable && showScatch && drawFloorPlan && (
                  <MeasurementTab
                    setShowPublishSidebar={setShowPublishSidebar}
                    setIsLoading={setIsLoading}
                    fetchProfileDetails={props.fetchProfileDetails}
                    isTechnician={{ create: true, edit: false }}
                    newMeasurementTypes={"4"}
                    setSelectedFloorScanId={floorScanId}
                    selectedFloorScanName={floorNameJson}
                    JsonObject={JsonObject}
                    setJsonObject={setJsonObject}
                    screenMode={screenMode}
                  ></MeasurementTab>
                )}
              </div>
            </div>
            <PublishFormSidebar
              showPublishSidebar={showPublishSidebar}
              setShowPublishSidebar={setShowPublishSidebar}
              floorNameJson={floorNameJson}
              onSubmit={(name) => {
                SetPopUpMsg(threeDFloorScan.msgForPublish);
                setPopUp({
                  show: true,
                  override: false,
                });
                setPublish({
                  show: true,
                  name,
                });
              }}
            />
          </div>
        </div>
      </section>
    </>
  );
}
const mapStateToProps = (state) => {
  return {
    state: state,
    technicianJob: state.technicianJob,
  };
};
export default connect(mapStateToProps, {
  fetchFloor,
  fetchFloorContent,
  fetchZipFile,
  publishJson,
  StartLoading,
  StopLoading,
  fetchProfileDetails,
  updateNavBar,
  updateHeader,
  autoSaveThreeDJson,
})(View3DFloorPlan);
