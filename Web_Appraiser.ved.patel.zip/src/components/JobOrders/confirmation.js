<div class="confirm-box open">
  <div class="inner-modal">
    <p>Are You Sure You Want to Cancel This Appointment?</p>
    <div class="conf-footer text-right">
      <button class="gray-btn">No</button>
      <button class="blue-btn">Yes</button>
    </div>
  </div>
</div>;
