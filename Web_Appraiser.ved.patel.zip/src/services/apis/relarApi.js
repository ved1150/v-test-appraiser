import api from "./api";

export default class RelarAPI {
  getRelars(data) {
    return api.get(
      `/measurement/relar/${data.jobOrderId}?direction=${data.direction}&sortBy=${data.sortBy}&relarCompsType=${data.relarCompsType}&page=${data.pageNo}&size=${data.size}
      `
    );
  }
  filterRelars(data) {
    return api.post(`/measurement/relar/filter`, data);
  }

  requestRelar(data) {
    return api.post(`/joborder/initiate-relar-request/${data}`);
  }
}
