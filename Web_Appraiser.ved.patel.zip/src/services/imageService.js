import api from "./apis/api";
import {
  hydrateImages,
  dyHydrateImageList,
  dyHydrateImageListForDelete,
} from "./transformers/jobOrderDetailsTransformer";

class ImageService {
  getImages(data) {
    return api.image.getImages(data).then(hydrateImages);
  }

  downloadImages(data) {
    return api.image.downloadImages(dyHydrateImageList(data));
  }

  deleteImages(data) {
    return api.image.deleteImages(dyHydrateImageListForDelete(data));
  }
}

export default new ImageService();
