import React from "react";

export default function InstructionModal(props) {
  return (
    <>
      {props.explorePlanInstruction && (
        <div className="guideline-popup open">
          <div className="error-info text-left">
            <div className="content">
              <button
                className="close-modal"
                onClick={() => props.setExplorePlanInstruction(false)}
              >
                <i className="icon-close-image"></i>
              </button>
              <p>
                <b>Instructions</b>
              </p>
              <ul>
                <li>
                  <p>
                    <b>Top-Down:</b> The canvas will be frozen from the top/bird
                    view.
                  </p>
                </li>
                <li>
                  <p>
                    <b>Move/Drag the PLY:</b> Click on Ctrl/Command + mouse and
                    drag the mouse pointer anywhere in the canvas (white space)
                  </p>
                </li>
                <li>
                  <p>
                    <b>Zoom-in/Zoom-out:</b> If you are using mouse, wheel up to
                    zoom-in and wheel down to zoom-out. If you are using
                    touchpad, use two fingers to zoom
                  </p>
                </li>
                <li>
                  <p>
                    <b>Rotate the PLY:</b> Click and move pointer in the canvas
                    to rotate the object 360 degrees
                  </p>
                </li>
                <li>
                  <p>
                    You can explore and adjust the PLY using above all actions.
                    If you feel the PLY of the floor scan is proper, click on
                    'Create Floorplan' option to proceed further
                  </p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
      {props.measurementInstruction && (
        <div className="guideline-popup open">
          <div className="error-info text-left">
            <div className="content">
              <button
                className="close-modal"
                onClick={() => props.setMeasurementInstruction(false)}
              >
                <i className="icon-close-image"></i>
              </button>
              <p>
                <b>Instructions</b>
              </p>
              <div className="modal-info-body">
                <ul>
                  <li>
                    <p>
                      To draw or edit the floor plan, use the options given in
                      the Tools menu
                    </p>
                  </li>
                  <li>
                    <p>To add room/lines, click on Add line tool</p>
                  </li>
                  <li>
                    <p>
                      If you want to consider your room in the area calculation,
                      select "Add line as Additional" tool. If you just want to
                      mark the room and does not want to add in area
                      calculation, select "Add line as Non-Additional" tool
                    </p>
                  </li>
                  <li>
                    <p>
                      Select Area type and Area label options for particular
                      measurement
                    </p>
                  </li>
                  <li>
                    <p>
                      The PLY is locked during this process. If you want to
                      move/adjust the PLY during measurement, turn off the Add
                      line switch from the Tools
                    </p>
                  </li>
                  <li>
                    <p>
                      Once you draw two lines, you will see suggestion line in
                      red color. Click on Connect and finish icon to complete
                      the room; or you can continue drawing lines and once you
                      feel suggestion red line is actual last line, click on
                      Connect and finish icon
                    </p>
                  </li>
                  <li>
                    <p>
                      If you want to see the floor plan/drawn lines, click on
                      Hide PLY option from Tools
                    </p>
                  </li>
                  <li>
                    <p>
                      You can adjust/edit the line by clicking and dragging on
                      any red circled shape endpoint
                    </p>
                  </li>
                  <li>
                    <p>You can Undo any action on click of Undo icon</p>
                  </li>
                  <li>
                    <p>
                      You can add Doors from Tools. You have to mark on starting
                      and ending point of door on any wall after clicking on Add
                      Door option,
                    </p>
                    <p>
                      1. If the door opens on the inside of the room, you can
                      add it as an interior door.
                    </p>
                    <p>
                      2. If the door opens on the outside of the room, you can
                      add it as an exterior door.
                    </p>
                    <p>
                      <b>Note : </b>Both interior/exterior doors can be used
                      vice-versa regardless of the purpose depending on the
                      requirement.
                    </p>
                  </li>
                  <li>
                    <p>
                      You can add partition inside the room by clicking on "Add
                      partition" tool. Remember, partition is just a child of
                      the room and is not a wall of room
                    </p>
                  </li>
                  <li>
                    <p>
                      You can add multiple labels inside room by clicking on
                      "Add label" tool
                    </p>
                  </li>
                  <li>
                    <p>
                      To edit the label inside room, click on the red border of
                      the label and drag it to the desired place or click on the
                      Delete icon from the tool to remove the label
                    </p>
                  </li>
                  <li>
                    <p>
                      You can select any room by clicking on "Select Item" tool
                      and clicking on any wall of it. Once it is selected, it
                      will highlighted in red. You can then edit the Area type
                      and Area label of that room. Furthermore, the Delete icon
                      will be enabled which will allow to delete the room along
                      with its label, partitions and doors
                    </p>
                  </li>
                  <li>
                    <p>
                      Once you finish the measurement, click on Preview to see
                      2D floor plan of the same
                    </p>
                  </li>
                  <li>
                    <p>
                      While adding the lines for a room the measurement of the
                      line will be shown and once the particular room creation
                      has been created successfully then the room measurement
                      will be shown.
                    </p>
                  </li>
                  <li>
                    <p>
                      If the technician/user is required to hide the labels,
                      simply click on the button to hide/show the labels.
                    </p>
                  </li>
                  <li>
                    <p>
                      If you want to view only top side of the ply, click on
                      Top-Down view option in the top right corner of the
                      editor. This will restrict the ply to rotate in only
                      clockwise and anti-clockwise direction instead of 3D.
                    </p>
                  </li>
                  <li>
                    <p>
                      Auto save will get triggered on every action you perform
                      in the editor and will persist until it is published
                      successfully.
                    </p>
                  </li>
                  <li>
                    <p>
                      You can add the staircase anywhere inside the room area.
                    </p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
