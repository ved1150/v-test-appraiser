import React, { useEffect } from "react";
import { connect } from "react-redux";
import { JSEncrypt } from "jsencrypt";
import { fetchLink } from "../../actions/authenticationAction";

const publicKey =
  "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgaj70+XcoQbuqUUr/99mxbjX1qRodvCjwgyCChxQ9pN+86Q1cTz0LxrhFCsaLz2N66j2lg5UAjryPMHy1UMzNyFPZdkrTimFP/7q4yulhNt18+VaPwvHaWbfLYeEWHfwNN2sbyGQgkc48mOr9btSCt8gyWAjIGtlzX5oXFvP2tL1fdM63+/57ta9ZrmghZziZ5cFIX+AC21nvNVv9avPPZZchxyS4BVojVfWnEzijU0OtrnkaKe31v1qIMyerDGOIOwq4PxodqZqMeZzmWF/oY6iB1oBF6PsG0B+5yUx62qsa3HGMkDyfC/wk/hG56REpOPzbHgSRjbWjQcqohOtTQIDAQAB";

const ShortCallLink = (props) => {
  const id = props.match.params.id;
  id && localStorage.setItem("shortLink", id);
  let encryptedPass;
  const encryptLink = () => {
    let RSAEncrypt = new JSEncrypt();
    RSAEncrypt.setPublicKey(publicKey);
    encryptedPass = RSAEncrypt.encrypt(id);
  };

  useEffect(() => {
    if (id) {
      encryptLink();
      props.fetchLink(encryptedPass, props.history).then((data) => {
        // data.originalUrl = data.originalUrl.replace("https://appraiser.v-site.xyz", "http://localhost:3000");
        data && (window.location.href = data.originalUrl);
      });
    } else {
    }
  }, []);

  return <></>;
};

const mapDispatchToProps = (dispatch) => ({
  fetchLink: (data, history) => dispatch(fetchLink(data, history)),
});

const mapStateToProps = ({ me }) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(ShortCallLink);
