import React from "react";
import Button from "../common/Button";

const ConfirmationModal = (props) => {
  return (
    <div className="confirm-box open">
      <div className="inner-modal">
        <p>{props.title}</p>
        {!props.hideButtons && (
          <div className="conf-footer text-right">
            {!props.hideCancel && (
              <Button className="gray-btn" onClick={props.cancelEvent}>
                {props.cancelText}
              </Button>
            )}
            <Button
              className="blue-btn"
              onClick={() => {
                props.confirmEvent();
              }}
            >
              {props.confirmText}
            </Button>
          </div>
        )}
        {props.children}
      </div>
    </div>
  );
};

ConfirmationModal.defaultProps = {
  hideButtons: false,
};
export default ConfirmationModal;
