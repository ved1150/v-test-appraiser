import React, { useEffect, useState } from "react";
import PDFView from "../Common/PDFView";
import { useTranslation } from "react-i18next";
import _ from "lodash";
import "./index.scss";

const PDRReports = (props) => {
  const { t } = useTranslation();
  const [PDRReport, setPDRReport] = useState({});
  useEffect(() => {
    props.fetchPDRDetails(props.jobOrderId).then((data) => {
      setPDRReport(_.get(data, ["pdrReportFileData"], {}));
    });
  }, []);

  return (
    <>
      {PDRReport ? (
        <PDFView pdfData={PDRReport} />
      ) : (
        <div className="no-data-found div-height">
          <div className="box">
            <i className="icon-pdr-report"></i>
            <p>There is no PDR Report available.</p>
          </div>
        </div>
      )}
    </>
  );
};

export default PDRReports;
