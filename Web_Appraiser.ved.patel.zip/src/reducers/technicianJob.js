import * as actionTypes from "../actions/actionTypes";

export const defaultState = {
  loading: false,
  jobOrders: {},
  floorScan: {},
  floorDetail: {},
  error: null,
  uploadImage: {},
  floosScansLoading: false,
};

const plyRetryState = {
  plyRetryStart: false,
  plyRetrySuccess: {},
  plyRetryError: null,
};

const fetchFloorScanReportListState = {
  fetchFloorScanReportListStart: false,
  fetchFloorScanReportListSuccess: [],
  fetchFloorScanReportListError: null,
};

const scanIsOkayState = {
  scanIsOkayStart: false,
  scanIsOkaySuccess: [],
  scanIsOkayError: null,
};

const requestRescanHistoryState = {
  requestRescanHistoryStateStart: false,
  requestRescanHistoryStateSuccess: [],
  requestRescanHistoryStateError: null,
};

const states = {
  ...defaultState,
  ...plyRetryState,
  ...fetchFloorScanReportListState,
  ...scanIsOkayState,
  ...requestRescanHistoryState,
};

// eslint-disable-next-line import/no-anonymous-default-export
export default (state = states, action = {}) => {
  switch (action.type) {
    case actionTypes.TECHNICIAN_JOB_ORDER_START:
      return {
        ...state,
        loading: true,
        jobOrders: {},
        error: null,
      };
    case actionTypes.TECHNICIAN_JOB_ORDER_SUCCESS:
      return {
        ...state,
        loading: false,
        jobOrders: action.payload,
        error: null,
      };
    case actionTypes.TECHNICIAN_JOB_ORDER_ERROR:
      return {
        ...state,
        loading: false,
        jobOrders: {},
        error: action.payload,
      };

    case actionTypes.FLOOR_SCAN_START:
      return {
        ...state,
        loading: true,
        floorScan: {},
        error: null,
        floosScansLoading: true,
      };
    case actionTypes.FLOOR_SCAN_SUCCESS:
      return {
        ...state,
        loading: false,
        floorScan: action.payload,
        error: null,
        floosScansLoading: false,
      };
    case actionTypes.FLOOR_SCAN_ERROR:
      return {
        ...state,
        loading: false,
        floorScan: {},
        error: action.payload,
        floosScansLoading: false,
      };
    case actionTypes.FLOOR_SCAN_DETAIL_START:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case actionTypes.FLOOR_SCAN_DETAIL_SUCCESS:
      return {
        ...state,
        loading: false,
        floorDetail: action.payload,
        error: null,
      };
    case actionTypes.FLOOR_SCAN_DETAIL_ERROR:
      return {
        ...state,
        loading: false,
        floorDetail: {},
        error: action.payload,
      };
    case actionTypes.FLOOR_SCAN_DETAIL_UNMOUNT:
      return {
        ...state,
        loading: false,
        floorDetail: {},
        error: null,
      };
    case actionTypes.UPDATE_FLOOR_SCAN_IMAGE_START:
      return {
        ...state,
        loading: true,
        error: null,
        uploadImage: {},
      };
    case actionTypes.UPDATE_FLOOR_SCAN_IMAGE_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        uploadImage: action.payload,
      };
    case actionTypes.FLOOR_SCAN_UPDATE_STATUS_START:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case actionTypes.FLOOR_SCAN_UPDATE_STATUS_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
      };
    case actionTypes.FLOOR_SCAN_UPDATE_STATUS_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case actionTypes.UPDATE_FLOOR_SCAN_IMAGE_ERROR:
      return {
        ...state,
        loading: false,
        uploadImage: {},
        error: action.payload,
      };
    case actionTypes.PLY_RETRY_START:
      return {
        ...state,
        plyRetryStart: true,
        plyRetrySuccess: {},
        plyRetryError: null,
      };
    case actionTypes.PLY_RETRY_SUCCESS:
      return {
        ...state,
        plyRetryStart: false,
        plyRetrySuccess: action.payload,
        plyRetryError: null,
      };
    case actionTypes.PLY_RETRY_ERROR:
      return {
        ...state,
        plyRetryStart: false,
        plyRetrySuccess: {},
        plyRetryError: action.payload,
      };
    case actionTypes.FETCH_FLOOR_SCAN_REPORT_LIST_START:
      return {
        ...state,
        fetchFloorScanReportListStart: true,
        fetchFloorScanReportListSuccess: [],
        fetchFloorScanReportListError: null,
      };
    case actionTypes.FETCH_FLOOR_SCAN_REPORT_LIST_SUCCESS:
      return {
        ...state,
        fetchFloorScanReportListStart: false,
        fetchFloorScanReportListSuccess: action.payload,
        fetchFloorScanReportListError: null,
      };
    case actionTypes.FETCH_FLOOR_SCAN_REPORT_LIST_ERROR:
      return {
        ...state,
        fetchFloorScanReportListStart: false,
        fetchFloorScanReportListSuccess: [],
        fetchFloorScanReportListError: action.payload,
      };
    case actionTypes.SCAN_IS_OKAY_START:
      return {
        ...state,
        scanIsOkayStart: true,
        scanIsOkaySuccess: [],
        scanIsOkayError: null,
      };
    case actionTypes.SCAN_IS_OKAY_SUCCESS:
      return {
        ...state,
        scanIsOkayStart: false,
        scanIsOkaySuccess: action.payload,
        scanIsOkayError: null,
      };
    case actionTypes.SCAN_IS_OKAY_ERROR:
      return {
        ...state,
        scanIsOkayStart: false,
        scanIsOkaySuccess: [],
        scanIsOkayError: action.payload,
      };
    case actionTypes.GET_REQUEST_RESCAN_HISTORY_START:
      return {
        ...state,
        requestRescanHistoryStateStart: true,
        requestRescanHistoryStateSuccess: [],
        requestRescanHistoryStateError: null,
      };
    case actionTypes.GET_REQUEST_RESCAN_HISTORY_SUCCESS:
      return {
        ...state,
        requestRescanHistoryStateStart: false,
        requestRescanHistoryStateSuccess: action.payload,
        requestRescanHistoryStateError: null,
      };
    case actionTypes.GET_REQUEST_RESCAN_HISTORY_ERROR:
      return {
        ...state,
        requestRescanHistoryStateStart: false,
        requestRescanHistoryStateSuccess: [],
        requestRescanHistoryStateError: action.payload,
      };
    default:
      return state;
  }
};
