import { fabric } from "fabric";
import _ from "lodash";
import { doorDirectionEnum } from "../../../../constants/enums";
import { getParentPartitionPoint } from "../../../FloorScanJob/View3DFloorPlan/ConvertJSON";

export const PARTITION_WINDOW_COLOR = "#FFFFFF",
  PARTITION_DOOR_COLOR = "#FFFFFF",
  PARTITION_INSIDE_DOOR_COLOR = "#FFFFFF",
  ROOM_WALL_DOOR_COLOR = "#FFFFFF",
  ROOM_WALL_WINDOW_COLOR = "#FFFFFF",
  PARTITION_COLOR = "#000000",
  lineStokeWidth = 6,
  partitionLineStokeWidth = 2,
  GLA_BORDER_COLOR = "#004080",
  NON_ADDITIONAL_BORDER_COLOR = "#09B5FF",
  NON_GLA_BORDER_COLOR = "#3D73AA",
  GLA_ROOM_COLOR = "rgb(99 152 98 / 25%)",
  NON_GLA_ROOM_COLOR = "rgb(72 90 159 / 22%)",
  EXTERIOR_BORDER_COLOR = "#004080",
  NON_ADDITIONAL_COLOR = "rgb(9 181 255 / 16%)",
  PARTITION_WINDOW_COLOR_BORDER = "black";

export const createEditablePartition = (thisCanvas, targetedPartitionId) => {
  removePartitionCircle(thisCanvas);
  let obj = thisCanvas.canvas.getActiveObject();
  if (obj) {
    obj.stroke = "black";
  }
  let connectedPartition = findConnectedDoorsWithPatition(
    [
      [targetedPartitionId.x1, targetedPartitionId.y1].toString(),
      [targetedPartitionId.x2, targetedPartitionId.y2].toString(),
    ],
    thisCanvas
  );
  let circle1Door = [];
  let circle2Door = [];
  connectedPartition?.forEach((el) => {
    circle1Door.push(
      el?.[0] === [targetedPartitionId.x1, targetedPartitionId.y1].toString()
        ? el
        : null
    );
    circle2Door.push(
      el?.[0] === [targetedPartitionId.x2, targetedPartitionId.y2].toString()
        ? el
        : null
    );
  });
  const circle1 = new fabric.Circle({
    radius: 3,
    fill: "black",
    left: targetedPartitionId.x1 - 3,
    top: targetedPartitionId.y1 - 3,
    hasControls: false,
    hasBorders: false,
    type: "circle",
    name: "partitionSelector1",
    id: "partitionSelector1",
    targetedPartitionId: targetedPartitionId,
    connectedDoor: circle1Door,
  });
  circle1.line1 = targetedPartitionId;

  const circle2 = new fabric.Circle({
    radius: 3,
    fill: "black",
    left: targetedPartitionId.x2 - 3,
    top: targetedPartitionId.y2 - 3,
    hasControls: false,
    hasBorders: false,
    type: "circle",
    name: "partitionSelector2",
    id: "partitionSelector2",
    targetedPartitionId: targetedPartitionId,
    connectedDoor: circle2Door,
  });
  circle2.line1 = targetedPartitionId;
  thisCanvas.canvas.add(circle1, circle2);
  thisCanvas.canvas.discardActiveObject();
  thisCanvas.canvas.renderAll();
};

export const removePartitionCircle = (thisCanvas, removeAll = false) => {
  if (removeAll) {
    thisCanvas.canvas
      .getObjects()
      .filter((e) => e.name === "partitionLine")
      .forEach((obj) => {
        thisCanvas.canvas.remove(obj);
      });
  }
  thisCanvas.canvas.remove(
    thisCanvas.canvas.getItemByAttr("id", "partitionSelector1")
  );
  thisCanvas.canvas.remove(
    thisCanvas.canvas.getItemByAttr("id", "partitionSelector2")
  );
};

export const deselectPartition = (thisCanvas) => {
  let obj = thisCanvas.canvas.getObjects();
  obj.forEach((element) => {
    if (element.type === "LINE") {
      element.stroke = "black";
    }
  });
};

export const dragPartitionDoor = (originalFloorPlan, selectedpartition) => {
  let copyOriginal = _.cloneDeep(originalFloorPlan);
  let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
  let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
  let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
  for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
    if (
      facesArray[faceIndex]["@type"] == "PARTITION_DOOR" &&
      (facesArray[faceIndex]["@parentPartition"]?.[0]?.line ===
        selectedpartition?.id ||
        facesArray[faceIndex]["@parentPartition"]?.[1]?.line ===
          selectedpartition?.id)
    ) {
      for (
        let rooflineIndex = 0;
        rooflineIndex < rooflines.length;
        rooflineIndex++
      ) {
        if (
          facesArray[faceIndex].POLYGON["@path"] ==
          rooflines[rooflineIndex]["@id"]
        ) {
          for (
            let roofPointIndex = 0;
            roofPointIndex < roofPoints.length;
            roofPointIndex++
          ) {
            for (
              let roofPointIndex1 = 0;
              roofPointIndex1 < roofPoints.length;
              roofPointIndex1++
            ) {
              if (
                roofPoints[roofPointIndex]["@id"] ==
                  facesArray[faceIndex]["@parentPartition"][0]
                    ?.partitionCoord &&
                roofPoints[roofPointIndex1]["@id"] ==
                  `C${facesArray[faceIndex]["@parentPartition"][0]?.partitionDoorCoord}`
              ) {
                roofPoints[roofPointIndex1]["@editedXY"] =
                  roofPoints[roofPointIndex]["@editedXY"];
                roofPoints[roofPointIndex1]["@autoSnappedXY"] =
                  roofPoints[roofPointIndex]["@editedXY"];
              }
              if (
                roofPoints[roofPointIndex]["@id"] ==
                  facesArray[faceIndex]["@parentPartition"][1]
                    ?.partitionCoord &&
                roofPoints[roofPointIndex1]["@id"] ==
                  `C${facesArray[faceIndex]["@parentPartition"][1]?.partitionDoorCoord}`
              ) {
                roofPoints[roofPointIndex1]["@editedXY"] =
                  roofPoints[roofPointIndex]["@editedXY"];
                roofPoints[roofPointIndex1]["@autoSnappedXY"] =
                  roofPoints[roofPointIndex]["@editedXY"];
              }
            }
          }
        }
      }
    } else {
      continue;
    }
  }
  copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
  return copyOriginal;
};

export const dragPartitionWindow = (
  originalFloorPlan,
  selectedpartition,
  windowId,
  newWindowStartXY,
  newWindowEndXY,
  ratio,
  minX,
  minY
) => {
  let copyOriginal = _.cloneDeep(originalFloorPlan);
  let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
  let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
  let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
  for (let faceIndex = 0; faceIndex < facesArray.length; faceIndex++) {
    if (
      facesArray[faceIndex]["@type"] == "PARTITION_WINDOW" &&
      facesArray[faceIndex]["@id"] === windowId &&
      facesArray[faceIndex]["@parentPartition"] === selectedpartition
    ) {
      for (
        let rooflineIndex = 0;
        rooflineIndex < rooflines.length;
        rooflineIndex++
      ) {
        let pointPathSplit = rooflines[rooflineIndex]["@path"].split(",");
        if (
          pointPathSplit.length === 2 &&
          facesArray[faceIndex].POLYGON["@path"] ==
            rooflines[rooflineIndex]["@id"]
        ) {
          for (
            let roofPointIndex = 0;
            roofPointIndex < roofPoints.length;
            roofPointIndex++
          ) {
            if (pointPathSplit[0] === roofPoints[roofPointIndex]["@id"]) {
              let datax = newWindowStartXY.x / ratio + minX;
              let datay = newWindowStartXY.y / ratio + minY;
              roofPoints[roofPointIndex]["@editedXY"] = datax + "," + datay;
              roofPoints[roofPointIndex]["@autoSnappedXY"] =
                datax + "," + datay;
            } else if (
              pointPathSplit[1] === roofPoints[roofPointIndex]["@id"]
            ) {
              let datax = newWindowEndXY.x / ratio + minX;
              let datay = newWindowEndXY.y / ratio + minY;
              roofPoints[roofPointIndex]["@editedXY"] = datax + "," + datay;
              roofPoints[roofPointIndex]["@autoSnappedXY"] =
                datax + "," + datay;
            }
          }
        }
      }
    } else {
      continue;
    }
  }
  copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT = roofPoints;
  return copyOriginal;
};

export const createPartitionDoor = (
  thisCanvas,
  originalFloorPlan,
  doorShape = true
) => {
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let linesObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = linesObject[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let lines = faceArray.filter((el) => el["@type"] == "PARTITION_DOOR");
  for (let i = 0; i < lines.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@partitionDoor"] &&
        el["@partitionDoor"].split(",").includes(lines[i]["@id"])
    );
    if (
      parentroom[0] &&
      parentroom[0]["@floorindex"] == thisCanvas.state.selectedFloor
    ) {
      let linePath = linesArray.filter(
        (el) => el["@id"] == lines[i].POLYGON["@path"]
      );
      let pointpath = linePath[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray.filter(
          (el) => el["@id"] == pointpath[0]
        )[0];
        point1 = point1["@editedXY"].split(",");

        let point2 = roofPointsArray.filter(
          (el) => el["@id"] == pointpath[1]
        )[0];
        point2 = point2["@editedXY"].split(",");
        const fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - thisCanvas.minX) * thisCanvas.ratio,
            (parseFloat(point1[1]) - thisCanvas.minY) * thisCanvas.ratio,
            (parseFloat(point2[0]) - thisCanvas.minX) * thisCanvas.ratio,
            (parseFloat(point2[1]) - thisCanvas.minY) * thisCanvas.ratio,
          ],
          {
            id: lines[i]["@id"],
            roomID: parentroom[0]["@id"],
            objectCaching: false,
            type: "PARTITION_DOOR",
            stroke: PARTITION_DOOR_COLOR,
            originX: "center",
            originY: "center",
            strokeUniform: true,
            strokeWidth: partitionLineStokeWidth,
            padding: 4,
            parentRoomCordinates: null,
            partitionWallCordinates: [],
            lockScalingX: true,
            lockScalingY: true,
            lockRotation: false,
            hasControls: false,
            lockMovementX: false,
            lockMovementY: false,
            doorDirection: lines[i]["@doorDirection"]
              ? lines[i]["@doorDirection"]
              : doorDirectionEnum.inside,
          }
        );
        fabricLine.setCoords();
        if (!thisCanvas.state.isEditModeEnabled) {
          if (lines[i]["@mode"] == "PARTITION_DOOR") {
            thisCanvas.createDoorShapeObject(fabricLine, doorShape);
          }
        }
        thisCanvas.canvas.add(fabricLine);
      }
    }
  }
};

export const addPartitionDoorFromBuildMenu = (
  thisCanvas,
  originalFloorPlan,
  selectedRoom
) => {
  let copyOriginal = _.cloneDeep(originalFloorPlan);
  let facesArray = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE;
  let roofPoints = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT;
  let rooflines = copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE;
  const lineId = thisCanvas.getMaxId(facesArray, "PARTITION_DOOR") + 1;
  thisCanvas.addPartitionDoorVariables.line.id = "PARTITION_DOOR" + lineId;
  const cid = thisCanvas.getMaxId(roofPoints, "C") + 1;
  const lid = thisCanvas.getMaxId(rooflines, "L") + 1;
  let datax1 =
    thisCanvas.addPartitionDoorVariables.line.x1 / thisCanvas.ratio +
    thisCanvas.minX;
  let datay1 =
    thisCanvas.addPartitionDoorVariables.line.y1 / thisCanvas.ratio +
    thisCanvas.minY;
  let datax2 =
    thisCanvas.addPartitionDoorVariables.line.x2 / thisCanvas.ratio +
    thisCanvas.minX;
  let datay2 =
    thisCanvas.addPartitionDoorVariables.line.y2 / thisCanvas.ratio +
    thisCanvas.minY;

  // prepare points data
  let cdata1 = {
    "@id": "C" + cid,
    "@data": "0,0",
    "@dataXY": datax1 + "," + datay1,
    "@autoSnappedXY": datax1 + "," + datay1,
    "@editedXY": datax1 + "," + datay1,
  };
  roofPoints.push(_.cloneDeep(cdata1));
  let cdata2 = {
    "@id": "C" + (cid + 1),
    "@data": "0,0",
    "@dataXY": datax2 + "," + datay2,
    "@autoSnappedXY": datax2 + "," + datay2,
    "@editedXY": datax2 + "," + datay2,
  };
  roofPoints.push(_.cloneDeep(cdata2));
  // prepare face data
  let parentPartitionPoint = getParentPartitionPoint(
    roofPoints,
    rooflines,
    facesArray,
    `${datax1},${datay1}`,
    `${datax2},${datay2}`,
    cid + 2
  );
  let facedata = {
    "@floorindex": "",
    "@floor": "",
    "@areaname": "",
    "@measuretype": "",
    "@type": "PARTITION_DOOR",
    "@text": "",
    "@area": "",
    "@editedArea": "",
    "@designator": "",
    POLYGON: {
      "@orientation": "",
      "@pitch": "",
      "@unroundedsize": "",
      "@path": "L" + lid,
      "@editedUnroundedsize": "",
      "@size": "",
      "@editedSize": "",
      "@id": "",
    },
    "@children": "",
    "@id": "PARTITION_DOOR" + lineId,
    "@mode": "PARTITION_DOOR",
    "@parentPartition": parentPartitionPoint,
    "@doorDirection": thisCanvas.state.doorDirection,
  };
  facesArray.push(_.cloneDeep(facedata));
  // prepare line data
  let ldata = {
    "@angle": "",
    "@distance": "",
    "@id": "L" + lid,
    "@path": "C" + cid + ",C" + (cid + 1),
    "@type": "PARTITION_DOOR",
    linePointObjectArray: [cdata1, cdata2],
  };
  rooflines.push(_.cloneDeep(ldata));
  for (let i = 0; i < facesArray.length; i++) {
    if (facesArray[i]["@id"] == selectedRoom) {
      if (!facesArray[i]["@partitionDoor"]) {
        facesArray[i]["@partitionDoor"] = "";
      }
      let child = facesArray[i]["@partitionDoor"].split(",");
      if (facesArray[i]["@partitionDoor"].length == 0) {
        child = [];
      }
      child.push("PARTITION_DOOR" + lineId);
      facesArray[i]["@partitionDoor"] = child.join(",");
      break;
    }
  }
  copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.FACES.FACE =
    _.cloneDeep(facesArray);
  copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT =
    _.cloneDeep(roofPoints);
  copyOriginal.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES.LINE =
    _.cloneDeep(rooflines);
  originalFloorPlan = _.cloneDeep(copyOriginal);
  return originalFloorPlan;
};

export const addPartitionCircle = (thisCanvas) => {
  removePartitionCircle(thisCanvas);
  let obj = thisCanvas.canvas.getObjects().filter((el) => el?.type === "LINE");
  obj?.forEach((el) => {
    const circle1 = new fabric.Circle({
      radius: 3,
      fill: "black",
      left: el?.x1 - 3,
      top: el?.y1 - 3,
      hasControls: false,
      hasBorders: false,
      type: "partitionLine",
      name: "partitionLine",
      id: `${el?.id}_x1,y1`,
      customLineCoords: { x1: el?.x1, y1: el?.y1 },
      roomID: el?.roomID,
    });

    const circle2 = new fabric.Circle({
      radius: 3,
      fill: "black",
      left: el?.x2 - 3,
      top: el?.y2 - 3,
      hasControls: false,
      hasBorders: false,
      type: "partitionLine",
      name: "partitionLine",
      id: `${el?.id}_x2,y2`,
      customLineCoords: { x2: el?.x2, y2: el?.y2 },
      roomID: el?.roomID,
    });
    thisCanvas.canvas.add(circle1, circle2);
  });
  thisCanvas.canvas.discardActiveObject();
  thisCanvas.canvas.renderAll();
};

export const createPartitionWindow = (thisCanvas, originalFloorPlan) => {
  let roofObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF];
  let roofPoints = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS];
  let roofPointsArray = roofPoints[0]["POINT"];
  let linesObject = [originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.LINES];
  let linesArray = linesObject[0].LINE;
  let faceArray = roofObject[0]["FACES"]["FACE"];
  let lines = faceArray.filter((el) => el["@type"] == "PARTITION_WINDOW");
  for (let i = 0; i < lines.length; i++) {
    const parentroom = faceArray.filter(
      (el) =>
        el["@partitionWindow"] &&
        el["@partitionWindow"].split(",").includes(lines[i]["@id"])
    );
    if (
      parentroom[0] &&
      parentroom[0]["@floorindex"] == thisCanvas.state.selectedFloor
    ) {
      let linePath = linesArray.filter(
        (el) => el["@id"] == lines[i].POLYGON["@path"]
      );
      let pointpath = linePath[0]["@path"].split(",");
      if (pointpath.length === 2) {
        let point1 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[0])[0]
          ["@editedXY"].split(",");

        let point2 = roofPointsArray
          .filter((el) => el["@id"] == pointpath[1])[0]
          ["@editedXY"].split(",");
        const fabricLine = new fabric.Line(
          [
            (parseFloat(point1[0]) - thisCanvas.minX) * thisCanvas.ratio,
            (parseFloat(point1[1]) - thisCanvas.minY) * thisCanvas.ratio,
            (parseFloat(point2[0]) - thisCanvas.minX) * thisCanvas.ratio,
            (parseFloat(point2[1]) - thisCanvas.minY) * thisCanvas.ratio,
          ],
          {
            id: lines[i]["@id"],
            roomID: parentroom[0]["@id"],
            objectCaching: false,
            type: "PARTITION_WINDOW",
            stroke: PARTITION_WINDOW_COLOR,
            originX: "center",
            originY: "center",
            strokeUniform: true,
            strokeWidth: partitionLineStokeWidth,
            padding: 4,
            parentPartitionId: lines[i]["@parentPartition"],
            lockScalingX: true,
            lockScalingY: true,
            lockRotation: false,
            hasControls: false,
            lockMovementX: false,
            lockMovementY: false,
          }
        );
        fabricLine.setCoords();
        thisCanvas.canvas.add(fabricLine);
      }
    }
  }
};

export const findConnectedDoorsWithPatition = (
  lineArray,
  partitionDoorArray
) => {
  let partitionDoors = partitionDoorArray.canvas
    .getObjects()
    .filter((el) => el.type === "PARTITION_DOOR");
  let partitionDoorId = [];
  partitionDoors.forEach((doorEl) => {
    if ([doorEl.x1, doorEl.y1]?.toString()?.trim() === lineArray[0]?.trim()) {
      partitionDoorId.push([lineArray[0], doorEl?.id, "x1,y1"]);
    } else if (
      [doorEl.x2, doorEl.y2]?.toString()?.trim() === lineArray[1]?.trim()
    ) {
      partitionDoorId.push([lineArray[1], doorEl?.id, "x2,y2"]);
    } else if (
      [doorEl.x1, doorEl.y1]?.toString()?.trim() === lineArray[1]?.trim()
    ) {
      partitionDoorId.push([lineArray[1], doorEl?.id, "x1,y1"]);
    } else if (
      [doorEl.x2, doorEl.y2]?.toString()?.trim() === lineArray[0]?.trim()
    ) {
      partitionDoorId.push([lineArray[0], doorEl?.id, "x2,y2"]);
    }
  });
  return partitionDoorId;
};

export const calculateWallThicknessForRoom = (
  roomData,
  faceArray,
  wallThickness
) => {
  let walls = roomData["@children"].split(",");
  const wallData = faceArray.filter(
    (el) => walls.includes(el["@id"]) && el["@type"] == "WALL"
  );
  const perimeter = wallThickness / 12;
  let totalWallsThickness = 0;
  for (let wallIndex = 0; wallIndex < wallData.length; wallIndex++) {
    const wallObject = wallData[wallIndex];
    const wallLenght = wallObject["POLYGON"]["@editedUnroundedsize"];
    let tempFoot = parseInt(wallLenght.split(".")[0]);
    let inch = parseInt(wallLenght.split(".")[1]);
    inch = inch + tempFoot * 12;
    totalWallsThickness += inch * perimeter;
  }
  let inch = totalWallsThickness % 12;
  totalWallsThickness = parseInt(totalWallsThickness / 12);
  let tempFoot = parseInt(totalWallsThickness);
  return parseFloat(tempFoot + "." + inch);
};

export const updateOldJSON = (floorPlanJson) => {
  let originalFloorPlan = _.cloneDeep(floorPlanJson);
  const originalFloorPlanNew = _.cloneDeep(
    originalFloorPlan?.EAGLEVIEW_EXPORT?.STRUCTURES?.ROOF?.POINTS?.POINT
  );
  originalFloorPlanNew?.forEach((el, floorPlannewIndex) => {
    if (
      _.isEmpty(
        originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT[
          floorPlannewIndex
        ]["@editedXY"]
      )
    ) {
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT[
        floorPlannewIndex
      ]["@editedXY"] = el["@dataXY"];
      originalFloorPlan.EAGLEVIEW_EXPORT.STRUCTURES.ROOF.POINTS.POINT[
        floorPlannewIndex
      ]["@autoSnappedXY"] = el["@dataXY"];
    }
  });
  return originalFloorPlan;
};
