import * as actionTypes from "../actions/actionTypes";

const configurationDetailState = {
  configurationDetail: {},
  configurationDetailLoading: false,
  configurationDetailError: null,
};

const defaultState = {
  ...configurationDetailState,
};

export default (state = defaultState, action = {}) => {
  switch (action.type) {
    case actionTypes.GET_CONFIGURATION_DETAIL_START:
      return {
        ...state,
        configurationDetailLoading: true,
        configurationDetail: {},
        configurationDetailError: null,
      };
    case actionTypes.GET_CONFIGURATION_DETAIL_SUCCESS:
      return {
        ...state,
        configurationDetailLoading: false,
        configurationDetail: action.payload,
        configurationDetailError: null,
      };
    case actionTypes.GET_CONFIGURATION_DETAIL_ERROR:
      return {
        ...state,
        configurationDetailLoading: false,
        configurationDetailError: action.payload,
      };
    default:
      return state;
  }
};
