import * as actionTypes from "../actions/actionTypes";

const completeJobOrder = {
  completeJobOrderStart: false,
  completeJobOrderSuccess: null,
  completeJobOrderError: null,
};

const setPrimaryPictureForReportsPDF = {
  setPrimaryPictureForReportsPdfStart: false,
  setPrimaryPictureForReportsPdfSuccess: null,
  setPrimaryPictureForReportsPdfError: null,
};

const defaultStates = {
  ...completeJobOrder,
  ...setPrimaryPictureForReportsPDF,
};

export default (state = defaultStates, action = {}) => {
  switch (action.type) {
    case actionTypes.COMPLETE_JOBORDER_START:
      return {
        ...state,
        completeJobOrderStart: true,
        completeJobOrderSuccess: null,
        completeJobOrderError: null,
      };
    case actionTypes.COMPLETE_JOBORDER_SUCCESS:
      return {
        ...state,
        completeJobOrderStart: false,
        completeJobOrderSuccess: action.payload,
        completeJobOrderError: null,
      };
    case actionTypes.COMPLETE_JOBORDER_ERROR:
      return {
        ...state,
        completeJobOrderStart: false,
        completeJobOrderSuccess: null,
        completeJobOrderError: action.payload,
      };
    case actionTypes.SET_PRIMARY_PICTURE_FOR_REPORTS_PDF_START:
      return {
        ...state,
        setPrimaryPictureForReportsPdfStart: true,
        setPrimaryPictureForReportsPdfSuccess: null,
        setPrimaryPictureForReportsPdfError: null,
      };
    case actionTypes.SET_PRIMARY_PICTURE_FOR_REPORTS_PDF_SUCCESS:
      return {
        ...state,
        setPrimaryPictureForReportsPdfStart: false,
        setPrimaryPictureForReportsPdfSuccess: action.payload,
        setPrimaryPictureForReportsPdfError: null,
      };
    case actionTypes.SET_PRIMARY_PICTURE_FOR_REPORTS_PDF_ERROR:
      return {
        ...state,
        setPrimaryPictureForReportsPdfStart: false,
        setPrimaryPictureForReportsPdfSuccess: null,
        setPrimaryPictureForReportsPdfError: action.payload,
      };
    default:
      return state;
  }
};
