import React, { useState, Suspense, useEffect } from "react";
import { Canvas, useThree, extend } from "@react-three/fiber";
import { OrbitControls, TransformControls, Bounds } from "@react-three/drei";
import CameraControls from "camera-controls";

import { connect, useSelector } from "react-redux";
import { customToast } from "../../../../helpers/customToast";
import { PLYLoader } from "three/examples/jsm/loaders/PLYLoader";
import { MTLLoader } from "three/examples/jsm/loaders/MTLLoader";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader";
import { fetchFloor, fetchZipFile } from "../../../../actions/floorAction";
import localStorage from "../../../../services/storage";
import * as THREE from "three";
import { StartLoading, StopLoading } from "../../../../actions/UIAction";
import _ from "lodash";
import "./Index.scss";
import {
  storageTypes,
  threeDFloorScan,
} from "../../../../constants/appConstant";
import sessionStorage from "../../../../services/sessionStorage";
import { FLOORPLANS_ICON } from "../../../JobOrders/JobOrderDetails/Common/commonText";
import NoDataView from "../../../JobOrders/JobOrderDetails/Common/noDataView";
import { UNEXPECTED_ERROR_MESSAGE } from "../../../../constants/commonMessages";
import JSZip from "jszip";
import { useParams, Link } from "react-router-dom";
import useWindowDimensions from "./windowHeightWidth";
import Button from "../../../common/Button";
import InstructionModal from "../../../FloorScanJob/View3DFloorPlan/InstructionModal";
import authenticationService from "../../../../services/authenticationService";
import { pinPoint } from "../../../FloorScanJob/View3DFloorPlan/UtilityThreejs";
import { floorScanType } from "../../../../constants/enums";

let oldOrbitPointerDownDistance = null;
let meshExist = [],
  meshLoaded = [],
  isloaded = false;
let state = null;
let meshName = "meshName";
CameraControls.install({ THREE });
extend({ CameraControls });

const ScenePLY = ({
  setLine,
  plyFilePath,
  setLoader,
  setLoadingPer,
  loadingPer,
  setContentAvailable,
  index,
  floorScanTypeVar,
  pinLocation,
}) => {
  state = useThree();
  let scene = state.scene;
  if (plyFilePath && !isloaded && !meshExist.includes(`${meshName + index}`)) {
    setLoader(true);
    meshExist.push(`${meshName + index}`);
    if (_.isEmpty(plyFilePath?.image)) {
      const loader = new PLYLoader();
      let token;
      if (sessionStorage.get("storageType") == storageTypes.sessionStorage) {
        token = sessionStorage.get("token");
      } else {
        token = localStorage.get("token");
      }
      const currentTenantSubDomain =
        authenticationService.getTenantDetails() &&
        _.get(
          JSON.parse(authenticationService.getTenantDetails()),
          ["tenantSubDomain"],
          ""
        );
      loader.setRequestHeader({
        authorization: `Bearer ${token}`,
        "X-Tenant": currentTenantSubDomain,
      });
      loader.load(
        plyFilePath,
        function (geometry) {
          const silverColor = "#CACACA";
          const ambientLight = new THREE.AmbientLight(silverColor, 0.4);
          const pointLight1 = new THREE.PointLight(silverColor, 5);
          const pointLight2 = new THREE.PointLight(silverColor, 1);
          const pointLight3 = new THREE.PointLight(silverColor, 0.2);
          const pointLight4 = new THREE.PointLight(silverColor, 0.2);
          pointLight1.position.set(0, 0, 0);
          pointLight2.position.set(0, 20, -50);
          pointLight3.position.set(0, 20, 50);
          pointLight4.position.set(0, -20, 50);
          scene.add(ambientLight);
          scene.add(pointLight1);
          scene.add(pointLight2);
          scene.add(pointLight3);
          scene.add(pointLight4);
          const material = new THREE.MeshStandardMaterial({
            side: THREE.FrontSide,
            depthWrite: true,
            depthTest: true,
            color: "#C0C0C0",
            defines: { STANDARD: "" },
          });
          geometry.computeVertexNormals();
          const mesh = new THREE.Mesh(geometry, material);
          mesh.name = `${meshName + index}`;
          scene.add(mesh);
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          isloaded = true;
          meshLoaded.push(`${meshName + index}`);
          if (meshLoaded.length === meshExist.length) {
            setLoader(false);
          }
          let pinCoords = pinLocation ? JSON.parse(pinLocation) : null;
          if (
            meshLoaded.length === 1 &&
            floorScanTypeVar == floorScanType[1].value &&
            pinCoords
          ) {
            pinPoint(scene, pinCoords?.data);
          }
        },
        (onProgress) => {
          setLoadingPer(
            Math.floor((onProgress.loaded / onProgress.total) * 100)
          );
        },
        (error) => {
          setContentAvailable(false);
        }
      );
    } else if (!_.isEmpty(plyFilePath?.image)) {
      new MTLLoader().load(
        plyFilePath.material,
        function (materials) {
          materials.preload();
          new OBJLoader()
            .setMaterials(materials)
            .load(plyFilePath.obj, function (object) {
              const texture = new THREE.TextureLoader().load(plyFilePath.image);
              const ambientLight = new THREE.AmbientLight("#FFFFFF");

              object.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                  child.material.map = texture;
                  child.name = `${meshName + index}`;
                }
              });
              object.name = `${meshName + index}`;
              const group = new THREE.Group();
              group.name = `${meshName} colouredObjGrp`;
              group.add(ambientLight);
              group.add(object);
              scene.add(group);
              meshLoaded.push(`${meshName + index}`);
              setTimeout(() => {
                isloaded = true;
                setLoader(false);
              }, 1000);
            });
        },
        (onProgress) => {
          setLoadingPer(
            Math.floor((onProgress.loaded / onProgress.total) * 100)
          );
        },
        (error) => {
          setContentAvailable(false);
        }
      );
    }
  }
  return (
    <primitive
      object={scene}
      onPointerDown={(e) => {
        oldOrbitPointerDownDistance =
          e.clientX && e.clientY ? (e.clientX, e.clientY).toString() : null;
      }}
      onPointerUp={(e) => setLine(e)}
    />
  );
};

function ViewFloorPlan(props) {
  const [plyFilePath, setPlyFilePath] = useState([]);
  const [loader, setLoader] = useState(false);
  const [loadingPer, setLoadingPer] = useState(0);
  const [contentAvailable, setContentAvailable] = useState(true);
  const downloadFilePercentage = useSelector(
    (state) => state.downloadFilePercentageReducer.downloadFilePercentage
  );
  const [nameOfMesh, setNameOfMesh] = useState(null);
  const { scanId } = useParams();
  const { height } = useWindowDimensions();
  const [floorScanDetails, setFloorScanDetails] = useState({});
  const [explorePlanInstruction, setExplorePlanInstruction] = useState(false);
  const [pinLocation, setPinLocation] = useState(null);
  const [floorScanTypeDetail, setFloorScanTypeDetail] = useState(null);

  useEffect(() => {
    setLoader(loader);
  }, [loader]);

  useEffect(() => {
    meshLoaded = [];
    meshExist = [];
    isloaded = false;
    if (plyFilePath?.length === 0) {
      state?.scene?.clear();
      props
        .fetchFloor({ floorScanId: scanId })
        .then((data) => {
          setPinLocation(data?.data?.pinLocation);
          setFloorScanTypeDetail(data?.data?.floorScanType);
          setFloorScanDetails({
            floorScanNumber: data?.data?.floorScanNumber,
            jobOrderId: data?.data?.jobOrderId,
            orderNumber: data?.data?.orderNumber,
            floorScanId: data?.data?.floorScanId,
          });
          let payloadForZip = {
            floorScanId: data?.data?.floorScanId,
            fileName: data?.data?.plyViewPath?.substring(
              data?.data?.plyViewPath?.lastIndexOf("/") + 1
            ),
          };
          let isZip = payloadForZip?.fileName?.split(".").pop();
          if (isZip === "zip") {
            setLoader(true);
            props
              .fetchZipFile(payloadForZip)
              .then(function (response) {
                setLoader(false);
                if (response.status === 200 || response.status === 0) {
                  return Promise.resolve(response.data);
                } else {
                  return Promise.reject(new Error(response.statusText));
                }
              })
              .then(JSZip.loadAsync)
              .then(function (zip) {
                let extractedFiles = Object.values(zip.files);
                if (extractedFiles.length > 0) {
                  let plysPath = [];
                  let materialObj = null;
                  extractedFiles?.map((element, index) => {
                    element
                      .async("blob")
                      .then((res) => {
                        let plyName = new File([res], element.name);

                        if (plyName?.name?.split(".")?.pop() == "mtl") {
                          materialObj = {
                            ...materialObj,
                            material: URL.createObjectURL(plyName),
                          };
                        } else if (plyName.name?.split(".")?.pop() == "obj") {
                          materialObj = {
                            ...materialObj,
                            obj: URL.createObjectURL(plyName),
                          };
                        } else if (plyName.name?.split(".")?.pop() == "jpg") {
                          materialObj = {
                            ...materialObj,
                            image: URL.createObjectURL(plyName),
                          };
                        } else if (
                          !_.isNil(element.name?.split(".")?.[0]) &&
                          !materialObj
                        ) {
                          plysPath[parseInt(element.name.split(".")[0])] =
                            URL.createObjectURL(plyName);
                        }
                        if (
                          extractedFiles?.length === plysPath?.length &&
                          !materialObj &&
                          !plysPath.includes(undefined)
                        ) {
                          setPlyFilePath(plysPath);
                        } else if (
                          !_.isEmpty(materialObj?.image) &&
                          !_.isEmpty(materialObj?.material) &&
                          !_.isEmpty(materialObj?.obj)
                        ) {
                          setPlyFilePath([materialObj]);
                        }
                      })
                      .catch((err) => {
                        if (
                          err?.response &&
                          err?.response?.data &&
                          err?.response?.data?.message
                        ) {
                          const {
                            response: { data },
                          } = err;
                          customToast.error(data?.message);
                          throw err;
                        }
                        customToast.error(UNEXPECTED_ERROR_MESSAGE);
                        throw err;
                      });
                  });
                } else {
                  setContentAvailable(false);
                  setLoader(true);
                }
              })
              .catch((err) => {
                if (
                  err?.response &&
                  err?.response?.data &&
                  err?.response?.data?.message
                ) {
                  const {
                    response: { data },
                  } = err;
                  customToast.error(data?.message);
                  throw err;
                }
                customToast.error(UNEXPECTED_ERROR_MESSAGE);
                throw err;
              });
          } else {
            setPlyFilePath([data?.data?.plyViewPath]);
          }
        })
        .catch((err) => {
          if (
            err?.response &&
            err?.response?.data &&
            err?.response?.data?.message
          ) {
            const {
              response: { data },
            } = err;
            customToast.error(data?.message);
            throw err;
          }
          customToast.error(UNEXPECTED_ERROR_MESSAGE);
          throw err;
        });
    }
  }, []);

  const setLine = (e) => {
    e.stopPropagation();
    if (
      oldOrbitPointerDownDistance === (e.clientX, e.clientY).toString() &&
      plyFilePath.length > 1 &&
      e?.object?.name?.substring(0, 8) === meshName
    ) {
      setNameOfMesh(e?.object?.name);
    } else if (plyFilePath.length > 1) {
      setNameOfMesh(null);
    }
  };

  const downloadPercentage = (text) => {
    return (
      <div class="no-data-found">
        <div class="box">
          <div class="loader-spin"></div>
          <p className="blue-text">{text}</p>
        </div>
      </div>
    );
  };

  return (
    <>
      <section className="content-wapper ">
        <div className="breadcrumb nav-right-button">
          <ul>
            <li>
              <Link to="/">
                <button>Job Orders</button>
              </Link>
            </li>
            {floorScanDetails?.jobOrderId && (
              <li>
                <Link to={`/joborder/${floorScanDetails?.jobOrderId}`}>
                  <button>{floorScanDetails?.orderNumber}</button>
                </Link>
              </li>
            )}
            {floorScanDetails?.floorScanNumber && (
              <li>{floorScanDetails?.floorScanNumber}</li>
            )}
          </ul>
          <div className="right-side">
            <Button
              onClick={() => setExplorePlanInstruction(true)}
              className="info-btn"
            >
              <span>
                <i className="icon-information mr-0"></i>
              </span>
            </Button>
          </div>
        </div>
        <section>
          <div className="common-panel measurement-segment">
            <div className="panel-body job-details-wapper">
              <div
                style={{
                  position: "relative",
                  overflow: "hidden",
                  width: "100%",
                  height: height - 151,
                }}
              >
                {loader && !contentAvailable && (
                  <div class="no-data-found">
                    <div className="box">
                      <i className={FLOORPLANS_ICON}></i>
                      <p>{"Oops! PLY file failed to load. Please try again"}</p>
                    </div>
                  </div>
                )}
                {loader &&
                  loadingPer > 0 &&
                  downloadPercentage(
                    loadingPer < 100
                      ? loadingPer + "% Loaded..."
                      : "Preparing Sketch..."
                  )}
                {loader &&
                  downloadFilePercentage > 0 &&
                  downloadPercentage(
                    downloadFilePercentage < 100
                      ? downloadFilePercentage + "% Loaded..."
                      : "Preparing Sketch..."
                  )}
                {loader && loadingPer == 0 && contentAvailable && (
                  <div class="no-data-found">
                    <div class="box">
                      <p className="blue-text">{threeDFloorScan.Please_Wait}</p>
                    </div>
                  </div>
                )}

                {!plyFilePath && (
                  <NoDataView text={"3D Floor Plan"} icon={FLOORPLANS_ICON} />
                )}
                {plyFilePath?.length !== 0 && contentAvailable && (
                  <>
                    <Canvas
                      camera={{
                        position: [0, 0, 30],
                        zoom: 4,
                        up: [0, 0, 1],
                        far: 10000,
                      }}
                      style={{
                        display: loader && loadingPer >= 0 ? "none" : "block",
                        cursor: "move",
                      }}
                    >
                      <Suspense fallback={null}>
                        {plyFilePath?.map((element, index) => {
                          return (
                            <ScenePLY
                              key={element}
                              setLine={setLine}
                              plyFilePath={element}
                              setLoader={setLoader}
                              setLoadingPer={setLoadingPer}
                              loadingPer={loadingPer}
                              setContentAvailable={setContentAvailable}
                              index={index}
                              floorScanTypeVar={floorScanTypeDetail}
                              pinLocation={pinLocation}
                            />
                          );
                        })}
                      </Suspense>
                      {nameOfMesh && (
                        <TransformControls
                          object={state.scene.getObjectByName(nameOfMesh)}
                          mode={"translate"}
                          onChange={(e) => {
                            if (nameOfMesh == "meshName0") {
                              state.scene
                                .getObjectByName("pinPoint")
                                .position.set(
                                  state.scene.getObjectByName("pinPoint")
                                    .oldposition.x +
                                    state.scene.getObjectByName(nameOfMesh)
                                      .position.x,
                                  state.scene.getObjectByName("pinPoint")
                                    .oldposition.y +
                                    state.scene.getObjectByName(nameOfMesh)
                                      .position.y,
                                  state.scene.getObjectByName("pinPoint")
                                    .oldposition.z +
                                    state.scene.getObjectByName(nameOfMesh)
                                      .position.z
                                );
                            }
                          }}
                        />
                      )}
                      {plyFilePath?.length === meshExist?.length && (
                        <OrbitControls
                          enableDamping={true}
                          enableZoom={true}
                          enableRotate={true}
                          enablePan={true}
                          makeDefault
                          minPolarAngle={0}
                          maxPolarAngle={Math.PI}
                        />
                      )}
                    </Canvas>
                  </>
                )}
              </div>
            </div>
          </div>
          <InstructionModal
            explorePlanInstruction={explorePlanInstruction}
            setExplorePlanInstruction={setExplorePlanInstruction}
          />
        </section>
      </section>
    </>
  );
}
const mapStateToProps = (state) => {
  return {
    state: state,
  };
};
export default connect(mapStateToProps, {
  fetchFloor,
  fetchZipFile,
  StartLoading,
  StopLoading,
})(ViewFloorPlan);
