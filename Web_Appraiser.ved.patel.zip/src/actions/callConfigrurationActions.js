import * as actionTypes from "./actionTypes";
import configurationService from "../services/configurationService";
import { StartLoading, StopLoading } from "./UIAction";
export const loadConfigurationDetailStart = () => {
  return {
    type: actionTypes.GET_CONFIGURATION_DETAIL_START,
  };
};

export const loadConfigurationDetailSuccess = (payload) => {
  return {
    type: actionTypes.GET_CONFIGURATION_DETAIL_SUCCESS,
    payload,
  };
};

export const loadConfigurationDetailError = (error) => {
  return {
    type: actionTypes.GET_CONFIGURATION_DETAIL_ERROR,
    payload: error,
  };
};

export const LoadConfigurationDetail = (type) => async (dispatch) => {
  dispatch(StartLoading());
  dispatch(loadConfigurationDetailStart());
  return configurationService
    .get(type)
    .then((configurationDetail) => {
      dispatch(StopLoading());
      return dispatch(loadConfigurationDetailSuccess(configurationDetail));
    })
    .catch((error) => {
      dispatch(StopLoading());
      dispatch(loadConfigurationDetailError(error));
    });
};
