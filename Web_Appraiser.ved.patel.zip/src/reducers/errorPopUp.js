import * as actionTypes from "../actions/actionTypes";

const defaultState = {
  errorModalloading: false,
  errorPayload: null,
  reLogin: false,
};

export default (state = defaultState, action = {}) => {
  switch (action.type) {
    case actionTypes.ERROR_POPUP_START:
      return {
        ...state,
        errorPayload: action.payload,
        errorModalloading: true,
      };
    case actionTypes.ERROR_POPUP_STOP:
      return {
        ...state,
        errorPayload: null,
        errorModalloading: false,
      };
    case actionTypes.RELOGIN_START:
      return {
        ...state,
        reLogin: true,
      };
    case actionTypes.RELOGIN_STOP:
      return {
        ...state,
        reLogin: false,
      };
    default:
      return state;
  }
};
